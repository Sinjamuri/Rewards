package com.bayer.atlas.common.model;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author ATPINZ
 * @version $Revision$
 */
public class S3DownloadProperties {

    S3baseProperties baseProperties;
    String sourceFolder;

    public S3baseProperties getBaseProperties() {
        return baseProperties;
    }

    public void setBaseProperties(S3baseProperties baseProperties) {
        this.baseProperties = baseProperties;
    }

    public String getSourceFolder() {
        return sourceFolder;
    }

    public void setSourceFolder(String sourceFolder) {
        this.sourceFolder = sourceFolder;
    }

}