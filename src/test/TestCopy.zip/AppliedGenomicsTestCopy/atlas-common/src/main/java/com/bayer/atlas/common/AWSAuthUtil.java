package com.bayer.atlas.common;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.util.IOUtils;
import com.bayer.atlas.common.json.AccessTokenResponse;
import com.bayer.atlas.common.utils.ServiceCommon;
import com.bayer.atlas.common.utils.UtilCommon;
import com.bayer.atlas.common.utils.WfUtilCommon;
import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Connection;


/**
 * Created by ASHAR7 on 3/16/2017.
 */
public class AWSAuthUtil extends UtilCommon {

    private static final Logger LOG = LoggerFactory.getLogger(AWSAuthUtil.class);

    public static String getAccessToken(String baseUrl, String clientId, String secretKey, String grantType, String httpsProtocolsValue) {
        System.setProperty("https.protocols", httpsProtocolsValue);
        return getAccessToken(baseUrl, clientId, secretKey, grantType);
    }

    public static String getAccessToken(String baseUrl, String clientId, String secretKey, String grantType) {

        String accessToken = null;
        try {

            String queryParamsEncoded = "client_id=" + URLEncoder.encode(clientId, "UTF-8") +
                    "&client_secret=" + URLEncoder.encode(secretKey, "UTF-8") +
                    "&grant_type=" + URLEncoder.encode(grantType, "UTF-8");

            //LOG.info("Encoded Url:"+queryParamsEncoded);

            URL url;
            URLConnection urlConn;
            DataOutputStream printout;
            DataInputStream input;

            // URL of CGI-Bin script.
            url = new URL(baseUrl);
            // URL connection channel.
            urlConn = url.openConnection();
            // Let the run-time system (RTS) know that we want input.
            urlConn.setDoInput(true);
            // Let the RTS know that we want to do output.
            urlConn.setDoOutput(true);
            // No caching, we want the real thing.
            urlConn.setUseCaches(false);
            // Specify the content type.
            urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            // Send POST output.
            printout = new DataOutputStream(urlConn.getOutputStream());

            printout.writeBytes(queryParamsEncoded);
            printout.flush();
            printout.close();
            // Get response data.
            input = new DataInputStream(urlConn.getInputStream());
            String str;
            StringBuilder textArea = new StringBuilder();
            while (null != ((str = input.readLine()))) {
                textArea.append(str + "\n");
            }
            input.close();

            //LOG.info(textArea);

            AccessTokenResponse accessTokenResponse =
                    new Gson().fromJson(textArea.toString(), AccessTokenResponse.class);
            accessToken = accessTokenResponse.getToken_type() + " " + accessTokenResponse.getAccess_token();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();

        }
        return accessToken;
    }

    public static ClientResponse getResponse(String accessToken, String baseUrl) throws Exception {

        LOG.info("Accessing Service at:" + baseUrl + " with Token" + accessToken);
        WebResource webResource = getWebResource(baseUrl);
        ClientResponse serviceResponse = getServiceResponse(webResource, accessToken);
        LOG.info("Accessing Response:" + serviceResponse + " with Token:" + accessToken + " for URL:" + baseUrl);
        return serviceResponse;
    }

    private static WebResource getWebResource(String baseUrl) {
        Client client = Client.create();
        return client.resource(baseUrl);
    }

    private static ClientResponse getServiceResponse(WebResource webResource, String accessToken) throws Exception {
        ClientResponse response = webResource.accept("application/json")
                .type("application/json").header("Authorization", accessToken).get(ClientResponse.class);

        return response;
    }

    public AWSCredentials getAWSCredentials() {

        //atlas_lambda
        Connection con = null;
        AWSCredentials credentials = null;
        try {
            con = AtlasAgent.getGBSConnection();
            con.setAutoCommit(false);
            String access_key = WfUtilCommon.getWfConfigProperyString(con, 1, "BIO_ACCESS_KEY");
            String secret_key = WfUtilCommon.getWfConfigProperyString(con, 1, "BIO_SECRET_KEY");
            credentials = new BasicAWSCredentials(access_key, secret_key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ServiceCommon.freeResource(con);
        }
        return credentials;
    }

    public AWSCredentials getAWSCredentialsCF() {

        Connection con = null;
        AWSCredentials credentials = null;
        try {
            con = AtlasAgent.getGBSConnection();
            con.setAutoCommit(false);
            String access_key = WfUtilCommon.getWfConfigProperyString(con, 1, "CF_ACCESS_KEY");
            String secret_key = WfUtilCommon.getWfConfigProperyString(con, 1, "CF_SECRET_KEY");
   /*   String access_key = "AKIAI2VQ3KSQGW6LHCIQ";
      String secret_key = "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";*/
            credentials = new BasicAWSCredentials(access_key, secret_key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ServiceCommon.freeResource(con);
        }

        return credentials;
    }

    public AmazonS3 getS3Client(AWSCredentials credentials) {

        AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion("us-east-1")
                .build();

        return s3Client;
    }

    public void putObject(String bucketname, String keyName, byte[] content) {

        try {
            AmazonS3 s3Client = getS3Client(getAWSCredentialsCF());
            boolean doesObjectExist = s3Client.doesObjectExist(bucketname, keyName);
            if (!doesObjectExist) {
                // create meta-data for your folder and set content-length to 0
                ObjectMetadata metadata = new ObjectMetadata();
                metadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
                metadata.setContentLength(content.length);

                // create empty content
                InputStream contentStream = new ByteArrayInputStream(content);

                // create a PutObjectRequest passing the folder name suffixed by /
                PutObjectRequest putObjectRequest = new PutObjectRequest(bucketname,
                        keyName, contentStream, metadata);

                // send request to S3 to create folder
                PutObjectResult putObjectResult = s3Client.putObject(putObjectRequest);
            }
        } catch (AmazonServiceException ase) {
            LOG.error("Error Message:    " + ase.getMessage());
            LOG.error("HTTP Status Code: " + ase.getStatusCode());
            LOG.error("AWS Error Code:   " + ase.getErrorCode());
            LOG.error("Error Type:       " + ase.getErrorType());
            LOG.error("Request ID:       " + ase.getRequestId());
        } catch (AmazonClientException ace) {
            LOG.error("Error Message: " + ace.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error Message: " + e.getMessage());
        }
    }

    public void putObject(String bucketname, String keyName, String content) {

        try {
            AmazonS3 s3Client = getS3Client(getAWSCredentialsCF());
            boolean doesObjectExist = s3Client.doesObjectExist(bucketname, keyName);
            if (!doesObjectExist) {
                // create meta-data for your folder and set content-length to 0
               /* ObjectMetadata metadata = new ObjectMetadata();
                metadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
                metadata.setContentLength(content.length);

                // create empty content
                InputStream contentStream = new ByteArrayInputStream(content);

                // create a PutObjectRequest passing the folder name suffixed by /
                PutObjectRequest putObjectRequest = new PutObjectRequest(bucketname,
                        keyName, contentStream, metadata);*/

                // send request to S3 to create folder
                s3Client.putObject(bucketname, keyName, content);
            }
        } catch (AmazonServiceException ase) {
            LOG.error("Error Message:    " + ase.getMessage());
            LOG.error("HTTP Status Code: " + ase.getStatusCode());
            LOG.error("AWS Error Code:   " + ase.getErrorCode());
            LOG.error("Error Type:       " + ase.getErrorType());
            LOG.error("Request ID:       " + ase.getRequestId());
        } catch (AmazonClientException ace) {
            LOG.error("Error Message: " + ace.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error Message: " + e.getMessage());
        }
    }


    public byte[] getObject(String bucketName, String keyName) {
        byte[] message = null;
        try {
            AmazonS3 s3Client = getS3Client(getAWSCredentialsCF());
            S3Object s3object = s3Client.getObject(new GetObjectRequest(
                    bucketName, keyName));
            if (s3object != null && s3object.getObjectContent() != null) {
                InputStream objectData = s3object.getObjectContent();
                message = IOUtils.toByteArray(objectData);
            }
        } catch (AmazonClientException ace) {
            LOG.error("Error Message: " + ace.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error Message: " + e.getMessage());
        }
        return message;
    }

    public byte[] deleTeObject(String bucketName, String keyName) {
        byte[] message = null;
        try {
            AmazonS3 s3Client = getS3Client(getAWSCredentialsCF());
            s3Client.deleteObject(bucketName, keyName);
        } catch (AmazonClientException ace) {
            LOG.error("Error Message: " + ace.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error Message: " + e.getMessage());
        }
        return message;
    }

    public void putObjectToSas(String bucketname, String keyName, byte[] content) {

        try {
            AmazonS3 s3Client = getS3Client(getAWSCredentialsSas());

            boolean doesObjectExist = s3Client.doesObjectExist(bucketname, keyName);
            if (!doesObjectExist) {
                // create meta-data for your folder and set content-length to 0
                ObjectMetadata metadata = new ObjectMetadata();
                metadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
                metadata.setContentLength(content.length);

                // create empty content
                InputStream contentStream = new ByteArrayInputStream(content);

                // create a PutObjectRequest passing the folder name suffixed by /
                PutObjectRequest putObjectRequest = new PutObjectRequest(bucketname,
                        keyName, contentStream, metadata);

                // send request to S3 to create folder
                PutObjectResult putObjectResult = s3Client.putObject(putObjectRequest);
            }

        } catch (AmazonServiceException ase) {
            LOG.error("Error Message:    " + ase.getMessage());
            LOG.error("HTTP Status Code: " + ase.getStatusCode());
            LOG.error("AWS Error Code:   " + ase.getErrorCode());
            LOG.error("Error Type:       " + ase.getErrorType());
            LOG.error("Request ID:       " + ase.getRequestId());
        } catch (AmazonClientException ace) {
            LOG.error("Error Message: " + ace.getMessage());
        } catch (Exception e) {
            LOG.error("Error Message: " + e.getMessage());
        }
    }

    public AWSCredentials getAWSCredentialsSas() {

        Connection con = null;
        AWSCredentials credentials = null;
        try {
            con = AtlasAgent.getGBSConnection();
            String access_key = WfUtilCommon.getWfConfigProperyString(con, 1, "SAS_ACCESS_KEY");
            String secret_key = WfUtilCommon.getWfConfigProperyString(con, 1, "SAS_SECRET_KEY");

            credentials = new BasicAWSCredentials(access_key, secret_key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ServiceCommon.freeResource(con);
        }

        return credentials;
    }

    public boolean uploadToS3Location(String bucketName, String uploadLoc, byte[] resultCsv, String reportName) {
        boolean isUploadedSuccefully = false;
        try {
            putObject(bucketName, uploadLoc + "/" + reportName, resultCsv);
            isUploadedSuccefully = true;
        } catch (Exception e) {
            LOG.error("Exception occurred while processing bucket " + bucketName + " From HapChipDataLoaderAgent at  " + String.valueOf(System.currentTimeMillis()), e);
        }
        return isUploadedSuccefully;
    }


    public void createFolderInS3(String bucketname, String folderName) {

        InputStream emptyContent = null;
        try {
            AmazonS3 s3Client = getS3Client(getAWSCredentialsCF());
/*
      List<Bucket> buckets = s3Client.listBuckets();
      for(Bucket bucket : buckets){
        LOG.info(bucket.getName());
      }*/
            //String folderName = "TorrentRuns/"+keyName+"/";
            boolean doesObjectExist = s3Client.doesObjectExist(bucketname, folderName);
            if (!doesObjectExist) {
                // create meta-data for your folder and set content-length to 0
                ObjectMetadata metadata = new ObjectMetadata();
                metadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
                metadata.setContentLength(0);

                // create empty content
                emptyContent = new ByteArrayInputStream(new byte[0]);

                // create a PutObjectRequest passing the folder name suffixed by /
                PutObjectRequest putObjectRequest = new PutObjectRequest(bucketname,
                        folderName, emptyContent, metadata);

                // send request to S3 to create folder
                s3Client.putObject(putObjectRequest);
            }
        } catch (AmazonServiceException ase) {
            LOG.error("Error Message:    " + ase.getMessage());
            LOG.error("HTTP Status Code: " + ase.getStatusCode());
            LOG.error("AWS Error Code:   " + ase.getErrorCode());
            LOG.error("Error Type:       " + ase.getErrorType());
            LOG.error("Request ID:       " + ase.getRequestId());
        } catch (AmazonClientException ace) {
            LOG.error("Error Message: " + ace.getMessage());
        } catch (Exception e) {
            LOG.error("Error Message: " + e.getMessage());
        } finally {

        }
    }
}
