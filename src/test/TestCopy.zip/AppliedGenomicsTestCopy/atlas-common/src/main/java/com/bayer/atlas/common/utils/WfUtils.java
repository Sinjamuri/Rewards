package com.bayer.atlas.common.utils;


import com.bayer.atlas.common.json.JsonResponse;
import com.bayer.atlas.common.model.RestPostServiceProperties;
import com.bayer.atlas.common.model.WfAssoc;
import com.bayer.atlas.common.model.WfBase;
import com.bayer.atlas.common.model.WfWellMap;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.commons.lang3.tuple.Pair;

import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

public class WfUtils extends AkanaUtils {


    public static WfBase createWf(long wfId, long wfConfigId, long wfEntityTypeId, String wfEntityLabel,
                                  long wfStepConfigId, String wfStatus, String createUser) {

        WfBase wf = new WfBase();
        wf.setWfId(wfId);
        wf.setWfConfigId(wfConfigId);
        wf.setWfEntityTypeId(wfEntityTypeId);
        wf.setWfEntityLabel(wfEntityLabel);
        wf.setWfStepConfigId(wfStepConfigId);
        wf.setWfStatus(wfStatus);
        wf.setCreateUser(createUser);

        return wf;
    }

    public static WfBase updateWf(long wfId, long wfConfigId, long wfEntityTypeId, String wfEntityLabel,
                                  long wfStepConfigId, String wfStatus, String updateUser) {

        WfBase wf = new WfBase();
        wf.setWfId(wfId);
        wf.setWfConfigId(wfConfigId);
        wf.setWfEntityTypeId(wfEntityTypeId);
        wf.setWfEntityLabel(wfEntityLabel);
        wf.setWfStepConfigId(wfStepConfigId);
        wf.setWfStatus(wfStatus);
        wf.setUpdateUser(updateUser);

        return wf;
    }

    public static void insertWf(WfBase wfBase) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String url = akanaBaseUrl + "/wf-details";

        String accessToken = ServiceCommon.getAccessToken(serviceCommon.ACCESS_TOKEN_BASE_URL, serviceCommon.CLIENT_ID, serviceCommon.CLIENT_SECRET,
                serviceCommon.GRANT_TYPE, serviceCommon.HTTPS_PROTOCOL_VALUE);
        RestPostServiceProperties restPostServiceProperties = new RestPostServiceProperties(wfBase, WfBase.class, JsonResponse.class, url, accessToken);
        ServiceCommon.getResponse(restPostServiceProperties);
    }



    public static void insertWf(long wfId, long wfConfigId, String wfStatus, long wfStepConfigId, String createUser,
                                long wfEntityTypeId, String wfEntityLabel) throws Exception {

        WfBase wfBase = createWf(wfId, wfConfigId, wfEntityTypeId, wfEntityLabel, wfStepConfigId, wfStatus, createUser);
        insertWf(wfBase);
    }

    /*public static void updateWf(WfBase wfBase) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String url = akanaBaseUrl + "/wf-details";

        String accessToken = ServiceCommon.getAccessToken(serviceCommon.ACCESS_TOKEN_BASE_URL, serviceCommon.CLIENT_ID,
                serviceCommon.CLIENT_SECRET,
                serviceCommon.GRANT_TYPE, serviceCommon.HTTPS_PROTOCOL_VALUE);
        RestPostServiceProperties restPostServiceProperties = new RestPostServiceProperties(wfBase, WfBase.class,
                JsonResponse.class, url, accessToken);
        ServiceCommon.getResponse(restPostServiceProperties, "PUT");
    }*/

    public static void updateWf(long wfId, String wfStatus) throws Exception {

        Optional<WfBase> wfByWfIdOptional = Optional.ofNullable(getWfByWfId(wfId));
        if (wfByWfIdOptional.isPresent()) {
            WfBase wfByWfId = wfByWfIdOptional.get();
            Optional<WfBase> wfBaseOptional = Optional.ofNullable(updateWf(wfId, wfByWfId.getWfConfigId(), wfByWfId.getWfEntityTypeId(), wfByWfId.getWfEntityLabel(), wfByWfId.getWfStepConfigId(), wfStatus, "ATLAS"));
            if (wfBaseOptional.isPresent()) {
                updateWf(wfBaseOptional.get());
            }
        }
    }

    public static void updateWfStepConfig(long wfId, long wfStepConfigId) throws Exception {

        Optional<WfBase> wfByWfIdOptional = Optional.ofNullable(getWfByWfId(wfId));
        if (wfByWfIdOptional.isPresent()) {
            WfBase wfByWfId = wfByWfIdOptional.get();
            WfBase wfBase = updateWf(wfId, wfByWfId.getWfConfigId(), wfByWfId.getWfEntityTypeId(), wfByWfId.getWfEntityLabel(), wfStepConfigId, wfByWfId.getWfStatus(), "ATLAS");
            updateWf(wfBase);
        }
    }

    public static void updateWfStepAndStatus(long wfId, long wfStepConfigId, String wfStatus) throws Exception {

        Optional<WfBase> wfByWfIdOptional = Optional.ofNullable(getWfByWfId(wfId));
        if (wfByWfIdOptional.isPresent()) {
            WfBase wfByWfId = wfByWfIdOptional.get();
            WfBase wfBase = updateWf(wfId, wfByWfId.getWfConfigId(), wfByWfId.getWfEntityTypeId(), wfByWfId.getWfEntityLabel(), wfStepConfigId, wfStatus, "ATLAS");
            updateWf(wfBase);
        }
    }

    public static List<WfBase> getWfByLabel(String wfEntityLabel) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String getWfIdUrl = akanaBaseUrl + "/wf?wfEntityLabel=";

        try {
            String url = getWfIdUrl + wfEntityLabel;
            String response = serviceCommon.getResponseAsString(url);

            if (null != response) {
                Type collectionType = new TypeToken<List<WfBase>>() {
                }.getType();

                List<WfBase> wfBaseResponse = new Gson().fromJson(response, collectionType);
                return wfBaseResponse;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<WfBase> getWfDetailsByLabel(String wfEntityLabel) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String getWfIdUrl = akanaBaseUrl + "/wf-details?wfEntityLabel=";

        try {
            String url = getWfIdUrl + wfEntityLabel;
            String response = serviceCommon.getResponseAsString(url);

            if (null != response) {
                Type collectionType = new TypeToken<List<WfBase>>() {
                }.getType();

                List<WfBase> wfBaseResponse = new Gson().fromJson(response, collectionType);
                return wfBaseResponse;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<WfWellMap> getWfPlateMap(String plateMapType) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String getWfIdUrl = akanaBaseUrl + "/plateMap?plateMapType=";

        try {
            String url = getWfIdUrl + plateMapType;
            String response = serviceCommon.getResponseAsString(url);

            if(null != response) {
                Type collectionType = new TypeToken<List<WfWellMap>>() {
                }.getType();

                List<WfWellMap> wfWellMapResponse = new Gson().fromJson(response, collectionType);
                return wfWellMapResponse;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public static List<WfBase> getWfByLabelAndType(String wfEntityLabel, long wfEntityTypeId) throws Exception {

        List<WfBase> wfIdByLabel = getWfByLabel(wfEntityLabel);
        if (wfIdByLabel != null && wfIdByLabel.size() > 0 && wfIdByLabel.get(0) != null) {
            Map<Long, List<WfBase>> wfIdBase = wfIdByLabel.stream().collect(Collectors.groupingBy(WfBase::getWfEntityTypeId));

            return wfIdBase.get(wfEntityTypeId);
        }
        return null;
    }

    public static List<WfBase> getWfByLabelTypeAndConfig(String wfEntityLabel, long wfConfigId, long wfEntityTypeId) throws Exception {

        List<WfBase> wfIdByLabel = getWfByLabel(wfEntityLabel);
        if (wfIdByLabel != null && wfIdByLabel.size() > 0 && wfIdByLabel.get(0) != null) {
            Map<Pair<Long, Long>, List<WfBase>> wfIdBase = wfIdByLabel.stream().collect(Collectors.groupingBy(
                    (p -> Pair.of(p.getWfConfigId(), p.getWfEntityTypeId()))));

            return wfIdBase.get(Pair.of(wfConfigId, wfEntityTypeId));

        }
        return null;
    }

    public static List<WfBase> getWfByLabelTypeAndStep(String wfEntityLabel, long wfEntityTypeId, long wfStepConfigId) throws Exception {

        List<WfBase> wfIdByLabel = getWfByLabel(wfEntityLabel);
        if (wfIdByLabel != null && wfIdByLabel.size() > 0 && wfIdByLabel.get(0) != null) {
            Map<Pair<Long, Long>, List<WfBase>> wfIdBase = wfIdByLabel.stream().collect(Collectors.groupingBy(
                    (p -> Pair.of(p.getWfStepConfigId(), p.getWfEntityTypeId()))));

            return wfIdBase.get(Pair.of(wfStepConfigId, wfEntityTypeId));
        }
        return null;
    }

    public static List<WfBase> getWfByLabelTypeStepAndConfig(String wfEntityLabel, long wfEntityTypeId, long wfStepConfigId, long wfConfigId) throws Exception {

        List<WfBase> wfIdByLabel = getWfByLabel(wfEntityLabel);
        if (wfIdByLabel != null && wfIdByLabel.size() > 0 && wfIdByLabel.get(0) != null) {
            List<WfBase> wfIdBase = wfIdByLabel.stream().
                    filter(wfBase -> wfBase.getWfEntityTypeId() == wfEntityTypeId && wfBase.getWfStepConfigId() == wfStepConfigId && wfBase.getWfConfigId() == wfConfigId).
                    collect(Collectors.toList());

            return wfIdBase;
        }
        return null;
    }

    public static List<WfBase> getWfDetailsByLabelTypeStepAndConfig(String wfEntityLabel, long wfEntityTypeId, long
            wfStepConfigId, long wfConfigId) throws Exception {

        List<WfBase> wfIdByLabel = getWfDetailsByLabel(wfEntityLabel);
        if (wfIdByLabel != null && wfIdByLabel.size() > 0 && wfIdByLabel.get(0) != null) {
            List<WfBase> wfIdBase = wfIdByLabel.stream().
                    filter(wfBase -> wfBase.getWfEntityTypeId() == wfEntityTypeId && wfBase.getWfStepConfigId() == wfStepConfigId && wfBase.getWfConfigId() == wfConfigId).
                    collect(Collectors.toList());

            return wfIdBase;
        }
        return null;
    }

    public static List<WfBase> getWfByLabelTypeStepAndStatus(String wfEntityLabel, long wfEntityTypeId, long wfStepConfigId, String status) throws Exception {

        List<WfBase> wfIdByLabel = getWfByLabel(wfEntityLabel);

        if (null == status) {
            status = "I";
        }

        if (wfIdByLabel != null && wfIdByLabel.size() > 0 && wfIdByLabel.get(0) != null) {
            String finalStatus = status;
            List<WfBase> wfIdBase = wfIdByLabel.stream().
                    filter(wfBase -> wfBase.getWfEntityTypeId() == wfEntityTypeId && wfBase.getWfStepConfigId() == wfStepConfigId && wfBase.getWfStatus().equalsIgnoreCase(finalStatus)).
                    collect(Collectors.toList());

            return wfIdBase;
        }
        return null;
    }

    public static WfBase getWfByWfId(long wfId) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String getWfIdUrl = akanaBaseUrl + "/wf/";

        try {
            String url = getWfIdUrl + wfId;
            String response = serviceCommon.getResponseAsString(url);

            if (null != response) {
                WfBase wfBaseResponse = new Gson().fromJson(response, WfBase.class);
                return wfBaseResponse;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static WfBase getWfDetailsByWfId(long wfId) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String getWfIdUrl = akanaBaseUrl + "/wf-details/";

        try {
            String url = getWfIdUrl + wfId;
            String response = serviceCommon.getResponseAsString(url);

            if (null != response) {
                WfBase wfBaseResponse = new Gson().fromJson(response, WfBase.class);
                return wfBaseResponse;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public static Boolean wfExists(String wfEntityLabel, long wfEntityTypeId) throws Exception {

        List<WfBase> wfIdByLabelAndType = getWfByLabelAndType(wfEntityLabel, wfEntityTypeId);
        if (null != wfIdByLabelAndType && wfIdByLabelAndType.size() > 0) {
            return true;
        }
        return false;
    }

    public static Boolean wfInProgress(long wfConfigId, long wfStepConfigId, long wfEntityTypeId, String wfEntityLabel) throws
            Exception {

        List<WfBase> wfIdByLabelAndTypeAtStepAndConfig = getWfByLabelTypeStepAndConfig(wfEntityLabel, wfEntityTypeId, wfStepConfigId, wfConfigId);
        if (null != wfIdByLabelAndTypeAtStepAndConfig && wfIdByLabelAndTypeAtStepAndConfig.size() > 0) {
            return true;
        }
        return false;
    }

    public static List<WfBase> getWfIdsLikebyEntitylabel(String wfEntityLabel, long wfEntityTypeId) throws Exception {

        return getWfByLabelAndType(wfEntityLabel, wfEntityTypeId);
    }

    public static List<WfBase> getWfIdsLikebyEntitylabelAndStatus(String wfEntityLabel, long wfEntityTypeId, String wfStatus) throws Exception {

        List<WfBase> wfBaseList = getWfIdsLikebyEntitylabel(wfEntityLabel, wfEntityTypeId);
        if (null != wfBaseList) {
            List<WfBase> wfBaseListByStatus = wfBaseList.stream().filter(wfBase -> wfBase.getWfStatus().equalsIgnoreCase(wfStatus)).collect(Collectors.toList());
            return wfBaseListByStatus;
        }
        return null;

    }

    public static List<WfBase> getWfIdsLikebyEntitylabelTypeConfig(long wfConfigId, long wfEntityTypeId, String wfEntityLabel) throws Exception {

        Optional<List<WfBase>> wfBaseListOptional = Optional.ofNullable(getWfIdsLikebyEntitylabel(wfEntityLabel, wfEntityTypeId));
        if (wfBaseListOptional.isPresent()) {
            List<WfBase> wfBaseList = wfBaseListOptional.get();
            return wfBaseList.stream().
                    filter(wfBase -> wfBase.getWfConfigId() == wfConfigId).
                    collect(Collectors.toList());
        }

        return null;
    }

    public static List<WfBase> getWfIdsLikebyEntitylabelTypeConfigAtStep(long wfConfigId, long wfStepConfigId, long wfEntityTypeId, String wfEntityLabel) throws Exception {

        Optional<List<WfBase>> wfBaseListOptional = Optional.ofNullable(getWfIdsLikebyEntitylabel(wfEntityLabel, wfEntityTypeId));
        if (wfBaseListOptional.isPresent()) {
            List<WfBase> wfBaseList = wfBaseListOptional.get();
            return wfBaseList.stream().
                    filter(wfBase -> wfBase.getWfConfigId() == wfConfigId && wfBase.getWfStepConfigId() == wfStepConfigId).
                    collect(Collectors.toList());
        }

        return null;
    }

    public static Timestamp getCreateTsForChip(String limsId) throws Exception {

        WfBase base = new WfBase();
        List<WfBase> wfBaseList = getWfIdsLikebyEntitylabel(limsId, 52);
        if (null != wfBaseList) {
            base = wfBaseList.stream().
                    filter(wfBase -> !wfBase.getWfStatus().equalsIgnoreCase("D") && wfBase.getWfEntityLabel().startsWith("D")).
                    min(Comparator.comparing(WfBase::getCreateTs)).get();

        } else {
            throw new AssertionError("Unable to locate create ts for D related to " + limsId);
        }
        return base.getCreateTs();
    }

    //TODO - get by wfconfig id and step
    public static List<String> wfInStep(long wfConfigId, long wfStepConfigId) throws
            Exception {
        final String SQL = "select wf_entity_label from ATLAS.wf where " +
                " wf_config_id=? " +
                " and wf_step_config_id=? " +
                " and wf_status='I' ";

        List<String> entityLabelList = new ArrayList<String>();

        return entityLabelList;
    }

    //TODO - get by wfconfig id and step
    public static List<String> wfInStep(Connection con, long wfConfigId, long wfStepConfigId) throws
            Exception {
        final String SQL = "select wf_entity_label from gbs.wf where " +
                " wf_config_id=? " +
                " and wf_step_config_id=? " +
                " and wf_status='I' ";

       /* PreparedStatement pstmt = null;
        ResultSet rs = null;*/
        List<String> entityLabelList = new ArrayList<String>();
       /* try {
            pstmt = con.prepareStatement(SQL);
            pstmt.setLong(1, wfConfigId);
            pstmt.setLong(2, wfStepConfigId);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                entityLabelList.add(rs.getString(1));
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }*/
        return entityLabelList;
    }


    //TODO - get by wfconfig id and step
    public static List<WfBase> getWfByConfigStep(long wfConfigId, long wfStepConfigId) throws
            Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String getWfUrl =akanaBaseUrl+ "/wf/"+wfConfigId+"/"+wfStepConfigId;

        try {
            String response = serviceCommon.getResponseAsString(getWfUrl);

            if(null != response) {
                Type collectionType = new TypeToken<List<WfBase>>() {
                }.getType();

                List<WfBase> wfBaseResponse = new Gson().fromJson(response, collectionType);
                return wfBaseResponse;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }


    //WF_ASSOC

    public static WfAssoc createWfAssoc(Long fromWfId, Long toWfId, String fromWfLabel, String toWfLabel, String matchKey, boolean active, Long entityTypeIdentifier,
                                        Long toEntityTypeIdentifier, Long wfDataNumber, Long sortKey, Timestamp createTs) {

        WfAssoc wfAssoc = new WfAssoc();
        wfAssoc.setFromWfId(fromWfId);
        wfAssoc.setToWfId(toWfId);
        wfAssoc.setFromWfLabel(fromWfLabel);
        wfAssoc.setToWfLabel(toWfLabel);
        wfAssoc.setMatchKey(matchKey);
        wfAssoc.setActive(active);
        wfAssoc.setEntityTypeIdentifier(entityTypeIdentifier);
        wfAssoc.setToEntityTypeIdentifier(toEntityTypeIdentifier);
        wfAssoc.setWfDataNumber(wfDataNumber);
        wfAssoc.setSortKey(sortKey);
        wfAssoc.setCreateTs(createTs);

        return wfAssoc;
    }

    public static void insertWfAssoc(WfAssoc wfAssoc) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String url = akanaBaseUrl + "/wf-assoc";

        String accessToken = ServiceCommon.getAccessToken(serviceCommon.ACCESS_TOKEN_BASE_URL, serviceCommon.CLIENT_ID,
                serviceCommon.CLIENT_SECRET,
                serviceCommon.GRANT_TYPE, serviceCommon.HTTPS_PROTOCOL_VALUE);
        RestPostServiceProperties restPostServiceProperties = new RestPostServiceProperties(wfAssoc, WfAssoc.class,
                JsonResponse.class, url, accessToken);
        ServiceCommon.getResponse(restPostServiceProperties);

    }

    public static void insertWfAssoc(long fromWfId, long toWfId, long sortKey, String matchKey) throws Exception {

        //check for existing assoc
        if (checkAssocExists(fromWfId, toWfId) != null) {
            throw new AssertionError("An association already exists for from_wf_id=" + fromWfId + ",to_wf_id=" + toWfId);
        }

        WfAssoc wfAssoc = createWfAssoc(fromWfId, toWfId, null, null, matchKey, true,
                null, null, null, sortKey, null);
        insertWfAssoc(wfAssoc);
    }

    public static void updateWfAssoc(WfAssoc wfAssoc) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String url = akanaBaseUrl + "/wf-assoc";

        String accessToken = ServiceCommon.getAccessToken(serviceCommon.ACCESS_TOKEN_BASE_URL, serviceCommon.CLIENT_ID,
                serviceCommon.CLIENT_SECRET,
                serviceCommon.GRANT_TYPE, serviceCommon.HTTPS_PROTOCOL_VALUE);
        RestPostServiceProperties restPostServiceProperties = new RestPostServiceProperties(wfAssoc, WfAssoc.class,
                JsonResponse.class, url, accessToken);
        ServiceCommon.getResponse(restPostServiceProperties, "PUT");

    }

    public static void updateWf(WfBase wfBase) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String url = akanaBaseUrl + "/wf";

        String accessToken = ServiceCommon.getAccessToken(serviceCommon.ACCESS_TOKEN_BASE_URL, serviceCommon.CLIENT_ID,
                serviceCommon.CLIENT_SECRET,
                serviceCommon.GRANT_TYPE, serviceCommon.HTTPS_PROTOCOL_VALUE);
        RestPostServiceProperties restPostServiceProperties = new RestPostServiceProperties(wfBase, WfBase.class,
                JsonResponse.class, url, accessToken);
        ServiceCommon.getResponse(restPostServiceProperties, "PUT");

    }

    public static void updateWfAssocList(List<WfAssoc> wfAssocList) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String url = akanaBaseUrl + "/wf-assoc-list";

        String accessToken = ServiceCommon.getAccessToken(serviceCommon.ACCESS_TOKEN_BASE_URL, serviceCommon.CLIENT_ID,
                serviceCommon.CLIENT_SECRET,
                serviceCommon.GRANT_TYPE, serviceCommon.HTTPS_PROTOCOL_VALUE);
        RestPostServiceProperties restPostServiceProperties = new RestPostServiceProperties(wfAssocList, List.class,
                JsonResponse.class, url, accessToken);
        ServiceCommon.getResponse(restPostServiceProperties, "PUT");

    }

    public static void updateWfAssoc(long fromWfId, long toWfId, boolean isActive) throws Exception {

        Optional<List<WfAssoc>> assocsByFromAndToOptional = Optional.ofNullable(getAssocsByFromAndTo(fromWfId, toWfId));
        if (assocsByFromAndToOptional.isPresent()) {
            List<WfAssoc> assocsByFromAndTo = assocsByFromAndToOptional.get();
            assocsByFromAndTo.stream().forEach(wfAssoc -> wfAssoc.setActive(isActive));
            updateWfAssocList(assocsByFromAndTo);
        }
    }

    public static void updateWfAssocMatchKey(long fromWfId, long toWfId, String matchKey) throws Exception {

        Optional<List<WfAssoc>> assocsByFromAndToOptional = Optional.ofNullable(getAssocsByFromAndTo(fromWfId, toWfId));
        if (assocsByFromAndToOptional.isPresent()) {
            List<WfAssoc> assocsByFromAndTo = assocsByFromAndToOptional.get();
            assocsByFromAndTo.stream().forEach(wfAssoc -> wfAssoc.setMatchKey(matchKey));
            updateWfAssocList(assocsByFromAndTo);
        }
    }

    public static void deleteWfAssoc(long fromWfId, long toWfId) throws Exception {

        updateWfAssoc(fromWfId, toWfId, false);
    }

    public static List<WfAssoc> getRightAssoc(long fromWfId) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String getWfIdUrl = akanaBaseUrl + "/wf-assoc/to/";

        try {
            String url = getWfIdUrl + fromWfId;
            String response = serviceCommon.getResponseAsString(url);

            if (null != response) {
                Type collectionType = new TypeToken<List<WfAssoc>>() {
                }.getType();

                List<WfAssoc> wfAssocResponse = new Gson().fromJson(response, collectionType);
                return wfAssocResponse;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<WfAssoc> getRightAssocActiveByType(long fromWfId, long toEntityTypeId) throws Exception {

        List<WfAssoc> rightAssocs = getRightAssoc(fromWfId);

        if (rightAssocs != null && rightAssocs.size() > 0) {
            Map<Pair<Boolean, Long>, List<WfAssoc>> wfAssocMap = rightAssocs.stream().collect(Collectors.groupingBy(
                    (p -> Pair.of(p.isActive(), p.getToEntityTypeIdentifier()))));

            return wfAssocMap.get(Pair.of(Boolean.TRUE, toEntityTypeId));
        }
        return null;
    }

    public static Long getRightActiveWfIdByTypeAndLabel(String wfEntityLabel, long wfEntityTypeId, long fromWfId) throws Exception {

        List<WfAssoc> rightAssocActiveByType = WfUtils.getRightAssocActiveByType(fromWfId, wfEntityTypeId);
        List<WfAssoc> wfAssocList = rightAssocActiveByType.stream().filter(wfAssoc -> wfAssoc.getToWfLabel().equalsIgnoreCase(wfEntityLabel)).collect(Collectors.toList());
        if (null != wfAssocList && wfAssocList.size() == 1) {
            return wfAssocList.get(0).getToWfId();
        } else {
            return null;
        }
    }

    public static List<WfAssoc> getLeftAssoc(long toWfId) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String getWfIdUrl = akanaBaseUrl + "/wf-assoc/from/";

        try {
            String url = getWfIdUrl + toWfId;
            String response = serviceCommon.getResponseAsString(url);

            if (null != response) {
                Type collectionType = new TypeToken<List<WfAssoc>>() {
                }.getType();

                List<WfAssoc> wfAssocResponse = new Gson().fromJson(response, collectionType);
                return wfAssocResponse;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<WfAssoc> getLeftAssocActiveByType(long toWfId, long toEntityTypeId) throws Exception {

        List<WfAssoc> rightAssocs = getLeftAssoc(toWfId);

        if (rightAssocs != null && rightAssocs.size() > 0) {
            Map<Pair<Boolean, Long>, List<WfAssoc>> wfAssocMap = rightAssocs.stream().collect(Collectors.groupingBy(
                    (p -> Pair.of(p.isActive(), p.getToEntityTypeIdentifier()))));

            return wfAssocMap.get(Pair.of(Boolean.TRUE, toEntityTypeId));
        }
        return null;
    }

    public static Long getLeftAssocWfIdAtStep(long toWfId, long stepConfigId) throws Exception {

        List<WfAssoc> rightAssocs = getLeftAssoc(toWfId);

        if (rightAssocs != null && rightAssocs.size() > 0) {
            List<WfAssoc> wfAssocs = rightAssocs.stream().filter(wfAssoc -> wfAssoc.isActive())
                    .collect(Collectors.toList());
            for (WfAssoc wfAssoc : wfAssocs) {
                if (WfUtils.getWfByWfId(wfAssoc.getFromWfId()).getWfStepConfigId().longValue() == stepConfigId) {
                    return wfAssoc.getFromWfId();
                }
            }
        }
        return null;
    }


    public static List<WfAssoc> getAssocsByFromAndTo(long fromWfId, long toWfId) throws Exception {

        List<WfAssoc> rightAssocs = getRightAssoc(fromWfId);

        if (rightAssocs != null && rightAssocs.size() > 0) {
            List<WfAssoc> wfAssocList = rightAssocs.stream().
                    filter(wfAssoc -> wfAssoc.getToWfId() == toWfId).
                    collect(Collectors.toList());

            return wfAssocList;
        }
        return null;
    }

    public static Boolean checkAssocExists(long fromWfId, long toWfId) throws Exception {

        List<WfAssoc> rightAssocs = getRightAssoc(fromWfId);

        if (rightAssocs != null && rightAssocs.size() > 0) {
            Map<Pair<Boolean, Long>, List<WfAssoc>> wfAssocMap = rightAssocs.stream().collect(Collectors.groupingBy(
                    (p -> Pair.of(p.isActive(), p.getToWfId()))));

            if (wfAssocMap.containsKey(Pair.of(Boolean.TRUE, toWfId))) {
                return true;
            }
        }
        return false;
    }
}
