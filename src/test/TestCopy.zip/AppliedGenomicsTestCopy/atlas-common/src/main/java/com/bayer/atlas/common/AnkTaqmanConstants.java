package com.bayer.atlas.common;


public class AnkTaqmanConstants {

    public static final String ANK_TAQMAN_WF_USER = "ANK-TAQMAN-AGENT";
    public static final String CONFIG_KEY_ANK_TAQMAN_DONT_SCHEDULE_LIST = "ANK_TAQMAN_DONT_SCHEDULE_LIST";
    public static final Long ANK_TAQMAN_WF_CONFIG_ID = 50L;
    public static final String ATLAS_USER_ID = "ATLAS";
    public static final String ANK_TAQMAN_API_USER = "API";


    public enum Steps { // wf_step_config.wf_step_config_id
        RECEIVING(5010L),
        CHIPPING(5015L),
        READY_FOR_DETECTION(5030L),
        SAMPLING(5000L),
        READY_FOR_EXTRACTION(5020L),
        EXTRACTION_IN_PROGRESS(5025L),
        READING(5060L),
        PCR_ASSEMBLY(5050L),
        CYCLING(5055L),
        MV_CREATION(5045L),
        SUGGEST_SCHEDULE(5035L),
        BATCH_SCHEDULE(5040L),
        IN_TRANSIT_TO_LAB(5005L),
        ANALYSIS_REVIEW(5065L),
        HOLDING_QUEUE(5070L),
        READY_FOR_DETECTION_PLATES(5075L),
        SUBMISSIONS(5080L);


        private final Long value;

        Steps(final Long newValue) {
            value = newValue;
        }

        public Long getValue() {
            return value;
        }

    }


    public enum Entities { // wf_entity_type.wf_entity_type_id
        D_PLATE(504L),
        PROJECT(501L),
        F_BLOCK(502L),
        P_PLATE(506L),
        E_PLATE(511L),
        MIX_VESSEL_BARCODE(507L),
        BATCH_ID(512L),
        LAB_SUBMISSION_ID(513L);

        private final Long value;

        Entities(final Long newValue) {
            value = newValue;
        }

        public Long getValue() {
            return value;
        }

    }

    public enum WfStatus { // wf_entity_type.wf_entity_type_id
        IN_PROGRESS("I"),
        READY("R"),
        YES("Y"),
        MERGE("M"),
        COMPLETE("C"),
        HOLD("H"),
        BRANCHED("B"),
        NCR("N");


        private final String value;

        WfStatus(final String newValue) {
            value = newValue;
        }

        public String getValue() {
            return value;
        }

    }

    public enum WfDataConfigs { // wf_entity_type.wf_entity_type_id
        F_BLOCK(5015L),
        CROP(5004l),
        PLATFORM(5022l),
        CYCLING(5050l),
        PROJECT(5001l),
        SAMPLE_TYPE(5009l),
        MV_PLATE(5017L),
        LOCATION(5019l),
        PRIORITY(5020l),
        BATCH_GROUP(5021L),
        RUN_ID(5027L),
        BATCH_STATUS(5059l),
        MV_WORKLIST_S3_PATH(10696l),
        PCR_WORKLIST_S3_PATH(10697l),
        ROUND(5052l),
        REDO(5051l),
        SYSTEM_DESIGNED_FOR(5053L),
        SYSTEM_RUNNING_ON(5056L),
        MV_UPSTACK_OR_DOWNSTACK(5054L),
        LOT_ID(5055L),
        FILE_NAME(5049L),
        PCR_PLATE(5058L),
        NO_OF_PCR(10694l),
        NO_OF_MV(10695l),
        EXTRACTED_WELL_TYPE(10698l),
        PCR_PLATE_COUNT(10694l),
        PROCESSED_BY_TOTAL(10629l),
        OWNER_GROUP(5039l),
        NO_OF_SAMPLES(5040l),
        REQUESTER(5041l),
        SUBMISSION_NAME(5042l),
        LAB_REQUEST_ID(5043l),
        CREATED_BY(5044l),
        RETURN_DATE(5045l),
        STATUS(5014l),
        PROJECT_STATUS_IN_DETECTION(5060l),
        GENERATION(5046l),
        COMMENTS(5006l),
        NO_OF_BLOCKS(5007l),
        CAPACITY_REQUEST_NUMBER(5036l),
        NO_OF_MARKERS(5034l),

        PROJECT_ID_DATA_CONFIG_ID(5001L),
        COMMENTS_DATA_CONFIG_ID(5006L),
        CROP_DATA_CONFIG_ID(5004L),
        SEND_DATE_DATA_CONFIG_ID(5033L),
        SUGGESTED_PLATFORM_DATA_CONFIG_ID(5022L),
        NUMBER_OF_MARKERS_DATA_CONFIG_ID(5034L),
        CREATE_DATE_DATA_CONFIG_ID(5035L),
        CAPACITY_REQUEST_NUMBER_DATA_CONFIG_ID(5036L),
        DESCRIPTION_DATA_CONFIG_ID(5037L),
        OWNER_GROUP_DATA_CONFIG_ID(5039L),
        NUMBER_OF_SAMPLES_DATA_CONFIG_ID(5040L),
        REQUESTER_DATA_CONFIG_ID(5041L),
        SUBMISSION_NAME_DATA_CONFIG_ID(5042L),
        LAB_REQUEST_ID_DATA_CONFIG_ID(5043L),
        STATUS_DATA_CONFIG_ID(5014L),
        CREATED_BY_DATA_CONFIG_ID(5044L),
        RETURN_DATE_DATA_CONFIG_ID(5045L),
        OWNER_DATA_CONFIG_ID(5038L),
        SAMPLE_TYPE_DATA_CONFIG_ID(5009L),
        GENERATION_DATA_CONFIG_ID(5046L),
        NUMBER_OF_BLOCKS_DATA_CONFIG_ID(5007L),
        SCREENING_PURPOSE_DATA_CONFIG_ID(5063L),
        D_PLATE(5016L),
        FILE_PROCESSED_DATA_CONFIG_ID(5049L),
        READER_NAME_DATA_CONFIG_ID(5048L),
        EXTRACTION_STATUS_CONFIG_ID(5031L),
        TISSUE_TYPE_DATA_CONFIG_ID(5085L),
        ENVIRONMENT_ID_DATA_CONFIG_ID(5086L),
        TAXON_ID_DATA_CONFIG_ID(5088L),

        MARKER(5067L),
        ASSAY(5068L),
        ALLELES(5069L),
        ALLELE_NAME(5070L),
        FORWARD(5072L),
        REVERSE(5073L),
        ALLELE_ID(5074L),
        SEQUENCE(5075L),
        PROBE(5078L),
        QUENCHER(5079L),
        DESCRIPTION(5071L),
        AMPLICON(5076L),
        MARKER_BARCODE_QUADRANT_1(5080L),
        MARKER_BARCODE_QUADRANT_2(5081L),
        MARKER_BARCODE_QUADRANT_3(5082L),
        MARKER_BARCODE_QUADRANT_4(5083L);

        private final Long value;

        WfDataConfigs(final Long newValue) {
            value = newValue;
        }

        public Long getValue() {
            return value;
        }

    }

    public enum WfGridDataConfigs { // wf_entity_type.wf_entity_type_id
        WELL(5001l),
        VIRGO_SN(5002l),
        PEDIGREE(5003l),
        MATERIAL_SAMPLE_ID(5004l),
        GENOTYPE(5005l),
        INVENTORY_BARCODE_NUMBER(5006l),
        GENERATION(5007l),
        ORIGIN(5008l),
        EVENT(5009l),
        CONSTRUCT(5010l),
        VERIFIED(5011l);


        private final Long value;

        WfGridDataConfigs(final Long newValue) {
            value = newValue;
        }

        public Long getValue() {
            return value;
        }

    }


    // Props

    public enum Urls { //

        MARKER_VALIDATION_URL("ANK_TAQMAN_MARKER_VALIDATION_URL"),
        REDO_MARKER_VALIDATION_URL("ANK_TAQMAN_REDO_MARKER_VALIDATION_URL"),
        ROLLBACK_PROJECT_URL("ANK_TAQMAN_ROLLBACK_PROJECT_URL"),
        ROLLBACK_PROJECT_URL_WITHOUT_INCRMENT("ANK_TAQMAN_ROLLBACK_PROJECT_URL_WITHOUT_INCRMENT"),
        RUBICON_GENOTYPIC_SERVICE_URL("ANK_TAQMAN_RUBICON_GENOTYPIC_SERVICE_URL"),
        MIX_VESSEL_URL("ANK_TAQMAN_MIX_VESSEL_URL"),
        PCR_ASSEMBLY_URL("ANK_TAQMAN_PCR_ASSEMBLY_URL"),
        SERVICE_TOKEN_URL("ANK_TAQMAN_SERVICE_TOKEN_URL"),
        LAB_PROCESS_GET_ALL_COMPLETE_URL("ANK_TAQMAN_LAB_PROCESS_GET_ALL_COMPLETE_URL"),
        LAB_PROCESS_IS_COMPLETE_URL("ANK_TAQMAN_LAB_PROCESS_IS_COMPLETE_URL"),
        MULTIPLEXING_SERVICE_URL("ANK_TAQMAN_MULTIPLEXING_SERVICE_URL"),
        MIXING_VESSEL_WORKLIST_API_URL("ANK_TAQMAN_MIXING_VESSEL_WORKLIST_API_URL");

        private final String value;

        Urls(final String newValue) {
            value = newValue;
        }

        public String getValue() {
            return value;
        }

    }

    public enum S3 {
        CONFIG_KEY_ANK_TAQMAN_PCR_ASSEMBLY_URL ("ANK_TAQMAN_PCR_ASSEMBLY_URL"),
        CONFIG_KEY_ANK_TAQMAN_WORKLIST_DIR ("ANK_TAQMAN_WORKLIST_DIR"),
        CONFIG_KEY_ANK_TAQMAN_PCR_ASSEMBLY_COMPLETION_FILE ("ANK_TAQMAN_PCR_ASSEMBLY_COMPLETION_FILE"),
        CONFIG_KEY_ANK_TAQMAN_VWORKS_MIX_VESSEL_WORKLIST_PATH_FORMAT("ANK_TAQMAN_VWORKS_MIX_VESSEL_WORKLIST_PATH_FORMAT"),
        CONFIG_KEY_ANK_TAQMAN_S3_PCR_BUCKET_NAME ("ANK_TAQMAN_S3_PCR_BUCKET_NAME"),
        CONFIG_KEY_ANK_TAQMAN_S3_REGION ("ANK_TAQMAN_S3_REGION"),
        ANK_TAQMAN_S3_BUCKET_NAME("ANK_TAQMAN_S3_BUCKET_NAME_CF"),
        ANK_TAQMAN_S3_LABSUBMISSIONAPI_RESPONSE_PATH("ANK_TAQMAN_S3_LABSUBMISSIONAPI_RESPONSE_PATH"),
        ORIGINAL_LAB_INSTRUMENT_INSTRUCTIONS_PATH("ANK_TAQMAN_S3_ORIGINAL_LAB_INSTRUMENT_INSTRUCTIONS_PATH"),
        TEMP_LAB_INSTRUMENT_INSTRUCTIONS_PATH("ANK_TAQMAN_S3_TEMP_LAB_INSTRUMENT_INSTRUCTIONS_PATH"),
        ANK_TAQMAN_S3_PROJECT_CREATION_JSON_PATH("ANK_TAQMAN_S3_PROJECT_CREATION_JSON_PATH");

        private final String value;

        S3(final String newValue) {
            value = newValue;
        }

        public String getValue() {
            return value;
        }

    }

    public enum StatusPcrPlate { //

        READING_PENDING("ANK_TAQMAN_P_PLATE_STATUS_READING_PENDING"),
        S3_RAW_DATA_UPLOAD_PENDING("ANK_TAQMAN_P_PLATE_STATUS_S3_RAW_DATA_UPLOAD_PENDING"),
        S3_SCORING_RESULTS_DOWNLOAD_PENDING("ANK_TAQMAN_P_PLATE_STATUS_S3_SCORING_RESULTS_DOWNLOAD_PENDING"),
        S3_SCORING_RESULTS_ARCHIVE_PENDING("ANK_TAQMAN_P_PLATE_STATUS_S3_SCORING_RESULTS_ARCHIVE_PENDING"),
        CONSOLIDATION_PENDING("ANK_TAQMAN_P_PLATE_STATUS_CONSOLIDATION_PENDING"),
        UPLOAD_PENDING("ANK_TAQMAN_P_PLATE_STATUS_UPLOAD_PENDING"),
        REDO_PENDING("ANK_TAQMAN_P_PLATE_STATUS_REDO_PENDING"),
        REDO_IN_PROGRESS("ANK_TAQMAN_P_PLATE_STATUS_REDO_IN_PROGRESS"),
        REDO_COMPLETE("ANK_TAQMAN_P_PLATE_STATUS_REDO_COMPLETE");

        private final String value;

        StatusPcrPlate(final String newValue) {
            value = newValue;
        }

        public String getValue() {
            return value;
        }

    }



    public enum StatusMvRun { //

        MIX_VESSEL_WORKLIST_PENDING_LAB("ANK_TAQMAN_MIX_VESSEL_WORKLIST_PENDING_LAB"),
        PCR_ASSEMBLY_WORKLIST_PENDING_ATLAS("ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_PENDING_ATLAS"),
        PCR_ASSEMBLY_WORKLIST_PENDING_LAB("ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_PENDING_LAB"),
        PCR_ASSEMBLY_WORKLIST_COMPLETE_LAB("ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_COMPLETE_LAB");

        private final String value;

        StatusMvRun(final String newValue) {
            value = newValue;
        }

        public String getValue() {
            return value;
        }

    }

    // Steps
    public static final long STEP_PCR_ASSEMBLY = 9008;
    public static final long STEP_PCR_ASSEMBLY_RUN_XML_FILE_HOME = 9017;
    public static final long STEP_P_PLATE_HOME = 9018;


    // Entities
    public static final long ENTITY_MIXING_VESSEL_RUN = 92;
    public static final long ENTITY_PROJECT = 95;
    public static final long ENTITY_P_PLATE = 100;
    public static final long ENTITY_ASSEMBLY_RUN_XML_FILE = 106;

    // 2nd:  Mix Vessel Completion agent has recognized WL files as being completed in lab
    public static final String CONFIG_KEY_ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_PENDING_ATLAS = "ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_PENDING_ATLAS";

    // 3rd:  PCR Assembly Agent has written files
    public static final String CONFIG_KEY_ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_PENDING_LAB = "ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_PENDING_LAB";

    // 4th:  PCR Assembly Completion agent as recognized files as being completed in lab
    public static final String CONFIG_KEY_ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_COMPLETE_LAB = "ANK_TAQMAN_PCR_ASSEMBLY_WORKLIST_COMPLETE_LAB";


    public static final String BIOCELL_EXTRACTION_PROTOCOL_BUL_IT = "Bul-IT";
    public static final String BIOCELL_EXTRACTION_PROTOCOL_384_96 = "384to96";

    //Wf Config
    public enum WfConfigs {
        GBS(1L),
        ANK_TAQMAN(50L);
        private final Long value;

        WfConfigs(final Long newValue) {
            value = newValue;
        }

        public Long getValue() {
            return value;
        }

    }

    //Wf Config Property Keys

    public enum WfConfigPropertyKeys {
        URL_ACCESS_TOKEN("URL_ACCESS_TOKEN"),
        GRANT_TYPE("GRANT_TYPE"),
        HTTPS_PROTOCOL_VALUE("HTTPS_PROTOCOL_VALUE"),
        CLIENT_ID_ATLAS("CLIENT_ID_ATLAS"),
        CLIENT_SECRET_ATLAS("CLIENT_SECRET_ATLAS"),
        CLIENT_ID_ANK_TAQMAN("CLIENT_ID_ANK_TAQMAN"),
        CLIENT_SECRET_ANK_TAQMAN("CLIENT_SECRET_ANK_TAQMAN"),
        CLIENT_SECRET_ANK_TAQMAN_API("CLIENT_SECRET_ANK_TAQMAN_API"),
        PING_NP_URL("PING_NP_URL"),
        MARKER_VALIDATION_CLIENT_ID("MARKER_VALIDATION_CLIENT_ID"),
        MARKER_VALIDATION_CLIENT_SECRET("MARKER_VALIDATION_CLIENT_SECRET"),
        MARKER_VALIDATION_URL("MARKER_VALIDATION_URL"),
        MARKER_VALIDATE_AND_RESERVE_URL("MARKER_VALIDATE_AND_RESERVE_URL"),
        MARKER_DECREMENT_URL("MARKER_DECREMENT_URL"),
        REACTION_VOLUME("ReactionVolume"),
        DEAD_VOLUME("DeadVolume"),
        OVERAGEASP("overageASP"),
        DNA_DISPENSE("DnaDispense"),
        DNA_DRYDOWN("DnaDryDown"),
        COCKTAIL_CONCENTRATION("CocktailConcentration"),
        DNA_VOLUME("DnaVolume"),
        Mongoose("Mongoose"),
        PLATFORM("Platform"),
        CYCLING("Cycling"),
        WORKFLOWTYPE("Workflow_Type"),
        MARKER_LIBRARY_ID("MarkerLibraryId"),
        EXTRACTED_WELL_TYPE("ExtractedWellType"),
        MIX_VESSEL_WORKLIST_PATH("ANK_TAQMAN_MIX_VESSEL_WORKLIST_PATH"),
        ANK_TAQMAN_S3_MIXING_VESSEL_WORKLISTS_DIR("ANK_TAQMAN_S3_MIXING_VESSEL_WORKLISTS_DIR"),
        CF_ACCESS_KEY("CF_ACCESS_KEY"),
        CF_SECRET_KEY("CF_SECRET_KEY"),
        CROP_TYPE_CODES("CropTypeCodes"),
        TISSUE_TYPE_CODES("TissueTypeCodes"),
        ENVIRONMENT_IDS("EnvironmentIds");

        private final String value;
        WfConfigPropertyKeys(final String newValue) {
            value = newValue;
        }
        public String getValue() {
            return value;
        }
    }


    public enum WfConfigPropertyRefKeys {
        UPPER_THRESHOLD(100208L),
        LOWER_THRESHOLD(100209L);
        private final Long value;

        WfConfigPropertyRefKeys(final Long newValue) {
            value = newValue;
        }

        public Long getValue() {
            return value;
        }
    }



}
