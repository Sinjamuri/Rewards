package com.bayer.atlas.common.json;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TaxonIdResponse {
    private Taxon taxon;

    public Taxon getTaxon() {
        return taxon;
    }

    public void setTaxon(Taxon taxon) {
        this.taxon = taxon;
    }

    private List<Taxon> taxa;

    public List<Taxon> getTaxa() {
        return taxa;
    }

    public void setTaxa(List<Taxon> taxa) {
        this.taxa = taxa;
    }

    public class Taxon {

        private String ncbiId;
        private String rank;
        private String scientificName;
        private String taxonId;

        private List<Synonym> synonyms;

        public Annotation annotations;

        public Metadata metadata;

        public String getNcbiId() {
            return ncbiId;
        }

        public void setNcbiId(String ncbiId) {
            this.ncbiId = ncbiId;
        }

        public String getRank() {
            return rank;
        }

        public void setRank(String rank) {
            this.rank = rank;
        }

        public String getScientificName() {
            return scientificName;
        }

        public void setScientificName(String scientificName) {
            this.scientificName = scientificName;
        }

        public String getTaxonId() {
            return taxonId;
        }

        public void setTaxonId(String taxonId) {
            this.taxonId = taxonId;
        }

        public List<Synonym> getSynonyms() {
            return synonyms;
        }

        public void setSynonyms(List<Synonym> synonyms) {
            this.synonyms = synonyms;
        }

        public Annotation getAnnotations() {
            return annotations;
        }


        public void setAnnotations(Annotation annotations) {
            this.annotations = annotations;
        }

        public Metadata getMetadata() {
            return metadata;
        }

 

        public void setMetadata(Metadata metadata) {
            this.metadata = metadata;
        }

        public class Synonym {
            private String name;
            private String type;
            private String source;

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getSource() {
                return source;
            }

            public void setSource(String source) {
                this.source = source;
            }
        }

        public class Annotation {

            @SerializedName("mabmart.crop")
            private String crop;

            public String getCrop() {
                return crop;
            }

            public void setCrop(String crop) {
                this.crop = crop;
            }
        }

        public class Metadata {
            private String modifiedOn;
            private String modifiedBy;
            private String modifiedByUser;

            public String getModifiedOn() {
                return modifiedOn;
            }

            public void setModifiedOn(String modifiedOn) {
                this.modifiedOn = modifiedOn;
            }

            public String getModifiedBy() {
                return modifiedBy;
            }

            public void setModifiedBy(String modifiedBy) {
                this.modifiedBy = modifiedBy;
            }

            public String getModifiedByUser() {
                return modifiedByUser;
            }

            public void setModifiedByUser(String modifiedByUser) {
                this.modifiedByUser = modifiedByUser;
            }
        }
    }

}
