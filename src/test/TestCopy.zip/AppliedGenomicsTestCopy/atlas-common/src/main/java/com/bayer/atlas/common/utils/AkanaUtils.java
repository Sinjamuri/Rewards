package com.bayer.atlas.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AkanaUtils {


    static String akanaBaseUrl = null;

    static {
        try {
            Properties properties = new Properties();
            InputStream props;
            try {
                props = WfUtilCommon.class.getClassLoader().getResourceAsStream("akana.properties");
                properties.load(props);
            } catch (IOException e) {
                System.out.println("IO error occurred while reading akana.properties file. ");
                e.printStackTrace();
            }
            akanaBaseUrl = properties.get("akanaBaseUrl").toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
