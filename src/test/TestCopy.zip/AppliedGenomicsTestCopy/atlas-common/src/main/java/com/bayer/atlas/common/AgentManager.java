package com.bayer.atlas.common;

import org.reflections.Reflections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Constructor;
import java.util.*;

public class AgentManager implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(AgentManager.class);

    private Set<String> agentsClassNames = null;

    public AgentManager() {
    }

    public AgentManager(String[] agentsClassNames) {
        this.agentsClassNames = new HashSet<String>();

        for (String agentClassName : agentsClassNames) {
            this.agentsClassNames.add(agentClassName);
        }
    }

    public static void main(String[] args) {
        new Thread(new AgentManager()).start();
    }

    @Override
    public void run() {
        //reflect and collect all subclasses of ManagedAgent
        Reflections reflections = new Reflections("com.bayer.atlas.agent");
        Set<Class<? extends ManagedAgent>> managedAgentSet = reflections.getSubTypesOf(ManagedAgent.class);
        Map<ManagedAgent, Class<? extends ManagedAgent>> managedAgents = new HashMap<ManagedAgent, Class<? extends ManagedAgent>>();

        //initialize agents
        for (Class<? extends ManagedAgent> managedAgent : managedAgentSet) {
            if (agentsClassNames == null || agentsClassNames.size() == 0) {
                managedAgents.put(startManagedAgent(managedAgent), managedAgent);
            } else if (agentsClassNames.contains(managedAgent.getSimpleName())) {
                managedAgents.put(startManagedAgent(managedAgent), managedAgent);
            }
        }

        //monitor agents
        while (true) {
            //sleep to avoid resource thrashing
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
            }

            //create a container map to avoid concurrent modification exceptions
            Map<ManagedAgent, Class<? extends ManagedAgent>> mergeIn = new HashMap<ManagedAgent, Class<? extends ManagedAgent>>();

            //iterate over agents and check to make sure the agent is running
            Iterator<ManagedAgent> iter = managedAgents.keySet().iterator();
            while (iter.hasNext()) {
                ManagedAgent managedAgent = iter.next();
                Class<? extends ManagedAgent> managedAgentClass = managedAgents.get(managedAgent);
                if (!(managedAgent.isAgentRunning())) {
                    //remove dead agent
                    managedAgent.freeConnection();
                    iter.remove();

                    //start new agent in place
                    mergeIn.put(startManagedAgent(managedAgentClass), managedAgentClass);
                }
            }

            //merge in restarted agents to map used for monitoring
            managedAgents.putAll(mergeIn);
        }
    }

    private ManagedAgent startManagedAgent(Class<? extends ManagedAgent> managedAgent) {
        try {
            Constructor agentConstructor = managedAgent.getConstructor(new Class[]{});
            ManagedAgent instance = (ManagedAgent) agentConstructor.newInstance(new Object[]{});
            new Thread(instance).start();
            //instance.updateStatus("Running");
            return instance;
        } catch (Throwable t) {
            LOG.error("Unexpected exception", t);
            return null;
        }
    }
}
