package com.bayer.atlas.common.json;

import java.util.ArrayList;
import java.util.List;

public class JsonResponse {
    private List<String> errors = new ArrayList<String>();
    private List<String> messages = new ArrayList<String>();
    private String exception;
    private List<Object> data = new ArrayList<Object>();
    private int recordsSynced;

    public List<Object> getData() {
        return data;
    }

    public void addData(Object data) {
        this.data.add(data);
    }


    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }

    public List<String> getMessages() {
        return messages;
    }

    public void addError(String error) {
        errors.add(error);
    }

    public void addMessage(String message) {
        messages.add(message);
    }

    public int getErrorCnt() {
        return errors.size();
    }

    public int getMessageCnt() {
        return errors.size();
    }

    public String getException() {
        return exception;
    }

    public void setException(String exception) {
        this.exception = exception;
    }

    public boolean isValid() {
        return (this.exception == null && this.errors.size() == 0);
    }

    public void setAccessDenied() {
        errors.add("You are not allowed to perform this action!  Please contact an Atlas Administrator.");
    }

    public int getRecordsSynced() {
        return recordsSynced;
    }

    public void setRecordsSynced(int recordsSynced) {
        this.recordsSynced = recordsSynced;
    }
}
