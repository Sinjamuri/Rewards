package com.bayer.atlas.common.json;


import com.bayer.atlas.common.model.XRobotJob;
import com.bayer.atlas.common.model.XRobotTransferTsk;

import java.util.List;

/**
 * Created by syroth on 6/14/2017.
 */
public class XRobotJobWithTasksWrapper {

    private XRobotJob xRobotJob;

    private long robotJobId;

    private List<XRobotTransferTsk> xRobotTransferTskList;

    private boolean jobCompleted;

    public XRobotJob getxRobotJob() {
        return xRobotJob;
    }

    public void setxRobotJob(XRobotJob xRobotJob) {
        this.xRobotJob = xRobotJob;
    }

    public long getRobotJobId() {
        return robotJobId;
    }

    public void setRobotJobId(long robotJobId) {
        this.robotJobId = robotJobId;
    }

    public List<XRobotTransferTsk> getxRobotTransferTskList() {
        return xRobotTransferTskList;
    }

    public void setxRobotTransferTskList(List<XRobotTransferTsk> xRobotTransferTskList) {
        this.xRobotTransferTskList = xRobotTransferTskList;
    }

    public boolean isJobCompleted() {
        return jobCompleted;
    }

    public void setJobCompleted(boolean jobCompleted) {
        this.jobCompleted = jobCompleted;
    }

    @Override
    public String toString() {
        return String.format("Job Id: " + robotJobId);
    }
}
