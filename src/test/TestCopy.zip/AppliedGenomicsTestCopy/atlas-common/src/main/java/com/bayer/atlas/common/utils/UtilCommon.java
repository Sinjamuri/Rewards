/*
 Copyright:  Copyright � 2016 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.bayer.atlas.common.utils;

import au.com.bytecode.opencsv.CSVWriter;
import com.jcraft.jsch.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.*;
import java.math.BigDecimal;
import java.nio.channels.FileChannel;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;
import java.util.regex.Pattern;

import static java.lang.String.format;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author ATPINZ
 * @version $Revision$
 */
public class UtilCommon {
    public static final String MAIL_PROTOCOL = "aws";
    private static final Logger LOG = LoggerFactory.getLogger(UtilCommon.class);
    private static final String COPY_TORRENT_FILE_SCRIPT = "/copyTorrentFile.sh";

    /**
     * Converts a stack trace to String representation.
     *
     * @param t
     * @return
     */
    public static String getStackTrace(Throwable t) {
        final Writer sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        t.printStackTrace(pw);
        return sw.toString();
    }

    public static String readFileIntoString(String filePath) throws Exception {
        File file = new File(filePath);
        if (file.exists()) {
            FileInputStream fis = new FileInputStream(file);
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            fis.close();

            return new String(data, "UTF-8");
        } else {
            return null;
        }
    }

    public static String getScriptCommand(ProcessBuilder pb) {
        StringBuilder sb = new StringBuilder();

        for (String command : pb.command()) {
            sb.append(command).append(" ");
        }

        return sb.toString();
    }

    public static void copyFile(File sourceFile, File destFile) throws IOException {
        if (!destFile.exists()) {
            destFile.createNewFile();
        }

        FileChannel source = null;
        FileChannel destination = null;

        try {
            source = new FileInputStream(sourceFile).getChannel();
            destination = new FileOutputStream(destFile).getChannel();
            destination.transferFrom(source, 0, source.size());
        } finally {
            if (source != null) {
                source.close();
            }
            if (destination != null) {
                destination.close();
            }
        }
    }

    public static void freeResource(Session session) {
        try {
            session.disconnect();
        } catch (Exception ex) {
            //no exception handling needed
        }
    }

    public static void freeResource(CSVWriter csvWriter) {
        try {
            csvWriter.flush();
            csvWriter.close();
        } catch (Exception ex) {
            //no exception handling needed
        }
    }

    public static void freeResource(OutputStream os) {
        try {
            os.flush();
            os.close();
        } catch (Exception ex) {
            //no exception handling needed
        }
    }

    public static void freeResource(Writer writer) {
        if (writer != null) {
            try {
                writer.flush();
                writer.close();
            } catch (Exception ex) {
                //no error handling needed
            }
        }
    }

    public static void freeResource(FileInputStream fis) {
        try {
            fis.close();
        } catch (Exception ex) {
            //no exception handling needed
        }
    }

    public static void freeResource(BufferedReader br) {
        try {
            br.close();
        } catch (Exception ex) {
            //no exception handling needed
        }
    }

    public static String getJsonFilenameFromRunName(String runName) {
        return "serialized_" + runName.substring(0, runName.lastIndexOf("_")) + ".json";
    }

    public static String getValueForProperty(String filePath, String torrentRunName, long torrentAnalysisId, String property) throws Exception {

        // ATP: JSON from torrent is dynamic and we don't yet have an object structure to fully wrap it.
        // Until we get that all this is doing is plucking the associated value for the passed in property.
        // ex: "chefInstrumentName": "CHEF00413", \n

        String fullyQualifiedJsonFileName = filePath + torrentAnalysisId + "/" + UtilCommon.getJsonFilenameFromRunName(torrentRunName);
        File jsonFile = new File(fullyQualifiedJsonFileName);
        String returnVal = "JSON not found";

        if (jsonFile.exists()) {
            FileInputStream fis = null;
            fis = new FileInputStream(jsonFile);
            Scanner scanner = new Scanner(fis);
            while (scanner.hasNextLine()) {
                String[] lineVal = scanner.nextLine().trim().split(":");
                if (lineVal.length > 1) {
                    if (lineVal[0].equals("\"" + property + "\"")) {
                        String parts = lineVal[1].trim().split(",")[0];
                        String val[] = parts.split("\"");
                        if (val.length > 1) {
                            returnVal = val[1];
                            break;
                        }
                    }
                }
            }
        }

        return returnVal;

    }

    public static void deleteFile(File file) throws IOException {
        if (file.exists()) {
            file.delete();
        } else {
            LOG.warn("Attempt to delete file failed - does not exist:\n" + file.getName());
        }
    }

    public static final int getYear(int yearsFromNow) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, yearsFromNow);
        return cal.get(Calendar.YEAR) % 100;
    }

    /**
     * NOTE : Error Check/Exception handling should be done in the calling method
     * gets the String and returns the numeric position for it.
     *
     * @param s String
     * @return String
     */
    public static int getNumericPosition(String s) {

        int length = s.length();
        int position = s.charAt(length - 1) - 'A' + 1;
        position = position + (length - 1) * 26;

        // to get the literal value for each alphabet
        /*
        StringBuilder pos = new StringBuilder();
        for( int i = length-1; i > length-2; ++i) {
            int position = s.charAt(i) - 'a' + 1;
            pos.append(position);
        }*/

        return position;
    }

    /**
     * NOTE : Error Check/Exception handling should be done in the calling method
     * split the string between groups of alphabets and digits
     *
     * @param s String
     * @return String[]
     */
    public static String[] splitStringToPositionArray(String s) {

        Pattern pattern = Pattern.compile("\"[^A-Z0-9]+|(?<=[A-Z])(?=[0-9])|(?<=[0-9])(?=[A-Z])\"");
        String rowAndColumnArray[] = pattern.split(s.toUpperCase());

        return rowAndColumnArray;
    }

    public static int getWellPosition(String s) {

        String[] strings = splitStringToPositionArray(s);
        int numericPosition = getNumericPosition(strings[0]);

        return (Integer.valueOf(strings[1]) - 1) * 8 + (numericPosition);
    }

    public static int getNumberForLetter(String val) {
        return (int) val.charAt(0) - 64;
    }

    public static String getLetterForNumber(int val) {
        return String.valueOf((char) ((val) + 64));
    }


    public static Integer getBarcodeAdapter(Integer gridRow, Integer gridCol, Integer barcodeIndexPlate) {

        int wellPosition = gridRow + ((gridCol - 1) * 8);

        return ((barcodeIndexPlate - 1) * 96) + wellPosition;
    }

    public static String getWellAddress(int wellPosition) {
        if (wellPosition == 1) return "A01";
        else if (wellPosition == 2) return "B01";
        else if (wellPosition == 3) return "C01";
        else if (wellPosition == 4) return "D01";
        else if (wellPosition == 5) return "E01";
        else if (wellPosition == 6) return "F01";
        else if (wellPosition == 7) return "G01";
        else if (wellPosition == 8) return "H01";
        else if (wellPosition == 9) return "A02";
        else if (wellPosition == 10) return "B02";
        else if (wellPosition == 11) return "C02";
        else if (wellPosition == 12) return "D02";
        else if (wellPosition == 13) return "E02";
        else if (wellPosition == 14) return "F02";
        else if (wellPosition == 15) return "G02";
        else if (wellPosition == 16) return "H02";
        else if (wellPosition == 17) return "A03";
        else if (wellPosition == 18) return "B03";
        else if (wellPosition == 19) return "C03";
        else if (wellPosition == 20) return "D03";
        else if (wellPosition == 21) return "E03";
        else if (wellPosition == 22) return "F03";
        else if (wellPosition == 23) return "G03";
        else if (wellPosition == 24) return "H03";
        else if (wellPosition == 25) return "A04";
        else if (wellPosition == 26) return "B04";
        else if (wellPosition == 27) return "C04";
        else if (wellPosition == 28) return "D04";
        else if (wellPosition == 29) return "E04";
        else if (wellPosition == 30) return "F04";
        else if (wellPosition == 31) return "G04";
        else if (wellPosition == 32) return "H04";
        else if (wellPosition == 33) return "A05";
        else if (wellPosition == 34) return "B05";
        else if (wellPosition == 35) return "C05";
        else if (wellPosition == 36) return "D05";
        else if (wellPosition == 37) return "E05";
        else if (wellPosition == 38) return "F05";
        else if (wellPosition == 39) return "G05";
        else if (wellPosition == 40) return "H05";
        else if (wellPosition == 41) return "A06";
        else if (wellPosition == 42) return "B06";
        else if (wellPosition == 43) return "C06";
        else if (wellPosition == 44) return "D06";
        else if (wellPosition == 45) return "E06";
        else if (wellPosition == 46) return "F06";
        else if (wellPosition == 47) return "G06";
        else if (wellPosition == 48) return "H06";
        else if (wellPosition == 49) return "A07";
        else if (wellPosition == 50) return "B07";
        else if (wellPosition == 51) return "C07";
        else if (wellPosition == 52) return "D07";
        else if (wellPosition == 53) return "E07";
        else if (wellPosition == 54) return "F07";
        else if (wellPosition == 55) return "G07";
        else if (wellPosition == 56) return "H07";
        else if (wellPosition == 57) return "A08";
        else if (wellPosition == 58) return "B08";
        else if (wellPosition == 59) return "C08";
        else if (wellPosition == 60) return "D08";
        else if (wellPosition == 61) return "E08";
        else if (wellPosition == 62) return "F08";
        else if (wellPosition == 63) return "G08";
        else if (wellPosition == 64) return "H08";
        else if (wellPosition == 65) return "A09";
        else if (wellPosition == 66) return "B09";
        else if (wellPosition == 67) return "C09";
        else if (wellPosition == 68) return "D09";
        else if (wellPosition == 69) return "E09";
        else if (wellPosition == 70) return "F09";
        else if (wellPosition == 71) return "G09";
        else if (wellPosition == 72) return "H09";
        else if (wellPosition == 73) return "A10";
        else if (wellPosition == 74) return "B10";
        else if (wellPosition == 75) return "C10";
        else if (wellPosition == 76) return "D10";
        else if (wellPosition == 77) return "E10";
        else if (wellPosition == 78) return "F10";
        else if (wellPosition == 79) return "G10";
        else if (wellPosition == 80) return "H10";
        else if (wellPosition == 81) return "A11";
        else if (wellPosition == 82) return "B11";
        else if (wellPosition == 83) return "C11";
        else if (wellPosition == 84) return "D11";
        else if (wellPosition == 85) return "E11";
        else if (wellPosition == 86) return "F11";
        else if (wellPosition == 87) return "G11";
        else if (wellPosition == 88) return "H11";
        else if (wellPosition == 89) return "A12";
        else if (wellPosition == 90) return "B12";
        else if (wellPosition == 91) return "C12";
        else if (wellPosition == 92) return "D12";
        else if (wellPosition == 93) return "E12";
        else if (wellPosition == 94) return "F12";
        else if (wellPosition == 95) return "G12";
        else if (wellPosition == 96) return "H12";
        else {
            //LOG.error("The wellPosition must be between 1 and 96");
            throw new AssertionError("The wellPosition must be between 1 and 96");
        }
    }

    // Created for Autotool tasks. Returns in format A1, B1, C1 (not A01, B01, C01)
    public static String get384WellAddress(Integer row, Integer col) {
        if (row < 1 || row > 17) {
            throw new AssertionError("The row position must be between 1 and 16");
        } else if (col < 1 || col > 24) {
            throw new AssertionError("The col position must be between 1 and 24");
        }
        String rowLabel = row > 0 && row < 27 ? String.valueOf((char) (row + 64)) : null;
        return rowLabel + col.toString();
    }

    // Returns in format A01, B01, C01
    public static String getWellAddressLongFormat(Integer row, Integer col) {
        if (row < 1 || row > 17) {
            throw new AssertionError("The row position must be between 1 and 16");
        } else if (col < 1 || col > 24) {
            throw new AssertionError("The col position must be between 1 and 24");
        }
        String rowLabel = row > 0 && row < 27 ? String.valueOf((char) (row + 64)) : null;
        return rowLabel + format("%02d", col);
    }

    // startTime and endTime values between "00:00" and "24.00"
    public static boolean currentTimeBetweenRange(String startTime, String endTime) throws Exception {

        Calendar now = Calendar.getInstance();

        int hour = now.get(Calendar.HOUR_OF_DAY);
        int minute = now.get(Calendar.MINUTE);

        java.util.Date date = parseDate(hour + ":" + minute);
        java.util.Date dateStart = parseDate(startTime);
        java.util.Date dateEnd = parseDate(endTime);

        if (dateStart.before(date) && dateEnd.after(date)) {
            return true;
        } else {
            return false;
        }

    }

    private static java.util.Date parseDate(String date) throws ParseException {

        final String inputFormat = "HH:mm";
        SimpleDateFormat inputParser = new SimpleDateFormat(inputFormat, Locale.US);
        try {
            return inputParser.parse(date);
        } catch (java.text.ParseException e) {
            throw e;
        }

    }

    public static java.sql.Date parseSqlDate(String date) throws ParseException {

        final String inputFormat = "HH:mm";
        SimpleDateFormat inputParser = new SimpleDateFormat(inputFormat, Locale.US);
        try {
            Date utilDate = inputParser.parse(date);
            java.sql.Date sqldate = new java.sql.Date(utilDate.getTime());
            return sqldate;
        } catch (java.text.ParseException e) {
            throw e;
        }

    }

    public static java.sql.Date parseSqlDateWithFormnat(String date, String inputFormat) throws ParseException {

        SimpleDateFormat inputParser = new SimpleDateFormat(inputFormat, Locale.US);
        try {
            Date utilDate = inputParser.parse(date);
            java.sql.Date sqldate = new java.sql.Date(utilDate.getTime());
            return sqldate;
        } catch (java.text.ParseException e) {
            throw e;
        }

    }

    public static BigDecimal evaluateExpression(String[] args, String expression) throws ScriptException {

        for (int i = 0; i < args.length; i++) {
            if (expression.indexOf("arg" + i) > -1) {
                expression = expression.replace("[arg" + i + "]", args[i]);
            }
        }
        ScriptEngineManager factory = new ScriptEngineManager();
        ScriptEngine engine = factory.getEngineByName("JavaScript");
        Object result = engine.eval(expression);

        return new BigDecimal(result.toString());
    }

    public static long getDaysToMillis(int days) {
        // return the number of days represented in millis for lastModified dates and such
        return (System.currentTimeMillis() - (days * 24L * 60L * 60L * 1000L));
    }

    /**
     * @param timeInQueue
     * @return: Example: returns 376 00:45:47 for +376 00:45:47.000000
     */
    public static String parseTimeInQueue(String timeInQueue) {

        String returnVal = "";

        String[] timeParts1 = timeInQueue.split("\\.");
        if (timeParts1.length == 0) {
            return timeInQueue;
        } else {
            String[] timeParts2 = timeParts1[0].replace("+", "").split(":");  // lose milliseconds & leading +

            String[] daysAndHours = timeParts2[0].split(" ");
            if (!daysAndHours[0].equals("0")) {
                returnVal = daysAndHours[0] + "d ";
            }
            returnVal += daysAndHours[1] + "h";

            return returnVal;
        }

    }

    public static String getToday(String pattern) {
        Calendar cal = Calendar.getInstance();
        return new SimpleDateFormat(pattern).format(cal.getTime());
    }

    public static String getTime() {
        java.util.Date date = new java.util.Date();
        DateFormat format = new SimpleDateFormat("HHmm");
        return format.format(date);
    }

    public static Timestamp getTimestampFromString(String pattern, String dateTime) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
        java.util.Date parsedDate = dateFormat.parse(dateTime);
        Timestamp ts = new java.sql.Timestamp(parsedDate.getTime());
        return ts;
    }

}
