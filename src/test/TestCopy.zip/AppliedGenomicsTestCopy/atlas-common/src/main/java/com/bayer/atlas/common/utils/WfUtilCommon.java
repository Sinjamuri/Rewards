package com.bayer.atlas.common.utils;


import com.bayer.atlas.common.AnkTaqmanConstants;
import com.bayer.atlas.common.model.*;
import com.fasterxml.jackson.databind.annotation.JsonAppend;
import com.google.gson.Gson;
import com.bayer.atlas.common.json.GemsSampleServiceResp;
import com.google.gson.reflect.TypeToken;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.nio.file.Paths;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;


public class WfUtilCommon extends AkanaUtils {
    private static final Logger LOG = LoggerFactory.getLogger(WfUtilCommon.class);


    public static long getNextSeq(String sequenceName) throws Exception {
        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String url = akanaBaseUrl + "/sequence?sequenceName=";

        url = url + sequenceName;
        String response = serviceCommon.getResponseAsString(url);

        if(null != response) {
            Long seqId = new Gson().fromJson(response, Long.class);
            return seqId;
        }

        return -1;
    }

    public static void insertWfAll(List<WfBase> wfBaseList) throws Exception {

        for (WfBase wfBase : wfBaseList) {
            insertWfAll(wfBase);
        }
    }

    public static void insertWfAll( WfBase wfBase) throws Exception {

        WfUtils.insertWf(wfBase);
        // NOTE: Data and grid data is inserted automatically alongside wfBase. We cannot insert data list separate since it will lack wf id
//        if (null != wfBase.getWfDataList() && !wfBase.getWfDataList().isEmpty()) {
//            WfDataUtils.insertWfDataList(wfBase.getWfDataList());
//        }
//        if (null != wfBase.getWfGridBaseList() && !wfBase.getWfGridBaseList().isEmpty()) {
//            WfGridUtils.insertGridAll(wfBase.getWfGridBaseList());
//        }
    }

    public static List<WfBase> getWfAtStepByWfData(String wfDataVarchar2, long wfDataConfigId, long wfStepConfigId,
                                                   String status) throws Exception {

        List<WfBase> wfBaseList = new ArrayList<>();
        List<WfData> wfDataWfID = WfDataUtils.getWfDataWfID(wfDataVarchar2, wfDataConfigId);
        wfDataWfID.forEach(wfData -> {
            try {
                wfBaseList.add(WfUtils.getWfByWfId(wfData.getWfId()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        List<WfBase> wfBasesFiltered = wfBaseList.stream().filter(wfBase -> wfBase.getWfStepConfigId().longValue() == wfStepConfigId && wfBase.getWfStatus().equalsIgnoreCase(status)).collect(Collectors.toList());
        return wfBasesFiltered;
    }

    public static List<Long> getWfDataWfIdAtStep(String wfDataVarchar2, long wfDataConfigId, long wfStepConfigId,
                                                 String status) throws Exception {

        List<WfBase> wfBaseList = getWfAtStepByWfData(wfDataVarchar2, wfDataConfigId, wfStepConfigId, status);
        return wfBaseList.stream().map(wfBase -> wfBase.getWfId()).collect(Collectors.toList());

    }

    public static String getWfDataVarcharAtWfStepActive(String wfEntityLabel, long wfEntityTypeId, long wfStepConfigId,
                                                  long wfDataConfigId) throws Exception {
        String wfDataVarchar2 = null;
        List<WfBase> wfBases = WfUtils.getWfByLabelTypeStepAndStatus(wfEntityLabel, wfEntityTypeId, wfStepConfigId, "I");
        if(null != wfBases && !wfBases.isEmpty()){
            wfDataVarchar2 = WfDataUtils.getWfDataByWfIdAndConfig(wfBases.get(0).getWfId(), wfDataConfigId).getWfDataVarchar2();
        }

        return wfDataVarchar2;
    }

    public static String getAssociatedWfDataVarchar(String wfEntityLabel, long wfEntityTypeId,
                                                    long wfDataConfigId) throws Exception {

        String wfDataVarchar2 = null;
        List<WfBase> wfBases = WfUtils.getWfByLabelAndType(wfEntityLabel, wfEntityTypeId);
        if(null != wfBases && !wfBases.isEmpty()){
            wfDataVarchar2 = WfDataUtils.getWfDataByWfIdAndConfig(wfBases.get(0).getWfId(), wfDataConfigId).getWfDataVarchar2();
        }

        return wfDataVarchar2;
    }

    public static Timestamp getAssociatedWfDataTimeStamp(String wfEntityLabel, long wfEntityTypeId,
                                                         long wfDataConfigId) throws Exception {
        Timestamp wfTimestamp = null;
        List<WfBase> wfBases = WfUtils.getWfByLabelAndType(wfEntityLabel, wfEntityTypeId);
        if(null != wfBases && !wfBases.isEmpty()){
            wfTimestamp = WfDataUtils.getWfDataByWfIdAndConfig(wfBases.get(0).getWfId(), wfDataConfigId).getWfDataTimestamp();
        }

        return wfTimestamp;
    }

    public static long getQueuedRecords(String wfStatus, int wfEntityType, int wfStepConfigId,
                                        int wfDataConfigId, String wfEntityLabel) throws Exception {

        List<WfBase> wfBaseList = getWfAtStepByWfData(wfEntityLabel, wfDataConfigId, wfStepConfigId, wfStatus);
        List<WfBase> wfBases = wfBaseList.stream().filter(wfBase -> wfBase.getWfEntityTypeId().intValue() == wfEntityType).
                collect(Collectors.toList());
        return wfBases.size();
    }

    /**
     * Common routine to increment a counter that is stored as a wf data attribute
     * creates it if as 1 it does not exist, adds 1 to it if it exists
     *
     * @param wfId
     * @throws Exception
     */
    public static void incrementWfDataCounter(long wfId, long wfDataConfigId) throws Exception {

        Long counter = 0L;
        try {
            counter = WfDataUtils.getCountByWfDataConfigId(wfId, wfDataConfigId);
            WfDataUtils.insertWfData(wfId, wfDataConfigId, counter + 1);
        } catch (NullPointerException npe) {
            WfDataUtils.insertWfData(wfId, wfDataConfigId, 1);
        }

    }

    public static String getProjectSampleType(String limsId) throws Exception {

        Set<String> distinctSampleType = new HashSet<>();
        List<WfBase> wfBaseList = new ArrayList<>();
        List<WfData> wfDataWfID = WfDataUtils.getWfDataWfID(limsId, 8);
        wfDataWfID.forEach(wfData -> {
            try {
                wfBaseList.add(WfUtils.getWfByWfId(wfData.getWfId()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        List<WfBase> wfBasesFiltered = wfBaseList.stream().filter(wfBase -> wfBase.getWfEntityTypeId().longValue() == 1L && !wfBase.getWfStatus().equalsIgnoreCase("D")).collect(Collectors.toList());
        wfBasesFiltered.forEach(wfData -> {
            try {
                distinctSampleType.add(WfDataUtils.getWfDataByWfIdAndConfig(wfData.getWfId(), 61L).getWfDataVarchar2());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        if (distinctSampleType.isEmpty() || distinctSampleType.size() > 1) {
            throw new AssertionError("multiple project sample types found for: " + limsId + ".  Single type expected.");
        }else {
            return distinctSampleType.iterator().next();
        }
    }

    //WF_STEP
    public static void finishCurrentStep( long wfId, String username) throws Exception {
        WfUtils.updateWf(wfId, "M");
    }

    public static void finishCurrentStep(long wfId) throws Exception {
        finishCurrentStep(wfId, "ATLAS");
    }

    public static void moveEntityToNextStep(long wfId, long nextWfStepConfigId) throws Exception {
        WfUtils.updateWf(wfId, "M");
        WfUtils.updateWfStepConfig( wfId, nextWfStepConfigId);
    }

    public static long completeThisStepWithDataCopy(Long wfId, long wfConfigId, Long nextStepId) throws Exception {
        WfBase wfBase = WfUtils.getWfByWfId(wfId);

        return completeThisStepWithDataCopy(wfId, wfConfigId, wfBase.getWfEntityLabel(), wfBase.getWfEntityTypeId(), nextStepId, "M");
    }

    public static long completeThisStepWithDataCopy(Long wfId, long wfConfigId, String entityLabel, Long entityId, Long nextStepId,
                                                    String updateStatus) throws Exception {

        //create review workflow
        long nextWfIdSeq = WfUtilCommon.getNextSeq("ATLAS.wf_id_seq");
        WfUtils.updateWf(wfId, updateStatus);
        WfUtils.insertWf(nextWfIdSeq, wfConfigId, "I", nextStepId, "ATLAS", entityId, entityLabel);
        //create review workflow data
        WfDataUtils.copyDataWithDifferentWfId(wfId, nextWfIdSeq);
        WfUtils.insertWfAssoc(wfId, nextWfIdSeq, 1, entityLabel);
        //update status
        return nextWfIdSeq;
    }

    //WF_GRID_ASSOC
    public static void insertWfGridAssoc(long wfGridId, long wfConfigId, long wfId, int gridRow, int gridCol, String label) throws
            Exception {

        insertWfGridAssoc(wfGridId, wfConfigId, wfId, gridRow, gridCol, label, null);
    }

    //WF_GRID_ASSOC - overloaded with aggregation
    public static void insertWfGridAssoc(long wfGridId, long wfConfigId, long wfId, int gridRow, int gridCol,
                                         String label, Long aggregateGroupId) throws Exception {

        WfGridAssoc wfGridAssoc = new WfGridAssoc(wfGridId, wfId, gridRow, gridCol, label, wfConfigId, "A", aggregateGroupId);

        List<WfGridAssoc> arrayList = new ArrayList<>();
        arrayList.add(wfGridAssoc);
        WfGridUtils.insertWfGridAssoc(arrayList);
    }

    /**
     * This method returns previous WF_STEP_CONFIG_ID for the wfId
     *
     * @param con
     * @param wfId
     * @return
     * @throws Exception
     */
    public static Long getPreviousWfStepConfigId(Connection con, long wfId) throws Exception {

        final String SQL = "select WF_STEP_CONFIG_ID from ATLAS.WF_STEP where WF_STEP_ID IN " +
                "(select MAX(ws.WF_STEP_ID) from ATLAS.WF wf " +
                "INNER JOIN ATLAS.WF_STEP_CONFIG wsc ON wf.WF_STEP_CONFIG_ID = wsc.NEXT_WF_STEP_CONFIG_ID " +
                "INNER JOIN ATLAS.WF_STEP ws ON wf.WF_ID = ws.WF_ID and ws.WF_STEP_CONFIG_ID = wsc.WF_STEP_CONFIG_ID " +
                "where wf.WF_ID = ? and ws.ACTION_FLG='C')";

        ResultSet rs = null;
        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement(SQL);
            pstmt.setLong(1, wfId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getLong(1);
            }
        } finally {
            ServiceCommon.freeResource(pstmt);
            ServiceCommon.freeResource(rs);
        }
        return null;
    }

    /**
     * Based on the passed in criteria, re-order the queue's sort order
     *
     * @param con
     * @param wfStepConfigId
     * @param wfDataConfigId
     * @param orderBy
     * @return number of records sorted
     * @throws SQLException
     */
    public static int reorderQueue(Connection con, long wfStepConfigId, long wfDataConfigId, String orderBy) throws SQLException {

        final String SQLselect = "select w.wf_id, wd.wf_data_varchar2, wd.wf_data_number, wd.wf_data_timestamp\n" +
                "from ATLAS.wf w\n" +
                "inner join ATLAS.wf_data wd on wd.wf_id = w.wf_id\n" +
                "where \n" +
                "w.wf_status='I' and\n" +
                "w.wf_step_config_id=? and\n" +
                "wd.wf_data_config_id=?\n" +
                "order by " + orderBy;

        final String SQLupdate = "update ATLAS.wf set queue_sort_order=?,update_ts=now() where wf_id=?";

        int newOrder = 0;

        ResultSet rs = null;
        PreparedStatement pstmtSelect = null;
        PreparedStatement pstmtUpdate = null;
        try {
            pstmtSelect = con.prepareStatement(SQLselect);
            pstmtSelect.setLong(1, wfStepConfigId);
            pstmtSelect.setLong(2, wfDataConfigId);
            rs = pstmtSelect.executeQuery();
            while (rs.next()) {
                newOrder++;
                pstmtUpdate = con.prepareStatement(SQLupdate);
                pstmtUpdate.setInt(1, newOrder);
                pstmtUpdate.setLong(2, rs.getLong("wf_id"));
                pstmtUpdate.executeUpdate();
                ServiceCommon.freeResource(pstmtUpdate);
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmtSelect);
        }

        return newOrder;

    }

    public static List<String> getCodes(Connection con, String code_type) throws
            Exception {
        final String SQL = "select key from atlas.codes where " +
                " code_type=? ";

        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<String> codeList = new ArrayList<String>();
        try {
            pstmt = con.prepareStatement(SQL);
            pstmt.setString(1, code_type);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                codeList.add(rs.getString(1));
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
        return codeList;
    }


    public static List<GemsSampleServiceResp> loadWellsDataForLims(Connection con, String blockBarcodeNbr) throws Exception {

        List<GemsSampleServiceResp> responseFromOnPremServices = new ArrayList<GemsSampleServiceResp>();
        try {
            final String MAP_SAMPLES = WfUtilCommon.getWfConfigProperyString(con, 1, "URL_PREMDATA_GET_GEMS_SAMPLE_INFO");

            ServiceCommon serviceCommon = new ServiceCommon();
            responseFromOnPremServices = serviceCommon.getResponseFromOnPremServices(MAP_SAMPLES.replace("{BLOCK_BARCODE_NBR}", blockBarcodeNbr));

        } catch (Exception e) {
            LOG.error("Exception while processing: " + blockBarcodeNbr);
            throw e;
        }
        return responseFromOnPremServices;

    }

    public static void insertErrorLog(Connection con) throws Exception {

        // This is for testing only, but we might tweak for prod usage at some point...


        LOG.info("executing agent test...");

        final String SQL = "insert into ATLAS.error_log (error_log_id, error_level, error_message, error_source, error_detail, create_ts) values (?,?,?,?,?,now())";

        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement(SQL);

            pstmt.setLong(1, getNextSeq("ATLAS.error_log_id_seq"));
            pstmt.setString(2, "info");
            pstmt.setString(3, "agent test");
            pstmt.setString(4, "TestAgent");
            pstmt.setString(5, "");

            pstmt.executeUpdate();

        } finally {
            ServiceCommon.freeResource(pstmt);
        }
    }


    public static WfWellMap getWfPlateMapBySourceWell(Connection con, String sourceWell) throws Exception {

        final String SQL = "SELECT * FROM atlas.WF_PLATE_MAP WHERE SOURCE_WELL_NAME = ? AND TYPE = 'BIOCELL_96_TO_384' ";
        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement(SQL);
            pstmt.setString(1, sourceWell);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                WfWellMap plate = new WfWellMap();
                plate.setSourceRow(rs.getInt("SOURCE_ROW"));
                plate.setSourceCol(rs.getInt("SOURCE_COL"));
                return plate;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return null;
    }

    public static WfWellMap getDestRowColumn(Connection con, long wfConfigId, String plateMapType, int quadrant, int sourceRow, int sourceCol) throws SQLException {

        // Returns the dest well for the source data passed in (ex: returns A01, P24, etc..)

        String SQL = "select dest_well_name,dest_row,dest_col from ATLAS.wf_plate_map\n" +
                "where\n" +
                "wf_config_id=?\n" +
                "and type=?\n" +
                "and source_quadrant=?\n" +
                "and source_row=?\n" +
                "and source_col=?";

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement(SQL);
            stmt.setLong(1, wfConfigId);
            stmt.setString(2, plateMapType);
            stmt.setInt(3, quadrant);
            stmt.setInt(4, sourceRow);
            stmt.setInt(5, sourceCol);
            rs = stmt.executeQuery();
            if (null == rs) {
                return null;
            } else {
                while (rs.next()) {
                    WfWellMap wellMap = new WfWellMap();
                    wellMap.setDestRow(rs.getInt("dest_row"));
                    wellMap.setDestCol(rs.getInt("dest_col"));
                    wellMap.setDestWellName(rs.getString("dest_well_name"));
                    return wellMap;
                }
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(stmt);
        }

        return null;

    }

    public static List<WfWellMap> getWfPlateMap(Connection con, long wfConfigId, String plateMapType) {
        String SQL = "select * from atlas.wf_plate_map\n" +
                "where\n" +
                "wf_config_id=?\n" +
                "and type=?";
        List<WfWellMap> wfPlateMapList = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement(SQL);
            stmt.setLong(1, wfConfigId);
            stmt.setString(2, plateMapType);
            rs = stmt.executeQuery();

            WfWellMap wellEntry = null;
            while (rs.next()) {
                wellEntry = new WfWellMap();
                wellEntry.setSourceQuadrant(rs.getInt("source_quadrant"));
                wellEntry.setSourceRow(rs.getInt("source_row"));
                wellEntry.setSourceCol(rs.getInt("source_col"));
                wellEntry.setSourceWellName(rs.getString("source_well_name"));
                wellEntry.setDestQuadrant(rs.getInt("dest_quadrant"));
                wellEntry.setDestRow(rs.getInt("dest_row"));
                wellEntry.setDestCol(rs.getInt("dest_col"));
                wellEntry.setDestWellName(rs.getString("dest_well_name"));
                wellEntry.setControl(rs.getString("is_control").equals("Y") ? true : false);
                wfPlateMapList.add(wellEntry);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return wfPlateMapList;
    }

    /**
     * public List<WfPlateMap> getWfPlateMapForQuadrant(long wfConfigId, String plateMapType, long quadrant, String isControl)  {
     * // Returns the dest well for the source data passed in (ex: returns A01, P24, etc..)
     * <p>
     * String SQL = "select * from atlas.wf_plate_map\n" +
     * "where\n" +
     * "wf_config_id=?\n" +
     * "and type=?" +
     * "and dest_quadrant=?" +
     * "and is_control=?";
     * <p>
     * List<WfPlateMap>  wfPlateMapList = null;
     * try {
     * return jdbcTemplate.query(SQL, new RowMapperImpl(),  wfConfigId, plateMapType, quadrant, isControl);
     * }  catch (Exception ex) {
     * // nothing returned - expected in some cases for data that existed pre-wfDataConfigId implementation
     * }
     * return null;
     * }
     *
     * @param con
     * @return
     */
    public static List<WfWellMap> getWfPlateMapForQuadrant(Connection con, long wfConfigId, String plateMapType, long quadrant, String isControl) {
        String SQL = "select * from atlas.wf_plate_map\n" +
                "where\n" +
                "wf_config_id=?\n" +
                "and type=?" +
                "and dest_quadrant=?" +
                "and is_control=?";
        List<WfWellMap> wfPlateMapList = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement(SQL);
            stmt.setLong(1, wfConfigId);
            stmt.setString(2, plateMapType);
            stmt.setLong(3, quadrant);
            stmt.setString(4, isControl);
            rs = stmt.executeQuery();

            WfWellMap wellEntry = null;
            while (rs.next()) {
                wellEntry = new WfWellMap();
                wellEntry.setSourceQuadrant(rs.getInt("source_quadrant"));
                wellEntry.setSourceRow(rs.getInt("source_row"));
                wellEntry.setSourceCol(rs.getInt("source_col"));
                wellEntry.setSourceWellName(rs.getString("source_well_name"));
                wellEntry.setDestQuadrant(rs.getInt("dest_quadrant"));
                wellEntry.setDestRow(rs.getInt("dest_row"));
                wellEntry.setDestCol(rs.getInt("dest_col"));
                wellEntry.setDestWellName(rs.getString("dest_well_name"));
                wellEntry.setControl(rs.getString("is_control").equals("Y") ? true : false);
                wfPlateMapList.add(wellEntry);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return wfPlateMapList;
    }

    public static void deleteRobotJobAndTasksWithWfID(Connection con, long wfId, long wfDataConfigId) throws Exception {
        final String SQL_SELECT = "select wf_data_varchar2 from ATLAS.wf_data where wf_id=? and wf_data_config_id=?";
        final String DELETE_JOB = "delete from ATLAS.x_robot_job where robot_job_id=? ";
        final String DELETE_TASKS = "delete from ATLAS.x_robot_transfer_tsk where robot_job_id=?";

        PreparedStatement pstmtSelect = null;
        PreparedStatement pstmtJob = null;
        PreparedStatement pstmtTasks = null;
        ResultSet rsSelect = null;
        try {
            pstmtSelect = con.prepareStatement(SQL_SELECT);
            pstmtSelect.setLong(1, wfId);
            pstmtSelect.setLong(2, wfDataConfigId);
            rsSelect = pstmtSelect.executeQuery();
            while (rsSelect.next()) {
                try {
                    String jobName = rsSelect.getString("wf_data_varchar2");
                    long jobId = jobName != null && jobName.startsWith("CHPK") ? Long.valueOf(jobName.replace("CHPK", "")) : 0;
                    if (jobId != 0) {
                        pstmtTasks = con.prepareStatement(DELETE_TASKS);
                        pstmtTasks.setLong(1, jobId);
                        pstmtTasks.execute();
                        pstmtJob = con.prepareStatement(DELETE_JOB);
                        pstmtJob.setLong(1, jobId);
                        pstmtJob.execute();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    ServiceCommon.freeResource(pstmtJob);
                    ServiceCommon.freeResource(pstmtTasks);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ServiceCommon.freeResource(pstmtSelect);
            ServiceCommon.freeResource(rsSelect);
        }
    }


    //WF_CONFIG_PROPERTIES
    public static void saveWfConfigPropertyMapStringString(Connection con, long wfConfigId, String key, Map<String, String> map) throws Exception {
        saveWfConfigProperyString(con, wfConfigId, key, new Gson().toJson(map));
    }

    public static void saveWfConfigPropertyMapStringInteger(Connection con, long wfConfigId, String key, Map<String, Integer> map) throws Exception {
        saveWfConfigProperyString(con, wfConfigId, key, new Gson().toJson(map));
    }

    public static void saveWfConfigPropertyMapStringTimestamp(Connection con, long wfConfigId, String key, Map<String, Timestamp> map) throws
            Exception {
        saveWfConfigProperyString(con, wfConfigId, key, new Gson().toJson(map));
    }

    public static void saveWfConfigProperyString(Connection con, long wfConfigId, String key, String val) throws Exception {
        PreparedStatement pstmtUpdate = null;
        PreparedStatement pstmtInsert = null;
        try {
            pstmtUpdate = con.prepareStatement("update ATLAS.wf_config_properties set value_varchar2=? where wf_config_id=? and key=?");
            pstmtUpdate.setString(1, val);
            pstmtUpdate.setLong(2, wfConfigId);
            pstmtUpdate.setString(3, key.toUpperCase());
            int records = pstmtUpdate.executeUpdate();
            if (records == 0) {
                //no record exists, so insert one
                pstmtInsert = con.prepareStatement("insert into ATLAS.wf_config_properties (wf_config_id,key,value_varchar2) values (?,?,?)");
                pstmtInsert.setLong(1, wfConfigId);
                pstmtInsert.setString(2, key.toUpperCase());
                pstmtInsert.setString(3, val);
                pstmtInsert.executeUpdate();
            }
        } finally {
            ServiceCommon.freeResource(pstmtInsert);
            ServiceCommon.freeResource(pstmtUpdate);
        }
    }

    public static void saveWfConfigProperyInteger(Connection con, long wfConfigId, String key, Integer val) throws Exception {
        PreparedStatement pstmtUpdate = null;
        PreparedStatement pstmtInsert = null;
        try {
            pstmtUpdate = con.prepareStatement("update ATLAS.wf_config_properties set value_number=? where wf_config_id=? and key=?");
            pstmtUpdate.setInt(1, val);
            pstmtUpdate.setLong(2, wfConfigId);
            pstmtUpdate.setString(3, key.toUpperCase());
            int records = pstmtUpdate.executeUpdate();
            if (records == 0) {
                //no record exists, so insert one
                pstmtInsert = con.prepareStatement("insert into ATLAS.wf_config_properties (wf_config_id,key,value_number) values (?,?,?)");
                pstmtInsert.setLong(1, wfConfigId);
                pstmtInsert.setString(2, key.toUpperCase());
                pstmtInsert.setInt(3, val);
                pstmtInsert.executeUpdate();
            }
        } finally {
            ServiceCommon.freeResource(pstmtInsert);
            ServiceCommon.freeResource(pstmtUpdate);
        }
    }

    public static void saveWfConfigProperyTimestamp(Connection con, long wfConfigId, String key, Timestamp val) throws Exception {
        PreparedStatement pstmtUpdate = null;
        PreparedStatement pstmtInsert = null;
        try {
            pstmtUpdate = con.prepareStatement("update ATLAS.wf_config_properties set value_timestamp=? where wf_config_id=? and key=?");
            pstmtUpdate.setTimestamp(1, val);
            pstmtUpdate.setLong(2, wfConfigId);
            pstmtUpdate.setString(3, key.toUpperCase());
            int records = pstmtUpdate.executeUpdate();
            if (records == 0) {
                //no record exists, so insert one
                pstmtInsert = con.prepareStatement("insert into ATLAS.wf_config_properties (wf_config_id,key,value_timestamp) values (?,?,?)");
                pstmtInsert.setLong(1, wfConfigId);
                pstmtInsert.setString(2, key.toUpperCase());
                pstmtInsert.setTimestamp(3, val);
                pstmtInsert.executeUpdate();
            }
        } finally {
            ServiceCommon.freeResource(pstmtInsert);
            ServiceCommon.freeResource(pstmtUpdate);
        }
    }

    public static Map<String, String> getWfConfigPropertyMapStringString(Connection con, long wfConfigId, String key) throws Exception {
        String serializedVal = getWfConfigProperyString(con, wfConfigId, key);

        //deserialize into object and return
        Map map = new Gson().fromJson(serializedVal, LinkedHashMap.class);
        return (Map<String, String>) map;
    }

    public static Map<String, Double> getWfConfigPropertyMapStringInteger(Connection con, long wfConfigId, String key) throws Exception {

        String serializedVal = getWfConfigProperyString(con, wfConfigId, key);
        //deserialize into object and return
        Map map = new Gson().fromJson(serializedVal, LinkedHashMap.class);

        return (Map<String, Double>) map;
    }

    public static Map<String, Timestamp> getWfConfigPropertyMapStringTimestamp(Connection con, long wfConfigId, String key) throws Exception {
        String serializedVal = getWfConfigProperyString(con, wfConfigId, key);

        //deserialize into object and return
        Map map = new Gson().fromJson(serializedVal, LinkedHashMap.class);
        return (Map<String, Timestamp>) map;
    }

    public static String getWfConfigProperyString(Connection con, long wfConfigId, String key) throws Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = con.prepareStatement("select value_varchar2 from ATLAS.wf_config_properties where wf_config_id=? and key=?");
            pstmt.setLong(1, wfConfigId);
            pstmt.setString(2, key);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString(1);
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
        return null;
    }

    public static WfConfigProperty getWfConfigPropertyByKey(long wfConfigId, String key) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String baseUrl = akanaBaseUrl + "/";

        try {
            // /wf-config-property/wf-config-id/{wf-config-id}/key/{key}
            String url = baseUrl + "wf-config-property/wf-config-id/" + wfConfigId + "/key/" + key;
            String response = serviceCommon.getResponseAsString(url);

            if(null != response) {

                WfConfigProperty wfConfigProperty = new Gson().fromJson(response, WfConfigProperty.class);
                return wfConfigProperty;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<WfConfigProperty> getWfConfigPropertyByRefKey(String refKey) throws Exception {

        ServiceCommon serviceCommon = new ServiceCommon();
        //TODO
        String baseUrl = akanaBaseUrl + "/";

        try {
            String url = baseUrl + "wf-config-property/ref-key/" + refKey ;
            String response = serviceCommon.getResponseAsString(url);


            if(null != response) {
                Type collectionType = new TypeToken<List<WfConfigProperty>>() {
                }.getType();

                List<WfConfigProperty> wfConfigPropertyList = new Gson().fromJson(response, collectionType);
                return wfConfigPropertyList;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Integer getWfConfigProperyInteger(Connection con, long wfConfigId, String key) throws Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = con.prepareStatement("select value_number from ATLAS.wf_config_properties where wf_config_id=? and key=?");
            pstmt.setLong(1, wfConfigId);
            pstmt.setString(2, key);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
        return null;
    }

    public static Number getWfConfigPropertyNumber(Connection con, long wfConfigId, String key, Class parseNumberAsTypeExtendingNumber) throws
            Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = con.prepareStatement("select value_number from ATLAS.wf_config_properties where wf_config_id=? and key=?");
            pstmt.setLong(1, wfConfigId);
            pstmt.setString(2, key);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                Method getterMethod = ResultSet.class
                        .getDeclaredMethod("get" + StringUtils.capitalize(parseNumberAsTypeExtendingNumber.getSimpleName()), int.class);
                return (Number) getterMethod.invoke(rs, 1);
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
        return null;
    }

    public static Timestamp getWfConfigProperyTimestamp(Connection con, long wfConfigId, String key) throws Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = con.prepareStatement("select value_timestamp from ATLAS.wf_config_properties where wf_config_id=? and key=?");
            pstmt.setLong(1, wfConfigId);
            pstmt.setString(2, key);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getTimestamp(1);
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
        return null;
    }

    public static Timestamp getWfConfigPropertyValueTimestamp(Connection con, String keyValue, String valueColumnName) throws Exception {
        final String SQL = "select " + valueColumnName + " from ATLAS.wf_config_properties where key='" + keyValue + "'";

        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = con.prepareStatement(SQL);
            rs = pstmt.executeQuery();
            rs.next();
            return rs.getTimestamp(valueColumnName);
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
    }

    public static void updateWfConfigPropertyValueTimestamp(Connection con, String keyValue, String valueColumnName, Timestamp value) throws Exception {
        final String SQL = "update ATLAS.wf_config_properties set " + valueColumnName + "=? where key='" + keyValue + "'";

        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement(SQL);

            pstmt.setTimestamp(1, value);
            pstmt.executeUpdate();

        } finally {
            ServiceCommon.freeResource(pstmt);
        }
    }

    public static void updateWfConfigPropertyValue(Connection con, String keyValue, String valueColumnName, String value) throws Exception {
        final String SQL = "update ATLAS.wf_config_properties set " + valueColumnName + "=? where key='" + keyValue + "'";

        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement(SQL);

            pstmt.setString(1, value);
            pstmt.executeUpdate();

        } finally {
            ServiceCommon.freeResource(pstmt);
        }
    }

    public static void updateWfConfigPropertyValueNumber(Connection con, String keyValue, long value) throws Exception {
        final String SQL = "update ATLAS.wf_config_properties set value_number=? where key='" + keyValue + "'";

        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement(SQL);

            pstmt.setLong(1, value);
            pstmt.executeUpdate();

        } finally {
            ServiceCommon.freeResource(pstmt);
        }
    }


    public static Map<String, Object> getChildProperties(Connection con, String key) throws SQLException {

        final String SQL = "select cp2.KEY,cp2.VALUE_VARCHAR2,cp2.VALUE_NUMBER,cp2.VALUE_TIMESTAMP from ATLAS.WF_CONFIG_PROPERTIES cp1 " +
                "INNER JOIN ATLAS.WF_CONFIG_PROPERTIES cp2 ON cp1.PROPERTY_ID = cp2.REF_KEY where cp1.KEY = ?";

        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Map<String, Object> childPropertiesMap = new HashMap<String, Object>();
        try {
            pstmt = con.prepareStatement(SQL);
            pstmt.setString(1, key);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                if (null != rs.getString(2)) {
                    childPropertiesMap.put(rs.getString(1), rs.getString(2));
                } else if (null != rs.getString(3)) {
                    childPropertiesMap.put(rs.getString(1), rs.getLong(3));
                } else {
                    childPropertiesMap.put(rs.getString(1), rs.getTimestamp(4));
                }
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
        return childPropertiesMap;
    }

    public static boolean wfConfigPropertyKeyInNumberBasedRefGroup(Connection con, int refKey, int valueNumber) throws SQLException {

        String SQL = "SELECT\n" +
                "            COUNT(*) cnt\n" +
                "          FROM\n" +
                "            ATLAS.wf_config_properties\n" +
                "          where\n" +
                "            ref_key=? AND\n" +
                "            value_number = ?";

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = con.prepareStatement(SQL);
            stmt.setLong(1, refKey);
            stmt.setLong(2, valueNumber);
            rs = stmt.executeQuery();
            if (null != rs) {
                while (rs.next()) {
                    return (rs.getLong("cnt") > 0) ? true : false;
                }
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(stmt);
        }
        return false;
    }

    public static String[] getWfConfigPropertyStringArray(Connection con, long wfConfigId, String key) throws Exception {
        String valueList = WfUtilCommon.getWfConfigProperyString(con, wfConfigId, key);
        return valueList.split(",");
    }

    public static Integer[] getWfConfigPropertyIntegerArray(Connection con, long wfConfigId, String key) throws Exception {
        String valueList = WfUtilCommon.getWfConfigProperyString(con, wfConfigId, key);
        String[] vals = valueList.split(",");
        Integer[] intArray = new Integer[vals.length];
        for (int i = 0; i < vals.length; i++) {
            intArray[i] = Integer.parseInt(vals[i]);
        }
        return intArray;
    }

    public static byte[] getWfConfigPropertyByteArray(Connection con, long wfConfigId, String key) throws Exception {
        String value = WfUtilCommon.getWfConfigProperyString(con, wfConfigId, key);
        return (value).getBytes();
    }

    public static List<String> getWfConfigPropertyStringKey(Connection con, long wfConfigId, long refKey) throws Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        List<String> keysList = new ArrayList<String>();
        try {
            pstmt = con.prepareStatement("select distinct key from atlas.wf_config_properties where wf_config_id=? and ref_key=?");
            pstmt.setLong(1, wfConfigId);
            pstmt.setLong(2, refKey);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                keysList.add(rs.getString(1));
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
        return keysList;
    }

    public static HashMap<String, String> getWfConfigPropertyStringKeyAndValue(Connection con, long wfConfigId, long refKey) throws Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        HashMap<String, String> keyValueMap = new HashMap();
        try {
            pstmt = con.prepareStatement("select distinct key,value from atlas.wf_config_properties where wf_config_id=? and ref_key=?");
            pstmt.setLong(1, wfConfigId);
            pstmt.setLong(2, refKey);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                keyValueMap.put(rs.getString(1), rs.getString(2));
            }
        } finally {
            ServiceCommon.freeResource(rs);
            ServiceCommon.freeResource(pstmt);
        }
        return keyValueMap;
    }


    public static String getNotInClauseForEntitiesToHold(Connection con, String wfPropKey, String fieldToCheck) {
        // Use in conjunction with queries that agents use to filter out (skip) problematic entities

        String holdEntities = "";
        String notInClause = "";

        StackTraceElement myCaller = Thread.currentThread().getStackTrace()[2];

        try {
            holdEntities = WfUtilCommon.getWfConfigProperyString(con, 1, wfPropKey);

            if (null != holdEntities) {
                if (holdEntities.length() != 0) {
                    notInClause = " " + fieldToCheck + " not in(" + holdEntities + ") ";
                }
            }
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            ex.printStackTrace(pw);
            pw.flush();
            String stackTraceString = pw.toString();
            LOG.error(stackTraceString);
        }

        return notInClause;
    }


}
