package com.bayer.atlas.common.model;

import java.util.Date;
import java.util.List;

public class LabSubmissionAPIResponse {

    private long labSubmissionId;
    private long numberOfSamples;
    private Date sendDate;
    private Date returnDate;

    public long getLabSubmissionId() {
        return labSubmissionId;
    }

    public void setLabSubmissionId(long labSubmissionId) {
        this.labSubmissionId = labSubmissionId;
    }

    public long getNumberOfSamples() {
        return numberOfSamples;
    }

    public void setNumberOfSamples(long numberOfSamples) {
        this.numberOfSamples = numberOfSamples;
    }

    public Date getSendDate() {
        return sendDate;
    }

    public void setSendDate(Date sendDate) {
        this.sendDate = sendDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public String getRequester() {
        return requester;
    }

    public void setRequester(String requester) {
        this.requester = requester;
    }

    public String[] getOwners() {
        return owners;
    }

    public void setOwners(String[] owners) {
        this.owners = owners;
    }

    public String[] getOwnerGroups() {
        return ownerGroups;
    }

    public void setOwnerGroups(String[] ownerGroups) {
        this.ownerGroups = ownerGroups;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<AllocateData> getAllocateDataList() {
        return allocateDataList;
    }

    public void setAllocateDataList(List<AllocateData> allocateDataList) {
        this.allocateDataList = allocateDataList;
    }

    public List<SampleMaterial> getSampleMaterialList() {
        return sampleMaterialList;
    }

    public void setSampleMaterialList(List<SampleMaterial> sampleMaterialList) {
        this.sampleMaterialList = sampleMaterialList;
    }

    public List<Container> getContainerList() {
        return containerList;
    }

    public void setContainerList(List<Container> containerList) {
        this.containerList = containerList;
    }

    private String requester;
    private String[] owners;
    private String[] ownerGroups;
    private String description;
    private List<AllocateData> allocateDataList;
    private List<SampleMaterial> sampleMaterialList;
    private List<Container> containerList;

    public CapacityRequestData getCapacityRequestData() {
        return capacityRequestData;
    }

    public void setCapacityRequestData(CapacityRequestData capacityRequestData) {
        this.capacityRequestData = capacityRequestData;
    }

    private CapacityRequestData capacityRequestData;

    public static class CapacityRequestData {
        private long capacityRequestNumber;
        private String taxonId;
        private String sample_type;
        private String material_type;
        private List<Trials_By_Intent> trialsByIntentList;

        public long getCapacityRequestNumber() {
            return capacityRequestNumber;
        }

        public void setCapacityRequestNumber(long capacityRequestNumber) {
            this.capacityRequestNumber = capacityRequestNumber;
        }

        public String getTaxonId() {
            return taxonId;
        }

        public void setTaxonId(String taxonId) {
            this.taxonId = taxonId;
        }

        public String getSample_type() {
            return sample_type;
        }

        public void setSample_type(String sample_type) {
            this.sample_type = sample_type;
        }

        public String getMaterial_type() {
            return material_type;
        }

        public void setMaterial_type(String material_type) {
            this.material_type = material_type;
        }

        public List<Trials_By_Intent> getTrialsByIntentList() {
            return trialsByIntentList;
        }

        public void setTrialsByIntentList(List<Trials_By_Intent> trialsByIntentList) {
            this.trialsByIntentList = trialsByIntentList;
        }

        public String[] getProject_ar() {
            return project_ar;
        }

        public void setProject_ar(String[] project_ar) {
            this.project_ar = project_ar;
        }

        public String getOrganization() {
            return organization;
        }

        public void setOrganization(String organization) {
            this.organization = organization;
        }

        public static class Trials_By_Intent {
            public String getIntent() {
                return intent;
            }

            public void setIntent(String intent) {
                this.intent = intent;
            }

            public String getSub_intent() {
                return sub_intent;
            }

            public void setSub_intent(String sub_intent) {
                this.sub_intent = sub_intent;
            }

            public String[] getEnvironmentIds() {
                return environmentIds;
            }

            public void setEnvironmentIds(String[] environmentIds) {
                this.environmentIds = environmentIds;
            }

            private String intent;
            private String sub_intent;
            private String[] environmentIds;

        }

        private String[] project_ar;
        private String organization;

    }

    public static class AllocateData {
        public String getEnvironmentId() {
            return environmentId;
        }

        public void setEnvironmentId(String environmentId) {
            this.environmentId = environmentId;
        }

        public Date getStartDate() {
            return startDate;
        }

        public void setStartDate(Date startDate) {
            this.startDate = startDate;
        }

        public Date getEndDate() {
            return endDate;
        }

        public void setEndDate(Date endDate) {
            this.endDate = endDate;
        }

        private String  environmentId;
        private Date      startDate;
        private Date     endDate;
    }

    public static class SampleMaterial {
        public long getInventoryBarcode() {
            return inventoryBarcode;
        }

        public void setInventoryBarcode(long inventoryBarcode) {
            this.inventoryBarcode = inventoryBarcode;
        }

        public String getOrigin() {
            return origin;
        }

        public void setOrigin(String origin) {
            this.origin = origin;
        }

        public String getGeneration() {
            return generation;
        }

        public void setGeneration(String generation) {
            this.generation = generation;
        }

        public long getLotId() {
            return lotId;
        }

        public void setLotId(long lotId) {
            this.lotId = lotId;
        }

        public long getSampleId() {
            return sampleId;
        }

        public void setSampleId(long sampleId) {
            this.sampleId = sampleId;
        }

        private long inventoryBarcode;
        private String origin;
        private String generation;
        private long lotId;
        private long sampleId;
    }

    public static class Container {
        private long plateId;

        public long getPlateId() {
            return plateId;
        }

        public void setPlateId(long plateId) {
            this.plateId = plateId;
        }

        public List<SampleMaterial> getSampleMaterialList() {
            return sampleMaterialList;
        }

        public void setSampleMaterialList(List<SampleMaterial> sampleMaterialList) {
            this.sampleMaterialList = sampleMaterialList;
        }

        private List<SampleMaterial> sampleMaterialList;
        public static class SampleMaterial {
            public long getInventoryBarcode() {
                return inventoryBarcode;
            }

            public void setInventoryBarcode(long inventoryBarcode) {
                this.inventoryBarcode = inventoryBarcode;
            }

            public String getOrigin() {
                return origin;
            }

            public void setOrigin(String origin) {
                this.origin = origin;
            }

            public String getGeneration() {
                return generation;
            }

            public void setGeneration(String generation) {
                this.generation = generation;
            }

            public long getLotId() {
                return lotId;
            }

            public void setLotId(long lotId) {
                this.lotId = lotId;
            }

            public List<Samples> getSampleList() {
                return sampleList;
            }

            public void setSampleList(List<Samples> sampleList) {
                this.sampleList = sampleList;
            }

            private long inventoryBarcode;
            private String origin;
            private String generation;
            private long lotId;
            private List<Samples> sampleList;
        public static class Samples {
            public String getRow() {
                return row;
            }

            public void setRow(String row) {
                this.row = row;
            }

            public long getColumn() {
                return column;
            }

            public void setColumn(long column) {
                this.column = column;
            }

            public long getSampleId() {
                return sampleId;
            }

            public void setSampleId(long sampleId) {
                this.sampleId = sampleId;
            }

            private String row;
            private long column;
            private long sampleId;
        }

        }
    }
}
