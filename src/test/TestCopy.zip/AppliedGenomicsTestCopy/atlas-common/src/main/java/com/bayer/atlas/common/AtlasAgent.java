package com.bayer.atlas.common;

import com.bayer.atlas.common.utils.ServiceCommon;
import com.monsanto.labos.config.atlas.DbConfig;
import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.sql.Connection;

public class AtlasAgent {

    private static final Logger LOG = LoggerFactory.getLogger(AtlasAgent.class);
    private static Boolean dbInitialized = false;
    private static BasicDataSource dataSource = new BasicDataSource();
    private static Boolean readDbInitialized = false;
    private static BasicDataSource readDataSource = new BasicDataSource();
    private static File dbcpLogFile;
    private static Writer dbcpLogWriter;

    public static Connection getGBSConnection() throws Exception {
        synchronized (dbInitialized) {
            if (!dbInitialized) {
                DbConfig dbConfig = new DbConfig();

                final String dbUrl = dbConfig.getUrl();
                LOG.info("\n***********************************************************************************************\n" +
                        "Initializing Write-data-source and connecting, using:\n" + dbUrl +
                        "\n***********************************************************************************************");

                dataSource.setDriverClassName(dbConfig.getDriverClassName());
                dataSource.setUrl(dbConfig.getUrl());
                dataSource.setUsername(dbConfig.getUsername());
                dataSource.setPassword(dbConfig.getPassword());
                dataSource.addConnectionProperty("ssl", "true");
                dataSource.addConnectionProperty("sslmode", "verify-ca");
                dataSource.addConnectionProperty("sslfactory", "org.postgresql.ssl.NonValidatingFactory");
                dataSource.setInitialSize(10);
                dataSource.setMinIdle(10);
                dataSource.setMaxIdle(10);
                dataSource.setMaxActive(60);
                dataSource.setMaxWait(-1); //wait indefinitely
                dataSource.setValidationQuery("select version()");
                dataSource.setTestOnBorrow(true);
                dataSource.setTimeBetweenEvictionRunsMillis(120000); //evict idle connections every 10 minutes
                dataSource.setNumTestsPerEvictionRun(10);
                //prevent data source leaks and log offenders
                dataSource.setRemoveAbandoned(true);
                dataSource.setRemoveAbandonedTimeout(180);
                dataSource.setLogAbandoned(true);
                dataSource.setLogWriter(new PrintWriter(System.out));
                dataSource.setAccessToUnderlyingConnectionAllowed(false); //do not allow direct access to connection
                //setup log file for production logging
                File prodLogDirectory = new File("/na1000app-gbs/log/");
                if (prodLogDirectory.exists()) {
                    //only configure logger for production
                    dbcpLogFile = new File(prodLogDirectory.getPath() + File.separator + "dbcp.log");
                    dbcpLogWriter = new BufferedWriter(new FileWriter(dbcpLogFile));
                    dbcpLogWriter.write("Epoch\tActive\tIdle\tTotal\n");
                    dbcpLogWriter.flush();
                }
                dbInitialized = true;
            }
        }
        Connection con = dataSource.getConnection();
        if (dbcpLogFile != null) {
            //to keep the log file terse, use unix epoch as the date indicator
            dbcpLogWriter.write((System.currentTimeMillis() / 1000) + "\t" + dataSource.getNumActive() + "\t" + dataSource.getNumIdle() + "\t" + (dataSource.getNumActive() + dataSource.getNumIdle()) + "\n");
            dbcpLogWriter.flush();
        }
        return con;
    }

    public static Connection getReadGBSConnection() throws Exception {
        synchronized (readDbInitialized) {
            if (!readDbInitialized) {
                DbConfig dbConfig = new DbConfig();
                final String dbUrl = dbConfig.getReadDbUrl();

                LOG.info("\n***********************************************************************************************\n" +
                        "Initializing read-data-source and connecting, using:\n" + dbUrl +
                        "\n***********************************************************************************************");

                readDataSource.setDriverClassName(dbConfig.getDriverClassName());
                readDataSource.setUrl(dbConfig.getReadDbUrl());
                readDataSource.setUsername(dbConfig.getReadDbUsername());
                readDataSource.setPassword(dbConfig.getReadDbPassword());
                readDataSource.addConnectionProperty("ssl", "true");
                readDataSource.addConnectionProperty("sslfactory", "org.postgresql.ssl.NonValidatingFactory");
                readDataSource.setInitialSize(10);
                readDataSource.setMinIdle(10);
                readDataSource.setMaxIdle(10);
                readDataSource.setMaxActive(60);
                readDataSource.setMaxWait(-1); //wait indefinitely
                readDataSource.setValidationQuery("select version()");
                readDataSource.setTestOnBorrow(true);
                readDataSource.setTimeBetweenEvictionRunsMillis(120000); //evict idle connections every 10 minutes
                readDataSource.setNumTestsPerEvictionRun(10);
                //prevent data source leaks and log offenders
                readDataSource.setRemoveAbandoned(true);
                readDataSource.setRemoveAbandonedTimeout(180);
                readDataSource.setLogAbandoned(true);
                readDataSource.setLogWriter(new PrintWriter(System.out));
                readDataSource.setAccessToUnderlyingConnectionAllowed(false); //do not allow direct access to connection
                //setup log file for production logging
                File prodLogDirectory = new File("/na1000app-gbs/readLog/");
                if (prodLogDirectory.exists()) {
                    //only configure logger for production
                    dbcpLogFile = new File(prodLogDirectory.getPath() + File.separator + "dbcp.log");
                    dbcpLogWriter = new BufferedWriter(new FileWriter(dbcpLogFile));
                    dbcpLogWriter.write("Epoch\tActive\tIdle\tTotal\n");
                    dbcpLogWriter.flush();
                }
                readDbInitialized = true;
            }
        }
        Connection con = readDataSource.getConnection();
        if (dbcpLogFile != null) {
            //to keep the log file terse, use unix epoch as the date indicator
            dbcpLogWriter.write((System.currentTimeMillis() / 1000) + "\t" + readDataSource.getNumActive() + "\t" + readDataSource.getNumIdle() + "\t" + (readDataSource.getNumActive() + readDataSource.getNumIdle()) + "\n");
            dbcpLogWriter.flush();
        }
        return con;
    }


    public static void main(String[] args) {
        if (args.length > 0) {
            try {
                LOG.info("Sleeping 10 seconds, attach debugger now!!!!");
                Thread.sleep(10000);
            } catch (InterruptedException ignored) {
            }
        }
        //start agent manager
        new Thread(new AgentManager()).start();
    }

    @Override
    protected void finalize() throws Throwable {
        ServiceCommon.freeResource(dbcpLogWriter);
    }
}

