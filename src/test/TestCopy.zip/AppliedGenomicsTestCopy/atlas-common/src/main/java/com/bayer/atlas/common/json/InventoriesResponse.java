package com.bayer.atlas.common.json;

/**
 * Created by svant on 6/25/2018.
 */
public class InventoriesResponse {

    private String isolation_category_id;

    private String germplasmId;

    private String barcode;

    private String id;

    private String breeding_program;

    private String line_name;

    private String line_code;

    private String lineCode;

    private String crop;

    private String parent1GermplasmId;

    private String parent2GermplasmId;


    public String getLine_name() {
        return line_name;
    }

    public void setLine_name(String line_name) {
        this.line_name = line_name;
    }

    public String getLine_code() {
        return line_code;
    }

    public void setLine_code(String line_code) {
        this.line_code = line_code;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getIsolation_category_id() {
        return isolation_category_id;
    }

    public void setIsolation_category_id(String isolation_category_id) {
        this.isolation_category_id = isolation_category_id;
    }

    public String getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(String germplasmId) {
        this.germplasmId = germplasmId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBreeding_program() {
        return breeding_program;
    }

    public void setBreeding_program(String breeding_program) {
        this.breeding_program = breeding_program;
    }

    public String getParent1GermplasmId() {
        return parent1GermplasmId;
    }

    public void setParent1GermplasmId(String parent1GermplasmId) {
        this.parent1GermplasmId = parent1GermplasmId;
    }

    public String getParent2GermplasmId() {
        return parent2GermplasmId;
    }

    public void setParent2GermplasmId(String parent2GermplasmId) {
        this.parent2GermplasmId = parent2GermplasmId;
    }
}
