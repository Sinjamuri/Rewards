package com.bayer.atlas.common.json;

public class InventoryIdResponse {

    private Integer isolationCategoryId;
    private String barcode;
    private String breedingProgram;
    private Long id;

    public Integer getIsolationCategoryId() {
        return isolationCategoryId;
    }

    public void setIsolationCategoryId(Integer isolationCategoryId) {
        this.isolationCategoryId = isolationCategoryId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getBreedingProgram() {
        return breedingProgram;
    }

    public void setBreedingProgram(String breedingProgram) {
        this.breedingProgram = breedingProgram;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
