package com.bayer.atlas.common.json;

public class GemsSampleServiceResp {
    private String LIMS_ID;
    private String FBLOCK;
    private String BLOCK_BARCODE_NBR;
    private int SAMPLE_ID;
    private int barcodeIndexPlate;
    private int POS;
    private String GENERATION_NAME;
    private int CROP_ID;
    private String PARENT_CODE;
    private String WELL_STATUS_CD;

    private String WELL_NBR;
    private int PLATE_TEMPLATE_ROW_NBR;
    private int PLATE_TEMPLATE_COLUMN_NBR;

    private int ACTIVE_SAMPLE_CNT;
    private int DROP_SAMPLE_CNT;
    private int CONTROL_CNT;
    private int EPLATE_CNT;

    private int WELL_POSITION;

    private String ORIGIN;
    private String PEDIGREE_NAME;
    private String LINE_CODE;

    private String GENETIC_MATERIAL_ID;
    private Long GERMPLASM_ID;
    private String INVENTORY_ID;
    private String BARCODE;
    private String SAMPLE_NBR;

    private String ORIGIN_TXT;
    private String MOLECULAR_BREEDING_REQUEST_NBR;

    private int MAB_PROJECT_CYCLE_STATUS_ID;
    private String DATA_DUE_DATE;
    private String SAMPLE_DELIVERY_DATE;
    private String LAST_STATUS_UPDATE;

    private Double PCT;

    private int cnt;
    private int COUNT;

    private String LIMS_PROJECT;
    private String DUE_DATE;
    private int SAMPLE_CNT;
    private int COLUMN_CNT;
    private String OLIGO_POOL;

    private String COLUMN_DATA;
    private String CROP_NAME;

    private String ARRIVED_TIME;

    private String id;

    private InventoriesResponse inventoriesResponse;

    public String getFBLOCK() {
        return FBLOCK;
    }

    public void setFBLOCK(String FBLOCK) {
        this.FBLOCK = FBLOCK;
    }

    public String getCROP_NAME() {
        return CROP_NAME;
    }

    public void setCROP_NAME(String CROP_NAME) {
        this.CROP_NAME = CROP_NAME;
    }

    public String getARRIVED_TIME() {
        return ARRIVED_TIME;
    }

    public void setARRIVED_TIME(String ARRIVED_TIME) {
        this.ARRIVED_TIME = ARRIVED_TIME;
    }

    public String getLIMS_ID() {
        return LIMS_ID;
    }

    public void setLIMS_ID(String LIMS_ID) {
        this.LIMS_ID = LIMS_ID;
    }

    public String getBLOCK_BARCODE_NBR() {
        return BLOCK_BARCODE_NBR;
    }

    public void setBLOCK_BARCODE_NBR(String BLOCK_BARCODE_NBR) {
        this.BLOCK_BARCODE_NBR = BLOCK_BARCODE_NBR;
    }

    public int getSAMPLE_ID() {
        return SAMPLE_ID;
    }

    public void setSAMPLE_ID(int SAMPLE_ID) {
        this.SAMPLE_ID = SAMPLE_ID;
    }

    public int getBarcodeIndexPlate() {
        return barcodeIndexPlate;
    }

    public void setBarcodeIndexPlate(int barcodeIndexPlate) {
        this.barcodeIndexPlate = barcodeIndexPlate;
    }

    public int getPOS() {
        return POS;
    }

    public void setPOS(int POS) {
        this.POS = POS;
    }

    public String getGENERATION_NAME() {
        return GENERATION_NAME;
    }

    public void setGENERATION_NAME(String GENERATION_NAME) {
        this.GENERATION_NAME = GENERATION_NAME;
    }

    public int getCROP_ID() {
        return CROP_ID;
    }

    public void setCROP_ID(int CROP_ID) {
        this.CROP_ID = CROP_ID;
    }

    public String getPARENT_CODE() {
        return PARENT_CODE;
    }

    public void setPARENT_CODE(String PARENT_CODE) {
        this.PARENT_CODE = PARENT_CODE;
    }

    public String getWELL_STATUS_CD() {
        return WELL_STATUS_CD;
    }

    public void setWELL_STATUS_CD(String WELL_STATUS_CD) {
        this.WELL_STATUS_CD = WELL_STATUS_CD;
    }

    public String getWELL_NBR() {
        return WELL_NBR;
    }

    public void setWELL_NBR(String WELL_NBR) {
        this.WELL_NBR = WELL_NBR;
    }

    public int getPLATE_TEMPLATE_ROW_NBR() {
        return PLATE_TEMPLATE_ROW_NBR;
    }

    public void setPLATE_TEMPLATE_ROW_NBR(int PLATE_TEMPLATE_ROW_NBR) {
        this.PLATE_TEMPLATE_ROW_NBR = PLATE_TEMPLATE_ROW_NBR;
    }

    public int getPLATE_TEMPLATE_COLUMN_NBR() {
        return PLATE_TEMPLATE_COLUMN_NBR;
    }

    public void setPLATE_TEMPLATE_COLUMN_NBR(int PLATE_TEMPLATE_COLUMN_NBR) {
        this.PLATE_TEMPLATE_COLUMN_NBR = PLATE_TEMPLATE_COLUMN_NBR;
    }

    public int getACTIVE_SAMPLE_CNT() {
        return ACTIVE_SAMPLE_CNT;
    }

    public void setACTIVE_SAMPLE_CNT(int ACTIVE_SAMPLE_CNT) {
        this.ACTIVE_SAMPLE_CNT = ACTIVE_SAMPLE_CNT;
    }

    public int getDROP_SAMPLE_CNT() {
        return DROP_SAMPLE_CNT;
    }

    public void setDROP_SAMPLE_CNT(int DROP_SAMPLE_CNT) {
        this.DROP_SAMPLE_CNT = DROP_SAMPLE_CNT;
    }

    public int getCONTROL_CNT() {
        return CONTROL_CNT;
    }

    public void setCONTROL_CNT(int CONTROL_CNT) {
        this.CONTROL_CNT = CONTROL_CNT;
    }

    public int getEPLATE_CNT() {
        return EPLATE_CNT;
    }

    public void setEPLATE_CNT(int EPLATE_CNT) {
        this.EPLATE_CNT = EPLATE_CNT;
    }

    public int getWELL_POSITION() {
        return WELL_POSITION;
    }

    public void setWELL_POSITION(int WELL_POSITION) {
        this.WELL_POSITION = WELL_POSITION;
    }

    public String getORIGIN() {
        return ORIGIN;
    }

    public void setORIGIN(String ORIGIN) {
        this.ORIGIN = ORIGIN;
    }

    public String getPEDIGREE_NAME() {
        return PEDIGREE_NAME;
    }

    public void setPEDIGREE_NAME(String PEDIGREE_NAME) {
        this.PEDIGREE_NAME = PEDIGREE_NAME;
    }

    public String getLINE_CODE() {
        return LINE_CODE;
    }

    public void setLINE_CODE(String LINE_CODE) {
        this.LINE_CODE = LINE_CODE;
    }

    public String getGENETIC_MATERIAL_ID() {
        return GENETIC_MATERIAL_ID;
    }

    public void setGENETIC_MATERIAL_ID(String GENETIC_MATERIAL_ID) {
        this.GENETIC_MATERIAL_ID = GENETIC_MATERIAL_ID;
    }

    public Long getGERMPLASM_ID() {
        return GERMPLASM_ID;
    }

    public void setGERMPLASM_ID(Long GERMPLASM_ID) {
        this.GERMPLASM_ID = GERMPLASM_ID;
    }

    public String getINVENTORY_ID() {
        return INVENTORY_ID;
    }

    public void setINVENTORY_ID(String INVENTORY_ID) {
        this.INVENTORY_ID = INVENTORY_ID;
    }

    public String getBARCODE() {
        return BARCODE;
    }

    public void setBARCODE(String BARCODE) {
        this.BARCODE = BARCODE;
    }

    public String getSAMPLE_NBR() {
        return SAMPLE_NBR;
    }

    public void setSAMPLE_NBR(String SAMPLE_NBR) {
        this.SAMPLE_NBR = SAMPLE_NBR;
    }

    public String getORIGIN_TXT() {
        return ORIGIN_TXT;
    }

    public void setORIGIN_TXT(String ORIGIN_TXT) {
        this.ORIGIN_TXT = ORIGIN_TXT;
    }

    public String getMOLECULAR_BREEDING_REQUEST_NBR() {
        return MOLECULAR_BREEDING_REQUEST_NBR;
    }

    public void setMOLECULAR_BREEDING_REQUEST_NBR(String MOLECULAR_BREEDING_REQUEST_NBR) {
        this.MOLECULAR_BREEDING_REQUEST_NBR = MOLECULAR_BREEDING_REQUEST_NBR;
    }

    public Double getPCT() {
        return PCT;
    }

    public void setPCT(Double PCT) {
        this.PCT = PCT;
    }

    public int getMAB_PROJECT_CYCLE_STATUS_ID() {
        return MAB_PROJECT_CYCLE_STATUS_ID;
    }

    public void setMAB_PROJECT_CYCLE_STATUS_ID(int MAB_PROJECT_CYCLE_STATUS_ID) {
        this.MAB_PROJECT_CYCLE_STATUS_ID = MAB_PROJECT_CYCLE_STATUS_ID;
    }

    public String getDATA_DUE_DATE() {
        return DATA_DUE_DATE;
    }

    public void setDATA_DUE_DATE(String DATA_DUE_DATE) {
        this.DATA_DUE_DATE = DATA_DUE_DATE;
    }

    public String getSAMPLE_DELIVERY_DATE() {
        return SAMPLE_DELIVERY_DATE;
    }

    public void setSAMPLE_DELIVERY_DATE(String SAMPLE_DELIVERY_DATE) {
        this.SAMPLE_DELIVERY_DATE = SAMPLE_DELIVERY_DATE;
    }

    public String getLAST_STATUS_UPDATE() {
        return LAST_STATUS_UPDATE;
    }

    public void setLAST_STATUS_UPDATE(String LAST_STATUS_UPDATE) {
        this.LAST_STATUS_UPDATE = LAST_STATUS_UPDATE;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public int getCOUNT() {
        return COUNT;
    }

    public void setCOUNT(int COUNT) {
        this.COUNT = COUNT;
    }

    public String getLIMS_PROJECT() {
        return LIMS_PROJECT;
    }

    public void setLIMS_PROJECT(String LIMS_PROJECT) {
        this.LIMS_PROJECT = LIMS_PROJECT;
    }

    public String getDUE_DATE() {
        return DUE_DATE;
    }

    public void setDUE_DATE(String DUE_DATE) {
        this.DUE_DATE = DUE_DATE;
    }

    public int getSAMPLE_CNT() {
        return SAMPLE_CNT;
    }

    public void setSAMPLE_CNT(int SAMPLE_CNT) {
        this.SAMPLE_CNT = SAMPLE_CNT;
    }

    public int getCOLUMN_CNT() {
        return COLUMN_CNT;
    }

    public void setCOLUMN_CNT(int COLUMN_CNT) {
        this.COLUMN_CNT = COLUMN_CNT;
    }

    public String getOLIGO_POOL() {
        return OLIGO_POOL;
    }

    public void setOLIGO_POOL(String OLIGO_POOL) {
        this.OLIGO_POOL = OLIGO_POOL;
    }

    public String getCOLUMN_DATA() {
        return COLUMN_DATA;
    }

    public void setCOLUMN_DATA(String COLUMN_DATA) {
        this.COLUMN_DATA = COLUMN_DATA;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public InventoriesResponse getInventoriesResponse() {
        return inventoriesResponse;
    }

    public void setInventoriesResponse(InventoriesResponse inventoriesResponse) {
        this.inventoriesResponse = inventoriesResponse;
    }
}
