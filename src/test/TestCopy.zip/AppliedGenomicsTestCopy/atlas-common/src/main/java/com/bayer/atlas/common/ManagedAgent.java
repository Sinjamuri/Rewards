package com.bayer.atlas.common;

import com.bayer.atlas.common.utils.ServiceCommon;
import com.bayer.atlas.common.utils.UtilCommon;
import com.bayer.atlas.common.utils.WfUtilCommon;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.Map;

public abstract class ManagedAgent implements Runnable {
    //convenient invocation intervals
    public static final long INVOCATION_INTERVAL_SECOND = 1000;
    //public abstract void invoke(int entityToProcess) throws Throwable;
    //public abstract void invoke(String entityToProcess) throws Throwable;
    public static final long INVOCATION_INTERVAL_SECONDS_5 = INVOCATION_INTERVAL_SECOND * 5;
    public static final long INVOCATION_INTERVAL_SECONDS_20 = INVOCATION_INTERVAL_SECOND * 20;
    public static final long INVOCATION_INTERVAL_MINUTE = INVOCATION_INTERVAL_SECOND * 60;
    public static final long INVOCATION_INTERVAL_MINUTES_2 = INVOCATION_INTERVAL_MINUTE * 2;
    public static final long INVOCATION_INTERVAL_MINUTES_5 = INVOCATION_INTERVAL_MINUTE * 5;
    public static final long INVOCATION_INTERVAL_MINUTES_15 = INVOCATION_INTERVAL_MINUTE * 15;
    public static final long INVOCATION_INTERVAL_HOUR = INVOCATION_INTERVAL_MINUTE * 60;
    public static final long INVOCATION_INTERVAL_DAY = INVOCATION_INTERVAL_HOUR * 24;
    private static final Logger LOG = LoggerFactory.getLogger(ManagedAgent.class);
    private static final String WF_CONFIG_PROPERTY_PAUSE_ALL_KEY_VALUE = "PAUSE_ALL_AGENTS";
    Connection con;
    private Long wfConfigId;
    private Long agentId;
    private String[] args;
    private Map<String, Object> properties;
    private long intervalBetweenInvocationsMillis;
    private boolean agentRunning;
    private boolean autoCommit = false;
    private long lastInvocationMillis;
    private boolean forceEnabled = false;

    public ManagedAgent(long intervalBetweenInvocationsMillis, boolean autoCommit) {
        try {
            this.autoCommit = autoCommit;
            this.intervalBetweenInvocationsMillis = intervalBetweenInvocationsMillis;
            //initialize connection
            refreshConnection();
            //self register the agent
            checkAgentRegistry();
        } catch (Throwable t) {
            logTopLevelException(t);
        }
    }

    public abstract void invoke() throws Throwable;

    private void refreshConnection() {
        freeConnection();
        try {
            con = AtlasAgent.getGBSConnection();
            con.setAutoCommit(false);
        } catch (Throwable t) {
            logTopLevelException(t);
        }
    }

    @Override
    public final void run() {
        updateStart();
        agentRunning = true;
        while (true) {
            LOG.info("inside run loop of manage agent");
            //re-establish connectione
            refreshConnection();
            //exit the infinite loop if a restart was triggered
            if (restartRequired()) {
                break;
            }
            if (forceEnabled || isAgentEnabled()) {
                try {
                    LOG.info("Invoking:" + this.getAgentName(false));
                    updateStatus("Running");
                    long start = System.currentTimeMillis();
                    setProperties(WfUtilCommon.getChildProperties(con, getClass().getName()));
                    invoke();
                    lastInvocationMillis = System.currentTimeMillis() - start;
                } catch (Throwable t) {
                    logTopLevelException(t);
                }
                updateActive();
            } else {
                updateStatus("Disabled");
            }
            //sleep for the configured time
            try {
                ServiceCommon.freeResource(con);
                Thread.sleep(intervalBetweenInvocationsMillis);
            } catch (InterruptedException ex) {
                LOG.info(getClass().getName() + " sleep has been interrupted");
                break;
            }
        }
        agentRunning = false;
    }

    private boolean isAgentEnabled() {

        try {
            if (pauseAllAgents(this.wfConfigId)) { // check WF_CONFIG_PROPERTIES to see if the agents for this wf are set to not invoke
                LOG.info("PAUSE_ALL_AGENTS=Y for WF_CONFIG_ID=" + wfConfigId + ", paused: " + getAgentName(false) + "(id=" + this.agentId + ")");
                return false;
            } else {
                final String SQL_ENABLED = "select agent_enabled from ATLAS.wf_agent where wf_agent_id=?";
                PreparedStatement pstmtEnabled = null;
                ResultSet rsEnabled = null;
                try {
                    pstmtEnabled = con.prepareStatement(SQL_ENABLED);
                    pstmtEnabled.setLong(1, this.agentId);
                    rsEnabled = pstmtEnabled.executeQuery();
                    if (rsEnabled.next()) {
                        return ("Y".equals(rsEnabled.getString(1)));
                    } else {
                        //this should never happen because the agent self registers in
                        //the constructor of the ManagedAgent super class
                        return false;
                    }
                } catch (Throwable t) {
                    LOG.error("Unexpected exception", t);
                    //if an error is thrown, it is better to disable the agent
                    return false;
                } finally {
                    ServiceCommon.freeResource(rsEnabled);
                    ServiceCommon.freeResource(pstmtEnabled);
                }
            }
        } catch (Exception e) {
            LOG.error("Unexpected exception", e);
            return false;
        }

    }

    private boolean restartRequired() {
        final String SQL_RESTART = "select restart_ts from ATLAS.wf_agent where wf_agent_id=?";
        final String SQL_RESET = "update ATLAS.wf_agent set restart_ts=null where wf_agent_id=?";
        PreparedStatement pstmtRestart = null;
        ResultSet rsRestart = null;
        PreparedStatement pstmtReset = null;
        try {
            pstmtRestart = con.prepareStatement(SQL_RESTART);
            pstmtReset = con.prepareStatement(SQL_RESET);
            pstmtRestart.setLong(1, this.agentId);
            rsRestart = pstmtRestart.executeQuery();
            rsRestart.next();
            if (rsRestart.getTimestamp(1) != null) {
                //reset timestamp for restart, AgentManager will handle the rest
                pstmtReset.setLong(1, this.agentId);
                pstmtReset.executeUpdate();
                con.commit();
                updateStatus("Restarting agent");
                return true;
            } else {
                return false;
            }
        } catch (Throwable t) {
            LOG.error("Unexpected exception", t);
            //if an error is thrown, it is better to not restart
            return false;
        } finally {
            ServiceCommon.freeResource(rsRestart);
            ServiceCommon.freeResource(pstmtRestart);
            ServiceCommon.freeResource(pstmtReset);
        }
    }

    private void checkAgentRegistry() {
        final String SQL_FIND = "select wf_agent_id,agent_args,wf_config_id from ATLAS.wf_agent where agent_classpath=?";
        final String SQL_NEXT_AGENT_ID = "select nextval('ATLAS.wf_agent_id_seq') dual";
        final String SQL_REGISTER = "insert into ATLAS.wf_agent (wf_agent_id,agent_classpath,agent_enabled,registered_ts,agent_status) " +
                "values (?,?,'N',now(),'Registered')";
        PreparedStatement pstmtFind = null;
        ResultSet rsFind = null;
        PreparedStatement pstmtNextAgentId = null;
        ResultSet rsNextAgentId = null;
        PreparedStatement pstmtRegister = null;
        try {
            pstmtFind = con.prepareStatement(SQL_FIND);
            pstmtNextAgentId = con.prepareStatement(SQL_NEXT_AGENT_ID);
            pstmtRegister = con.prepareStatement(SQL_REGISTER);
            pstmtFind.setString(1, getClass().getName());
            rsFind = pstmtFind.executeQuery();
            if (rsFind.next()) {
                wfConfigId = rsFind.getLong("wf_config_id");
                agentId = rsFind.getLong("wf_agent_id");
                String agentArgs = rsFind.getString("agent_args");
                if (agentArgs != null) {
                    args = agentArgs.split("\\|");
                }
            }
            //register the agent for the first time if not found
            if (agentId == null) {
                String sqlInsert =
                        "insert into ATLAS.wf_agent (wf_agent_id,agent_classpath,agent_enabled,registered_ts,agent_status,wf_config_id) " +
                                "values (nextval(ATLAS.wf_agent_id_seq),'" + getClass().getName() + "','N',now(),'Registered', ?)";
                LOG.info("New agent is not registered.\nReplace ? with wf_config_id and execute this statement:\n" + sqlInsert);
        /*rsNextAgentId = pstmtNextAgentId.executeQuery();
        rsNextAgentId.next();
       this.agentId = rsNextAgentId.getLong(1);
        //self register the agent
        pstmtRegister.setLong(1, this.agentId);
        pstmtRegister.setString(2, getClass().getName());
        pstmtRegister.executeUpdate();
        con.commit();*/
            }
        } catch (Throwable t) {
            LOG.error("Unexpected exception", t);
        } finally {
            ServiceCommon.freeResource(rsFind);
            ServiceCommon.freeResource(pstmtFind);
            ServiceCommon.freeResource(rsNextAgentId);
            ServiceCommon.freeResource(pstmtNextAgentId);
            ServiceCommon.freeResource(pstmtRegister);
        }
    }

    private void updateStart() {
        final String SQL_UPDATE = "update ATLAS.wf_agent set start_ts=now() where wf_agent_id=?";
        PreparedStatement pstmtUpdate = null;
        try {
            pstmtUpdate = con.prepareStatement(SQL_UPDATE);
            pstmtUpdate.setLong(1, this.agentId);
            pstmtUpdate.executeUpdate();
            con.commit();
        } catch (Throwable t) {
            LOG.error("Unexpected exception", t);
            LOG.error(t.getMessage());
        } finally {
            ServiceCommon.freeResource(pstmtUpdate);
        }
    }

    void updateActive() {
        final String SQL_UPDATE = "update ATLAS.wf_agent set active_ts=now() where wf_agent_id=?";
        PreparedStatement pstmtUpdate = null;
        try {
            pstmtUpdate = con.prepareStatement(SQL_UPDATE);
            pstmtUpdate.setLong(1, this.agentId);
            pstmtUpdate.executeUpdate();
            con.commit();
        } catch (Throwable t) {
            LOG.error("Unexpected exception", t);
            LOG.error("this.agentId=" + this.agentId);
        } finally {
            ServiceCommon.freeResource(pstmtUpdate);
        }
    }

    public void updateTimeCost() {
        updateStatus("Last invocation completed in " + lastInvocationMillis + " ms.");
    }

    public void updateTimeCost(int records) {
        updateStatus("Last invocation affecting " + records + " records completed in " + lastInvocationMillis + " ms.");
    }

    public void updateStatus(String status) {
        final String SQL_UPDATE = "update ATLAS.wf_agent set agent_status=? where wf_agent_id=?";
        PreparedStatement pstmtUpdate = null;
        try {
            pstmtUpdate = con.prepareStatement(SQL_UPDATE);
            pstmtUpdate.setString(1, status);
            pstmtUpdate.setLong(2, this.agentId);
            pstmtUpdate.executeUpdate();
            con.commit();
        } catch (Throwable t) {
            LOG.error("Unexpected exception", t);
            t.getMessage();
        } finally {
            ServiceCommon.freeResource(pstmtUpdate);
        }
    }

    public void logTopLevelException(Throwable t) {
        t.printStackTrace();
        updateStatus("An unexpected exception was thrown: " + UtilCommon.getStackTrace(t));
        LOG.error("Unexpected exception", t);
    }

    public Connection getConnection() {
        try {
            con.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }

    public boolean isAgentRunning() {
        return agentRunning;
    }

    public String[] getArgs() {
        return args;
    }

    public void setArgs(String[] args) {
        this.args = args;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }

    public Object getProperty(String key) {
        return getProperties().get(key);
    }

    @Override
    protected void finalize() throws Throwable {
        //allow garbage collection to free the database connection
        //from the DBCP connection pool
        ServiceCommon.freeResource(con);
    }

    protected void freeConnection() {
        //allow garbage collection to free the database connection
        //from the DBCP connection pool
        ServiceCommon.freeResource(con);
    }

    public void setForceEnabled() {
        LOG.info("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        LOG.info("Force enabled is set for " + getClass().getName() + " - This should only be used while debugging an agent class!!!!!");
        LOG.info("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        forceEnabled = true;
    }

    public boolean isForceEnabled() {
        return forceEnabled;
    }

    private boolean pauseAllAgents(long wfConfigId) throws Exception {

        // Return true if the PAUSE_ALL_AGENTS key in WF_CONFIG_PROPERTIES has been set to pause the agents for this workflow
        // value_varchar2=Y and value_number=wf_config_ids from wf_agent to pause
        if ("Y".equals(WfUtilCommon.getWfConfigProperyString(getConnection(), 1, WF_CONFIG_PROPERTY_PAUSE_ALL_KEY_VALUE)) &&
                this.wfConfigId == getWfConfigIdToPause()) {
            return true;
        } else {
            return false;
        }
    }

    private Long getWfConfigIdToPause() throws Exception {
        return WfUtilCommon.getWfConfigPropertyNumber(getConnection(), 1L, WF_CONFIG_PROPERTY_PAUSE_ALL_KEY_VALUE, Long.class).longValue();
    }

    private String getAgentName(boolean fullClasspath) {

        String agentName = "";
        String[] classpathParts = null;
        try {
            final String SQL = "select agent_classpath from ATLAS.wf_agent where wf_agent_id=?";
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            try {
                pstmt = con.prepareStatement(SQL);
                pstmt.setLong(1, this.agentId);
                rs = pstmt.executeQuery();
                rs.next();
                agentName = rs.getString(1);
            } catch (Throwable t) {
                LOG.error("Unexpected exception", t);
            } finally {
                ServiceCommon.freeResource(pstmt);
                ServiceCommon.freeResource(rs);
            }
        } catch (Exception e) {
            LOG.error("Unexpected exception", e);
        }
        if (fullClasspath) {
            return agentName; //ex:  com.monsanto.gwg.atlas.agent.gbs.TorrentAnalysisAgent
        } else {
            return agentName.split("\\.")[agentName.split("\\.").length - 1];  // ex: TorrentAnalysisAgent
        }

    }

    protected void logExecutionInfo(String agentName, String[] args, Timestamp startTs, String userName, String status) {

        final String SQL_INSERT = "insert into ATLAS.wf_agent_log (WF_AGENT_NAME ,ARGS ,CREATE_TS ,CREATE_USER ,STATUS) values (?,?,?,?,?)";
        StringBuilder sb = new StringBuilder();
        for (String arg : args) {
            sb.append(arg).append(",");
        }
        if (sb.length() == 0) {
            sb.append(",");
        }
        LOG.info(sb.toString());
        PreparedStatement pstmtInsert = null;
        try {
            pstmtInsert = con.prepareStatement(SQL_INSERT);
            pstmtInsert.setString(1, agentName);
            pstmtInsert.setString(2, sb.substring(0, sb.length() - 1));
            pstmtInsert.setTimestamp(3, startTs);
            pstmtInsert.setString(4, userName);
            pstmtInsert.setString(5, status);
            pstmtInsert.execute();
            con.commit();
        } catch (Throwable t) {
            LOG.error("Unexpected exception", t);
        } finally {
            ServiceCommon.freeResource(pstmtInsert);
        }
    }

    protected void updateExecutionInfo(String agentName, Timestamp startTs, Timestamp completeTs, String status) {

        final String SQL_UPDATE = "update ATLAS.wf_agent_log set COMPLETE_TS=?, STATUS=? where WF_AGENT_NAME=? and CREATE_TS=?";
        PreparedStatement pstmtUpdate = null;
        try {
            pstmtUpdate = con.prepareStatement(SQL_UPDATE);
            pstmtUpdate.setTimestamp(1, completeTs);
            pstmtUpdate.setString(2, status);
            pstmtUpdate.setString(3, agentName);
            pstmtUpdate.setTimestamp(4, startTs);
            pstmtUpdate.execute();
            con.commit();
        } catch (Throwable t) {
            LOG.error("Unexpected exception", t);
        } finally {
            ServiceCommon.freeResource(pstmtUpdate);
        }
    }
}

