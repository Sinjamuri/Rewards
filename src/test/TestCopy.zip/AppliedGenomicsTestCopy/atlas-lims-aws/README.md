# atlas-lims-aws
This repository is created for accessing functionality deployed as lambda, mostly file processing on atlas applied-genomics.
