package com.monsanto.aws;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.google.gson.Gson;
import com.monsanto.aws.json.JsonModel;
import com.monsanto.aws.pojo.CloudWatchMessage;
import com.monsanto.aws.pojo.CloudWatchRequest;
import com.monsanto.aws.pojo.CloudWatchResponse;
//import com.monsanto.aws.util.DbConnectionUtil;
import com.monsanto.aws.util.Util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Created by ashar7 on 3/25/2016.
 */
public class CloudWatchAgent extends Util implements RequestHandler<CloudWatchRequest,CloudWatchResponse> {

  public static void main(String[] args){
/*    try {

      Connection conn = DbConnectionUtil.getGBSConnection();
      final String SQL_SELECT = "select * from ATLAS.WF_AGENT_LOG";

      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery(SQL_SELECT);
      while(rs.next()){
        System.out.println(rs.getString(1));
      }
    }catch(Exception e){
      e.printStackTrace();
    } */
  }

  @Override
  public CloudWatchResponse handleRequest(CloudWatchRequest request, Context context) {
    LambdaLogger logger = context.getLogger();

    //context logging
    logger.log("Log Group : " + context.getLogGroupName());
    logger.log("Log Stream : " + context.getLogStreamName());
    logger.log("Function Name : " + context.getFunctionName());
    logger.log("AWS Request Id : " + context.getAwsRequestId());
    logger.log("Memory Limit MB: " + context.getMemoryLimitInMB());
    logger.log("Remaining Time ms : " + context.getRemainingTimeInMillis());
    logger.log("Request: " + request.toString());

    CloudWatchResponse response = processRequestLog(request.getAwslogs().getData(), logger);


    return response;
  }

  public CloudWatchResponse processRequestLog(String requestLogData, LambdaLogger logger) {
    //decode base64
    byte[] decodedBytes = decodeBase64(requestLogData);

    //incoming request is a zip file, decode and then convert to UTF-8
    String message = deCompressAndUTFencode(decodedBytes);

    //parse resultant Json string into object
    CloudWatchResponse response =  new Gson().fromJson(message, CloudWatchResponse.class);

    String streamName = response.getLogStream();
    String[] arr = streamName.split("_");
    String fileType = null;
    if(arr.length > 1){
      fileType = arr[1];
    }

    logger.log("Request LogGroup: " + response.getLogGroup());
    logger.log("Request LogStream: " + response.getLogStream());
    logger.log("Request MessageType: " + response.getMessageType());
    logger.log("Request Owner: " + response.getOwner());
    logger.log("Request Filters: " + response.getSubscriptionFilters());
    logger.log("Request Filter Pattern: " + response.getFilterPattern());

    for(CloudWatchMessage cloudWatchMessage : response.getLogEvents()){
      logger.log("Request Event Message: " + cloudWatchMessage.getMessage());
      logger.log("Request Event Timestamp: " + cloudWatchMessage.getTimestamp());
      logger.log("Request Event Id: " + cloudWatchMessage.getId());

      getParsedMessage(cloudWatchMessage, fileType);

      JsonModel jsonModel = callMethod(logger, arr[0], cloudWatchMessage);

      if(null != jsonModel){
        sendModelAsRequest(logger, jsonModel);
      }
    }
    return response;
  }
}
