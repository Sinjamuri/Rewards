package com.monsanto.aws.pojo;

/**
 * Created by ashar7 on 3/25/2016.
 */
public class CloudWatchRequest {

  private CloudWatchMessage awslogs;

  public CloudWatchMessage getAwslogs() {
    return awslogs;
  }

  public void setAwslogs(CloudWatchMessage awslogs) {
    this.awslogs = awslogs;
  }
}
