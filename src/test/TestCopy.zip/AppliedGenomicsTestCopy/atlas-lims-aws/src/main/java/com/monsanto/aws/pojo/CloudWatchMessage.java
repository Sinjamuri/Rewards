package com.monsanto.aws.pojo;

import com.amazonaws.services.s3.model.S3Object;

import java.io.InputStream;
import java.util.List;

/**
 * Created by ashar7 on 3/25/2016.
 */
public class CloudWatchMessage {
  private String id;
  private String timestamp;
  private String message;
  private String data;
  private List<String[]> parsedMessage;
  private S3Object objectData;
  private String key;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getData() {
    return data;
  }

  public void setData(String data) {
    this.data = data;
  }

  public List<String[]> getParsedMessage() {
    return parsedMessage;
  }

  public void setParsedMessage(List<String[]> parsedMessage) {
    this.parsedMessage = parsedMessage;
  }

  public S3Object getObjectData() {
    return objectData;
  }

  public void setObjectData(S3Object objectData) {
    this.objectData = objectData;
  }

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }
}
