package com.monsanto.aws;

import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.util.IOUtils;
import com.bayer.atlas.common.AnkTaqmanConstants;
import com.bayer.atlas.common.model.*;
import com.bayer.atlas.common.utils.UtilCommon;
import com.bayer.atlas.common.utils.WfDataUtils;
import com.bayer.atlas.common.utils.WfUtilCommon;
import com.bayer.atlas.common.utils.WfUtils;
import com.google.gson.Gson;
import com.monsanto.aws.json.JsonModel;
import com.monsanto.aws.pojo.Allele;
import com.monsanto.aws.pojo.CloudWatchMessage;
import com.monsanto.aws.pojo.ProjectDetail;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


/**
 * Created by SINJA on 06/24/2019
 * When a file is created/updated in s3 folder : AnkTaqmanLogs/createprojectagent-json, this agent is triggered.
 * Creates project and sample information in sampling queue.
 */
public class CreateProjectAgent {

  // Initialize the Log4j logger.
  static final Logger LOG = LoggerFactory.getLogger(CreateProjectAgent.class);
  public static final String INPUT_TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS";

  public JsonModel processMessage(LambdaLogger logger, CloudWatchMessage message) {

    logger.log("Start processing Message.key:"+message.getKey() +", id:"+message.getId());

    JsonModel jsonModel = new JsonModel();

    InputStream jsonInput = message.getObjectData().getObjectContent();

      String inputData = null;
      try {
          inputData = IOUtils.toString(jsonInput);
      } catch (IOException e) {
          e.printStackTrace();
      }

      Gson gson = new Gson();
    ProjectDetail project =  gson.fromJson(inputData, ProjectDetail.class);
    logger.log("Json Request:"+new Gson().toJson(project));
    jsonModel.setProjectDetail(project);

    try {
      processData(jsonModel);

    } catch (Exception e) {
      e.printStackTrace();
    }

    return jsonModel;
  }



  public void processData(JsonModel jsonModel) throws Exception {
    try {

      createProjectEntities(jsonModel.getProjectDetail());
      LOG.info("Agent Ran Succesfully..");
    } catch (Exception ex) {
      LOG.error("Error while creating Wf entries using the Json : "+ex.getMessage());
      throw ex;
    }finally{

    }
  }


  private void  createProjectEntities(ProjectDetail project) throws Exception{

      //create WfBase for project ... this will not have any wf_grid_data to it.
      //create WfBase for plate...this will have both wf_data and wf_grid_data to it.
      try {
        String projectId = project.getProjectId();
        /*if (!checkData(project)) {
          throw new Exception("Missing one or more of these mandatory data: Project Id, Crop, Sample Type, CreatedBy and Barcode.");
        }
        else */
        if (WfUtils.wfExists(projectId, AnkTaqmanConstants.Entities.PROJECT.getValue())) {
            throw new Exception("Project Id already exists.Cannot process ..");
          } else {
              WfBase projectWfBase = setProjectWfBase(project);
              List<WfData> projectWfDataList = createProjectWfDataList(project);
              projectWfBase.setWfDataList(projectWfDataList);
              projectWfBase.setCreateUser("Atlas");
              //make a api call to save the project info
              WfUtils.insertWf(projectWfBase);

              List<WfBase> wfBase=WfUtils.getWfByLabel(projectWfBase.getWfEntityLabel());

              //save assay entries after saving marker information
             insertProjectAssayWfData(project,wfBase.get(0).getWfId());

              List<ProjectDetail.Plate> platesList = project.getPlates();
              if (null != platesList) {
                List<WfBase> wfBaseList = WfUtils.getWfByLabelAndType(project.getProjectId(), AnkTaqmanConstants.Entities.PROJECT.getValue());
                if (wfBaseList.size() == 1) {
                  Long projectWfId = wfBaseList.get(0).getWfId();
                  for (ProjectDetail.Plate plate : platesList) {
                    String plateId = plate.getBarcode();
                   if (WfUtils.wfExists(plateId, AnkTaqmanConstants.Entities.F_BLOCK.getValue())) {
                      throw new Exception("Plate Id already exists.Cannot process ..");
                    } else {
                      WfBase plateWfBase = setPlateWfBase(project, plate);
                      //plate will have same data as project
                      projectWfDataList.add(new WfData(AnkTaqmanConstants.WfDataConfigs.F_BLOCK.getValue(),  plateId, null, null));
                      plateWfBase.setWfDataList(projectWfDataList);
                      plateWfBase.setWfGridBaseList(populateGridBaseList(project,plate));
                      plateWfBase.setCreateUser("ATLAS");

                      List wfAssocFromList = new ArrayList();
                      WfAssoc wfAssoc = new WfAssoc();
                      wfAssoc.setFromWfId(wfBaseList.get(0).getWfId());
                      wfAssoc.setSortKey(1L);
                      wfAssoc.setActive(true);
                      wfAssocFromList.add(wfAssoc);
                      plateWfBase.setWfAssocFromList(wfAssocFromList);
                      //Call API to insert Wf_data, Wf_grid_data, Wf_grid_assoc for plate
                      WfUtils.insertWf(plateWfBase);
                    }
                  }
                }
              }
            }
      }
      catch(Exception e){
      LOG.error("Error while creating project entities using the Json : "+e.getMessage());
        throw e;
      }

  }

  private WfBase setProjectWfBase(ProjectDetail project){
    WfBase projWfBase = new WfBase();
    projWfBase.setWfEntityLabel(project.getProjectId());
    projWfBase.setWfConfigId(AnkTaqmanConstants.ANK_TAQMAN_WF_CONFIG_ID);
    projWfBase.setWfEntityTypeId(AnkTaqmanConstants.Entities.PROJECT.getValue());
    projWfBase.setCreateUser(project.getCreatedBy());
    projWfBase.setWfStepConfigId(AnkTaqmanConstants.Steps.SAMPLING.getValue());
    projWfBase.setWfStatus(AnkTaqmanConstants.WfStatus.IN_PROGRESS.getValue());

    return projWfBase;
  }


  private void insertProjectAssayWfData( ProjectDetail project,long wfId) throws Exception {

    List<WfData> WfDataList=WfDataUtils.getWfByWfId(wfId);
    List<ProjectDetail.Markers> projectMarkers=project.getMarkers();

    for(ProjectDetail.Markers marker: projectMarkers)
    {
      List<WfData> markerWfDataList=new ArrayList();
      markerWfDataList=WfDataList.stream().filter(wfData ->  wfData.getWfDataConfigId() == AnkTaqmanConstants.WfDataConfigs.MARKER.getValue().longValue() &&wfData.getWfDataVarchar2().equalsIgnoreCase(marker.getMarkerName())).collect(Collectors.toList());
      WfData wfData = new WfData();
      wfData.setWfId(wfId);
      wfData.setWfDataAssocId(markerWfDataList.get(0).getWfDataId());
      wfData.setWfDataVarchar2(marker.getAssayName());
      wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.ASSAY.getValue());
      WfDataUtils.insertWfData(wfData);
    }

    List<WfData> assayWfDataList=WfDataUtils.getWfByWfId(wfId);
  for( ProjectDetail.Markers markers: projectMarkers) {
    List<Allele> alleleList = markers.getAlleles();
    List<WfData> assayList = assayWfDataList.stream().filter(wfData -> wfData.getWfDataConfigId() == AnkTaqmanConstants.WfDataConfigs.ASSAY.getValue().longValue() && wfData.getWfDataVarchar2().equalsIgnoreCase(markers.getAssayName())).collect(Collectors.toList());
    for (Allele list : alleleList) {

      WfData alleleWfData = new WfData();
      alleleWfData.setWfId(wfId);
      alleleWfData.setWfDataAssocId(assayList.get(0).getWfDataId());
      alleleWfData.setWfDataVarchar2(list.getName());
      alleleWfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.ALLELES.getValue());
      WfDataUtils.insertWfData(alleleWfData);
    }
  }
      List<WfData> alleleWfdataList=WfDataUtils.getWfByWfId(wfId);
    for( ProjectDetail.Markers markers: projectMarkers) {
      List<Allele> alleleList = markers.getAlleles();
      List<WfData> assayList = assayWfDataList.stream().filter(wfData -> wfData.getWfDataConfigId() == AnkTaqmanConstants.WfDataConfigs.ASSAY.getValue().longValue() && wfData.getWfDataVarchar2().equalsIgnoreCase(markers.getAssayName())).collect(Collectors.toList());
      List<WfData> allelewfdataList = alleleWfdataList.stream().filter(wfData -> wfData.getWfDataConfigId() == AnkTaqmanConstants.WfDataConfigs.ALLELES.getValue().longValue()&& wfData.getWfDataAssocId().longValue()==assayList.get(0).getWfDataId().longValue() ).collect(Collectors.toList());

      for (Allele list : alleleList) {

        for(WfData allelewfdata: allelewfdataList)
        {
          if(list.getName().contentEquals(allelewfdata.getWfDataVarchar2()))
          {
            List<WfData> alleleWfDataList = new ArrayList();
            WfData wfData = new WfData();
            wfData.setWfId(wfId);
            wfData.setWfDataVarchar2(list.getName());
            wfData.setWfDataAssocId(allelewfdata.getWfDataId());
            wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.ALLELE_NAME.getValue());
            alleleWfDataList.add(wfData);

            wfData = new WfData();
            wfData.setWfId(wfId);
            wfData.setWfDataVarchar2(list.getDescription());
            wfData.setWfDataAssocId(allelewfdata.getWfDataId());
            wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.DESCRIPTION.getValue());
            alleleWfDataList.add(wfData);

            wfData = new WfData();
            wfData.setWfId(wfId);
            wfData.setWfDataNumber(BigDecimal.valueOf(list.getId()));
            wfData.setWfDataAssocId(allelewfdata.getWfDataId());
            wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.ALLELE_ID.getValue());
            alleleWfDataList.add(wfData);

            wfData = new WfData();
            wfData.setWfId(wfId);
            wfData.setWfDataVarchar2(list.getProbe());
            wfData.setWfDataAssocId(allelewfdata.getWfDataId());
            wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.PROBE.getValue());
            alleleWfDataList.add(wfData);
            WfDataUtils.insertWfDataList(alleleWfDataList);
          }
        }
      }
    }

  }







  private List<WfData> createProjectWfDataList( ProjectDetail project) throws Exception{

    List<WfData> wfDataList = new ArrayList();
    WfData wfData = new WfData();
    wfData.setWfDataVarchar2(project.getProjectId());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.PROJECT_ID_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    if(null !=project.getSendDate() ){
      try{

        Date date=new SimpleDateFormat("yyyy-MM-dd").parse(project.getSendDate());
        Timestamp ts=new Timestamp(date.getTime());
        wfData = new WfData();
        wfData.setWfDataTimestamp(ts);
        wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.SEND_DATE_DATA_CONFIG_ID.getValue());
        wfDataList.add(wfData);
      }
      catch(Exception e){
        LOG.error("Incorrect Date format found on  sendDate field. Setting to null.");
      }
    }

    wfData = new WfData();
    wfData.setWfDataNumber(new BigDecimal(project.getNumberOfMarkers()));
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.NUMBER_OF_MARKERS_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);
    if(null !=project.getCreateDate() ){
      try{
        Date date=new SimpleDateFormat("yyyy-MM-dd").parse(project.getCreateDate());
        Timestamp ts=new Timestamp(date.getTime());
        wfData = new WfData();
        wfData.setWfDataTimestamp(ts);
        wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.CREATE_DATE_DATA_CONFIG_ID.getValue());
        wfDataList.add(wfData);
      }
      catch(Exception e){
        LOG.error("Incorrect Date format found on  createDate field. Setting to null.");
      }
    }

    wfData = new WfData();
    wfData.setWfDataNumber(new BigDecimal(project.getCapacityRequestNumber()));
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.CAPACITY_REQUEST_NUMBER_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    /*wfData = new WfData();
    wfData.setWfDataVarchar2(project.getDescription());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.DESCRIPTION_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);*/

    wfData = new WfData();
    String ownerGroup="";
    List<String> ownerGroupList = project.getOwnerGroup();
    if(null!= ownerGroupList){
      for (int i = 0; i < ownerGroupList.size() ; i++) {
        if(i==0){
          ownerGroup = ownerGroupList.get(i);
        }
        else{
          ownerGroup = ownerGroup+","+ownerGroupList.get(i);
        }
      }
    }
    wfData.setWfDataVarchar2(ownerGroup);
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.OWNER_GROUP_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    List<ProjectDetail.Markers> markersList=project.getMarkers();

    for(ProjectDetail.Markers markers: markersList)
    {
      wfData = new WfData();
      wfData.setWfDataVarchar2(markers.getMarkerName());
      wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.MARKER.getValue());
      wfDataList.add(wfData);
    }

    wfData = new WfData();
    wfData.setWfDataNumber(new BigDecimal(project.getNumberOfSamples()));
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.NUMBER_OF_SAMPLES_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    wfData = new WfData();
    wfData.setWfDataVarchar2(project.getRequester());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.REQUESTER_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    /*wfData = new WfData();
    wfData.setWfDataVarchar2(project.getSubmissionName());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.SUBMISSION_NAME_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);*/

    wfData = new WfData();
    wfData.setWfDataNumber(new BigDecimal(project.getLabRequestId()));
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.LAB_REQUEST_ID_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    /*wfData = new WfData();
    wfData.setWfDataVarchar2(project.getStatus());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.STATUS_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);*/

    wfData = new WfData();
    wfData.setWfDataVarchar2(project.getCreatedBy());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.CREATED_BY_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    //setting extracted well type to 96 for MVP. we might need to change it in future
    wfData = new WfData();
    wfData.setWfDataNumber(WfUtilCommon.getWfConfigPropertyByKey(AnkTaqmanConstants.ANK_TAQMAN_WF_CONFIG_ID,AnkTaqmanConstants.WfConfigPropertyKeys.EXTRACTED_WELL_TYPE.getValue()).getValueNumber());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.EXTRACTED_WELL_TYPE.getValue());
    wfDataList.add(wfData);

   //setting the value of cycling to Geese .for MVP it is geese. This has to come for capacity request in future

    wfData = new WfData();
    wfData.setWfDataVarchar2(WfUtilCommon.getWfConfigPropertyByKey(AnkTaqmanConstants.ANK_TAQMAN_WF_CONFIG_ID,AnkTaqmanConstants.WfConfigPropertyKeys.CYCLING.getValue()).getValueVarchar2());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.CYCLING.getValue());
    wfDataList.add(wfData);

    wfData = new WfData();
    wfData.setWfDataVarchar2(WfUtilCommon.getWfConfigPropertyByKey(AnkTaqmanConstants.ANK_TAQMAN_WF_CONFIG_ID,AnkTaqmanConstants.WfConfigPropertyKeys.PLATFORM.getValue()).getValueVarchar2());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.PLATFORM.getValue());
    wfDataList.add(wfData);

    if(null !=project.getReturnDate() ){
      try{
        String pattern = "YYYY-MM-DD";
        Date date=new SimpleDateFormat("yyyy-MM-dd").parse(project.getReturnDate());
        Timestamp ts=new Timestamp(date.getTime());
        wfData = new WfData();
        wfData.setWfDataTimestamp(ts);
        wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.RETURN_DATE_DATA_CONFIG_ID.getValue());
        wfDataList.add(wfData);
      }
      catch(Exception e){
        LOG.error("Incorrect Date format found on  returnDate field.");
      }
    }


    wfData = new WfData();
    String owner="";
    List<String> ownerList = project.getOwner();
    if(null!= ownerList){
      for (int i = 0; i < ownerList.size() ; i++) {
        if(i==0){
          owner = ownerList.get(i);
        }
        else{
          owner = owner+","+ownerList.get(i);
        }
      }
    }
    wfData.setWfDataVarchar2(owner);
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.OWNER_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    //Screening Purpose is same as Intent/SubIntent
    wfData = new WfData();
    String screeningPurpose = "";
    List<String> intentList = project.getIntentList();
    if(null!= intentList){
      for (int i = 0; i < intentList.size() ; i++) {
        if(i==0){
          screeningPurpose = intentList.get(i);
        }
        else{
          screeningPurpose = screeningPurpose+","+intentList.get(i);
        }
      }
    }
    wfData.setWfDataVarchar2(screeningPurpose);
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.SCREENING_PURPOSE_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    //TODO: set project_ar and Organization/Function Id too

    wfData = new WfData();
    wfData.setWfDataVarchar2(project.getCrop());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.CROP_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);


    wfData = new WfData();
    wfData.setWfDataVarchar2(project.getSampleType());
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.SAMPLE_TYPE_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);

    wfData = new WfData();
    wfData.setWfDataNumber(new BigDecimal(project.getNumberOfPlates()));
    wfData.setWfDataConfigId(AnkTaqmanConstants.WfDataConfigs.NUMBER_OF_BLOCKS_DATA_CONFIG_ID.getValue());
    wfDataList.add(wfData);
    return  wfDataList;
  }

  private WfBase setPlateWfBase(ProjectDetail project, ProjectDetail.Plate plate){
    WfBase wfBase = new WfBase();
    wfBase.setWfEntityLabel(plate.getBarcode());
    wfBase.setWfConfigId(AnkTaqmanConstants.ANK_TAQMAN_WF_CONFIG_ID); // set config id for Ankeny Taqman
    wfBase.setWfEntityTypeId(AnkTaqmanConstants.Entities.F_BLOCK.getValue());
    wfBase.setCreateUser(project.getCreatedBy());
    wfBase.setWfStepConfigId(AnkTaqmanConstants.Steps.READY_FOR_EXTRACTION.getValue());
    wfBase.setWfStatus(AnkTaqmanConstants.WfStatus.READY.getValue());
    return wfBase;
  }

  private List<WfGridBase> populateGridBaseList(ProjectDetail project, ProjectDetail.Plate plate) throws Exception{


    List<WfGridBase> wfGridBaseList = new ArrayList<>();
    //Get Samples data
    List<ProjectDetail.Plate.Sample> samplesList = plate.getSamples();
    if(null != samplesList)   {
      for (ProjectDetail.Plate.Sample sample : samplesList) {
        List<WfGridData> wfGridDataList = new ArrayList<>();
        WfGridBase wfGridBase = new WfGridBase(project.getProjectId(),new Long(sample.getSampleId()),AnkTaqmanConstants.ANK_TAQMAN_WF_CONFIG_ID);

        WfGridData wfGridData = new WfGridData();
        wfGridData.setValueVarchar2(sample.getMaterialSampleId());
        wfGridData.setWfGridDataConfigId(AnkTaqmanConstants.WfGridDataConfigs.MATERIAL_SAMPLE_ID.getValue());
        wfGridData.setStatus("Y");
        wfGridDataList.add(wfGridData);

        wfGridData = new WfGridData();
        wfGridData.setValueVarchar2(sample.getGeneration());
        wfGridData.setWfGridDataConfigId(AnkTaqmanConstants.WfGridDataConfigs.GENERATION.getValue());
        wfGridData.setStatus("Y");
        wfGridDataList.add(wfGridData);

        wfGridData = new WfGridData();
        wfGridData.setValueVarchar2(sample.getOrigin());
        wfGridData.setWfGridDataConfigId(AnkTaqmanConstants.WfGridDataConfigs.ORIGIN.getValue());
        wfGridData.setStatus("Y");
        wfGridDataList.add(wfGridData);

        wfGridData = new WfGridData();
        wfGridData.setValueNumber(BigDecimal.valueOf(sample.getInventoryBarcodeNbr()));
        wfGridData.setWfGridDataConfigId(AnkTaqmanConstants.WfGridDataConfigs.INVENTORY_BARCODE_NUMBER.getValue());
        wfGridData.setStatus("Y");
        wfGridDataList.add(wfGridData);

        // Add WfGridAssoc
        WfGridAssoc wfGridAssoc = new WfGridAssoc();
        wfGridAssoc.setWfConfigId(AnkTaqmanConstants.ANK_TAQMAN_WF_CONFIG_ID);
        wfGridAssoc.setStatus("A");
        int row =UtilCommon.getNumberForLetter(sample.getRow().substring(0,1));
        wfGridAssoc.setLabel(UtilCommon.getWellAddressLongFormat(row,sample.getCol()));
        wfGridAssoc.setRow(row);
        wfGridAssoc.setCol(sample.getCol());
        wfGridBase.setWfGridAssoc(wfGridAssoc);
        wfGridBase.setWfGridDataList(wfGridDataList);
        wfGridBaseList.add(wfGridBase);
      }
    }
    return wfGridBaseList;
  }

  private WfAssoc setWfAssoc(Long plateWfId,Long projectWfId, String plateId){
    WfAssoc wfAssoc = new WfAssoc();
    wfAssoc.setToWfId(plateWfId);
    wfAssoc.setFromWfId(projectWfId);
    wfAssoc.setSortKey(1L);
    wfAssoc.setMatchKey(plateId);
    wfAssoc.setActive(true);
    return  wfAssoc;
  }


  private Timestamp getTimeStamp(String val) throws Exception {
    return  new Timestamp(UtilCommon.parseSqlDateWithFormnat(val, INPUT_TIMESTAMP_FORMAT).getTime());
  }

  private boolean checkData(ProjectDetail projectDetail){
    // Project Id, Crop, Sample Type, CreatedBy and F Block Barcode are mandatory fields
    boolean isValid = true;
    if(StringUtils.isEmpty( projectDetail.getProjectId())){
      isValid=false;
    }
    if(StringUtils.isEmpty( projectDetail.getCrop())){
      isValid=false;
    }
    if(StringUtils.isEmpty( projectDetail.getSampleType())){
      isValid=false;
    }
    if(StringUtils.isEmpty( projectDetail.getCreatedBy())){
      isValid=false;
    }
    List<ProjectDetail.Plate> platesList = projectDetail.getPlates();
    if (null != platesList) {
      for (ProjectDetail.Plate plate : platesList) {
        String plateId = plate.getBarcode();
        if(StringUtils.isEmpty( plateId)){
          isValid=false;
        }
      }
    }

    return isValid;
  }
}
