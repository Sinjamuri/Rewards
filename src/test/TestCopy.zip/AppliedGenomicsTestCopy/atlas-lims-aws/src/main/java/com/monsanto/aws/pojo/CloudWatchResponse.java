package com.monsanto.aws.pojo;

import java.util.List;

/**
 * Created by ashar7 on 3/25/2016.
 */
public class CloudWatchResponse {

  private String messageType;
  private String owner;
  private String logGroup;
  private String logStream;
  private List<String> subscriptionFilters;
  private List<CloudWatchMessage> logEvents;
  private String filterPattern;

  public String getMessageType() {
    return messageType;
  }

  public void setMessageType(String messageType) {
    this.messageType = messageType;
  }

  public String getOwner() {
    return owner;
  }

  public void setOwner(String owner) {
    this.owner = owner;
  }

  public String getLogGroup() {
    return logGroup;
  }

  public void setLogGroup(String logGroup) {
    this.logGroup = logGroup;
  }

  public String getLogStream() {
    return logStream;
  }

  public void setLogStream(String logStream) {
    this.logStream = logStream;
  }

  public List<String> getSubscriptionFilters() {
    return subscriptionFilters;
  }

  public void setSubscriptionFilters(List<String> subscriptionFilters) {
    this.subscriptionFilters = subscriptionFilters;
  }

  public List<CloudWatchMessage> getLogEvents() {
    return logEvents;
  }

  public void setLogEvents(List<CloudWatchMessage> logEvents) {
    this.logEvents = logEvents;
  }

  public String getFilterPattern() {
    return filterPattern;
  }

  public void setFilterPattern(String filterPattern) {
    this.filterPattern = filterPattern;
  }
}
