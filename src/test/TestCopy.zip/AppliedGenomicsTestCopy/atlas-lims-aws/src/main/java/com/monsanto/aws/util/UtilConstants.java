package com.monsanto.aws.util;

/**
 * Created by ASHAR7 on 5/5/2016.
 */
public interface UtilConstants {

  public static String ATLAS_AWS_PACKAGE = "com.monsanto.aws.";


  // V-Works generated Cobra log file (relevant parts)...
  static final Integer VWORKS_LOG_TIMESTAMP_COL = 0;
  static final Integer VWORKS_LOG_PROTOCOL_COL = 9;

  static final Integer BIOCELL_EXTRACTION_LOG_SCRIPT_COL = 1;
  static final String BIOCELL_EXTRACTION_LOG_SCRIPT_TEXT = "Script";

  static final Integer BIOCELL_EXTRACTION_LOG_EVENT_COL = 1;
  static final String BIOCELL_EXTRACTION_LOG_EVENT_TEXT = "Event";
  static final Integer BIOCELL_EXTRACTION_LOG_EVENT_PROTOCOL_START_IDENTIFIER_COL = 6;

  static final Integer BIOCELL_EXTRACTION_LOG_EVENT_DOWNSTACK_START_IDENTIFIER_COL = 4;
  static final String BIOCELL_EXTRACTION_LOG_EVENT_DOWNSTACK_START_IDENTIFIER_TEXT = "Downstack Source";

  static final Integer BIOCELL_EXTRACTION_LOG_SCRIPT_DOWNSTACK_96BUL_IT_START_IDENTIFIER_COL = 6;
  static final String BIOCELL_EXTRACTION_LOG_SCRIPT_DOWNSTACK_96BUL_IT_START_IDENTIFIER_TEXT = "new source block =";


  static final Integer BIOCELL_EXTRACTION_LOG_EVENT_READER_START_IDENTIFIER_COL = 6;
  static final String  BIOCELL_EXTRACTION_LOG_EVENT_READER_START_IDENTIFIER_TEXT = "Barcode reader read ";


  static final String BIOCELL_EXTRACTION_LOG_EVENT_PROTOCOL_START_IDENTIFIER_TEXT = "Startup protocol starting";
  static final Integer BIOCELL_EXTRACTION_LOG_EVENT_PROTOCOL_COL = 7;
  static final Integer BIOCELL_EXTRACTION_LOG_SOURCE_F_BLOCK_COL = 6;

  static final Integer BIOCELL_EXTRACTION_LOG_TARGET_LIBRARY_PLATE_COL = 6;
  static final String BIOCELL_EXTRACTION_LOG_E_PLATE_IDENTIFIER = "Extraction Complete";
  static final String BIOCELL_EXTRACTION_LOG_F_E_BLOCK_IDENTIFIER_START = "\"F";
  static final String BIOCELL_EXTRACTION_LOG_F_E_BLOCK_IDENTIFIER_END = "A BIOCEL END_AUTOMATED_EXTRACTION";
  // static final String BIOCELL_EXTRACTION_LOG_F_BLOCK_END_IDENTIFIER = "for Dest plate.";

  static final String BIOCELL_EXTRACTION_LOG_384_E_PLATE_IDENTIFIER = "Upstack complete for barcode::";
  static final String BIOCELL_EXTRACTION_LOG_384_F_E_BLOCK_IDENTIFIER_START = "For_splunk current source plates::";
  static final String BIOCELL_EXTRACTION_LOG_384_F_E_BLOCK_IDENTIFIER_END = "For_splunk destination bar code will be::";


  static final Integer MV_TECAN_LOG_SCRIPT_COL = 1;
  static final String MV_TECAN_LOG_SCRIPT_TEXT = "Script";

  static final String MV_TECAN_LOG_SCRIPT_IDENTIFIER_TEXT = "mixing-vessel-update-invoker.jar";
  static final Integer MV_TECAN_LOG_SCRIPT_IDENTIFIER_COL = 6;

  static final Integer MV_TECAN_LOG_EVENT_COL = 1;
  static final String MV_TECAN_LOG_EVENT_TEXT = "Event";


  static final Integer MV_TECAN_LOG_EVENT_START_IDENTIFIER_COL = 4;

  static final Integer MV_TECAN_LOG_EVENT_UP_DOWN_STACK_END_IDENTIFIER_COL = 6;
  static final String MV_TECAN_LOG_EVENT_UPSTACK_END_IDENTIFIER_TEXT = "Completed: Upstack";
  static final String MV_TECAN_LOG_EVENT_DOWNSTACK_END_IDENTIFIER_TEXT = "Completed: Downstack";


}
