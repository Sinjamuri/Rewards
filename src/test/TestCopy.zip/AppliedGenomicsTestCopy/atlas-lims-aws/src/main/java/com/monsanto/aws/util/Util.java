package com.monsanto.aws.util;

import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.google.gson.Gson;
import com.monsanto.aws.json.JsonModel;
import com.monsanto.aws.pojo.CloudWatchMessage;
import org.apache.commons.codec.binary.Base64;
import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.lang.reflect.Method;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/**
 * Created by ASHAR7 on 4/22/2016.
 */
public class Util implements UtilConstants {

  static final Logger LOG = LoggerFactory.getLogger(Util.class);

  public static void getParsedMessage(CloudWatchMessage cloudWatchMessage, String fileType) {
    //parse message into rows and columns(split on tabs)
    if(null != cloudWatchMessage.getMessage() && !cloudWatchMessage.getMessage().isEmpty()){
      List<String[]> parsedMessage = parseMessage(cloudWatchMessage.getMessage(), fileType);
      cloudWatchMessage.setParsedMessage(parsedMessage);
    }
  }

  public static List<String[]> parseMessage(String cloudWatchMessage, String fileType) {
    List<String[]> parsedMessage = new ArrayList<String[]>();
    String[] rows = cloudWatchMessage.split("\n");
    for(String row : rows){
      if(null != fileType && fileType.equalsIgnoreCase("LOG")){
        String[] rowData = row.split("\t");
        parsedMessage.add(rowData);
      }else if(null != fileType && fileType.equalsIgnoreCase("CSV")){
        String[] rowData = row.split(",");
        parsedMessage.add(rowData);
      } else {
        String[] rowData = row.split("\t");
        parsedMessage.add(rowData);
      }
    }
    return parsedMessage;
  }

  public static byte[] decodeBase64(String logData) {
    byte[] decodedBytes = new byte[0];
    try {
      Base64 decoder = new Base64();
      byte[] saltArray = decoder.decode(logData);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return decodedBytes;
  }

  public static String deCompressAndUTFencode(byte[] decodedBytes) {

    GZIPInputStream gis = null;
    try {
      gis = new GZIPInputStream(new ByteArrayInputStream(decodedBytes));
    } catch (IOException e) {
      e.printStackTrace();
    }
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    try {
      byte[] buffer = new byte[1024];
      int len;
      while((len = gis.read(buffer))>0)
        baos.write(buffer, 0, len);

      return new String(baos.toByteArray(), "UTF-8");
    } catch (IOException e) {
      throw new AssertionError(e);
    }
  }

  public static void invoke(final JsonModel jsonModel, Timestamp createTs) {

    Runnable myrunnable = new Runnable() {
      public void run() {
        invokeMethod(jsonModel);
      }
    };

    new Thread(myrunnable).start();//Call it when you need to run the function

    updateExecutionInfo(jsonModel.getParsedAgentName(), createTs,
        new Timestamp((Calendar.getInstance().getTime()).getTime()), "Complete");
  }

  private static void invokeMethod(JsonModel jsonModel) {
    String className = "com.monsanto.aws."+jsonModel.getParsedAgentName();

    Class<?> delegateClass = null;
    Method delegateMethod = null;
    try {
      delegateClass = Class.forName(className);
      delegateMethod = delegateClass.getMethod("processData", JsonModel.class);
      try {
        delegateMethod.invoke(delegateClass.newInstance(),(Object) jsonModel);
      }catch (Throwable t) {
        t.printStackTrace();
      }
    }catch (ClassNotFoundException ex) {
      ex.printStackTrace();
      LOG.error("An agent was not found for " + className);
    }catch (NoSuchMethodException ex) {
      ex.printStackTrace();
      LOG.error("The agent " + delegateClass.getName() + " does not implement the required method");
    }catch (Exception e){
      e.printStackTrace();
    }
  }

  protected static void updateExecutionInfo(String agentName, Timestamp startTs, Timestamp completeTs, String status){

    final String SQL_UPDATE = "update ATLAS.wf_agent_log set COMPLETE_TS=?, STATUS=? where WF_AGENT_NAME=? and CREATE_TS=?";

    Connection conn = null;
    PreparedStatement pstmtUpdate = null;

    try {
     // conn = DbConnectionUtil.getGBSConnection();
      pstmtUpdate = conn.prepareStatement(SQL_UPDATE);
      pstmtUpdate.setTimestamp(1, completeTs);
      pstmtUpdate.setString(2, status);
      pstmtUpdate.setString(3, agentName);
      pstmtUpdate.setTimestamp(4, startTs);
      pstmtUpdate.execute();

    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      Util.freeResource(pstmtUpdate);
      Util.freeResource(conn);
    }
  }

  public static void freeResource(OutputStream os) {
    try {
      os.flush();
      os.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void freeResource(InputStream os) {
    try {
      os.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void freeResource(Writer writer) {
    if (writer != null) {
      try {
        writer.flush();
        writer.close();
      } catch (Exception ex) {
        //no error handling needed
      }
    }
  }

  public static void freeResource(FileInputStream fis) {
    try {
      fis.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void freeResource(Connection con) {
    try {
      con.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void freeResource(PreparedStatement pstmt) {
    try {
      pstmt.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void freeResource(Statement stmt) {
    try {
      stmt.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void freeResource(BufferedReader br) {
    try {
      br.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void freeResource(ResultSet rs) {
    try {
      rs.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void freeResource(CallableStatement stmt) {
    try {
      stmt.close();
    } catch (Exception ex) {
      //no exception handling needed
    }
  }

  public static void safeCommit(Connection con) {
    if (con != null) {
      try {
        con.commit();
      } catch (Exception ex) {
      }
    }
  }

  public static void safeRollback(Connection con) {
    if (con != null) {
      try {
        con.rollback();
      } catch (Exception ex) {
      }
    }
  }

  public static long getDaysToMillis(int days) {
    // return the number of days represented in millis for lastModified dates and such
    return (System.currentTimeMillis() - (days * 24L * 60L * 60L * 1000L));
  }

  public static int getNumberForLetter(String val) {
    return (int) val.charAt(0) -64;
  }

  public static String getLetterForNumber(int val) {
    return String.valueOf((char) ((val) + 64));
  }

  public JsonModel callMethod(LambdaLogger logger, String agentName, CloudWatchMessage cloudWatchMessage) {
    //trigger appropriate Agent based on Context Function Name
    //the agent should read the parsed message above
    JsonModel jsonModel = new JsonModel();
    try {

      String parsedAgentName = "";
      Reflections reflections1 = new Reflections(ATLAS_AWS_PACKAGE,
          new SubTypesScanner(false));
      Set<String> allClasses =
              reflections1.getAllTypes();
      for(String className : allClasses) {
        if(className.equalsIgnoreCase(ATLAS_AWS_PACKAGE +agentName)){
          parsedAgentName = className.substring(className.indexOf(ATLAS_AWS_PACKAGE)+ ATLAS_AWS_PACKAGE.length());
          break;
        }
      }
      logger.log("Setting Parsed Agent Name:"+ parsedAgentName);
      Class<?> aClass = Class.forName(ATLAS_AWS_PACKAGE + parsedAgentName);
      Method processMessage = aClass.getMethod("processMessage", LambdaLogger.class, CloudWatchMessage.class);
      //invoke method using reflection
      try {
        Object returnValue = processMessage.invoke(aClass.newInstance(), logger, cloudWatchMessage);
        jsonModel = (JsonModel) returnValue;
        jsonModel.setParsedAgentName(parsedAgentName);
      } catch (Exception e) {
        e.printStackTrace();
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (NoSuchMethodException e) {
      e.printStackTrace();
    }
    return jsonModel;
  }

  public void sendModelAsRequest(LambdaLogger logger, JsonModel jsonModel) {

    /*try {

      jsonModel.setAgentName(ATLAS_WEB_PACKAGE+jsonModel.getParsedAgentName());

      logger.log("Calling : "+ATLAS_WEB_URL + jsonModel.getAgentName());
      JsonResponse jsonResponse = makeRequest(logger, ATLAS_WEB_URL, jsonModel);
    } catch (Exception e) {
      e.printStackTrace();
    }*/
  }

  public Timestamp addRequest(LambdaLogger logger, JsonModel jsonModel) {

    logger.log("Starting insert into RDS DB");

    Connection conn = null;
    PreparedStatement pstmt = null;
    Timestamp currentTs = new Timestamp((Calendar.getInstance().getTime()).getTime());

    try {

      logger.log("Making connection");
     // conn = DbConnectionUtil.getGBSConnection();
      logger.log("Connection Successful");
      Gson gson = new Gson();

      final String SQL_INSERT = "insert into ATLAS.WF_AGENT_LOG (wf_agent_name,args,create_ts,create_user,complete_ts,status) values (?,?,now(),?,now(),?)";

      pstmt = conn.prepareStatement(SQL_INSERT);
      pstmt.setString(1, jsonModel.getParsedAgentName());
      pstmt.setBytes(2, gson.toJson(jsonModel).getBytes());
      pstmt.setString(3, "AWS ATLAS");
      pstmt.setString(4, "Initiated");

      pstmt.executeUpdate();
      logger.log("Insert Complete");

    }catch(Exception e){
      e.printStackTrace();
    }finally{
      Util.freeResource(pstmt);
      Util.freeResource(conn);
    }

    return currentTs;
  }


  public static String getWellAddress(int wellPosition) {
    if (wellPosition==1) return "A01";
    else if (wellPosition==2) return "B01";
    else if (wellPosition==3) return "C01";
    else if (wellPosition==4) return "D01";
    else if (wellPosition==5) return "E01";
    else if (wellPosition==6) return "F01";
    else if (wellPosition==7) return "G01";
    else if (wellPosition==8) return "H01";
    else if (wellPosition==9) return "A02";
    else if (wellPosition==10) return "B02";
    else if (wellPosition==11) return "C02";
    else if (wellPosition==12) return "D02";
    else if (wellPosition==13) return "E02";
    else if (wellPosition==14) return "F02";
    else if (wellPosition==15) return "G02";
    else if (wellPosition==16) return "H02";
    else if (wellPosition==17) return "A03";
    else if (wellPosition==18) return "B03";
    else if (wellPosition==19) return "C03";
    else if (wellPosition==20) return "D03";
    else if (wellPosition==21) return "E03";
    else if (wellPosition==22) return "F03";
    else if (wellPosition==23) return "G03";
    else if (wellPosition==24) return "H03";
    else if (wellPosition==25) return "A04";
    else if (wellPosition==26) return "B04";
    else if (wellPosition==27) return "C04";
    else if (wellPosition==28) return "D04";
    else if (wellPosition==29) return "E04";
    else if (wellPosition==30) return "F04";
    else if (wellPosition==31) return "G04";
    else if (wellPosition==32) return "H04";
    else if (wellPosition==33) return "A05";
    else if (wellPosition==34) return "B05";
    else if (wellPosition==35) return "C05";
    else if (wellPosition==36) return "D05";
    else if (wellPosition==37) return "E05";
    else if (wellPosition==38) return "F05";
    else if (wellPosition==39) return "G05";
    else if (wellPosition==40) return "H05";
    else if (wellPosition==41) return "A06";
    else if (wellPosition==42) return "B06";
    else if (wellPosition==43) return "C06";
    else if (wellPosition==44) return "D06";
    else if (wellPosition==45) return "E06";
    else if (wellPosition==46) return "F06";
    else if (wellPosition==47) return "G06";
    else if (wellPosition==48) return "H06";
    else if (wellPosition==49) return "A07";
    else if (wellPosition==50) return "B07";
    else if (wellPosition==51) return "C07";
    else if (wellPosition==52) return "D07";
    else if (wellPosition==53) return "E07";
    else if (wellPosition==54) return "F07";
    else if (wellPosition==55) return "G07";
    else if (wellPosition==56) return "H07";
    else if (wellPosition==57) return "A08";
    else if (wellPosition==58) return "B08";
    else if (wellPosition==59) return "C08";
    else if (wellPosition==60) return "D08";
    else if (wellPosition==61) return "E08";
    else if (wellPosition==62) return "F08";
    else if (wellPosition==63) return "G08";
    else if (wellPosition==64) return "H08";
    else if (wellPosition==65) return "A09";
    else if (wellPosition==66) return "B09";
    else if (wellPosition==67) return "C09";
    else if (wellPosition==68) return "D09";
    else if (wellPosition==69) return "E09";
    else if (wellPosition==70) return "F09";
    else if (wellPosition==71) return "G09";
    else if (wellPosition==72) return "H09";
    else if (wellPosition==73) return "A10";
    else if (wellPosition==74) return "B10";
    else if (wellPosition==75) return "C10";
    else if (wellPosition==76) return "D10";
    else if (wellPosition==77) return "E10";
    else if (wellPosition==78) return "F10";
    else if (wellPosition==79) return "G10";
    else if (wellPosition==80) return "H10";
    else if (wellPosition==81) return "A11";
    else if (wellPosition==82) return "B11";
    else if (wellPosition==83) return "C11";
    else if (wellPosition==84) return "D11";
    else if (wellPosition==85) return "E11";
    else if (wellPosition==86) return "F11";
    else if (wellPosition==87) return "G11";
    else if (wellPosition==88) return "H11";
    else if (wellPosition==89) return "A12";
    else if (wellPosition==90) return "B12";
    else if (wellPosition==91) return "C12";
    else if (wellPosition==92) return "D12";
    else if (wellPosition==93) return "E12";
    else if (wellPosition==94) return "F12";
    else if (wellPosition==95) return "G12";
    else if (wellPosition==96) return "H12";
    else {
      throw new AssertionError("The wellPosition must be between 1 and 96");
    }
  }

  public static String[] splitStringToPositionArray(String s) {
    Pattern pattern = Pattern.compile("\"[^A-Z0-9]+|(?<=[A-Z])(?=[0-9])|(?<=[0-9])(?=[A-Z])\"");
    String[] rowAndColumnArray = pattern.split(s.toUpperCase());
    return rowAndColumnArray;
  }
}
