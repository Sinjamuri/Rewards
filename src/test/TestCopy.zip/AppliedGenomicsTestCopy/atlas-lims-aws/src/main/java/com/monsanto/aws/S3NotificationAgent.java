package com.monsanto.aws;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.event.S3EventNotification.S3EventNotificationRecord;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.util.IOUtils;
import com.monsanto.aws.json.JsonModel;
import com.monsanto.aws.pojo.CloudWatchMessage;
import com.monsanto.aws.util.Util;
import org.apache.commons.dbcp.BasicDataSource;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.sql.Timestamp;

/**
 * Created by ashar7 on 5/4/2016.
 */
public class S3NotificationAgent extends Util implements
        RequestHandler<S3Event, String> {

  //data source
  public static BasicDataSource dataSource = new BasicDataSource();

  @Override
  public String handleRequest(S3Event s3Event, Context context) {

    final LambdaLogger logger = context.getLogger();
    String status = "Successful";

    CloudWatchMessage cloudWatchMessage = new CloudWatchMessage();

    try {
      S3EventNotificationRecord record = s3Event.getRecords().get(0);

      String srcBucket = record.getS3().getBucket().getName();
      logger.log("Src Bucket Name : "+srcBucket);

      // Object key may have spaces or unicode non-ASCII characters.
      String srcKey = record.getS3().getObject().getKey()
              .replace('+', ' ');
      srcKey = URLDecoder.decode(srcKey, "UTF-8");
      cloudWatchMessage.setKey(srcKey);
      logger.log("Src Key : "+srcKey);

      String[] folderName = srcKey.split("/");

      String[] arr = folderName[1].split("-");
      String fileType = null;
      if(arr.length > 1){
        fileType = arr[1];
      }

      // Download the document from S3 into a stream
      AmazonS3 s3Client = new AmazonS3Client();
      S3Object s3Object = s3Client.getObject(new GetObjectRequest(
              srcBucket, srcKey));
      InputStream objectData = s3Object.getObjectContent();

      try {
        // Read the source

        if(null != fileType && (fileType.equalsIgnoreCase("LOG") || fileType.equalsIgnoreCase("CSV") || fileType.equalsIgnoreCase("TXT"))){
          String message = IOUtils.toString(objectData);
          cloudWatchMessage.setMessage(message);
          getParsedMessage(cloudWatchMessage, fileType);
        }else{
          cloudWatchMessage.setObjectData(s3Object);
        }
      }catch(Exception e){
        e.printStackTrace();
      }

      JsonModel jsonModel = callMethod(logger, arr[0], cloudWatchMessage);

      if(null != jsonModel){
        jsonModel.setParsedAgentName(arr[0]);
        Timestamp createTs = addRequest(logger, jsonModel);
        //invoke(jsonModel, createTs);
      }

    } catch (IOException e) {
      status = "Unsuccessful";
      throw new RuntimeException(e);
    }
    return status;
  }

}