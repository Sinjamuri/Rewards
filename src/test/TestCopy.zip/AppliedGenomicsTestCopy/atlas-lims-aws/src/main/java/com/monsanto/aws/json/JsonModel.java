package com.monsanto.aws.json;

import com.bayer.atlas.common.model.PlateDetail;
import com.monsanto.aws.pojo.*;


import java.util.List;
import java.util.Map;

/**
 * Created by ASHAR7 on 4/22/2016.
 */
public class JsonModel {

  private String agentName;
  private String parsedAgentName;
  //CLicAgent
  private String instrumentId;
  private boolean nineTenRun;
  private String glBarcodeBase;
  private String runName;

  //RogueAgent
  private String systemName;
  private String userId;

  //qpcrAgent
  private String experimentName;
  private String instrumentName;
  private Map<String, Double> rawQuantsMap;

  //BeeHiveAgent
  private List<PlateDetail> platesFromFile;

  //CreateProjectAgent
  private ProjectDetail projectDetail;

  //PherastarFileReaderAgent

  private List<PcrPlateDetail> pcrPlateDetailList;

  //Soellex
  private List<Soellex> soellexList;

  public String getProtocol() {
    return protocol;
  }

  public void setProtocol(String protocol) {
    this.protocol = protocol;
  }

  private String protocol;

  public List<String> getSourcePlatesInExtraction() {
    return sourcePlatesInExtraction;
  }

  public void setSourcePlatesInExtraction(List<String> sourcePlatesInExtraction) {
    this.sourcePlatesInExtraction = sourcePlatesInExtraction;
  }

  private List<String> sourcePlatesInExtraction;

  public Map<String, List<BioCellExtractionRunAssoc>> getBioCellExtractionRunAssocsGroup() {
    return bioCellExtractionRunAssocsGroup;
  }

  public void setBioCellExtractionRunAssocsGroup(Map<String, List<BioCellExtractionRunAssoc>> bioCellExtractionRunAssocsGroup) {
    this.bioCellExtractionRunAssocsGroup = bioCellExtractionRunAssocsGroup;
  }

  private Map<String, List<BioCellExtractionRunAssoc>> bioCellExtractionRunAssocsGroup;


  private List<String> mixingVesselUpstackList;

  public List<String> getMixingVesselUpstackList() {
    return mixingVesselUpstackList;
  }

  public void setMixingVesselUpstackList(List<String> mixingVesselUpstackList) {
    this.mixingVesselUpstackList = mixingVesselUpstackList;
  }

  public List<String> getMixingVesselDownstackList() {
    return mixingVesselDownstackList;
  }

  public void setMixingVesselDownstackList(List<String> mixingVesselDownstackList) {
    this.mixingVesselDownstackList = mixingVesselDownstackList;
  }

  private List<String> mixingVesselDownstackList;


  public String getAgentName() {
    return agentName;
  }

  public void setAgentName(String agentName) {
    this.agentName = agentName;
  }

  public String getParsedAgentName() {
    return parsedAgentName;
  }

  public void setParsedAgentName(String parsedAgentName) {
    this.parsedAgentName = parsedAgentName;
  }

  public String getInstrumentId() {
    return instrumentId;
  }

  public void setInstrumentId(String instrumentId) {
    this.instrumentId = instrumentId;
  }

  public boolean isNineTenRun() {
    return nineTenRun;
  }

  public void setNineTenRun(boolean nineTenRun) {
    this.nineTenRun = nineTenRun;
  }

  public String getGlBarcodeBase() {
    return glBarcodeBase;
  }

  public void setGlBarcodeBase(String glBarcodeBase) {
    this.glBarcodeBase = glBarcodeBase;
  }

  public String getRunName() {
    return runName;
  }

  public void setRunName(String runName) {
    this.runName = runName;
  }

  public String getExperimentName() {
    return experimentName;
  }

  public void setExperimentName(String experimentName) {
    this.experimentName = experimentName;
  }

  public String getInstrumentName() {
    return instrumentName;
  }

  public void setInstrumentName(String instrumentName) {
    this.instrumentName = instrumentName;
  }

  public Map<String, Double> getRawQuantsMap() {
    return rawQuantsMap;
  }

  public void setRawQuantsMap(Map<String, Double> rawQuantsMap) {
    this.rawQuantsMap = rawQuantsMap;
  }

  public String getSystemName() {
    return systemName;
  }

  public void setSystemName(String systemName) {
    this.systemName = systemName;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public List<PlateDetail> getPlatesFromFile() {
    return platesFromFile;
  }

  public void setPlatesFromFile(List<PlateDetail> platesFromFile) {
    this.platesFromFile = platesFromFile;
  }

  public ProjectDetail getProjectDetail() {
    return projectDetail;
  }

  public void setProjectDetail(ProjectDetail projectDetail) {
    this.projectDetail = projectDetail;
  }

  public List<Soellex> getSoellexList() {
    return soellexList;
  }

  public void setSoellexList(List<Soellex> soellexList) {
    this.soellexList = soellexList;
  }

  public List<PcrPlateDetail> getPcrPlateDetailList() {
    return pcrPlateDetailList;
  }

  public void setPcrPlateDetailList(List<PcrPlateDetail> pcrPlateDetailList) {
    this.pcrPlateDetailList = pcrPlateDetailList;
  }
}
