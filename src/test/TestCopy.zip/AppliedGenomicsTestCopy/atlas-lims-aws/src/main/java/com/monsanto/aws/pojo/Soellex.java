package com.monsanto.aws.pojo;

import java.util.List;

public class Soellex {

    private String fileName;
    private String basketId;
    private String cycleTime;
    private String cycleNum;
    private List<Tank> tankList;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getBasketId() {
        return basketId;
    }

    public void setBasketId(String basketId) {
        this.basketId = basketId;
    }

    public String getCycleTime() {
        return cycleTime;
    }

    public void setCycleTime(String cycleTime) {
        this.cycleTime = cycleTime;
    }

    public String getCycleNum() {
        return cycleNum;
    }

    public void setCycleNum(String cycleNum) {
        this.cycleNum = cycleNum;
    }

    public List<Tank> getTankList() {
        return tankList;
    }

    public void setTankList(List<Tank> tankList) {
        this.tankList = tankList;
    }

    public static class Tank {

        private String tankId;
        private String tankAttr;

        public String getTankId() {
            return tankId;
        }

        public void setTankId(String tankId) {
            this.tankId = tankId;
        }

        public String getTankAttr() {
            return tankAttr;
        }

        public void setTankAttr(String tankAttr) {
            this.tankAttr = tankAttr;
        }
    }

}
