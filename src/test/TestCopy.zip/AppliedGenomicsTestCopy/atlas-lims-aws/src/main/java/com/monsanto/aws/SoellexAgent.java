package com.monsanto.aws;

import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.s3.model.S3Object;
import com.bayer.atlas.common.model.WfBase;
import com.bayer.atlas.common.model.WfData;
import com.bayer.atlas.common.utils.WfDataUtils;
import com.bayer.atlas.common.utils.WfUtils;
import com.monsanto.aws.json.JsonModel;
import com.monsanto.aws.pojo.CloudWatchMessage;
import com.monsanto.aws.pojo.Soellex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Agent to parse cycling xml files
 */
public class SoellexAgent {

    // Initialize the Log4j logger.
    static Logger LOG = LoggerFactory.getLogger(SoellexAgent.class);

    /**
     * Start of Agent call.
     * This method is called from S3NotificationAgent which simply passes on the whole message as an object without
     * parsing as this is an xml file with very specific format.
     * @param logger
     * @param message
     * @return
     */
    public JsonModel processMessage(LambdaLogger logger, CloudWatchMessage message) {

        //logger.log ("Start processing Message.key:" + message.getKey () + ", id:" + message.getId ());
        logger.log("Start processing Message.key:" + message.getKey());
        JsonModel jsonModel = new JsonModel();
        try {

            //parse incoming log file message
            jsonModel = parseRequriedInfo(message.getKey(), message.getObjectData());

            //fetch data using APIs
            List<WfBase> wfInfo = pullRequriedData(jsonModel);

            //reformatData
            processData(wfInfo);

            //updateData
            updateData(wfInfo);


            logger.log("Successfully completed parsing. Fetched:"+jsonModel.getPlatesFromFile().size());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return jsonModel;
    }

    public void updateData(List<WfBase> wfInfo) {

    }

    public void processData(List<WfBase> wfInfo) {


    }

    /**
     * pull all required data in this method
     * @param jsonModel
     * @return
     * @throws Exception
     */
    public List<WfBase> pullRequriedData(JsonModel jsonModel) throws Exception {

        List<String> basketList = new ArrayList<>();
        List<WfBase> wfBaseList = new ArrayList<>();
        jsonModel.getSoellexList().forEach(soellex -> basketList.add(soellex.getBasketId()));
        for(String basketId : basketList){
            List<WfData> wfDataList = WfDataUtils.getWfDataWfID(basketId, 0L);
            for(WfData wfData  :wfDataList){
                wfBaseList.add(WfUtils.getWfByWfId(wfData.getWfId()));
            }
        }
        return wfBaseList;
    }

    public JsonModel parseRequriedInfo(String key, S3Object objectData) {

        JsonModel jsonModel = parseXML(key, objectData.getObjectContent());
        return jsonModel;
    }

    /**
     * parse the xml into Soellex Model object
     * @param key
     * @param cloudWatchMessageStream
     * @return
     */
    public static JsonModel parseXML(String key, InputStream cloudWatchMessageStream) {

        JsonModel jsonModel = new JsonModel();
        List<Soellex> soellexList = new ArrayList<>();
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(cloudWatchMessageStream);
            doc.getDocumentElement().normalize();

            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList headerList = doc.getElementsByTagName("Header");
            String basketId = headerList.item(0).getTextContent();

            NodeList tempsList = doc.getElementsByTagName("Temps");
            System.out.println("----------------------------");

            for (int tempCnt = 0; tempCnt < tempsList.getLength(); tempCnt++) {

                List<Soellex.Tank> tankList = new ArrayList<>();
                Soellex soellexObj = new Soellex();
                soellexObj.setFileName(key);
                soellexObj.setBasketId(basketId);

                Node tempNode = tempsList.item(tempCnt);
                System.out.println("\nCurrent Temps Element :" + tempNode.getNodeName());

                if (tempNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element tempElement = (Element) tempNode;
                    String cycleNum = tempElement.getAttribute("Cycle");
                    String cycleTime = tempElement.getAttribute("Time");

                    soellexObj.setCycleNum(cycleNum);
                    soellexObj.setCycleTime(cycleTime);

                    NodeList tanksList = tempElement.getElementsByTagName("Tank");

                    for(int tankCnt = 0; tankCnt < tanksList.getLength(); tankCnt++){

                        Soellex.Tank tankObj = new Soellex.Tank();

                        Node tankNode = tanksList.item(tankCnt);
                        System.out.println("\nCurrent Tank Element :" + tankNode.getNodeName());

                        Element tankElement = (Element) tankNode;
                        String tankId = tankElement.getAttribute("ID");
                        String tankNodeTextContent = tankNode.getTextContent();
                        tankObj.setTankId(tankId);
                        tankObj.setTankAttr(tankNodeTextContent);

                        tankList.add(tankObj);
                    }
                }
                soellexObj.setTankList(tankList);

                soellexList.add(soellexObj);
            }
            jsonModel.setSoellexList(soellexList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonModel;
    }
}
