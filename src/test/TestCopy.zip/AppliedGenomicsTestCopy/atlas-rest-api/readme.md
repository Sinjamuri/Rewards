Application to create rest api calls for atlas database.

This app should consist of generic services only that 
can return data for any workflow, project or entity.

The logic involved with accepting/rejecting/filtering the data 
should live within the consumer of this api.

This app is a spring boot app utilizing spring cloud services 
for feching credentials for vault.
To get this app working, below environment variables 
need to be present in the application configuration
Update these 3 values as required.

to run it locally, use the run configuration at this url:
https://vault.agro.services/ui/vault/secrets/secret/show/dsa-data-backbone/atlas-rest-api/run-config

In application.properties file, we have server.port mentioned as 9090. Your local urls will be 
http://localhost:9090/wf-grid-data/wf-id/{wf-id}

When running locally, swagger documentation can be found at http://localhost:9090/swagger-ui.html

You can change the port server runs on by changing the application.properties file.

Akana swagger details : https://api-portal-np.monsanto.net/#/api/e45f89b2-a96d-464b-a736-a1ec63ab15c3.enterpriseapi/versions/3d2ca746-6494-42f7-a168-226cf7076778.enterpriseapi/specifics
