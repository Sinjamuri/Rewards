package com.monsanto.labos.controller;

import com.monsanto.labos.model.AnkenyControlDataItem;
import com.monsanto.labos.model.WfConfigProperty;
import com.monsanto.labos.service.PropertiesService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@Api(value="WfConfigProperty", description="Endpoints for workflow property data", tags = { "Properties" })
public class PropertiesController {

  @Autowired
  PropertiesService propertiesService;

  /**
   * GET method for wf config property searched for by wf config id and key.
   * @param wfConfigId
   * @param key
   * @return
   */
  @ApiOperation(value = "Get property by config id and key")
  @RequestMapping(value="/wf-config-property/wf-config-id/{wf-config-id}/key/{key}", method= RequestMethod.GET, produces="application/json")
  public ResponseEntity<WfConfigProperty> getWfProperty(
    @PathVariable("wf-config-id") Long wfConfigId,
    @PathVariable("key") String key) {
    Optional<WfConfigProperty> optionalWfBaseList = Optional.ofNullable(propertiesService.getWfConfigPropertyByWfConfigIdAndKey(wfConfigId, key));
    if(optionalWfBaseList.isPresent()) {
      return new ResponseEntity<>(optionalWfBaseList.get(), HttpStatus.OK);
    }
    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  /**
   * GET method for wf config property searched for by property id
   * @param propertyId
   * @return
   */
  @ApiOperation(value = "Get property by property id")
  @RequestMapping(value="/wf-config-property/property-id/{property-id}", method= RequestMethod.GET, produces="application/json")
  public ResponseEntity<WfConfigProperty> getWfProperty(
    @PathVariable("property-id") Long propertyId) {
    Optional<WfConfigProperty> optionalWfBaseList = Optional.ofNullable(propertiesService.getWfConfigPropertyByPropertyId(propertyId));
    if(optionalWfBaseList.isPresent()) {
      return new ResponseEntity<>(optionalWfBaseList.get(), HttpStatus.OK);
    }
    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  /**
   * GET method for Ankeny Taqman Lookup table
   */
  @ApiOperation(value = "Get ankeny taqman control data by crop and category (1 - 96 well, 2 - 384 well plate)")
  @RequestMapping(value="/lookup/ankeny-control/crop/{crop}/category/{category}")
  public ResponseEntity<List<AnkenyControlDataItem>> getAnkenyControlData (
    @PathVariable("crop") String crop,
    @PathVariable("category") Integer category) {
    Optional<List<AnkenyControlDataItem>> optional = Optional.ofNullable(propertiesService.getAnkenyTaqmanControlDataByCropAndCategory(crop, category));
    if(optional.isPresent()) {
      return new ResponseEntity<>(optional.get(), HttpStatus.OK);
    }
    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  /**
   * GET method for wf config property searched for by ref key
   * @param refKey
   * @return
   */
  @ApiOperation(value = "Get property by ref key")
  @RequestMapping(value="/wf-config-property/ref-key/{ref-key}", method= RequestMethod.GET,
          produces="application/json")
  public ResponseEntity<List<WfConfigProperty>> getWfProperty(
          @PathVariable("ref-key") String refKey) {
    Optional<List<WfConfigProperty>> optionalWfBaseList = Optional.ofNullable(propertiesService.getWfConfigPropertyByRefKey(refKey));
    if(optionalWfBaseList.isPresent()) {
      return new ResponseEntity<>(optionalWfBaseList.get(), HttpStatus.OK);
    }
    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

}
