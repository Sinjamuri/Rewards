package com.monsanto.labos.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class WfConfigProperty {
  private Long propertyId;
  private Long refKey;
  private Long wfConfigId;
  private String key;
  private String valueVarchar2;
  private Timestamp valueTimestamp;
  private byte[] valueBlob;
  private BigDecimal valueNumber;
  private Timestamp createTs;
  private Timestamp updateTs;

  public Long getPropertyId() {
    return propertyId;
  }

  public void setPropertyId(Long propertyId) {
    this.propertyId = propertyId;
  }

  public Long getRefKey() {
    return refKey;
  }

  public void setRefKey(Long refKey) {
    this.refKey = refKey;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public String getValueVarchar2() {
    return valueVarchar2;
  }

  public void setValueVarchar2(String valueVarchar2) {
    this.valueVarchar2 = valueVarchar2;
  }

  public Timestamp getValueTimestamp() {
    return valueTimestamp;
  }

  public void setValueTimestamp(Timestamp valueTimestamp) {
    this.valueTimestamp = valueTimestamp;
  }

  public byte[] getValueBlob() {
    return valueBlob;
  }

  public void setValueBlob(byte[] valueBlob) {
    this.valueBlob = valueBlob;
  }

  public BigDecimal getValueNumber() {
    return valueNumber;
  }

  public void setValueNumber(BigDecimal valueNumber) {
    this.valueNumber = valueNumber;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public Timestamp getUpdateTs() {
    return updateTs;
  }

  public void setUpdateTs(Timestamp updateTs) {
    this.updateTs = updateTs;
  }
}
