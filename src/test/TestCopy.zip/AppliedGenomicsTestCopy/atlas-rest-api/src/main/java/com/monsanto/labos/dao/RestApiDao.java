package com.monsanto.labos.dao;

import com.bayer.atlas.common.model.*;
import com.monsanto.labos.wrapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RestApiDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<WfBase> getWf(String name) {

        final String sql = "select * from ATLAS.WF where WF_ENTITY_LABEL=? ";
        List<WfBase> wfBaseList = jdbcTemplate.query(sql, new WfBaseWrapper(), name);
        return wfBaseList;
    }

    public List<WfData> getWfData(Long wfId) {

        final String sql = "select wd.*, wdc.WF_DATA_CONFIG_LABEL from ATLAS.WF_DATA wd INNER JOIN ATLAS.WF_DATA_CONFIG wdc ON wd.WF_DATA_CONFIG_ID=wdc.WF_DATA_CONFIG_ID where WF_ID=? ";
        List<WfData> wfDataList = jdbcTemplate.query(sql, new WfDataWrapper(), wfId);
        return wfDataList;
    }

    public WfGridBase getWfGridbase(Long wfGridId) {

        final String sql = "select * from ATLAS.WF_GRID where WF_GRID_ID=? ";
        WfGridBase wfGridBase = jdbcTemplate.queryForObject(sql, new WfGridBaseWrapper(), wfGridId);
        return wfGridBase;
    }

    public WfGridBase getWfGridbase(String projectId, Long sampleId) {

        final String sql = "select * from ATLAS.WF_GRID where PROJECT_ID=? and SAMPLE_ID=?";
        WfGridBase wfGridBase = jdbcTemplate.queryForObject(sql, new WfGridBaseWrapper(), projectId, sampleId);
        return wfGridBase;
    }

    public List<WfGridData> getWfGridDataByWfId(Long wfId) {

        final String sql = "select wgd.*,wgdc.WF_GRID_DATA_TYPE from ATLAS.WF_GRID_DATA wgd INNER JOIN ATLAS.WF_GRID_DATA_CONFIG wgdc ON wgd.WF_GRID_DATA_CONFIG_ID=wgdc.WF_GRID_DATA_CONFIG_ID where WF_ID=? ";
        List<WfGridData> wfGridDataList = jdbcTemplate.query(sql, new WfGridDataWrapper(), wfId);
        return wfGridDataList;
    }

    public List<WfGridData> getWfGridDataByGridId(Long wfGridId) {

        final String sql = "select wgd.*,wgdc.WF_GRID_DATA_TYPE from ATLAS.WF_GRID_DATA wgd INNER JOIN ATLAS.WF_GRID_DATA_CONFIG wgdc ON wgd.WF_GRID_DATA_CONFIG_ID=wgdc.WF_GRID_DATA_CONFIG_ID where WF_GRID_ID=? ";
        List<WfGridData> wfGridDataList = jdbcTemplate.query(sql, new WfGridDataWrapper(), wfGridId);
        return wfGridDataList;
    }

    public List<WfAssoc> getToWfAssocsByWfId(Long wfId){

        final String sql="select wa.*, " +
                "wf_from.wf_entity_type_id wf_entity_type_id_from ,wf_from.wf_entity_label wf_entity_label_from ,wf_to.wf_entity_type_id wf_entity_type_id_to ,wf_to.wf_entity_label wf_entity_label_to " +
                "from ATLAS.WF_ASSOC wa INNER JOIN ATLAS.WF wf_from ON wf_from.WF_ID=wa.FROM_WF_ID INNER JOIN ATLAS.WF wf_to ON wf_to.WF_ID=wa.TO_WF_ID where FROM_WF_ID=?";
        List<WfAssoc> wfAssocList = jdbcTemplate.query(sql, new WfAssocWrapper(), wfId);
        return wfAssocList;
    }

    public List<WfAssoc> getFromWfAssocsByWfId(Long wfId){

        final String sql="select wa.*, " +
                "wf_from.wf_entity_type_id wf_entity_type_id_from ,wf_from.wf_entity_label wf_entity_label_from ,wf_to.wf_entity_type_id wf_entity_type_id_to ,wf_to.wf_entity_label wf_entity_label_to " +
                "from ATLAS.WF_ASSOC wa INNER JOIN ATLAS.WF wf_from ON wf_from.WF_ID=wa.FROM_WF_ID INNER JOIN ATLAS.WF wf_to ON wf_to.WF_ID=wa.TO_WF_ID where TO_WF_ID=?";
        List<WfAssoc> wfAssocList = jdbcTemplate.query(sql, new WfAssocWrapper(), wfId);
        return wfAssocList;
    }

    public List<WfGridAtomData> getSubSampleDetailsByWfIdAndGridId(Long wfId, Long wfGridId){

        final String sql = "SELECT * FROM ATLAS.WF_GRID_ATOM_DATA WHERE Wf_ID=? and WF_GRID_ID = ?";
        List<WfGridAtomData> wfGridAtomDataList = jdbcTemplate.query(sql, new WfGridAtomDataWrapper(), wfId, wfGridId);
        return wfGridAtomDataList;

    }

    public List<WfGridAtomData> getSubSampleDetailsByGridId(Long wfGridId){

        final String sql = "SELECT * FROM ATLAS.WF_GRID_ATOM_DATA WHERE WF_GRID_ID = ?";
        List<WfGridAtomData> wfGridAtomDataList = jdbcTemplate.query(sql, new WfGridAtomDataWrapper(), wfGridId);
        return wfGridAtomDataList;

    }

    public long getNextSeq(String sequenceName)  {

        String sql = "select nextval('" + sequenceName + "') dual";
        Long seqId = jdbcTemplate.queryForObject(sql, Long.class);

        return seqId;
    }

    public List<WfBase> getWfByWfConfigId(String wfConfigid, String limit) {

        final String sql = "select * from ATLAS.wf_step_config wsc inner join ATLAS.WF wf \n" +
                "on wf.wf_step_config_id=wsc.wf_step_config_id inner join ATLAS.wf_entity_type we \n" +
                "on we.wf_entity_type_id=wf.wf_entity_type_id \n" +
                "where wsc.wf_config_id=? and active='Y' order by wf.create_ts desc limit ?; ";
        List<WfBase> wfBaseList = jdbcTemplate.query(sql, new WfBaseWrapper(), Long.valueOf(wfConfigid), Long.valueOf
                (limit));
        return wfBaseList;
    }
    public List<WfWellMap> getWfWellMapByMapType(String plateMapType){

        final String sql = "SELECT * FROM ATLAS.WF_PLATE_MAP WHERE WF_CONFIG_ID = 1 AND TYPE =? ";
        List<WfWellMap> wfWellMapList = jdbcTemplate.query(sql, new WfWellMapWrapper(), plateMapType);
        return wfWellMapList;

    }

}
