package com.monsanto.labos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
@EnableSwagger2
public class SpringApplicationClass extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(SpringApplicationClass.class, args);
    }

    @Bean
    public Docket productApi() {
        ApiInfo apiInfo = new ApiInfo(
          "Atlas API",
          "API resources for interacting with Plant Biotechnology ATLAS",
          "V1.0.0",
          null,
          "Aaron Smith",
          "Apache 2.0",
          "http://www.apache.org/licenses/LICENSE-2.0"
        );

        Set<String> produceSet = new HashSet<>();
        produceSet.add("application/json");

        Set<String> consumeSet = new HashSet<>();
        consumeSet.add("application/json");

        return new Docket(DocumentationType.SWAGGER_2).select()
          .apis(RequestHandlerSelectors.basePackage("com.monsanto.labos"))
          .build()
          .apiInfo(apiInfo)
          .consumes(consumeSet)
          .produces(produceSet);
          //.host("atlas-api.velocity-np.ag");
    }

    /*@Override
    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html")
          .addResourceLocations("classpath:/META-INF/resources/");

        registry.addResourceHandler("/webjars/**")
          .addResourceLocations("classpath:/META-INF/resources/webjars/");
    } */

}
