package com.monsanto.labos.dao;

import com.monsanto.labos.model.AnkenyControlDataItem;
import com.monsanto.labos.model.WfConfigProperty;
import com.monsanto.labos.wrapper.AnkenyControlDataItemWrapper;
import com.monsanto.labos.wrapper.WfConfigPropertyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PropertiesDao {

  @Autowired
  JdbcTemplate jdbcTemplate;

  /**
   * Function for querying atlas.wf_config_properties by wf_config_id and key
   * @param wfConfigId
   * @param key
   * @return
   */
  public WfConfigProperty getWfConfigPropertyByConfigIdAndKey(Long wfConfigId, String key) {
    try {
      final String sql = "select * from ATLAS.WF_CONFIG_PROPERTIES where WF_CONFIG_ID = ? AND KEY = ? ";
      WfConfigProperty wfConfigProperty = jdbcTemplate.queryForObject(sql, new WfConfigPropertyMapper(), wfConfigId, key);
      return wfConfigProperty;
    } catch (EmptyResultDataAccessException e) {
      return null;
    }
  }

  /**
   * Function for querying atlas.wf_config_properties by property_id
   * @param propertyId
   * @return
   */
  public WfConfigProperty getWfConfigPropertyByPropertyId(Long propertyId) {
    try {
      final String sql = "select * from ATLAS.WF_CONFIG_PROPERTIES where property_id = ?";
      WfConfigProperty wfConfigProperty = jdbcTemplate.queryForObject(sql, new WfConfigPropertyMapper(),  propertyId);
      return wfConfigProperty;
    } catch (EmptyResultDataAccessException e) {
      return null;
    }
  }

  public List<WfConfigProperty> getWfConfigPropertyByRefKey(String refKey) {

    try {
      final String sql =
              "select * from ATLAS.wf_config_properties where ref_key=(select property_id from ATLAS" +
              ".wf_config_properties where key = ?);";
      List<WfConfigProperty> wfConfigProperty = jdbcTemplate.query(sql, new WfConfigPropertyMapper(),  refKey);
      return wfConfigProperty;
    } catch (EmptyResultDataAccessException e) {
      return null;
    }
  }


  /**
   * Function for querying atlas.anktaqman_control_lookup by crop and category
   * @param crop
   * @param category
   * @return
   */
  public List<AnkenyControlDataItem> getAnkenyControlData(String crop, Integer category) {
    try {
      final String sql = "select * from ATLAS.ANKTAQMAN_CONTROL_LOOKUP where crop = ? and category = ?";
      List<AnkenyControlDataItem> ankenyControlDataItems = jdbcTemplate.query(sql, new AnkenyControlDataItemWrapper(),  crop, category);
      return ankenyControlDataItems;
    } catch (EmptyResultDataAccessException e) {
      return null;
    }
  }
}
