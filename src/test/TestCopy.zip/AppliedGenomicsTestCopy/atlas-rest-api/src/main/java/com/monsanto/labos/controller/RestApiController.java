package com.monsanto.labos.controller;

import com.bayer.atlas.common.model.*;
import com.monsanto.labos.service.RestApiService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@Api(value="non-wf", description="Endpoints for workflow entity data not specific to wf tables", tags = { "Workflow" })
public class RestApiController {

    @Autowired
    private RestApiService restApiService;

    //WF details

    /**
     * get all entity info by entity label and sample info by entity wf id
     * @param wfEntityLabel
     * @return
     */
    @RequestMapping(value="/getWfDetails", method= RequestMethod.GET, produces="application/json")
    public List<WfBase> getWfDetails(@RequestParam(value="wfEntityLabel", defaultValue="E") String wfEntityLabel) {
        return restApiService.getWfDetailsWithGridDataByWfId(wfEntityLabel);
    }

    //should be used at a minimum
    /**
     * get all entity info by entity label and sample info by it's grid id
     * @param wfEntityLabel
     * @return
     */
    @RequestMapping(value="/getWfDetailsWithAllSampleInfo", method= RequestMethod.GET, produces="application/json")
    public List<WfBase> getWfDetailsWithGridDataByGridId(@RequestParam(value="wfEntityLabel", defaultValue="E") String wfEntityLabel) {
        return restApiService.getWfDetailsWithGridDataByGridId(wfEntityLabel);
    }

    //WF GRID Details

    /**
     * get all sample info by project id and sample Id
     * @param projectId
     * @param sampleId
     * @return
     */
    @RequestMapping(value="/getSampleDetailsBySampleId", method= RequestMethod.GET, produces="application/json")
    public WfGridBase getSampleDetailsBySampleId(@RequestParam(value="projectId", defaultValue="19SM") String projectId,
                                       @RequestParam(value="sampleId", defaultValue="0001") Long sampleId) {
        return restApiService.getSampleDetailsBySampleId(projectId, sampleId);
    }

    /**
     * get all sample info by it's grid id
     * @param wfGridId
     * @return
     */
    @RequestMapping(value="/getSampleDetailsByGridId", method= RequestMethod.GET, produces="application/json")
    public WfGridBase getSampleDetailsByGridId(@RequestParam(value="gridId", defaultValue="19SM") Long wfGridId) {
        return restApiService.getSampleDetailsByGridId(wfGridId);
    }

    //WF GRID ATOM DATA Details

    /**
     * get all sub-sample level data by grid id
     * @param wfGridId
     * @return
     */
    @RequestMapping(value="/getSubSampleDetailsByGridId", method= RequestMethod.GET, produces="application/json")
    public List<WfGridAtomData> getSubSampleDetailsByGridId(@RequestParam(value="gridId", defaultValue="1") Long wfGridId) {
        return restApiService.getSubSampleDetailsByGridId(wfGridId);
    }

    /**
     * get all sub-sample level data by wf Id and grid id
     * @param wfId
     * @param wfGridId
     * @return
     */
    @RequestMapping(value="/getSubSampleDetailsByWfIdAndGridId", method= RequestMethod.GET, produces="application/json")
    public List<WfGridAtomData> getSubSampleDetailsByWfIdAndGridId(@RequestParam(value="wfId", defaultValue="1") Long wfId,
                                                            @RequestParam(value="gridId", defaultValue="1") Long wfGridId) {
        return restApiService.getSubSampleDetailsByWfIdAndGridId(wfId, wfGridId);
    }

    //WF ASSOC details

    /**
     * get all entity associations - both left and right
     * @param wfId
     * @return
     */
    @RequestMapping(value="/getWfRelationshipsByWfId", method= RequestMethod.GET, produces="application/json")
    public List<WfAssoc> getWfRelationshipsByWfId(@RequestParam(value="wfId", defaultValue="1") Long wfId) {
        return restApiService.getWfAssocsOnly(wfId);
    }

    //NCR Details

    /**
     * get all NCRs performed on the entity by entity label
     * @param wfEntityLabel
     * @return
     */
    @RequestMapping(value="/getNCRsByWfLabel", method= RequestMethod.GET, produces="application/json")
    public WfGridBase getNCRsByWfLabel(@RequestParam(value="wfEntityLabel", defaultValue="1S") Long wfEntityLabel) {
        return restApiService.getNCRsByWfLabel(wfEntityLabel);
    }

    /**
     * get all NCRs performed on the entity by entity wf id
     * @param wfId
     * @return
     */
    @RequestMapping(value="/getNCRsByWfId", method= RequestMethod.GET, produces="application/json")
    public WfGridBase getNCRsByWfId(@RequestParam(value="wfId", defaultValue="1") Long wfId) {
        return restApiService.getNCRsByWfId(wfId);
    }

    /**
     * Get next sequence id for a given sequence name
     * @param sequenceName
     * @return
     */
    @ApiOperation(value = "Get next sequence id for a given sequence name")
    @RequestMapping(value="/sequence", method= RequestMethod.GET, produces="application/json")
    public ResponseEntity<Long> getNextSeq(@RequestParam(value = "sequenceName",required = true) String sequenceName) {
        Optional<Long> optionalWfBase = Optional.ofNullable(restApiService.getNextSeq(sequenceName));
        if(optionalWfBase.isPresent()) {
            return new ResponseEntity<>(optionalWfBase.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    /**
     * Get active Wfs
     * @param wfConfigid
     * @return
     */
    @ApiOperation(value = "Get active entities for a workflow")
    @RequestMapping(value="/wfByWfConfigId/{wfConfigid}/limit/{limit}", method= RequestMethod.GET,
            produces="application/json")
    public ResponseEntity<List<WfBase>> getWfByWfConfigId(@PathVariable("wfConfigid") String wfConfigid,
                                                          @PathVariable("limit") String limit) {
        Optional<List<WfBase>> optionalWfBase = Optional.ofNullable(restApiService.getWfByWfConfigId(wfConfigid, limit));
        if(optionalWfBase.isPresent()) {
            return new ResponseEntity<>(optionalWfBase.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    /**
     *
     * @param
     * @return
     */
    @RequestMapping(value="/plateMap", method= RequestMethod.GET, produces="application/json")
    public List<WfWellMap> getWfWellMap(@RequestParam(value = "plateMapType",required = true) String plateMapType) {
        return restApiService.getWfWellMapByMapType(plateMapType);
    }




}
