package com.monsanto.labos.service;

import com.bayer.atlas.common.model.*;
import com.monsanto.labos.dao.RestApiDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RestApiService {

    @Autowired
    private RestApiDao restApiDao;

    public List<WfBase> getWfDetailsWithGridDataByWfId(String name) {

        List<WfBase> wfBaseList = restApiDao.getWf(name);
        for(WfBase wfBase : wfBaseList){

            getWfDataAndAssocsOnly(wfBase);

            List<WfGridBase> wfGridBaseList = new ArrayList<>();
            List<WfGridData> wfGridDataList = restApiDao.getWfGridDataByWfId(wfBase.getWfId());
            Map<Long, List<WfGridData>> wfGridDataListByGridId = wfGridDataList.stream().collect(Collectors.groupingBy(WfGridData::getWfGridId));

            for(Long wfGridId : wfGridDataListByGridId.keySet()){
                WfGridBase gridBase = restApiDao.getWfGridbase(wfGridId);
                gridBase.setWfGridDataList(wfGridDataListByGridId.get(wfGridId));
                wfGridBaseList.add(gridBase);
            }
            wfBase.setWfGridBaseList(wfGridBaseList);
        }

        return  wfBaseList;
    }

    public List<WfBase> getWfDetailsWithGridDataByGridId(String name) {

        List<WfBase> wfBaseList = restApiDao.getWf(name);
        for(WfBase wfBase : wfBaseList){

            getWfDataAndAssocsOnly(wfBase);

            List<WfGridBase> wfGridBaseList = new ArrayList<>();
            List<WfGridData> wfGridDataList = restApiDao.getWfGridDataByWfId(wfBase.getWfId());
            Map<Long, List<WfGridData>> wfGridDataListByGridId = wfGridDataList.stream().collect(Collectors.groupingBy(WfGridData::getWfGridId));

            for(Long wfGridId : wfGridDataListByGridId.keySet()){
                WfGridBase gridBase = getSampleDetailsByGridId(wfGridId);
                wfGridBaseList.add(gridBase);
            }
            wfBase.setWfGridBaseList(wfGridBaseList);
        }

        return  wfBaseList;
    }

    public void getWfDataAndAssocsOnly(WfBase wfBase) {

        getWfDataOnly(wfBase);
        List<WfAssoc> wfAssocFromList = getFromWfAssocsOnly(wfBase.getWfId());
        wfBase.setWfAssocFromList(wfAssocFromList);
        List<WfAssoc> wfAssocToList = getToWfAssocsOnly(wfBase.getWfId());
        wfBase.setWfAssocToList(wfAssocToList);
    }

    public List<WfAssoc> getWfAssocsOnly(Long wfId) {
        List<WfAssoc> wfAssocFromList = getFromWfAssocsOnly(wfId);
        List<WfAssoc> wfAssocToList = getToWfAssocsOnly(wfId);
        wfAssocFromList.addAll(wfAssocToList);

        return wfAssocFromList;
    }

    private List<WfAssoc> getToWfAssocsOnly(Long wfId) {
        return restApiDao.getToWfAssocsByWfId(wfId);
    }

    private List<WfAssoc> getFromWfAssocsOnly(Long wfId) {
        return restApiDao.getFromWfAssocsByWfId(wfId);
    }

    public void getWfDataOnly(WfBase wfBase) {
        List<WfData> wfDataList = restApiDao.getWfData(wfBase.getWfId());
        wfBase.setWfDataList(wfDataList);
    }

    public WfGridBase getSampleDetailsBySampleId(String projectId, Long sampleId) {

        WfGridBase gridBase = restApiDao.getWfGridbase(projectId, sampleId);
        List<WfGridData> wfGridDataList = restApiDao.getWfGridDataByGridId(gridBase.getWfGridId());
        gridBase.setWfGridDataList(wfGridDataList);

        return gridBase;
    }

    public WfGridBase getSampleDetailsByGridId(Long wfGridId) {

        WfGridBase gridBase = restApiDao.getWfGridbase(wfGridId);
        List<WfGridData> wfGridDataList = restApiDao.getWfGridDataByGridId(wfGridId);
        gridBase.setWfGridDataList(wfGridDataList);
        return gridBase;
    }

    public List<WfGridAtomData> getSubSampleDetailsByGridId(Long wfGridId) {
        List<WfGridAtomData> subSampleDetailsByGridId = restApiDao.getSubSampleDetailsByGridId(wfGridId);
        return subSampleDetailsByGridId;
    }

    public List<WfGridAtomData> getSubSampleDetailsByWfIdAndGridId(Long wfId, Long wfGridId) {
        List<WfGridAtomData> subSampleDetailsByWfIdAndGridIdGridId = restApiDao.getSubSampleDetailsByWfIdAndGridId(wfId, wfGridId);
        return subSampleDetailsByWfIdAndGridIdGridId;
    }

    public WfGridBase getWfRelationshipsByWfId(Long wfId) {
        return null;
    }

    public WfGridBase getNCRsByWfLabel(Long wfEntityLabel) {
        return null;
    }

    public WfGridBase getNCRsByWfId(Long wfId) {
        return null;
    }

    public Long getNextSeq(String sequenceName) {

        return restApiDao.getNextSeq(sequenceName);
    }

    public List<WfBase> getWfByWfConfigId(String wfConfigid, String limit) {

        return restApiDao.getWfByWfConfigId(wfConfigid, limit);
    }

    public List<WfWellMap> getWfWellMapByMapType(String plateMapType) {
        List<WfWellMap> wellMapList = restApiDao.getWfWellMapByMapType(plateMapType);
        return wellMapList;
    }

}
