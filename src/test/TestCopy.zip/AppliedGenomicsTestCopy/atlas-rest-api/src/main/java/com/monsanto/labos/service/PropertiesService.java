package com.monsanto.labos.service;

import com.monsanto.labos.dao.PropertiesDao;
import com.monsanto.labos.model.AnkenyControlDataItem;
import com.monsanto.labos.model.WfConfigProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PropertiesService {

  @Autowired
  PropertiesDao propertiesDao;

  public WfConfigProperty getWfConfigPropertyByWfConfigIdAndKey(Long wfConfigId, String key) {
    Optional<WfConfigProperty> optionalWfConfigProperty = Optional.ofNullable(propertiesDao.getWfConfigPropertyByConfigIdAndKey(wfConfigId, key));
    if(!optionalWfConfigProperty.isPresent()) {
      return null;
    }
    return optionalWfConfigProperty.get();
  }

  public WfConfigProperty getWfConfigPropertyByPropertyId(Long propertyId) {
    Optional<WfConfigProperty> optionalWfConfigProperty = Optional.ofNullable(propertiesDao.getWfConfigPropertyByPropertyId(propertyId));
    if(!optionalWfConfigProperty.isPresent()) {
      return null;
    }
    return optionalWfConfigProperty.get();
  }

  public List<AnkenyControlDataItem> getAnkenyTaqmanControlDataByCropAndCategory(String crop, Integer category) {
    Optional<List<AnkenyControlDataItem>> optional = Optional.ofNullable(propertiesDao.getAnkenyControlData(crop, category));
    if(!optional.isPresent()) {
      return null;
    }
    return optional.get();
  }

  public List<WfConfigProperty> getWfConfigPropertyByRefKey(String refKey) {

    Optional<List<WfConfigProperty>> optionalWfConfigProperty = Optional.ofNullable(propertiesDao.getWfConfigPropertyByRefKey(refKey));
    if (!optionalWfConfigProperty.isPresent()) {
      return null;
    }
    return optionalWfConfigProperty.get();
  }
}
