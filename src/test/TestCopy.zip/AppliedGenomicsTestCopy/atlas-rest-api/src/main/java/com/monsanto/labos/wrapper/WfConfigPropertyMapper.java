package com.monsanto.labos.wrapper;

import com.monsanto.labos.model.WfConfigProperty;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class WfConfigPropertyMapper implements RowMapper<WfConfigProperty> {

  @Override
  public WfConfigProperty mapRow(ResultSet resultSet, int i) throws SQLException {

    WfConfigProperty wfConfigProperty = new WfConfigProperty();
    wfConfigProperty.setPropertyId(resultSet.getLong("property_id"));
    wfConfigProperty.setRefKey(resultSet.getLong("ref_key"));
    wfConfigProperty.setWfConfigId(resultSet.getLong("wf_config_id"));
    wfConfigProperty.setKey(resultSet.getString("key"));
    wfConfigProperty.setValueVarchar2(resultSet.getString("value_varchar2"));
    wfConfigProperty.setValueTimestamp(resultSet.getTimestamp("value_timestamp"));
    wfConfigProperty.setValueBlob(resultSet.getBytes("value_blob"));
    wfConfigProperty.setValueNumber(resultSet.getBigDecimal("value_number"));
    wfConfigProperty.setCreateTs(resultSet.getTimestamp("create_ts"));
    wfConfigProperty.setUpdateTs(resultSet.getTimestamp("update_ts"));

    return wfConfigProperty;
  }
}
