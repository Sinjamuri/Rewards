package com.monsanto.labos.model;

public class WfGridDataConfig {

  private Long wfGridDataConfigId;
  private String wfGridDataType;

  public Long getWfGridDataConfigId() {
    return wfGridDataConfigId;
  }

  public void setWfGridDataConfigId(Long wfGridDataConfigId) {
    this.wfGridDataConfigId = wfGridDataConfigId;
  }

  public String getWfGridDataType() {
    return wfGridDataType;
  }

  public void setWfGridDataType(String wfGridDataType) {
    this.wfGridDataType = wfGridDataType;
  }
}
