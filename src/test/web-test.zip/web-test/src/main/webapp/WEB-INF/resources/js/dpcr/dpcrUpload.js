$(function() {
    if( $('#uploadFileButton')) {
        $('#uploadFileButton').click( function() {
            var requestId = $('#requestId').val() ? $('#requestId').val() : null;
            var fileName = $('#rawDataFile').val();
            var formData = new FormData();

            var queryParams = {};
            queryParams.requestId = $('#requestId').val();
            if( !queryParams.requestId ) {
                displayErrorMessages( "Request Name is required");
                return;
            }

            queryParams.fileName = $('#rawDataFile').val();


            formData.append( "rawDataFile", rawDataFile.files[0]);
            checkpoint( function() {
                showProgress();

                queryParams.createUser = checkpointUserId;

                $.ajax({
                    url:   './uploadRemediationFile/?' + $.param( queryParams ),
                    type:   'POST',
                    xhr:    function() {
                        var myXhr = $.ajaxSettings.xhr();
                        if( myXhr.upload ) {
                            myXhr.upload.addEventListener( 'progress', progressHandlingFunction, false )
                        }
                        return myXhr;
                    },
                    error: function( xhr, status, error ) {
                        if( !isJsonResponseValid( error )) {
                            alert( status + "\n" + error);
                            hideProgress();
                        }
                    },
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false
                }).done( function( response ) {
                    if( isJsonResponseValid( response )) {
                        if( response.data && response.data[0] && !response.data[0].isDone ) {
                            var wfAsyncStatusId = response.data[0].wfAsyncStatusId;
                            pollAsyncProcessStatus(
                                wfAsyncStatusId,
                                getCancelAsyncProcessFunction( wfAsyncStatusId )
                            );
                        } else {
                            hideProgress();
                            if( response.messages ) {
                                displaySuccessMessages( response.messages );
                            }
                        }
                    } else {
                        hideProgress();
                    }
                });
            });
        });
    }
});

function progressHandlingFunction(e) {
    if(e.lengthComputable) {
        $('progress').attr( {value: e.loaded, max: e.total});
    }
}

function exportResults( exportType ) {
    postObject = buildPostObject();

    //validates if all required fields are present
    var errors = postObject.errors;

    //posts json to controller
    var jsonPost = postObject.jsonPost;

    if( jsonPost.rows.length == 0 ) {
        errors.add( "No plates are selected for export");
    }

    //if everything is valid, post json object
    if (errors.isEmpty()) {
        var queryParams = $.param( jsonPost );
        window.location.href = './export/' + exportType + '/?' + queryParams;

    } else {
        //alert(errors.values().join('\n'));
        displayErrorMessages( errors.values() );
    }
}

$(document).on('click', '.export-raw-btn', function( e ) {
    var postObject = buildPostObject();

    //validates if all required fields are present
    var errors = postObject.errors;

    //posts json to controller
    var jsonPost = postObject.jsonPost;

    if( jsonPost.rows.length == 0 ) {
        errors.add( "No plates are selected for export");
    }

    var exportType = $(e.currentTarget).data("exportType");
    if( !exportType ) {
        errors.add("No export type provided.");
    }

    //if everything is valid, post json object
    if (errors.isEmpty()) {
        var queryParams = $.param( jsonPost );
        window.location.href = './export/' + exportType + '/?' + queryParams;

    } else {
        displayErrorMessages( errors.values() );
    }
});

$(document).on('click', '.export-results-btn', function( e ) {
    var queryParams = {};
    var row = $(e.currentTarget).closest('tr');

    queryParams.wfId = row.data("wfId");
    var checkedExportElement = row.find('input[name="export-type-' + queryParams.wfId + '"]:checked')

    if( checkedExportElement.length == 0 ) {
        displayErrorMessages( "You must select an export option." )
        return;
    }

    queryParams.exportType = checkedExportElement.data("exportType");
    checkedExportElement.siblings('select').find(':selected')
    if( checkedExportElement.siblings('select').length > 0) {
        var selectedElement = checkedExportElement.siblings('select').find(':selected');
        queryParams.exportOption = selectedElement.val();
    }

    console.log( queryParams );

    checkpoint( function() {
        window.location.href = './export/?' + $.param( queryParams );
    });

});
