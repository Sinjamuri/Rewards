function getLplateLayout() {
	var eplateLocations = new Array();

	//collect data
	for (var i=0;i<trsScanned.size();i++) {
		var trElement = $('#'+trsScanned.values()[i]);
		var trData = trElement.data();
		
		eplateLocations.push({
			batchIndex:trData.batchIndex_r,
			workflowIndex:trData.workflowIndex_r,
			lplateIndex:trData.lplateIndex_r,
			lplateCnt:trData.lplateCnt_r,
			eplateIndex:trData.eplateIndex_r,
			eplateCnt:trData.eplateCnt_r,
			blockBarcodeNbr:trData.blockBarcodeNbr_r,
			colStart:trData.colStart_r,
			sequencingInstrumentType:trData.sequencingInstrumentType_r,
			libraryCreationMethod:trData.libraryCreationMethod_r			
		});
	}
	
	//fetch json plate layout
	$.ajax({		
        url: './lplateLayout/',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({eplateLocations:eplateLocations}),
        processData: false,
        dataType: 'json'
    }).always(function(data) {
    	if (isJsonResponseValid(data, false)) {
    		console.log(data);
    		
    		//render tables
    		renderLplateLayout(data);
    	}
	});
}

function renderLplateLayout(json) {

	//use array join for better string concatenation performance in IE 7
	var html = [];

	//clear div
	$('#platemap').attr('style','min-width:245px;background-color:#C8C8C8');
	$('#platemap').html('<div id="platemap_h">Plate Maps <span class="glyphicon glyphicon-print pull-right" onclick="printLplateLayout();"></span></div>');
	
	var lastBatchIndex = -1;
	for (var i=0; i<json.lplateGroups.length; i++) {
		var lplateGroup = json.lplateGroups[i];
	
		if (lplateGroup.batchIndex!=lastBatchIndex) {
			if (lastBatchIndex!=-1) {
				//close the last batch div
				html.push('</div>');
			}
			
			//begin batch <div>
			html.push('<div class="batch"><h1>');						
			if (lplateGroup.libraryCreationMethod==52) {
				html.push('Manual Batch');
			} else {
				html.push('GenCell Batch');
			}
			html.push('</h1><hr style="margin:4px 0 0px 0;background-color:green;height:3px;">');
			
			lastBatchIndex = lplateGroup.batchIndex;
		}

		html.push('<hr style="margin:0 0 1px 0;background-color:green;height:3px;">');
		html.push('<div class="chipset">');

		html.push('<h2>Chip Set ID: ');
		if (lplateGroup.sequencingInstrumentType==49) {
			html.push('PGM-{' + lplateGroup.workflowIndex + '}');
		} else {
			html.push('Proton-{' + lplateGroup.workflowIndex + '}');
		}	
		var allScanned = true;
		if (lplateGroup.lplateCnt!=lplateGroup.jsonLplates.length) {
			allScanned = false;
		} else {
			for (var j=0; j<lplateGroup.jsonLplates.length; j++) {
				var jsonLplate = lplateGroup.jsonLplates[j];
				var jsonEplates = jsonLplate.jsonEplates;
				if (jsonLplate.eplateCnt!=jsonEplates.length) {
					allScanned = false;
					break;
				}
			}
		}
		if (allScanned) {
			html.push('&nbsp;&nbsp;<img title="Ready To Proceed" src="resources/img/ready.png"/>');
		} else {
			html.push('&nbsp;&nbsp;<img title="One or more E Plates are missing" src="resources/img/redfind.png"/>');
		}
		html.push('</h2>');
		
		var jsonLplates = lplateGroup.jsonLplates; 
		for (var j=0; j<jsonLplates.length; j++) {
			var jsonLplate = jsonLplates[j];
			var jsonEplates = jsonLplate.jsonEplates;
			
			html.push('<h3>L Plate (' + jsonLplate.lplateIndex + ' of ' + lplateGroup.lplateCnt + ')</h3>');
			html.push('<ul>');
			for (var k=0; k<jsonEplates.length; k++) {
				var jsonEplate = jsonEplates[k];
				
				html.push('<li onmouseover="$(\'table.plate96 td.' + jsonEplate.blockBarcodeNbr + '\').addClass(\'hwells\');" onmouseout="$(\'table.plate96 td.' + jsonEplate.blockBarcodeNbr + '\').removeClass(\'hwells\');"><span class="hplate">' + jsonEplate.blockBarcodeNbr + ' (' + jsonEplate.eplateIndex + ' of ' + jsonLplate.eplateCnt + ')</span></li>');
			}
			html.push('</ul>');
			
			//build graphical table
			html.push('<table class="plate96"><tr><th class="tlcorner"></th>');
			for (var c=1; c<=12; c++) {
				html.push('<th>'+c+'</th>');
			}
			html.push('</tr>');
			
			for (var r=1; r<=8; r++) {
				html.push('<tr><th>&#'+(64+r)+';</th>');					
				for (var c=1; c<=12; c++) {
					html.push('<td id="w' + lplateGroup.workflowIndex + '_' + jsonLplate.lplateIndex + '_' + r + '_' + c + '">&nbsp;</td>');
				}
				html.push('</tr>');
			}			
			html.push('</table>');
		}

		//close chipset <div>
		html.push('</div>');		
	}

	//append to the div
	$('#platemap').append(html.join(''));
	
	//now fill in and decorate the grid
	decorateLplateLayout(json);
}

function decorateLplateLayout(json) {
	for (var i=0; i<json.lplateGroups.length; i++) {
		var lplateGroup = json.lplateGroups[i];
		
		var jsonLplates = lplateGroup.jsonLplates; 
		for (var j=0; j<jsonLplates.length; j++) {
			var jsonLplate = jsonLplates[j];
			var jsonEplates = jsonLplate.jsonEplates;
			
			for (var e=0; e<jsonEplates.length; e++) {
				var jsonEplate = jsonEplates[e];
				var jsonEplateWells = jsonEplate.jsonEplateWells;
				
				for (var w=0; w<jsonEplateWells.length; w++) {
					var jsonEplateWell = jsonEplateWells[w];
					var domIdentifier = '#w' + lplateGroup.workflowIndex + '_' + jsonLplate.lplateIndex + '_' + jsonEplateWell.plateTemplateRowNbr + '_' + (jsonEplateWell.plateTemplateColumnNbr+(jsonEplate.colStart-1));
					var title = 'Well: ' + $(domIdentifier).parent().children('th:first').text() + jsonEplateWell.plateTemplateColumnNbr;
					
					title += '\nE Plate: ' + jsonEplate.blockBarcodeNbr;
		
					//add class for on-hover highlighting
					$(domIdentifier).addClass(jsonEplate.blockBarcodeNbr);
					
					if (jsonEplateWell.control) {
						title += '\nControl';
						
						$(domIdentifier).html('C');
						$(domIdentifier).addClass('control');						
					} else {
						title += '\nSample ID: ' + jsonEplateWell.sampleId; 

                        if (jsonEplateWell.dropped) {
                            $(domIdentifier).html('<del>' + jsonEplateWell.sampleId + '</del>');
                            $(domIdentifier).addClass('dropped');
                        } else {
                            $(domIdentifier).html(jsonEplateWell.sampleId);
                        }
					}
		
					$(domIdentifier).attr('title', title);
				}
			}
		}
	}
}

function printLplateLayout() {
	alert('one click printout to the thermal printer');
}

function trScanExtended(trId) {
	getLplateLayout();
}