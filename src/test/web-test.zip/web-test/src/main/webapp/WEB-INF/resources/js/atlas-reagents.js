function isNumberKey(evt)
{
 var charCode = (evt.which) ? evt.which : event.keyCode
 if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;

 return true;
}

$(function () {

    $("form.reagentUpdate").on("submit", function (event) {
        event.preventDefault();

        var actionUrl = $(this).attr('action');
        var formData = $(this).serialize();



        checkpoint(
            function() {
                $.ajax({
                    url: '../../util/secure_checkpoint/?userId=' + checkpointUserId + '&checkpoint=REAGENTS',
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json'
                }).always(function(data) {
                    //log any errors that occurred during authentication
                    if (data.error) {
                        console.log(data.error);
                    }
                    if (data.allowed) {


                                showProgress();
                                console.log('posting '+ formData + '&userId=' + checkpointUserId);
                                console.log('url='+ actionUrl);

                                $.ajax({
                                    url: actionUrl,
                                    data: formData + '&userId=' + checkpointUserId,
                                    type: 'POST',
                                    dataType: 'json'
                                }).always(function(data) {
                                    location.reload(true);
                                });

                    }
                else {
                        flashError('You are not allowed to perform this action!  Please contact an Atlas Administrator.');
                        cancelBadgeScan();
                    }
                });
            }
        )
        console.log("end");
    });


});
