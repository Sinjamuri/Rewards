/**
 * Created by hhzhu on 10/16/14.
 */
$(function () {
    if ($('#loadQCDataButton')) {
        $('#loadQCDataButton').click(function () {
            var requestId = $('#requestId').val() ? $('#requestId').val() : null;
            var fileName = $('#qcDataFile').val();
            var formData = new FormData();

            var queryParams = {};
            queryParams.requestId = $('#requestId').val();
            if (!queryParams.requestId) {
                displayErrorMessages("Request (alternative) Name is required");
                return;
            }
            var queryParams = {};
            queryParams.fileName = $('#qcDataFile').val();
            if (!queryParams.fileName) {
                displayErrorMessages("Rush QC Data File is required");
                return;
            }
            var queryParams = {};
            queryParams.fileName = $('#qcDataFile').val();
            if (queryParams.fileName.endsWith(".csv")) {
                displayErrorMessages("Rush QC Data File Format is good");
            } else {
                displayErrorMessages("Rush QC Data File must be in .csv format!");
                return;
            }

            formData.append("qcDataFile", qcDataFile.files[0]);
            checkpoint(function () {
                showProgress();
                queryParams.createUser = checkpointUserId;

                $.ajax({
                    url: './qcDataUpload/?' + $.param(queryParams),
                    type: 'POST',
                    xhr: function () {
                        var myXhr = $.ajaxSettings.xhr();
                        if (myXhr.upload) {
                            myXhr.upload.addEventListener('progress', progressHandlingFunction, false)
                        }
                        return myXhr;
                    },
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false
                }).done(function (response) {
                    if (isJsonResponseValid(response)) {
                        if (response.data && response.data[0] && !response.data[0].isDone) {
                            var wfAsyncStatusId = response.data[0].wfAsyncStatusId;
                            pollAsyncProcessStatus(
                                wfAsyncStatusId,
                                getCancelAsyncProcessFunction(wfAsyncStatusId)
                            );
                        } else {
                            hideProgress();
                            if (response.messages) {
                                displaySuccessMessages(response.messages);
                            }
                        }
                    } else {
                        hideProgress();
                    }
                });
            });
        });
    }
});