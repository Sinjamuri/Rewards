var enforceSingleScan = true;
