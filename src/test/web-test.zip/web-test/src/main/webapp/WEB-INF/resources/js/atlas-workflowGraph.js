/**
 * Created by pgros1 on 7/3/14.
 */

var atlasWorkflowGraph = (function() {
    var pub = {};

    var _graph;
    var _paper;

    var _wfConfigId;
    var _graphDisplayElement;
    var _readOnly;

    var _stepUrl;
    var _ncrUrl;
    var _nodesUrl;

    var _deactivatedLinks = [];

    var graphConsts = ( function() {
        var pub = {};

        var _stepTextSize = 10;
        pub.getStepTextSize = function() { return _stepTextSize; }

        var _stepTextWidthScale = 1.2;
        pub.getStepTextWidthScale = function() { return _stepTextWidthScale; }

        var _stepTextHeightScale = 1.5;
        pub.getStepTextHeightScale = function() { return _stepTextHeightScale; }

        var _toolTextSize = 10;
        pub.getToolTextSize = function() { return _toolTextSize; }

        var _stepCornerRadiusX = 5;
        pub.getStepCornerRadiusX = function() { return _stepCornerRadiusX; }

        var _stepCornerRadiusY = 5;
        pub.getStepCornerRadiusY = function() { return _stepCornerRadiusY; }

        var _stepStrokeColor = '#555';
        pub.getStepStrokeColor = function() { return _stepStrokeColor; }

        var _stepTextColor = '#FFFFFF';
        pub.getStepTextColor = function() { return _stepTextColor; }

        var _setDefaultToolText = "Set Default";
        pub.getSetDefaultToolText = function() { return _setDefaultToolText; }
        var _setDefaultToolFillColor = '#791A00';
        pub.getSetDefaultToolFillColor = function() { return _setDefaultToolFillColor; }
        var _setDefaultToolTextFillColor = '#FFFFFF';
        pub.getSetDefaultToolTextFillColor = function() { return _setDefaultToolTextFillColor; }
        var _setDefaultToolTextSize = 10;
        pub.getSetDefaultToolTextSize = function() { return _setDefaultToolTextSize; }

        var _ncrStepElementFillColor = '#D18316';
        var _defaultStepElementFillColor = '#8A8D09';
        var _highlightStepElementFillColor = '#FFCF01';

        pub.isNcrElement = function( elementId ) {
            return elementId.substr(0, 3).toLowerCase() == "ncr";
        }
        pub.getElementFillColor = function( elementId ) {
            return (pub.isNcrElement( elementId )) ?  _ncrStepElementFillColor : _defaultStepElementFillColor;
        }
        pub.setElementHighlight = function( element, shouldHighlight ) {
            element.attr( {
                rect: {
                    fill: (shouldHighlight) ? _highlightStepElementFillColor : pub.getElementFillColor( element.id )
                }
            } );
        };

        var _defaultLinkColor = '#791A00';
        var _defaultLinkTargetStyle = {
            'fill':     _defaultLinkColor,
            'stroke':   _defaultLinkColor,
            d:          'M 8 0 L 0 4 L 8 8 z'
        };
        var _defaultLinkConnectionStyle = {
            'stroke':           _defaultLinkColor,
            'stroke-width':     2
        };

        var _secondaryLinkColor = '#888';
        var _secondaryLinkTargetStyle = {
            'fill':     _secondaryLinkColor,
            'stroke':   _secondaryLinkColor,
            d:          'M 4 0 L 0 2 L 4 4 z'
        };
        var _secondaryLinkConnectionStyle = {
            'stroke':           _secondaryLinkColor,
            'stroke-width':     1
        }

        var _ncrLinkColor = '#D18316';
        var _ncrLinkTargetStyle = {
            'fill':     _ncrLinkColor,
            'stroke':   _ncrLinkColor,
            d:          'M 4 0 L 0 2 L 4 4 z'
        };
        var _ncrLinkConnectionStyle = {
            'stroke':           _ncrLinkColor,
            'stroke-width':     1
        }

        pub.updateLinkStyling = function( linkObject ) {
            if( linkObject.attributes.wfGraphLink.status === "D" ) {
                linkObject.attr( {
                    '.marker-target': _defaultLinkTargetStyle ,
                    '.connection': _defaultLinkConnectionStyle
                } );
            } else if( linkObject.attributes.wfGraphLink.status === "N" ) {
                linkObject.attr( {
                    '.marker-target': _ncrLinkTargetStyle ,
                    '.connection': _ncrLinkConnectionStyle
                } );
            } else if( linkObject.attributes.wfGraphLink.status === "I" ) {
                linkObject.remove();
            } else {
                linkObject.attr( {
                    '.marker-target': _secondaryLinkTargetStyle ,
                    '.connection': _secondaryLinkConnectionStyle
                } );
            }
        };

        pub.getElementDimensions = function( elementText, options ) {
            options = options || {};
            var textSize = options.textSize ? options.textSize : _stepTextSize;
            var widthScale = options.widthScale ? options.widthScale : _stepTextWidthScale;
            var heightScale = options.heightScale ? options.heightScale : _stepTextHeightScale;

            var maxLineLength=0;
            var numLines=0;

            if(null != elementText) {
                maxLineLength = _.max(elementText.split('\n'), function (l) {
                    return l.length;
                }).length;
                numLines = elementText.split('\n').length;
            }

            var width = widthScale * ( textSize * ( 0.6 * maxLineLength + 1));
            var height = heightScale * ( (numLines + 1) * textSize );

            return { width: width, height: height };
        }

        return pub;
    }());


    pub.paperClickHandler = ( function() {
        var pub = {};

        var activeLink;
        var activeSourceNode;
        var activeTargetNode;

        function resetLink() {
            if( activeLink ) {
                activeLink.remove();
                activeLink = null;
            }
        }

        function resetNodes() {
            if( activeSourceNode ) {
                graphConsts.setElementHighlight( activeSourceNode, false );
                activeSourceNode = null;
            }

            if( activeTargetNode ) {
                graphConsts.setElementHighlight( activeTargetNode, false );
                activeTargetNode = null;
            }
        }

        pub.clear = function() {
            resetLink();
            resetNodes();
        }

        pub.handleCellDblClick = function( cellView, evt, x, y ) {
            if( cellView && cellView != activeSourceNode) {
                if( !activeLink ) {
                    activeSourceNode = cellView.model;
                    activeLink = makeLinkFromSourceAndPosition( cellView.model.id, x, y );
                    graphConsts.setElementHighlight( activeSourceNode, true );
                    _graph.addCell( activeLink );
                } else {
                    activeLink.set( 'target', {id: cellView.model.id });
                    activeLink = null;

                    resetNodes();
                }
            } else if( activeLink ) {
                resetLink();
                resetNodes();
            }
        }

        pub.handlePaperClick =  function( evt, x, y ) {
            resetLink();
            resetNodes();
        };

        pub.handleMouseOver  = function( elementId ) {
            if( activeLink ) {
                activeTargetNode = _graph.getCell( elementId );
                graphConsts.setElementHighlight( activeTargetNode, true );
            }
        };

        pub.handleMouseOut = function( elementId ) {
            var element = _graph.getCell( elementId );
            if( element != activeSourceNode ) {
                graphConsts.setElementHighlight( element, false );
            }
        }

        return pub;
    }());

    var linkEventHandler = ( function() {
        var pub = {};

        pub.handleRemove = function( link ) {
            if( link instanceof joint.dia.Link ) {

                var sourceStep = link.attributes.source;
                var connectedLinks = _graph.getConnectedLinks( sourceStep, { outbound: true });
                if( connectedLinks.length > 0) {
                    connectedLinks[0].attributes.wfGraphLink.status = 'D';
                    connectedLinks[0].attributes.wfGraphLink.isDirty = true;
                    graphConsts.updateLinkStyling( connectedLinks[0] );
                }

                link.attributes.wfGraphLink.status = 'I';
                link.attributes.wfGraphLink.isDirty = true;
                _deactivatedLinks.push( link.attributes.wfGraphLink );

                graphConsts.updateLinkStyling( link );
            }
        }

        pub.handleSetDefault = function ( link ) {
            if( link instanceof joint.dia.Link ) {
                if( !(link.attributes.wfGraphLink.status === "D") ) {
                    var sourceStep = link.attributes.source;
                    var connectedLinks = _graph.getConnectedLinks( sourceStep, { outbound: true });

                    $.each( connectedLinks, function( index, connectedLink ) {
                        if( connectedLink.attributes.wfGraphLink.status === "D" ) {
                            connectedLink.attributes.wfGraphLink.status = 'A';
                            connectedLink.attributes.wfGraphLink.isDirty = true;
                            graphConsts.updateLinkStyling( connectedLink );
                        }
                    });

                    link.attributes.wfGraphLink.status = "D";
                    link.attributes.wfGraphLink.isDirty = true;
                    graphConsts.updateLinkStyling( link );
                }
            }
        }

        pub.handleOnNewLinkTarget = function( link ) {
            if( !link.wfGraphLink ) {
                link.set('wfGraphLink',  {
                    wfStepAssocId       : null,
                    wfSourceGraphNodeId : link.attributes.source.id,
                    wfTargetGraphNodeId : link.attributes.target.id,
                    status              : (_graph.getConnectedLinks( link.attributes.source, { outbound : true }).length === 1) ? 'D' : 'A',
                    isDirty             : true
                });

                graphConsts.updateLinkStyling( link );
            }
        };

        return pub;
    }());

    function makeLinkFromWfGraphLink( wfGraphLink ) {
        var link = new joint.shapes.custom.EndpointLockedLink({
            source: { id: wfGraphLink.wfSourceGraphNodeId },
            target: { id: wfGraphLink.wfTargetGraphNodeId },
            smooth: true,
            wfGraphLink: wfGraphLink
        });

        graphConsts.updateLinkStyling( link );
        return link;
    }

    function makeLinkFromSourceAndPosition( sourceElementLabel, x, y) {
        var link =  new joint.shapes.custom.EndpointLockedLink({
            source: { id: sourceElementLabel },
            target: { x: x, y: y},
            smooth: true
        });

        link.on('change:target', function() {
            linkEventHandler.handleOnNewLinkTarget( link )
        });
        return link;
    }

    function makeElement(label, id, internalId) {
        var dim = graphConsts.getElementDimensions( label );

        var args = {
            id: id,
            size: { width: dim.width, height: dim.height },
            attrs: {
                text: {
                    text: label,
                    'font-size':    graphConsts.getStepTextSize(),
                    fill:           graphConsts.getStepTextColor(),
                    'font-family': "'Helvetica Neue', Helvetica, Arial, sans-serif'" },
                rect: {
                    width: dim.width, height: dim.height,
                    rx:     graphConsts.getStepCornerRadiusX(),
                    ry:     graphConsts.getStepCornerRadiusY(),
                    stroke: graphConsts.getStepStrokeColor(),
                    fill:   graphConsts.getElementFillColor(id)
                    ,onmouseover: "atlasWorkflowGraph.paperClickHandler.handleMouseOver('" + id + "');"
                    ,onmouseout:  "atlasWorkflowGraph.paperClickHandler.handleMouseOut('" + id + "');"
                }
            }
        };

        if( graphConsts.isNcrElement( id ) && _ncrUrl) {
            args.attrs.a = { 'xlink:href': _ncrUrl + internalId , cursor: 'pointer'  }
        } else if( _stepUrl ) {
            args.attrs.a = { 'xlink:href': _stepUrl + internalId , cursor: 'pointer'  }
        }

        if( args.attrs.a ) {
            return new joint.shapes.custom.ElementLabelLink( args );
        } else {
            return new joint.shapes.basic.Rect( args );
        }
    }

    function makeElementFromNode( wfGraphNode ) {
        return makeElement( wfGraphNode.nodeDescription, wfGraphNode.graphNodeId, wfGraphNode.nodeInternalId );
    }

    function buildGraphFromAdjacencyList(adjacencyList) {
        var elements = [];
        var links = [];

        $.each( adjacencyList, function( index, wfGraphNode ) {
            elements.push( makeElementFromNode( wfGraphNode ) );

            $.each( wfGraphNode.childLinks, function( index, wfGraphLink ) {
                links.push( makeLinkFromWfGraphLink( wfGraphLink ));
            });
        });

        return elements.concat(links);
    }

    pub.init = function( options ) { //wfConfigId, graphDisplayElementId, readOnly ) {
        options = options || {};

        if( options.wfConfigId )            _wfConfigId = options.wfConfigId;
        if( !_wfConfigId )
            throw "GRAPH ERROR [refreshGraph, options.wfConfigId]: No wfConfigId provided to graph";

        if( options.graphDisplayElementId)    _graphDisplayElement = $(options.graphDisplayElementId);
        if( !_graphDisplayElement)
            throw "GRAPH ERROR [refreshGraph, options.graphDisplayElementId]: No DIV element id provided to display graph";

        if( options.readOnly ) {
            _readOnly = options.readOnly;
        } else if( !_readOnly ) {
            _readOnly = true;
        }

        if( options.stepBaseUrl )   _stepUrl = options.stepBaseUrl;
        if( options.ncrBaseUrl )    _ncrUrl = options.ncrBaseUrl;
        if( options.nodesUrl )      _nodesUrl = options.nodesUrl;
        if( !_nodesUrl ) {
            throw "GRAPH ERROR [refreshGraph, options.nodesUrl]: No URL provided to get nodes and links";
        }

        joint.shapes.custom = {};
        joint.shapes.custom.ElementLabelLink = joint.shapes.basic.Rect.extend({
            // Note the `<a>` SVG element surrounding the rest of the markup.
            markup: '<g class="rotatable"><g class="scalable"><rect/></g><a class="WfManagerStepLink"><text/></a></g>',
            defaults: joint.util.deepSupplement(
                { type: 'custom.ElementLabelLink' },
                joint.shapes.basic.Rect.prototype.defaults
            )
        });

        var setDefaultButtonDim = graphConsts.getElementDimensions( graphConsts.getSetDefaultToolText(), {
            textSize: graphConsts.getSetDefaultToolTextSize(),
            widthScale: 1.0,
            heightScale: 0.9
        });

        joint.shapes.custom.EndpointLockedLink = joint.dia.Link.extend({
            toolMarkup: [
                '<g class="link-tool">',
                '   <g class="tool-remove" event="link:remove">',
                '       <circle r="11" />',
                '       <path transform="scale(.8) translate(-16, -16)" d="M24.778,21.419 19.276,15.917 24.777,10.415 21.949,7.585 16.447,13.087 10.945,7.585 8.117,10.415 13.618,15.917 8.116,21.419 10.946,24.248 16.447,18.746 21.948,24.248z"/>',
                '       <title>Remove Step Transition</title>',
                '   </g>',
                '   <g class="tool-options" event="link:options">',
                '       <circle r="11" transform="translate(25)"/>',
                '       <path fill="white" transform="scale(.55) translate(29, -16)" d="M31.229,17.736c0.064-0.571,0.104-1.148,0.104-1.736s-0.04-1.166-0.104-1.737l-4.377-1.557c-0.218-0.716-0.504-1.401-0.851-2.05l1.993-4.192c-0.725-0.91-1.549-1.734-2.458-2.459l-4.193,1.994c-0.647-0.347-1.334-0.632-2.049-0.849l-1.558-4.378C17.165,0.708,16.588,0.667,16,0.667s-1.166,0.041-1.737,0.105L12.707,5.15c-0.716,0.217-1.401,0.502-2.05,0.849L6.464,4.005C5.554,4.73,4.73,5.554,4.005,6.464l1.994,4.192c-0.347,0.648-0.632,1.334-0.849,2.05l-4.378,1.557C0.708,14.834,0.667,15.412,0.667,16s0.041,1.165,0.105,1.736l4.378,1.558c0.217,0.715,0.502,1.401,0.849,2.049l-1.994,4.193c0.725,0.909,1.549,1.733,2.459,2.458l4.192-1.993c0.648,0.347,1.334,0.633,2.05,0.851l1.557,4.377c0.571,0.064,1.148,0.104,1.737,0.104c0.588,0,1.165-0.04,1.736-0.104l1.558-4.377c0.715-0.218,1.399-0.504,2.049-0.851l4.193,1.993c0.909-0.725,1.733-1.549,2.458-2.458l-1.993-4.193c0.347-0.647,0.633-1.334,0.851-2.049L31.229,17.736zM16,20.871c-2.69,0-4.872-2.182-4.872-4.871c0-2.69,2.182-4.872,4.872-4.872c2.689,0,4.871,2.182,4.871,4.872C20.871,18.689,18.689,20.871,16,20.871z"/>',
                '       <title>Link options.</title>',
                '   </g>',
                    '<g class="link-setDefault" event="setDefault" transform="translate(' + ( 0 - setDefaultButtonDim.width / 2 ) + ', -32)">',
                '       <rect rx="5" ry="5" fill="' + graphConsts.getSetDefaultToolFillColor() + '" width="' + setDefaultButtonDim.width + '" height="' + setDefaultButtonDim.height + '" />',
                '       <text style="font-size: ' + graphConsts.getSetDefaultToolTextSize() + ';" fill="' + graphConsts.getSetDefaultToolTextFillColor() + '" transform="translate(10, 12)">' + graphConsts.getSetDefaultToolText() + '</text>',
                '       <title>Set as Default Step Transition</title>',
                '   </g>',
                '</g>'
            ].join(''),
            arrowheadMarkup: '<g class="marker-arrowhead-group"></g>'
        });

        _graph = new joint.dia.Graph;

        var graphDisplayElement = $(_graphDisplayElement);
        _paper = new joint.dia.Paper({
            el: _graphDisplayElement,
            gridSize: 1,
            model: _graph,
            interactive: !_readOnly
//            width: graphDisplayElement.width(),
//            height: ( $(window).height() *.8 > 480 ? $(window).height() *.8 : 480 )
        });

//        $(window).resize( function() {
//            _paper.setDimensions( graphDisplayElement.width(), ( $(window).height() *.8> 480 ? $(window).height() *.8 : 480 ));
//        });

        pub.refresh();

        _paper.on( 'cell:pointerdblclick', pub.paperClickHandler.handleCellDblClick);
        _paper.on( 'blank:pointerclick ', pub.paperClickHandler.handlePaperClick );

        _paper.on('cell:pointerclick',
            function (cell,evt, x, y) {
                //alert("class name"+ evt.toElement.parentNode.classList.contains("link-setDefault"));
                //alert(evt.target.parentNode.getAttribute("class"));
                var targetParentEvent = evt.target.parentNode.getAttribute("event");
                if (targetParentEvent && targetParentEvent === "link:remove") {
                    linkEventHandler.handleRemove(cell.model);
                } else if (targetParentEvent && targetParentEvent === "setDefault") {
                    linkEventHandler.handleSetDefault(cell.model);
                }
            }
        );

    }

    pub.refresh = function() {
        pub.paperClickHandler.clear();

        try {
            $.ajax( {
                url: _nodesUrl + _wfConfigId + '/',
                type: "GET",
                contentType: 'application/json',
                processData: false,
                dataType: 'json'
            }).always( function( data ) {
                var adjacencyList = data;

                var cells = buildGraphFromAdjacencyList(adjacencyList);
                _graph.resetCells(cells);

                joint.layout.DirectedGraph.layout(_graph, { setLinkVertices: true });
                _paper.fitToContent(window.width, window.height, 20 );
            });

        } catch (e) { alert("GRAPH ERROR:" + e); }
    }

    pub.getDirtyWfGraphLinks = function() {
        var dirtyWfGraphLinks = _deactivatedLinks.slice(0);
        $.each( _graph.getLinks(), function( index, link ) {
            if( link.attributes.wfGraphLink.isDirty ) {
                dirtyWfGraphLinks.push( link.attributes.wfGraphLink );
            }
        });

        return dirtyWfGraphLinks;
    }

    pub.clearDirtyWfGraphLinks = function() {
        $.each( pub.getDirtyWfGraphLinks(), function( index, wfGraphLink ) {
            wfGraphLink.isDirty = false;
        });

        _deactivatedLinks = [];
    }

    return pub;
}());
