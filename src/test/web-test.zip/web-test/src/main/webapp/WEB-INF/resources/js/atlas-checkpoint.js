var checkpointUserId = null;
var checkpointTimeoutId;
var checkpointTimeoutCycles = 0;

function showProgress() {
    $('#wf-modal-wait').modal({backdrop:'static',keyboard:false});
}

function hideProgress() {
    $('#wf-modal-wait').modal('hide');
}

function uidCapture(charsCaptured) {
    //strip off prefix and suffix
    var bc = charsCaptured.substring(4);
    bc = bc.substring(0,bc.length-1);
    console.log('Encrypted barcode captured: ' + bc);

    var decrypted = CryptoJS.AES.decrypt(bc, "H5WYX7DB9cgeUaHa");
    console.log(decrypted);

    var uid = decrypted.toString(CryptoJS.enc.Latin1);
    console.log(uid);

    //set checkpoint user id
    checkpointUserId = uid;
}

//cancel pending scan
function cancelBadgeScan() {
    checkpointUserId = null;
    clearTimeout(checkpointTimeoutId);
    checkpointTimeoutCycles = 0;

    $('#wf-modal').modal('hide');
}

function checkpoint(fn) {
    if (checkpointTimeoutCycles==0) {
        console.log('initializing checkpoint');
        checkpointTimeoutCycles = 1;

        //clear any pending saves
        checkpointUserId = null;
        clearTimeout(checkpointTimeoutId);

        //check for ATLAS_UID cookie
        if ($.cookie('ATLAS_UID')) {
            var residentCookieUID = CryptoJS.AES.decrypt($.cookie('ATLAS_UID'), 'H5WYX7DB9cgeUaHa').toString(CryptoJS.enc.Latin1);
            console.log('Resident Atlas UID cookie found: ' + residentCookieUID);
            checkpointUserId = residentCookieUID;

            fn();
        } else {
            //show user id scan dialog
            console.log('checkpoint - show user id scan dialog');
            $('#wf-modal').modal({backdrop:'static',keyboard:false});

            checkpointTimeoutId = setTimeout(function(){checkpoint(fn)},10);
        }
    } else {
        if (checkpointUserId == null) {
            checkpointTimeoutCycles++;

            //allow 30 seconds to scan user id
            if (checkpointTimeoutCycles<3000) {
                checkpointTimeoutId = setTimeout(function(){checkpoint(fn)},10);
            } else {
                //hide user id dialog and cancel action
                console.log('checkpoint timeout');
                cancelBadgeScan();
            }
        } else {
            //user id has been captured, execute closure
            $('#wf-modal').modal('hide');
            fn();
        }
    }
}