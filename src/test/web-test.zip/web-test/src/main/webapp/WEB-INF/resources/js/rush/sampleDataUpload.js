/**
 * Created by hhzhu on 10/15/14.
 */
$(function () {
    if ($('#loadSampleFileButton')) {
        $('#loadSampleFileButton').click(function () {
            var requestId = $('#requestId').val() ? $('#requestId').val() : null;
            var fileName = $('#sampleDataFile').val();
            var formData = new FormData();

            var queryParams = {};
            queryParams.requestId = $('#requestId').val();
            if (!queryParams.requestId) {
                displayErrorMessages("Request (alternative) Name is required");
                return;
            }
            var queryParams = {};
            queryParams.fileName = $('#sampleDataFile').val();
            if (!queryParams.fileName) {
                displayErrorMessages("Rush Sample File is required");
                return;
            }
        var queryParams = {};
            queryParams.fileName = $('#sampleDataFile').val();
            if (queryParams.fileName.endsWith(".csv")) {
             displayErrorMessages("Rush Sample File Format is good");
            } else {
                displayErrorMessages("Rush Sample File must be in .csv format!");
                return;
            }

            formData.append("sampleDataFile", sampleDataFile.files[0]);
            checkpoint(function () {
                showProgress();
                queryParams.createUser = checkpointUserId;

                $.ajax({
                    url: './sampleDataUpload/?' + $.param(queryParams),
                    type: 'POST',
                    xhr: function () {
                        var myXhr = $.ajaxSettings.xhr();
                        if (myXhr.upload) {
                            myXhr.upload.addEventListener('progress', progressHandlingFunction, false)
                        }
                        return myXhr;
                    },
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false
                }).done(function (response) {
                    if (isJsonResponseValid(response)) {
                        if (response.data && response.data[0] && !response.data[0].isDone) {
                            var wfAsyncStatusId = response.data[0].wfAsyncStatusId;
                            pollAsyncProcessStatus(
                                wfAsyncStatusId,
                                getCancelAsyncProcessFunction(wfAsyncStatusId)
                            );
                        } else {
                            hideProgress();
                            if (response.messages) {
                                displaySuccessMessages(response.messages);
                            }
                        }
                    } else {
                        hideProgress();
                    }
                });
            });
        });
    }
});

