//reset by sitemesh template script block
var wfStepConfigId;
var trExtendedConfig;
var pageQueueTable;
var wfConfigId;
var plateType;
//used for rendering arrays of inputs and
//back collecting data
var uniqueId = 1;

//datatable global variables for fluid resizing
var jqdtProjectresults;

//plate composite load flag
var gridDataLoaded = false;
var graphDataLoaded = false;

//regex validation is tricky to enforce
//set flag to prevent save actions by barcode scanning
var jsonPostValid = true;

//refresh queue when idle and no data has been collected
var idleTimeMinutes = 0;

function timerIncrement() {
    idleTimeMinutes = idleTimeMinutes + 1;
    if (idleTimeMinutes > 5) { //5 minutes
        if (typeof window.reloadOnIdle === 'undefined') {
            window.location.reload();
        } else {
            if (window.reloadOnIdle) {
                window.location.reload();
            }
        }
    }
}

// For generation of div elements with attributes
function makeDivElement ( attr ) {
    var divElement = $('<div></div>');
    if( attr ) divElement.attr( attr );
    return divElement;
}

//on document ready
$(function() {
    //warn on invalid browser
    if (!(navigator.userAgent.match(/Chrome/g))) {
        alert('Please restart Atlas in a Chrome browser session');
    }

    //idle time refresh
    var idleInterval = setInterval(timerIncrement, 60000); // 1 minute
    $(this).mousemove(function (e) {
        idleTimeMinutes = 0;
    });
    $(this).keypress(function (e) {
        idleTimeMinutes = 0;
    });

    //convenience functions
    if (typeof String.prototype.endsWith !== 'function') {
        String.prototype.endsWith = function(suffix) {
            return this.indexOf(suffix, this.length - suffix.length) !== -1;
        };
    }

    //show tiemstamp when this wf was last made active
    showMaxTs();


    //if a page queue object exists then render a scan line
    var pagequeueCols = $('#pagequeue > thead > tr:first th');
    if (pagequeueCols.length>0) {
        //do not render twice, so check for existence
        //this can happen if a jQuery load pulls in this file again
        if (!($('#scanline').length)) {
            var label = 'SCAN LINE('+ trsScanned.size() +')';
            if (typeof scanLineLabel != 'undefined') {
                label = scanLineLabel + '('+ trsScanned.size() +')';
            }else{
                var removeSortColumns = [];
                for(var i = 0 ; i < pagequeueCols.length ; i++){
                    if(pagequeueCols[i].innerHTML == '' || pagequeueCols[i].class == 'extended'){
                        removeSortColumns.push(i);
                    }
                }
                pageQueueTable = $('#pagequeue').dataTable({
                    paging      : false,
                    aoColumnDefs  : [{
                        bSortable   : false,
                        aTargets    : removeSortColumns
                    }],
                    fnDrawCallback : function(){
                        var noSortRows = $(".noSort");
                        var noSortRowsSize = noSortRows.size();
                        if(noSortRowsSize > 1){
                            for(var i = 0 ; i < noSortRowsSize ; i++){
                                $('#pagequeue thead').append(noSortRows[i]);
                            }
                        }else{
                            $('#pagequeue thead').append(noSortRows);
                        }
                        var trScanline = $('#scanline');
                        $('#pagequeue thead').append(trScanline);
                    }

                });
            }
            $('<tr id="scanline"><td colspan="' + (pagequeueCols.length) + '">&uarr;&nbsp;&nbsp;&nbsp;&uarr;&nbsp;&nbsp;&nbsp;&uarr;&nbsp;&nbsp;&nbsp;<span id="labelSpan">' + label + '</span>&nbsp;&nbsp;&nbsp;&uarr;&nbsp;&nbsp;&nbsp;&uarr;&nbsp;&nbsp;&nbsp;&uarr;</td></tr>').insertAfter('#pagequeue > thead > tr:last');
        }
    }

    //call setup function if it exists
    if (typeof initGraphPage == 'function') {
        initGraphPage();
    }

    //pretty dates
    prettyDates();
    setInterval(prettyDates, 5000);


  /* $(document).ready(function(){
        $('#QRM001').dblclick(function(e){
            e.preventDefault();
        });
    });*/

    try{
        //datepicker
        $('.datepicker').datepicker({
            autoclose:true,
            todayHighlight:true
        });
    } catch (err) {
        console.debug( "Datepicker not found");
    }

    try{
        //render default buttons
        renderButtons([
            {
                title:'Refresh',
                target:'QRM000',
                jsFunction: function () {
                    location.reload();
                },
                onscreen:false
            },
            {
                title:'Save',
                target:'QRM001',
                jsFunction:function() {

                    var $el = $(this);
                    if ($el.data('clicked')) {
                        // Previously clicked, stop actions
                        e.preventDefault();
                        e.stopPropagation();
                    } else {
                        // Mark to ignore next click
                        $el.data('clicked', true);
                        if (jsonPostValid) {
                            postJson('false');
                        }
                        else {
                            alert('Please correct the highlighted errors before saving!')
                        }
                        // Unmark after 1 second
                        window.setTimeout(function () {
                            $el.removeData('clicked');
                        }, 1000)
                    }
                },
                onscreen:false
            },
            {
                title:'Hold',
                target:'QRM002',
                jsFunction: function () {
                    if (jsonPostValid) {
                        postJson('true');
                    } else {
                        alert('Please correct the highlighted errors before saving!')
                    }
                },
                onscreen:false
            }
        ]);
        // Added clause because this is fundamental to core workflow pages, but not admin pages, and
        // the function is in an external file which is not necessary with admin pages. Will wait for js refactoring.
    } catch( err ) {
        console.debug( "RenderButtons function not found" );
    }

    //initialize datatable styling for project result page
    if ($('#jqdt-projectresults').length==1) {
        jqdtProjectresults = $('#jqdt-projectresults').dataTable({
            "bPaginate": false,
            "sScrollY": '100000px',
            "bSort": false,
            "bFilter": false,
            "bInfo": false,
            "sScrollX": '100%'
        });
        setTimeout(function() {
            $('.dataTables_scrollBody').css('height', Math.floor($(window).height() - $('.dataTables_scrollHead').height()-125));
        },10);
        $(window).resize(function() {
            jqdtProjectresults.fnAdjustColumnSizing();
            $('.dataTables_scrollBody').css('height', Math.floor($(window).height() - $('.dataTables_scrollHead').height()-125));
        });
    }

    //tabbed interface of workflow detail page
    if ($('#easytabs-container').length==1) {
        $('#easytabs-container').easytabs();
    }

    //fun progress indicators
    var progressImages = ['Superman','Megaman','Batman','Loki','Hawk Eye','Thor','The Hulk','Captain America','Ironman','The Zombie','The Ninja','Cutman','Link','Pikachu','Trollface','Michael Myers','Tom Morello','Santa Claus'];
    var progressIndex = getRandomInt(0,progressImages.length-1);
    $('#wfModalWaitMsg').html('Please wait while '+progressImages[progressIndex]+' saves your request<br><br><div class="progressImg" id="progressImg'+progressIndex+'"></div>');

    // For hiding message divs on clicks, just set data-hide attribute of a button to class value (e.g., 'alert') and then
    // give parent element to hide the class (e.g., 'alert'). Clicking the button will then hide it.
    $("[data-hide]").on("click", function(){
        $(this).closest("." + $(this).attr("data-hide")).hide();
    });

    //cherry picking
    fillCherries();

    //environment check
    checkProduction();

    //populate Filter Drop Downs
    populateFilterDropDowns();

    //overview
    populateOverView();

});

//this is the array of tr ids that indicates what has been scanned
//and is used to move rows above and below the scan line
var trsScanned = new HashSet();

function isJsonResponseValid(jsonResponse) {
    if (jsonResponse.exception!=null) {
        //show exception if service failed
        displayErrorMessages( jsonResponse.exception );
    } else {
        if (jsonResponse.errorCnt>0) {
            displayErrorMessages( jsonResponse.errors );
        } else {
            return true;
        }
    }

    return false;
}

function trRemove(trId) {
    if (trsScanned.contains(trId)) {
        if (confirm('Are you sure you want to push this row below\n' +
                'the scan line? Any collected data will be lost.')) {
            var trScan = $('#'+trId);
            //get the scan line row reference
            var trScanline = $('#scanline');

            if($(trScan).hasClass("noSort")){
                $(trScan).removeClass("noSort");
            }

            //remove from collection
            trsScanned.remove(trId);

            //move row to just after commit line
            trScan.insertBefore('#pagequeue > tbody > tr:first');

            //clear extended data
            $('#'+trId+' td.extended').html('');

            var label = 'SCAN LINE('+ trsScanned.size() +')';
            if (typeof scanLineLabel != 'undefined') {
                label = scanLineLabel + '('+ trsScanned.size() +')';
            }
            $('#labelSpan').text(label);

            pageQueueTable.fnDraw();
        }
    }
}

function trScan(trId) {
    //get the data row reference
    var trScan = $('#'+trId);
    var trData = trScan.data();

    //set data collection column header
    $('#pagequeue > thead > tr > th.extended').html('Data Collection');

    //if the setIndex = 0 it means the row can not be scanned
    if (!$(trScan).data('setIndex') || $(trScan).data('containerLocked')) {
        alert('The row you have scanned is disabled');
    } else if(!isFiltered(trId)){
        alert('The row you have scanned is not filtered.');
    } else {
        //only move the item if it has not already been scanned
        if (!(trsScanned.contains(trId))) {
            if (typeof enforceSingleScan != 'undefined') {
                if (enforceSingleScan && trsScanned.size()>0) {
                    alert('You may only pass one container at a time at this step!');
                    return;
                }
            }
            $(trScan).addClass("noSort");

            trsScanned.add(trId);

            //get the scan line row reference
            var trScanline = $('#scanline');

            //move row to just before commit line
            trScan.insertBefore(trScanline);
            var label = 'SCAN LINE('+ trsScanned.size() +')';
            if (typeof scanLineLabel != 'undefined') {
                label = scanLineLabel + '('+ trsScanned.size() +')';
            }
            $('#labelSpan').text(label);

            //remove any action buttons on the row
            $(trScan).find('td a.btn').remove();

            //call workflowConfigId specific function
            //for more advanced data collection
            if (trExtendedConfig != null) {
                var tdExtended = $('#'+trId+' td.extended');

                //clear existing html in case row was moved down
                //then back up above the commit line
                var content = '<table class="extended">';

                //dynamically create input fields for data collection
                for (var i=0;i<trExtendedConfig.length;i++) {
                    var fieldId = trId+'_'+trExtendedConfig[i].attribute;
                    var attrib = trExtendedConfig[i].attribute;
                    var required = false;
                    var placeholder = null;

                    var inputArray = null;
                    var inputArrayCnt = 1;
                    var inputSetId = nextUniqueId();

                    if (attrib.endsWith('_r')) {
                        required = true;

                        var attribBase = attrib.substring(0,attrib.length-2);
                        if (trData[attribBase+'_m']) {
                            //test to see if match variable is an array
                            //represented in JSON notation
                            try {
                                inputArray = eval(trData[attribBase+'_m']);
                            } catch (e) {
                            }

                            if (isNumber(trData[attribBase+'_m']) || inputArray==null) {
                                inputArray = null;
                                placeholder = trData[attribBase+'_m'];
                            } else {
                                inputArrayCnt = inputArray.length;
                                placeholder = inputArray;
                            }
                        }
                    }

                    for (var inputIndex=1;inputIndex<=inputArrayCnt;inputIndex++) {
                        content += '<tr';

                        if (attrib=="ncrReason") {
                            content += ' id="'+trId + '_ncrReason_ReasonRow" style="display:none;"';
                        }

                        content += '><td class="r pr5" title="';

                        if (required) {
                            content += 'Required">';
                            content += '<b>' + trExtendedConfig[i].label;
                            if (inputArray!=null && inputArrayCnt>1) {
                                content += ' ' + inputIndex;
                            }
                            content += '</b>';
                        } else {

                            if (trExtendedConfig[i].type=='readonly') {
                                content += 'Informational">';
                                content += trExtendedConfig[i].label;
                            } else {
                                content += 'Optional">';
                                content += '<i>' + trExtendedConfig[i].label + '</i>';
                            }
                        }
                        content += '</td><td>';

                        if (trExtendedConfig[i].type=='input') {
                            //begin input element
                            content += '<input class="captureScan" type="text" ';

                            if (inputArray!=null) {
                                //array of inputs
                                content += 'name="inputSet'+ inputSetId + '" ';

                                content += 'onchange="$(\'#'+trId+'\').data(\''+trExtendedConfig[i].attribute+'\',getInputSetVal(' + inputSetId + '));" ';
                            } else {
                                //single input
                                content += 'onchange="$(\'#'+trId+'\').data(\''+trExtendedConfig[i].attribute+'\',this.value);" ';
                            }

                            //expected value
                            if (placeholder!=null) {
                                if (inputArray!=null) {
                                    content += 'placeholder="' + placeholder[inputIndex-1] + '" ';
                                } else {
                                    content += 'placeholder="' + placeholder + '" ';
                                }
                            }

                            //@PRE-PROD - remove prior to production release
                            content += 'ondblclick="$(this).val(this.placeholder);$(this).change();" ';

                            //optional maxlength
                            if (trExtendedConfig[i].maxlength) {
                                content += 'maxlength="'+trExtendedConfig[i].maxlength+'" ';
                            }

                            //regex match
                            if (trExtendedConfig[i].regexMatch!=null && trExtendedConfig[i].regexMatch!='') {
                                content += 'onblur="if ($(this).val()!=\'\' && new RegExp(\''+ trExtendedConfig[i].regexMatch + '\').test($(this).val())==false) {alert(\'The value you entered or scanned is not valid\');$(this).focus();$(this).select();jsonPostValid=false;} else {jsonPostValid=true;}" ';
                            }

                            if (trExtendedConfig[i].attribute=='location' || trExtendedConfig[i].attribute=='storageLocation' || trExtendedConfig[i].attribute=='beelocation' || trExtendedConfig[i].attribute=='jobType') {
                                content += 'id="'+fieldId+'" ';
                            }
                            //end input element
                            content += '/>';
                        } else if (trExtendedConfig[i].type=='option') {

                        } else if (trExtendedConfig[i].type=='readonly') {

                            //readonly just displays a value
                            if (trExtendedConfig[i].value) {
                                content += '<span class="label label-info">' + trExtendedConfig[i].value + '</span>';
                            }

                        } else if (trExtendedConfig[i].type=='select') {
                            //begin select element
                            content += '<select id="'+fieldId+'" onchange="$(\'#'+trId+'\').data(\''+trExtendedConfig[i].attribute+'\',this.value);';
                            if (trExtendedConfig[i].attribute=='ncrCode') {
                                content += 'if (this.value) {$(\'#' + trId + '_ncrReason_ReasonRow\').show();$(\'#' + fieldId + '_row\').show();$(\'#' + fieldId + '_comment\').focus();ncrPopup(this.value,\'.\');} else {$(\'#' + fieldId + '_row\').hide();$(\'#' + trId + '_ncrReason_ReasonRow\').hide();};';
                            }
                            content += '">';

                            //append options
                            if (trExtendedConfig[i].options) {
                                for (var j=0;j<trExtendedConfig[i].options.length;j++) {
                                    if (trExtendedConfig[i].options[j]!=null) {
                                        content += '<option value="' + trExtendedConfig[i].options[j].value + '"';
                                        if (trExtendedConfig[i].options[j].selected) {
                                            content += ' selected="selected"';
                                        }
                                        content += '>' + trExtendedConfig[i].options[j].label + '</option>';
                                    } else {
                                        content += '<option value=""></option>';
                                    }
                                }
                            } else {
                                if (trData[attribBase+'_o']) {
                                    var options = eval(trData[attribBase+'_o']);

                                    for (var optionIndex=0;optionIndex<options.length;optionIndex++) {
                                        content += '<option value="' + options[optionIndex] + '" ';

                                        //the first is always the default
                                        if (optionIndex==0) {
                                            content += 'selected="selected" ';
                                        }

                                        content += '>' + options[optionIndex] + '</option>';
                                    }
                                } else {
                                    console.log('select element does not have any static options or dynamic match values');
                                }
                            }

                            //end select element
                            content += '</select>';

                            //ncr comment
                            if (trExtendedConfig[i].attribute=='ncrCode') {
                                content += '</td></tr><tr style="display:none;" id="'+fieldId+'_row"><td class="r pr5" title="Optional"><i>Additional Notes</i></td>';
                                content += '<td><input type="text" id="'+fieldId+'_comment" maxlength="500" onchange="$(\'#'+trId+'\').data(\'ncrComment\',this.value);"/></td>';
                            }
                        } else {
                            alert('The trExtendedConfig type must be (input|option|select)');
                        }

                        //append to data collection td
                        content += '</td></tr>';
                    }
                }

                content += '</table>';

                tdExtended.html(content);

            }
        } else {
            //remove from scanned set
            trRemove(trId);
        }

        //enable save button if trsScanned is not empty
        if (trsScanned.size()!=0) {
            $('#QRM001').removeClass('disabled');
            $('#QRM002').removeClass('disabled');
        } else {
            $('#QRM001').addClass('disabled');
            $('#QRM002').addClass('disabled');
        }
    }

    //call setup function if it exists
    if (typeof trScanExtended == 'function') {
        trScanExtended(trId);
    }

    pageQueueTable.fnDraw();

    //set focus to the first input in the set
    $('#'+trId+' td.extended input:first').focus();
}

function isNumber(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

function buildPostObject() {
    //validates if all required fields are present
    var errors = new HashSet();

    //posts json to controller
    var jsonPost = {rows:[]};

    //setIndex to ensure all required rows for a set are captured
    var setIndexes = new HashSet();

    //for each row above the scan line, evaluate data
    //attribute tags to see what is required and build
    //the transport object along the way
    for (var i=0;i<trsScanned.size();i++) {
        var trElement = $('#'+trsScanned.values()[i]);
        var trData = trElement.data();

        //everything past the tr prefix is the hashmap key
        var mapValues = {};

        //console.debug(trData);
        for (var attrib in trData) {
            if (attrib=='setIndex') {
                setIndexes.add(trData[attrib]);
            }

            //required data attributes end with _r
            if (attrib.endsWith('_r')) {
                var attribBase = attrib.substring(0,attrib.length-2);

                //validation is not needed when a NCR code is applied to the container
                if (!(trData['ncrCode'])) {
                    if (!(trData[attrib])) {
                        console.log(attrib + ' is missing data');

                        errors.add('One or more required fields are missing for the rows highlighted.');
                        trElement.css({border:'2px solid red'});
                    } else {
                        //check for _m match attribute
                        if (trData[attribBase+'_m']) {
                            if (!(trData[attrib]==trData[attribBase+'_m'])) {
                                errors.add('One or more required fields do not match expected values for the rows highlighted.');
                                trElement.css({border:'2px solid red'});
                            }
                        }

                        //strip off _r suffix for marshaling
                        mapValues[attribBase] = trData[attrib];
                    }
                } else {
                    //collect other values which include workflow and container identifiers
                    mapValues[attribBase] = trData[attrib];
                }
            } else if (attrib.endsWith('_m')) {
                //ignore _m data attributes for marshaling
                //this is a match attribute paired with _r
            } else {
                mapValues[attrib] = trData[attrib];
            }
        }
        jsonPost.rows.push(mapValues);
    }

    return {
        errors : errors,
        jsonPost: jsonPost,
        setIndexes : setIndexes
    }
}

function postJson(hold) {

    //blur current field to fire any onchange events
    $(document.activeElement).blur();

    postObject = buildPostObject();

    //validates if all required fields are present
    var errors = postObject.errors;

    //posts json to controller
    var jsonPost = postObject.jsonPost;

    //setIndex to ensure all required rows for a set are captured
    var setIndexes = postObject.setIndexes;

    /*//validates if all required fields are present
     var errors = new HashSet();

     //posts json to controller
     var jsonPost = {rows:[]};

     //setIndex to ensure all required rows for a set are captured
     var setIndexes = new HashSet();

     //for each row above the scan line, evaluate data
     //attribute tags to see what is required and build
     //the transport object along the way
     for (var i=0;i<trsScanned.size();i++) {
     var trElement = $('#'+trsScanned.values()[i]);
     var trData = trElement.data();

     //everything past the tr prefix is the hashmap key
     var mapValues = {};

     //console.debug(trData);
     for (var attrib in trData) {
     if (attrib=='setIndex') {
     setIndexes.add(trData[attrib]);
     }

     //required data attributes end with _r
     if (attrib.endsWith('_r')) {
     var attribBase = attrib.substring(0,attrib.length-2);

     //validation is not needed when a NCR code is applied to the container
     if (!(trData['ncrCode'])) {
     if (!(trData[attrib])) {
     console.log(attrib + ' is missing data');

     errors.add('One or more required fields are missing for the rows highlighted.');
     trElement.css({border:'2px solid red'});
     } else {
     //check for _m match attribute
     if (trData[attribBase+'_m']) {
     if (!(trData[attrib]==trData[attribBase+'_m'])) {
     errors.add('One or more required fields do not match expected values for the rows highlighted.');
     trElement.css({border:'2px solid red'});
     }
     }

     //strip off _r suffix for marshaling
     mapValues[attribBase] = trData[attrib];
     }
     } else {
     //collect other values which include workflow and container identifiers
     mapValues[attribBase] = trData[attrib];
     }
     } else if (attrib.endsWith('_m')) {
     //ignore _m data attributes for marshaling
     //this is a match attribute paired with _r
     } else {
     mapValues[attrib] = trData[attrib];
     }
     }
     jsonPost.rows.push(mapValues);
     }*/

    //check set id to ensure all required rows within a set have been captured
    //use selector to retrieve all rows in the pagequeue table
    $('#pagequeue > tbody > tr').each(function() {
        var trId = $(this).attr('id');
        var trSetIndex = $(this).data('setIndex');

        if (trSetIndex) {
            if (!(trsScanned.contains(trId))) {
                if (setIndexes.contains(trSetIndex)) {
                    $(this).css({border:'2px solid red'});
                    errors.add('One or more required rows are missing from an expected set.');
                }
            } else {
                $(this).css({border:'none'});
            }
        }
    });

    //if everything is valid, post json object
    if (errors.isEmpty()) {
        //checkpoint
        if (hold == 'true' && confirm('Are you sure you want to hold the plates? Click OK to Confirm.')) {
            checkpoint(postJsonCompleteFn(jsonPost,hold));
        } else if (hold == 'false') {
            checkpoint(postJsonCompleteFn(jsonPost,hold));
        }
    } else {
        //alert(errors.values().join('\n'));
        displayErrorMessages( errors.values() );
    }
}

function postJsonCompleteFn(jsonPost,hold) {
    return function() {
        $.ajax({
            url: './secure_checkpoint/?userId=' + checkpointUserId + '&wfStepConfigId='+wfStepConfigId,
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json'
        }).always(function(data) {
            //log any errors that occurred during authentication
            if (data.error) {
                console.log(data.error);
            }
            if (data.allowed) {
                showProgress();
                var postUrl;

                if(hold == 'false') {
                    postUrl = './?wfStepConfigId='+wfStepConfigId;
                } else if(hold == 'true') {
                    postUrl = './holdWf/?wfStepConfigId='+wfStepConfigId;
                }

                //user allowed, post changes to queue
                jsonPost.userId = checkpointUserId;

                $.ajax({
                    url: postUrl,
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(jsonPost),
                    processData: false,
                    dataType: 'json'
                }).always(function(data) {
                    if (isJsonResponseValid(data)) {
                        refreshQueue();
                    } else {
                        hideProgress();
                    }
                });
            } else {
                flashError('You are not allowed to perform this action!  Please contact an Atlas Administrator.');
                cancelBadgeScan();
            }
        });
    };
}

function postNcrFn(frm, relativePath) {
    return function() {
        $.ajax({
            url: relativePath+'/util/secure_checkpoint/?userId=' + checkpointUserId + '&checkpoint='+wfStepConfigId,
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json'
        }).always(function(data) {
            //log any errors that occurred during authentication
            if (data.error) {
                console.log(data.error);
            }
            if (data.allowed) {
                showProgress();

                $.ajax({
                    url: relativePath+'/ncrApply/?'+frm+'&userId='+checkpointUserId,
                    type: 'GET'
                }).always(function(data) {
                    if (data.allowed) {
                        location.reload(true);
                    } else {
                        flashError('You are not allowed to apply this NCR!  Please contact an Atlas Administrator.');
                        hideProgress();
                    }
                });
            } else {
                flashError('You are not allowed to perform this action!  Please contact an Atlas Administrator.');
                cancelBadgeScan();
            }
        });
    };
}


function refreshQueue() {
    //hard reload page
    location.reload(true);
}

function flashError(error) {
    alert(error);
}

function showWorkflowDetail(workflowId) {
    window.open('./workflowDetail/?workflowId='+workflowId);
}

function prettyDate(time){
    var date = new Date((time || "").replace(/-/g,"/").replace(/[TZ]/g," ")),
        diff = (((new Date()).getTime() - date.getTime()) / 1000),
        day_diff = Math.floor(diff / 86400);

    if ( isNaN(day_diff) || day_diff < 0 || day_diff >= 31 )
        return;

    return day_diff == 0 && (
        diff < 60 && "just now" ||
        diff < 120 && "1 minute ago" ||
        diff < 3600 && Math.floor( diff / 60 ) + " minutes ago" ||
        diff < 7200 && "1 hour ago" ||
        diff < 86400 && Math.floor( diff / 3600 ) + " hours ago") ||
        day_diff == 1 && "Yesterday" ||
        day_diff < 7 && day_diff + " days ago" ||
        day_diff < 31 && Math.ceil( day_diff / 7 ) + " weeks ago";
}

function diffDays(time){
    var date = new Date((time || "").replace(/-/g,"/").replace(/[TZ]/g," ")),
        diff = (( date.getTime() - (new Date()).getTime()) / 1000),
        day_diff = Math.floor(diff / 86400);

    if ( isNaN(day_diff) )
        return;

    return day_diff ;
}

function prettyDates(){
    var links = $('span.prettydate');

    for (var i=0;i<links.length;i++) {
        if (links[i].title) {
            var date = prettyDate(links[i].title);
            if (date) {
                var alertToken = '';
                if ($(links[i]).data('alertLevel')) {
                    alertToken = '<span style="font-size:15px;">&nbsp;';
                    for (var j=0;j<$(links[i]).data('alertLevel');j++) {
                        alertToken += ' !';
                    }
                    alertToken += '</span>';
                }
                links[i].innerHTML = '('+prettyDate(links[i].title)+')' + alertToken;
            }
        }
    }
}

function processScan(charsCaptured) {
    if (typeof processScanOverride == 'function') {
        //check if a step specific js file (i.e. atlas_1.js) contains an override method
        processScanOverride(charsCaptured);
    } else {
        //check to see if the scanned input is a scan line id
        if ($('#tr'+charsCaptured).length) {
            //push row above scan line
            trScan('tr'+charsCaptured);
        } else {
            //use default scan action
            var $hasFocus = $(document.activeElement);
            if ($hasFocus.hasClass('captureScan')) {
                //set the value of the element that has focus
                //this simulates a direct scan
                $hasFocus.val(charsCaptured);
                $hasFocus.change();

                //now tab to the next input element within
                //the data collection table
                var inputs = $hasFocus.closest('table').find(':input');
                inputs.eq( inputs.index($hasFocus)+ 1 ).focus();
            }
        }
    }
}

function nextUniqueId() {
    return uniqueId++;
}

function getInputSetVal(id) {
    var inputs = $('[name="inputSet'+id+'"]');
    var val = '[';
    for (var i=0;i<inputs.length;i++) {
        val += '\'' + $(inputs[i]).val() + '\'';
        if ((i+1)<inputs.length) {
            val += ',';
        }
    }
    val += ']';

    return val;
}

function timeStamp() {
    // Create a date object with the current time
    var now = new Date();

    // Create an array with the current month, day and time
    var date = [ now.getMonth() + 1, now.getDate(), now.getFullYear() ];

    // Create an array with the current hour, minute and second
    var time = [ now.getHours(), now.getMinutes(), now.getSeconds() ];

    // Determine AM or PM suffix based on the hour
    var suffix = ( time[0] < 12 ) ? "AM" : "PM";

    // Convert hour from military time
    time[0] = ( time[0] < 12 ) ? time[0] : time[0] - 12;

    // If hour is 0, set it to 12
    time[0] = time[0] || 12;

    // If seconds and minutes are less than 10, add a zero
    for ( var i = 1; i < 3; i++ ) {
        if ( time[i] < 10 ) {
            time[i] = "0" + time[i];
        }
    }

    // Return the formatted string
    return date.join("/") + " " + time.join(":") + " " + suffix;
}

function print2DArray(user, data) {
    var applet = document.jzebra;
    if (applet != null) {
        //42 characters per line max
        var prntCharsWidth = 42;

        //initialize printer
        //ESC @
        applet.append(String.fromCharCode(27)+'@');
        applet.print();

        //append header
        applet.append(new Array(prntCharsWidth+1).join('=') + '\n');
//        applet.append("   User: " + user + '\n');
        applet.append("Printed: " + timeStamp() + '\n\n');
        applet.print();

        //append data
        for (var i=0;i<data.length;i++) {
            var prntFld1 = data[i][0];
            var prntFld2 = data[i][1];

            var prntFld1Width = prntFld1.length;
            var prntFld2Width = prntFld2.length;
            var prntFill = new Array((prntCharsWidth-prntFld1Width-prntFld2Width)+1).join(' ');
            var prntLine = prntFld1 + prntFill + prntFld2;

            //trim empty spaces to preserve printer buffer
            prntLine = prntLine.replace(/~+$/, '');

            applet.append(prntLine + '\n');

            //separator line
            if (i==0) {
                applet.append(new Array(prntCharsWidth+1).join('-') + '\n');
            }
        }

        //append footer
        applet.append(new Array(prntCharsWidth+1).join('=') + '\n');
        applet.append("\n\n");

        //print buffer
        applet.print();

        //issues a cut
        //GS V 66 5
        applet.append(String.fromCharCode(29)+'V'+String.fromCharCode(65)+String.fromCharCode(5));
        applet.print();
    }
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function ncrPopup(ncrConfigId, relativePath) {
    if (ncrConfigId!=null && ncrConfigId!='') {
        //pull ncr information
        $.ajax({
            url: relativePath+'/../ncrInfo/?ncrConfigId='+ncrConfigId,
            type: 'GET',
            contentType: 'application/json',
            dataType: 'json'
        }).always(function(data) {
            console.log(data);

            var html = '<b>' + data.ncrName + '</b> - ' + data.ncrDescription + '<br/><br/>';

            if (data.allowedUsers!=null) {
                html += 'You must be one of the following users to apply this NCR code: <b>' + data.allowedUsers + '</b>';
            }

            $('#wfModalNcrLabel').html('NCR Description')
            $('#wfModalNcrMsg').html(html);
            $('#wf-modal-ncr').modal('show');
        });
    }
}

function ncrDetail(workflowId, containerId) {
    //pull ncr information
    $.ajax({
        url: './ncr/ncrDetail/?workflowStepConfigId='+workflowStepConfigId + '&workflowId='+workflowId+(containerId!=null?'&containerId='+encodeURIComponent(containerId):''),
        type: 'GET',
        contentType: 'application/json',
        dataType: 'json'
    }).always(function(data) {
        console.log(data);
        $('#wfModalNcrLabel').html('Redo Action Required')
        $('#wfModalNcrMsg').html(data.stepNote);
        $('#wf-modal-ncr').modal('show');
    });
}

function postNcr(frm, relativePath) {
    checkpoint(postNcrFn(frm, relativePath));
}

function scanBypass(trId) {
    if (!(trsScanned.contains(trId))) {
        alert('This annoying popup only appears when barcode scanning has been bypassed');
    }
    trScan(trId);
}

function loadGraphData(path,wfId){
    if(!graphDataLoaded){
        console.log('Loading grid data for wfId='+wfId);

        Log.write('Loading.Please Wait...');

        var graphHtml = "";

        jQuery.ajax({
            url: "../wfGraph",
            success: function(result) {
                var elements = $(result.trim());
                var divElement = $('#graphLegend',elements);
                graphHtml = divElement.html();

                $('#graphLegend').html(graphHtml);
            }
        });

        $.ajax({
            url: path + 'containerGraphJson/?wfId=' + wfId,
            type: 'GET',
            contentType: 'application/json',
            dataType: 'json'

        }).always(function (data) {
            $(".tab-content").hide();
            $("#graph-tab").fadeIn();
            $('#infovis').html("");
            init(data);
            graphDataLoaded = true;
        });
    }
}

function loadGridDataTypes(path,wfId) {
    if (!gridDataLoaded) {
        console.log('Loading grid data for wfId='+wfId);

        $.ajax({
            url: path+'/grid_data_types/?wfId='+wfId,
            type: 'GET',
            contentType: 'application/json',
            dataType: 'json',
            async: false
        }).always(function(data) {
            console.log(data);

            //build legend with empty grid
            var html = '<table><tr><td style="width:230px;white-space:nowrap;vertical-align:top;background-color:#efefef;">';
            html += '<table><tr><th>&nbsp;</th><th>Layer</th></tr>';
            for (var i=0;i<data.wfGridDataTypeBeanList.length;i++) {
                if(null != data.wfGridDataTypeBeanList[i].filterType && null != data.wfGridDataTypeBeanList[i].filterValue){
                   html += '<tr><td><input type="checkbox" onchange="if ($(this).prop(\'checked\')){loadGridData(\''+path+'\','+wfId+','+data.wfGridDataTypeBeanList[i].wfGridDataTypeId+',\''+data.wfGridDataTypeBeanList[i].iconPng+'\');}else{clearGridData('+data.wfGridDataTypeBeanList[i].wfGridDataTypeId+');}" </td><td><img class="cicon" src="'+path+'../resources/img/grid/'+data.wfGridDataTypeBeanList[i].iconPng+'.png"/>'+data.wfGridDataTypeBeanList[i].wfGridDataType+' '+data.wfGridDataTypeBeanList[i].filterType+' <input type="input" class="GridTypeId'+data.wfGridDataTypeBeanList[i].wfGridDataTypeId+'" style="width:50px" value="'+data.wfGridDataTypeBeanList[i].filterValue+'"/></td></tr>'
               }else{
                   html += '<tr><td><input type="checkbox" onchange="if ($(this).prop(\'checked\')){loadGridData(\''+path+'\','+wfId+','+data.wfGridDataTypeBeanList[i].wfGridDataTypeId+',\''+data.wfGridDataTypeBeanList[i].iconPng+'\');}else{clearGridData('+data.wfGridDataTypeBeanList[i].wfGridDataTypeId+');}" </td><td><img class="cicon" src="'+path+'../resources/img/grid/'+data.wfGridDataTypeBeanList[i].iconPng+'.png"/>'+data.wfGridDataTypeBeanList[i].wfGridDataType+'</td></tr>'
               }
            }
            html += '</table>';

            //build grid
            html += '</td><td style="vertical-align:top;">';
            html += '<table class="gridData" id="gridData">';
            for (var row=0;row<=data.rowSize +1;row++) {
                html += '<tr>';
                for (var col=0;col<=data.colSize +1;col++) {
                    if (row==0) {
                        if (col>0 && col<data.colSize +1) {
                            html += '<td class="addr">'+col+'</td>';
                        } else {
                            html += '<td class="addr">&nbsp;</td>';
                        }
                    } else {
                        if (col==0) {
                            if (row>0 && row<data.rowSize +1) {
                                html += '<td class="addr">'+String.fromCharCode(65+(row-1))+'</td>';
                            } else {
                                html += '<td class="addr">&nbsp;</td>';
                            }
                        } else {
                            html += '<td class="gdv R'+row+'C'+col+'"></td>';
                        }
                    }
                }
                html += '</tr>';
            }
            html += '</table>';

            html += '</td></tr></table>';

            $('#griddata-tab').html(html);

            gridDataLoaded = true;
        });
    }
}

function loadGridData(path,wfId,gridDataTypeId,iconPng) {
    clearGridData(gridDataTypeId);

    var filterValue = '';
    if($('.GridTypeId'+gridDataTypeId).val()){
        filterValue = $('.GridTypeId'+gridDataTypeId).val();
    }

    $.ajax({
        url: path+'/grid_data/?gridDataTypeId='+gridDataTypeId+'&wfId='+wfId+'&filterValue='+filterValue,
        type: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        async: false
    }).always(function(data) {
        console.log(data);

        for (var i=0;i<data.length;i++) {
            var gdv = data[i];
            var htmlText = '<div class="gdt'+gridDataTypeId+'"><img class="cicon" src="'+path+'../resources/img/grid/'+iconPng+'.png"/>';
            if(gdv.meetsThresholds){
                htmlText = htmlText + '<span style="color: red;background-color: #ffff00;text-decoration: underline">'+gdv.value+'</span></div>';
            }else{
                htmlText = htmlText + '<span>'+gdv.value+'</span></div>';
            }

            $('#gridData td.R'+gdv.gridRow+'C'+gdv.gridCol).append(htmlText);
        }
    });
}

function clearGridData(gridDataTypeId) {
    $('#gridData .gdt'+gridDataTypeId).remove();
}

function wfDetail(wfId) {
    window.open('./wfDetail/?wfId='+wfId);
}

function checkProduction() {
    if (document.URL.indexOf('atlas.velocity.ag') > 0 ) {
        $("body").prepend('<div id="cloudProduction">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;This is the CLOUD Production version of Atlas.</div>');
    }else if (document.URL.indexOf('atlas-rearray.velocity.ag') > 0) {
        $("body").prepend('<div id="cloudRearrayProduction">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;This is the CLOUD ReArray Production version of Atlas.</div>');
    }else{
        $("body").prepend('<div id="nonProduction">This is not the Production version of Atlas.  Unless you are developing or testing the application, please use one of the following URL and make sure you update your bookmarks!' +
            '<br><br><a href="https://atlas.velocity.ag/">https://atlas.velocity.ag/</a>' +
            '<br><br><a href="https://atlas-rearray.velocity.ag/">https://atlas-rearray.velocity.ag/</a></div>');
    }
}

/**
 * Displays error messages in the error-messages div as a list
 * @param errors An array of error messages
 */
function displayErrorMessages( errorMessages ) {
    $('#error-messages ul').html('');
    $('#error-messages span').html('');

    if( errorMessages instanceof Array ) {
        for( var i = 0; i < errorMessages.length; i++ ) {
            $('#error-messages ul').append('<li class="text-error">' + errorMessages[i] + '</li>');
        }
    } else {
        $('#error-messages ul').append('<li class="text-error">' + errorMessages + '</li>');
    }

    $('#error-messages').show();
}

function displaySuccessMessages( messages ) {
    displayMessages( "success", messages );
}

function displayInfoMessages( messages ) {
    displayMessages( "info", messages );
}

function displayWarningMessages( messages ) {
    displayMessages( "warning", messages );
}

function displayMessages( messageStyleClassSuffix, messages ) {
    $('#messages ul').html('');
    $('#messages span').html('');
    $('#messages').removeClass('alert-danger alert-success alert-info alert-warning');

    $('#messages').addClass( 'alert-' + messageStyleClassSuffix );

    if( messages instanceof Array ) {
        for( var i = 0; i < messages.length; i++ ) {
            $('#messages ul').append('<li class="text-"' + messageStyleClassSuffix + '>' + messages[i] + '</li>');
        }
    } else {
        $('#messages ul').append('<li class="text-"' + messageStyleClassSuffix + '>' + messages + '</li>');
    }

    $('#messages').show();
}

function pollAsyncProcessStatus( wfAsyncStatusId, cancelFunction ) {
    if( !$('#progressStatusBar').length || !$('#progressStatusBar').is(':visible') ) {
        addStatusProgressBar( cancelFunction );
    }

    $.ajax({
        dataType: 'json',
        contentType: "application/json",
        type: 'GET',
        url: window.location.origin + '/async/' + wfAsyncStatusId + '/'
    }).done(function(status, textStatus, jqXHR){
        if( status.isDone || status.isCancelled ) {
            hideProgress();
            $('#progressStatusBar').hide();

            displayInfoMessages( status.message );
        } else {
            $('#progressStatusBar #statusMessage').text( status.message );
            $('#progressStatusBar div.progress-bar').width( status.percentComplete + '%' );
            $('#progressStatusBar #progressBarValueDisplay').text( status.percentComplete + '%');

            setTimeout(pollAsyncProcessStatus( wfAsyncStatusId ), 2000);
        }
    }).fail(function( jqXHR, textStatus ) {
        console.log( jqXHR.status );
        console.log( "Request failed: " + textStatus );
        hideProgress();
    });
}

function addStatusProgressBar( cancelFunction ) {
    if( !$('#progressStatusBar').length ) {
        var dialogBody = $('#wf-modal-wait div.modal-body' );
        dialogBody.append( '<div id="progressStatusBar">' +
            '                   <p><div id="statusMessage"></div></p>' +
            '                   <div class="progress">' +
            '                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0;">' +
            '                           <div id="progressBarValueDisplay"></div>' +
            '                         </div>' +
            '                   </div>' +
            '               </div>'
        );
    } else {
        $('#progressStatusBar #statusMessage').text( "" );
        $('#progressStatusBar div.progress-bar').width( '0%' );
        $('#progressStatusBar #progressBarValueDisplay').text( '0%');

        $('#progressStatusBar').show();
    }

    if( cancelFunction ) {
        if( !$('#cancelBar').length ) {
            $('#progressStatusBar').append( '<div id="cancelBar" class="r"><button id="cancelProgressButton" class="btn btn-danger">Cancel</button></div>');
        } else {
            $('#cancelBar').show();
        }

        $('#cancelProgressButton').click( cancelFunction );
    } else {
        if( $('#cancelBar').length ) {
            $('#cancelBar').hide();
        }
    }
}

function getCancelAsyncProcessFunction( wfAsyncStatusId, cancelSuccessCallback, cancelFailCallback ) {
    return function() {
        $.ajax({
            type: 'POST',
            url: window.location.origin + '/async/' + wfAsyncStatusId + '/cancel/'
        }).done( function ( response ) {
            if( response.wasCancelSuccessful ) {
                if( cancelSuccessCallback ) {
                    cancelSuccessCallback( response );
                }
            } else {
                if( cancelFailCallback ) {
                    cancelFailCallback( response );
                }

                alert( "Cancel request failed" );
            }
        }).fail(function( ) {
            alert( "Cancel request failed");
        });
    };
}

function updateProjectResults(limsId, checkBoxName, contextPath, path, projectStatusId) {
    console.log('updateProjectResults(\''+limsId+'\') invoked');

    //blur current field to fire any onchange events
    $(document.activeElement).blur();

    var jsonProjectUpdate = {includedEplates:[]};
    var projectEplates;
    var x = limsId.indexOf("/");
    if(x > 0) {
        limsId = limsId.substr(limsId.indexOf("/")+1);
    }
    jsonProjectUpdate.limsId = limsId;
    projectEplates = $(checkBoxName+limsId);

    jsonProjectUpdate.mabProjectStatusId = projectStatusId;
    //collect checked eplates
    console.log('found ' + projectEplates.length + ' possible eplates');
    for (var i=0;i<projectEplates.length;i++) {
        var projectEplate = projectEplates[i];
        if ($(projectEplate).prop('checked')) {
            console.log('found ' + projectEplates.length + ' included eplate with blockBarcodeNbr=' + $(projectEplate).data('blockBarcodeNbr'));

            var jsonProjectUpdateEplate = {
                blockBarcodeNbr: $(projectEplate).data('blockBarcodeNbr'),
                workflowId: $(projectEplate).data('workflowId')
            };
            console.log(JSON.stringify(jsonProjectUpdateEplate));
            jsonProjectUpdate.includedEplates.push(jsonProjectUpdateEplate);
        }
    }

    checkpoint(updateProjectResultsCompleteFn(jsonProjectUpdate, contextPath, path));
}

function updateProjectResultsCompleteFn(jsonProjectUpdate, contextPath, path) {
    return function() {
        $.ajax({
            url: contextPath+ '/secure_checkpoint/?userId=' + checkpointUserId + '&wfStepConfigId=26',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json'
        }).always(function(data) {
            if (data.allowed) {
                showProgress();

                //user allowed, post changes to queue
                jsonProjectUpdate.userId = checkpointUserId;

                $.ajax({
                    //url: './',
                    //url: './updateProjectResultsQCSubmit',
                    url: contextPath + path,
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(jsonProjectUpdate),
                    processData: false,
                    dataType: 'json'
                }).always(function(data) {
                    if (isJsonResponseValid(data)) {
                        refreshQueue();
                    } else {
                        hideProgress();
                    }
                });
            } else {
                flashError('You are not allowed to perform this action!  Please contact an Atlas Administrator.');
                cancelBadgeScan();
            }
        });
    };
}

function setNcrForAllScanned(){

    //get the default ncr code and reason
    //loop through all scanned lines
    //get the trid
    //generate the select id as trid+'_ncrCode
    //loop through the options and set 'selected=selected'
    //set the select id for the scanned line

    var selectedNcrCode = $("#defaultNcrCode").val();
    var selectedNcrComment = $("#defaultNotes_comment").val();
    var selectedNcrReason = $("#defaultNcrReason").val();
    //for each row above the scan line, evaluate data
    //attribute tags to see what is required and build
    //the transport object along the way
    for (var i=0;i<trsScanned.size();i++) {
        var trId = trsScanned.values()[i];
        var ncrFieldId = trId+'_ncrCode';

        $("#"+trId+"_ncrCode option[value="+selectedNcrCode+"]").prop('selected', true);

        $("#"+ncrFieldId+"_comment").val(selectedNcrComment);

        $("#"+trId+"_ncrReason option[value="+selectedNcrReason+"]").prop('selected', true);

        $('#'+trId).data('ncrCode',selectedNcrCode);
        $('#'+trId).data('ncrReason',selectedNcrReason);
        $('#'+trId).data('ncrComment',selectedNcrComment);

        if (selectedNcrCode){
            $("#"+trId + "_ncrReason_ReasonRow").show();
            $("#"+ncrFieldId+"_row").show();
            $("#"+ncrFieldId+"_comment").focus();
        } else {
            $("#"+trId + "_ncrReason_ReasonRow").hide();
            $("#"+ncrFieldId+"_row").hide();
        }
    }
}

function showNotesRow(){

    var selectedNcrCode = $("#defaultNcrCode").val();

    if (selectedNcrCode){
        $('#defaultReason_row').show();
        $('#defaultNotes_row').show();
        $('#defaultNotes_comment').focus();
        ncrPopup(selectedNcrCode,'.');
    } else {
        $('#defaultReason_row').hide();
        $('#defaultNotes_row').hide();
    }
}

function fillCherries() {
    $("td.cherry").each(function(){
        var parentWfId = $(this).parent().data('wfId');
        var currTd = $(this);
        var trId = $(this).parent().attr("id");
        fillCherry(parentWfId,currTd,trId);
    });

    $("td.cherryReExtract").each(function(){
        var wfId = $(this).parent().data('wfId');
        var currTd = $(this);
        fillReExtractCherry(wfId,currTd);
    });

    $("td.hold").each(function(){
        var wfId = $(this).parent().data('wfId');
        var currTd = $(this);
        var containerLocked=$(this).parent().data('containerLocked');
        if (containerLocked == 1) {
            fillHoldIcon(wfId,currTd);
        }
    });

    $("td.showNotes").each(function(){
        var wfId = $(this).parent().data('wfId');
        var currTd = $(this);
        var plateName = $(this).parent().data('wfEntityLabel');
        fillNoteSection(wfId,currTd,plateName);
    });

    $("td.pending").each(function(){
        var wfId = $(this).parent().data('wfId');
        var currTd = $(this);
        fillPendingIcon(wfId,currTd);
    });

    $("td.exportPrintFile").each(function(){
        var wfId = $(this).parent().data('wfId');
        var currTd = $(this);
        currTd.append('<span class="glyphicon glyphicon-print" onclick="generatePrintFile(' + wfId + ');"></span>');
    });

}

function fillPendingIcon(wfId,currTd){
    $.ajax({
        url: '/gbs/isPending?wfId='+wfId,
        type: 'GET',
        processData: false,
        dataType: 'json'
    }).done(function(data){
        if(data){
            currTd.append('<img src="/resources/img/refresh.png"/>');
        }

    });
}

function fillNoteSection(wfId,currTd,plateName) {

    var note = currTd.parent().data('note');
    var trId = currTd.parent().attr("id");
    var styleClasses = 'glyphicon glyphicon-pencil';

    if(note != ''){
        styleClasses += ' glyphicon-star-empty';
    }
    currTd.append('<span class="'+styleClasses+'" title="'+note+'" style="cursor:pointer;" onclick="loadDefaultNoteSection(' + wfId + ',\''+trId+'\',\''+plateName+'\');">&nbsp;&nbsp;</span>');

}

function loadDefaultNoteSection( wfId, trId,plateName){

    var html = '</br>Add Note for Plate :<b>'+plateName+'</b></br>';
    var note = $('#'+trId).data('note');

    html += '<input type="submit" id="saveNote" class="btn btn-xs btn-success" value="Save" onclick="javascript:checkpoint(postPlateNoteFn(\'${contextPath}\','+wfId+ ',\''+trId+'\'))"/><br/>';

    $('#noteComments').val("");
    $('#note-head').html(html);
    $('#existingNotes').empty();
    $('#existingNotes').append(note);
    if(wfConfigId == 1){
         $('#noteComments').hide();
    }
    // Initialize the plugin
    $('#note_popup').modal('show');
}

function postPlateNoteFn(contextPath , wfId, trId){

    return function() {
        var noteOption = $("#noteOptions option:selected").val();
        var noteComments = $("#noteComments").val();
        var updatedNote='';

        showProgress();

        var jsonProjectUpdateEplate = {};
        jsonProjectUpdateEplate.workflowId = wfId;
        jsonProjectUpdateEplate.userId = checkpointUserId;
        jsonProjectUpdateEplate.noteOption = noteOption;
        jsonProjectUpdateEplate.wfConfigId=wfConfigId;
        if(null != noteComments){
            jsonProjectUpdateEplate.noteComment = noteComments.trim();
        }

        $.ajax({
            url: '/wf/savePlateNote/',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(jsonProjectUpdateEplate),
            processData: false,
            dataType: 'json'
        }).always(function (response) {
            if (isJsonResponseValid(response)) {
                if (response.data && response.data[0]) {
                    updatedNote=response.data[0];

                    $(trId).data('note',updatedNote);
                    var span = $("span.glyphicon");
                    $(trId).find('.showNotes').find(span).addClass(" glyphicon-star-empty");
                }
            } else {
                flashError('You are not allowed to add this note!  Please contact an Atlas Administrator.');
            }

            hideProgress();

            // Initialize the plugin
            $('#note_popup').modal('hide');
        });
    }
}

function fillCherry(wfId,currTd,trId){
    if(trId.indexOf("trCP") != 0){
        $.ajax({
            url: '/gbs/isCherryPicked?wfId='+wfId,
            type: 'GET',
            processData: false,
            dataType: 'json'
        }).done(function(data){
            if(!data){
                currTd.append('<span class="cherry" data-wf-id="' + wfId + '"><img onclick="window.open(\'/gbs/cherryPickSamples/?wfId='+ wfId + '\');" src="/resources/img/cherry-wait.png"/></span>');
            } else {
                currTd.append('<img src="/resources/img/cherry-complete.png"/>');
            }
        });
    }
}

function fillReExtractCherry(wfId,currTd){
    $.ajax({
        url: '/gbs/isCherryPicked?wfId='+wfId,
        type: 'GET',
        processData: false,
        dataType: 'json'
    }).done(function(data){
        if(data){
            currTd.append('<img src="/resources/img/cherry-complete.png"/>');
        }
    });
}

function populateOverView(){
    $("td.overview").each(function(){
        var parentWfId = $(this).parent().data('wfId');
        var currTd = $(this);
        var trId = $(this).parent().attr("id");

        currTd.append('<span class="wfDetail"><img onclick="fetchPlates('+ parentWfId + ');" src="/resources/img/cherry-wait.png"/></span>');
    });
}

function showMaxTs(){
    $("td.showMaxTs").each(function(){
        var parentWfId = $(this).parent().data('wfId');
        var currTd = $(this);
        var trId = $(this).parent().attr("id");

        var maxTs = $(this).parent().data('maxTs');

        currTd.append(maxTs);
    });

    $("td.showMaxTsInDays").each(function(){
        var parentWfId = $(this).parent().data('wfId');
        var currTd = $(this);
        var trId = $(this).parent().attr("id");

        var maxTs = $(this).parent().data('maxTs');
        var prettyDateTime = prettyDate(maxTs);

        currTd.append(prettyDateTime);
    });


    $("td.showDaysTillDueDate").each(function(){
        var parentWfId = $(this).parent().data('wfId');
        var currTd = $(this);
        var trId = $(this).parent().attr("id");

        var dueTs = $(this).parent().data('dueTs');
        var prettyDateTime = diffDays(dueTs);

        currTd.append(prettyDateTime);
    });
}

function fillHoldIcon(wfId,currTd){
   $.ajax({
        url: '/gbs/isOnHold?wfId='+wfId,
        type: 'GET',
        processData: false,
        dataType: 'json'
    }).done(function(data){
        if(null != data){
            var imageSource = '<span title="Hold NCR: '+data.toString()+'" class="glyphicon glyphicon-lock" />'

            currTd.append(imageSource);
        }
    });
}


function populateFilterDropDowns(){
    $('.filter').each(function(){
        var filterArray = [];
        var filter = $(this);
        var dataConfigId = filter.data('data-config-id');
        $('.wfStepRow').each(function(){
            var rowTd = $(this).find('[data-data-config-id="'+dataConfigId+'"]');
            var tdText = $.trim(rowTd.text());

            var idx = $.inArray(tdText, filterArray);
            if (idx == -1) {
                filterArray.push(tdText);
            }
        });
        $.each(filterArray, function(value) {
            filter
                .append($("<option></option>")
                    .attr("value",filterArray[value])
                    .text(filterArray[value]));
        });
    });
}

function isFiltered(trId){
    var isFiltered = true;

    if($('.forceFilterToScan')[0]){
        if($('#'+trId).hasClass('wfStepRowSelected')){

        }else{
            isFiltered = false;
        }
    }

    return isFiltered;
}

$(document).ready(function() {
    $(".scanFilter").click(function(){
        var filterArray = [];
        var numberOfRecordsToScan = $("#numberOfRecordsToScan").val();
        var filterOnAdded = false;
        var isAdded = true;

        var shouldScanAbove = $(this).hasClass('scanAbove');

        $('.wfStepRow').removeClass('wfStepRowSelected');

        $(".filter").each(function(){
            var dataConfigId = $(this).data("data-config-id");
            var value = $(this).val();

            if(isAdded){
                $('.wfStepRow').each(function() {
                    var unScannedRowTd = $(this).find('[data-data-config-id="'+dataConfigId+'"]');
                    var tdText = unScannedRowTd.text();
                    var rowTrId = $(this).attr("id");
                    var idx = $.inArray(rowTrId, filterArray);

                    if($.trim(tdText) == $.trim(value)){
                        if(filterOnAdded){

                        }else{
                            if (idx == -1) {
                                filterArray.push(rowTrId);
                            }
                        }
                    }else {
                        if (idx > -1) {
                            filterArray.splice(idx, 1);
                        }
                    }
                });
                if(filterArray.length > 0){
                    isAdded = true;
                    filterOnAdded = true;
                }else{
                    isAdded = false;
                }
            }
        });

        $.each(filterArray,function(index, value ){
            if(index < numberOfRecordsToScan){
                highlightRow(value);
                if(shouldScanAbove){
                    trScan(value);
                }
            }
        });
    });


    $(".exportFilteredRows").click(function(){
        var filteredWfIds = '';
        $('.wfStepRowSelected').each(function() {
            var wfId = $(this).data('wf-id');
            filteredWfIds = filteredWfIds + wfId + ',';
        });

        if(filteredWfIds != ''){
            var url = '../exportStepFilteredPlateIds/?wfStepConfigId='+wfStepConfigId+'&scannedPlateIds='+filteredWfIds;
            $(location).attr('href',url);
        }else{
            alert("No rows filtered to export.");
        }
    });

    $(".exportScannedRows").click(function(){
        var filteredWfIds = '';
        $(".wfStepRow").each(function() {
            var wfId = $(this).data('wf-id');
            filteredWfIds = filteredWfIds + wfId + ',';
        });

        if(filteredWfIds != ''){
            filteredWfIds = '';
            var url = '../exportStepFilteredPlateIds/?wfStepConfigId='+wfStepConfigId+'&scannedPlateIds='+filteredWfIds;
            $(location).attr('href',url);
        }else{
            alert("No rows filtered to export.");
        }
    });

    $(".exportTossedRows").click(function(){
        var url = '../exportTossedPlateIds/?wfStepConfigId='+wfStepConfigId+'&plateType='+plateType;
        $(location).attr('href',url);
    });

});

$(document).ready(function() {
    $(".scanFilterWithoutDeselection").click(function(){
        var filterArray = [];
        var numberOfRecordsToScan = $("#numberOfRecordsToScan").val();
        var filterOnAdded = false;
        var isAdded = true;

        var shouldScanAbove = $(this).hasClass('scanAbove');

        //$('.wfStepRow').removeClass('wfStepRowSelected');

        $(".filter").each(function(){
            var dataConfigId = $(this).data("data-config-id");
            var value = $(this).val();

            if(isAdded){
                $('.wfStepRow').each(function() {
                    var unScannedRowTd = $(this).find('[data-data-config-id="'+dataConfigId+'"]');
                    var tdText = unScannedRowTd.text();
                    var rowTrId = $(this).attr("id");
                    var idx = $.inArray(rowTrId, filterArray);

                    if($.trim(tdText) == $.trim(value)){
                        if(filterOnAdded){

                        }else{
                            if (idx == -1) {
                                filterArray.push(rowTrId);
                            }
                        }
                    }else {
                        if (idx > -1) {
                            filterArray.splice(idx, 1);
                        }
                    }
                });
                if(filterArray.length > 0){
                    isAdded = true;
                    filterOnAdded = true;
                }else{
                    isAdded = false;
                }
            }
        });

        $.each(filterArray,function(index, value ){
            if(index < numberOfRecordsToScan){
                highlightRow(value);
                if(shouldScanAbove){
                    trScan(value);
                }
            }
        });
    });


    $(".exportFilteredRows").click(function(){
        var filteredWfIds = '';
        $('.wfStepRowSelected').each(function() {
            var wfId = $(this).data('wf-id');
            filteredWfIds = filteredWfIds + wfId + ',';
        });

        if(filteredWfIds != ''){
            var url = '../exportStepFilteredPlateIds/?wfStepConfigId='+wfStepConfigId+'&scannedPlateIds='+filteredWfIds;
            $(location).attr('href',url);
        }else{
            alert("No rows filtered to export.");
        }
    });

    $(".exportScannedRows").click(function(){
        var filteredWfIds = '';
        $(".wfStepRow").each(function() {
            var wfId = $(this).data('wf-id');
            filteredWfIds = filteredWfIds + wfId + ',';
        });

        if(filteredWfIds != ''){
            filteredWfIds = '';
            var url = '../exportStepFilteredPlateIds/?wfStepConfigId='+wfStepConfigId+'&scannedPlateIds='+filteredWfIds;
            $(location).attr('href',url);
        }else{
            alert("No rows filtered to export.");
        }
    });

});

function highlightRow(trRowId){
    $('#'+trRowId).addClass('wfStepRowSelected');
}


function setLocationForAllScanned(variableName){

    //get the default location
    //loop through all scanned lines
    //get the trid
    //generate the select id as trid+'_location
    //loop through the options and set 'selected=selected'
    //set the select id for the scanned line
    var selectedLocation = $("#default_"+variableName).val();
    //for each row above the scan line, evaluate data
    //attribute tags to see what is required and build
    //the transport object along the way
    for (var i=0;i<trsScanned.size();i++) {
        var trId = trsScanned.values()[i];
        $("#"+trId+"_"+variableName).val(selectedLocation);
        if(variableName == 'location') {
            $('#'+trId).data('wfdc461',selectedLocation);
        } else if (variableName == 'beelocation') {
            $('#'+trId).data('wfdc184',selectedLocation);
        } else {
            $('#'+trId).data('wfdc420',selectedLocation);
        }

    }
}



function confirmUnHoldAction(wfId) {

   if( confirm("Are you sure to activate the selected plate? Click OK to Confirm'?")) {
                   showProgress();
                   $.ajax({
                       url: '/gbs/UnHold/?wfId=' + wfId,
                       type: 'GET'
                   }).always(function (data) {
                       if (!data.error) {
                           location.reload(true);
                       } else {
                           flashError('Something went wrong! Please contact an Atlas Administrator.');
                       }
                   });
   }

}


function postNoteFn(contextPath , wfId){

    return function() {
        var noteOption = $("#noteOptions option:selected").val();
        var noteComments = $("#noteComments").val();

        showProgress();

        var jsonProjectUpdateEplate = {};
        jsonProjectUpdateEplate.workflowId = wfId;
        jsonProjectUpdateEplate.userId = checkpointUserId;
        jsonProjectUpdateEplate.noteOption = noteOption;
        if(null != noteComments){
        jsonProjectUpdateEplate.noteComment = noteComments.trim();
        }

        $.ajax({
            url: contextPath + '/gbs/saveProjectSummaryNote/',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(jsonProjectUpdateEplate),
            processData: false,
            dataType: 'json'
        }).always(function (response) {
            if (isJsonResponseValid(response)) {

            } else {
                flashError('You are not allowed to add this note!  Please contact an Atlas Administrator.');
            }

            hideProgress();

            // Initialize the plugin
            $('#note_popup').modal('hide');
        });
    }
}

function postMergeRawReads(){

    return function() {
        var noteOption = $("#noteOptions option:selected").val();
        var noteComments = $("#noteComments").val();
        var mergeUserId=checkpointUserId;

        if(document.forms[0].onsubmit){
            document.forms[0].userId.value=mergeUserId;
            document.forms[0].submit();
        }
    }
}





function setJobTypeForAllScanned(){

    var selectedJobType = $("#jobType").val();

    for (var i=0;i<trsScanned.size();i++) {
        var trId = trsScanned.values()[i];
        $("#"+trId+"_wfdc3077 option[value="+selectedJobType+"]").prop('selected', true);
        $('#'+trId).data('wfdc3077',selectedJobType);

    }
}

function setCyclerForAllScanned(){

    var selectedCycler = $("#cycler").val();

    for (var i=0;i<trsScanned.size();i++) {
        var trId = trsScanned.values()[i];
        $("#"+trId+"_wfdc3089 option[value="+selectedCycler+"]").prop('selected', true);
        $('#'+trId).data('wfdc3089',selectedCycler);

    }
}

function generatePrintFile(wfId){
    var url = '../stltaqman/exportPrintFile/?wfId='+wfId;
    $(location).attr('href',url);

}

function printEPlateBarcode(){
    var request = $("#request").val();
    if (request!=null && request!='') {
        $.ajax({url:'../stltaqman/printEPlateBarcode/?request='+request,contentType:'application/json',dataType:'json',async:false}).always(function(data)
        {console.log(data);alert('The E Plate ID '+data.id+' barcodes have been sent to the printer.');})
    } else{
        alert('Please enter Request.');
    }
}
