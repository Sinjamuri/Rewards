//buffer of keypress events
var charQueue = [];
var charCapture = false;

//btnConfig is an array with each object containing the following properties
//
//title - the text to display that indicates the action of the button
//target - the target dom object where the button will be rendered
//size - the width and height of the button in pixels
//jsFunction - the javascript function that is fired when the button is clicked or scanned
//onscreen - (true|false) render button on screen
//code - (reserved codes)
//       000 - Refresh screen (F5)
//       001 - Save queue
//
//       100-199 - Reserved for hyperlink jumps
//
function renderButtons(btnConfig) {
	for (var i=0;i<btnConfig.length;i++) {
        if (btnConfig[i]!=null) {
            //show micro QR code image macro
            if (btnConfig[i].onscreen) {
                $('#'+btnConfig[i].target).html('<div class="qrm-container" title="Click - OR - Scan to ' + btnConfig[i].title + '"><input type="button" class="_' + btnConfig[i].size + '" id="'+btnConfig[i].target+'" /><br/><span>' + btnConfig[i].title + '</span></div>');
            } else {
                $('#'+btnConfig[i].target).attr('title','Click to ' + btnConfig[i].title);
            }

            //bind function to button
            $('#'+btnConfig[i].target).click(btnConfig[i].jsFunction);
        }
	}
}

$(document).keypress(function(e){
	var keyCode = e.keyCode || e.which;		
	var c = String.fromCharCode(keyCode);
	
	//clear char queue and toggle mode
	//to prevent default send key action
	if (c=='<') {
		charQueue = [];
		charCapture = true;
		
		//do not process begin marker key
		e.preventDefault();		
		return false;
	}
	
	if (c=='>' && charCapture==true) {
		//reset buffer on tab key
		charCapture = false;
		
		//process macros
		var charsCaptured = charQueue.join('').trim();
		console.log(charsCaptured);

		//QRM code
		if (charsCaptured.match(/^QRM[0-9]{3}$/) || charsCaptured.match(/^qrm[0-9]{3}$/)) {
            console.log('firing click event for #'+charsCaptured);
            $('#'+charsCaptured).click();
        } else if (charsCaptured.match(/^QRM[0-9]{6}$/) || charsCaptured.match(/^qrm[0-9]{6}$/)) {
			//this is a QR code for workstation navigation
            if ($.isFunction(window[charsCaptured])) {
                console.log('executing function '+charsCaptured);
                window[charsCaptured]();
            } else {
                console.log('function not found for '+charsCaptured);
            }
		} else {
            if (charsCaptured.match(/^UID\/.*\/$/)) {
                //this is a user id
                if (typeof uidCapture == 'function') {
                    uidCapture(charsCaptured);
                }
            } else {
                //attempt to detect when the caps lock is on
                if (charsCaptured.match(/^qrm[0-9]{3}$/) || charsCaptured.match(/^uid\/.*\/$/)) {
                    alert('Caps Lock is ON. Please turn Caps lock OFF to proceed.\n\nCheck any scans to ensure data has not been corrupted!')
                } else {
                    //process scan
                    if (typeof processScan == 'function') {
                        processScan(charsCaptured);
                    }
                }
            }
		}

		//do not process end marker key
		e.preventDefault();
		return false;
	}
	
	//add character to queue
	charQueue.push(c);

	//do not process any keys while in character capture mode
	if (charCapture) {
		e.preventDefault();
		return false;
	}	
});