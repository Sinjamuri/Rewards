var masterPwdHash = '562191ee9089b8073a4f2eaf8a4060bfb8b54127f4cbaf54c0753501850effbef78a7172fded8043088cb84ce0c274290337d63ac4f21f34f2e80845c8e0f482';

function generateBadgeDoc(){

    var generateBadge = $('#generateBadge').is(":checked");
    var uid = $("#userIdGenerated").val();
    console.log("badge generated for userid "+uid);
    if(generateBadge) {
        var encrypted = CryptoJS.AES.encrypt(uid.trim().toUpperCase(), 'H5WYX7DB9cgeUaHa').toString();

        encrypted = 'UID/' + encrypted + '/';
        console.log(encrypted);

        var url = '../../util/badge/?userId=' + uid.trim().toUpperCase() + '&data=' + encodeURIComponent(encrypted) ;

        //render the QR code for the encrypted data
        window.open(url);
        window.location.reload(true);
    }
}

function saveUserInfo(fn){

    return function(){
        var uid = $('#uid').val();
        var adminUserId = checkpointUserId;
        var wfConfigId = $('#wfConfigId').val();
        var userStatus = $('#userStatus').val();
        var generateBadge = $('#generateBadge').is(":checked");
        var badgeReason = $('#badgeReason').val();

        var url = '../../util/saveUserInfo/?userId=' + uid.trim().toUpperCase() +
            "&adminUserId=" + adminUserId + "&wfConfigId=" + wfConfigId +
            "&generateBadge=" + generateBadge + "&userStatus=" + userStatus + "&badgeReason=" + badgeReason;

        $.ajax({
            url: url,
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            async: false
        }).always(function (data) {
            if (isJsonResponseValid(data)) {
                displaySuccessMessages(data.messages);
                if(generateBadge){
                    var userGeneratedIds = data.data;
                    if( userGeneratedIds instanceof Array ) {
                        $("#userIdGenerated").val(userGeneratedIds[0]);
                    }
                    $("#downloadBadgeFile").show();
                }
            } else {
                generateBadge = false;
                flashError(data.errors);
            }
        });
    }
}

function validate(fn){

    return function() {
        var uid = $('#uid').val();
        var generateBadge = $('#generateBadge').is(":checked");
        var wasBadgeGenerated = $('#wasBadgeGenerated').is(":checked");
        var badgeReason = $('#badgeReason').val();

        if (generateBadge && badgeReason.trim() == '') {
            $.ajax({
                url: '../../util/doesBadgeExist/?userId=' + uid,
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                async: false
            }).always(function (data) {
                if (data.errorCnt < 1) {
                    fn();
                } else {
                    flashError(data.errors);
                }
            });
        }else{
            fn();
        }
    }
}

function isAdmin(fn) {

    var wfConfigId = $('#wfConfigId').val();

    $.ajax({
        url: '../../util/secure_checkpoint/?userId=' + checkpointUserId + '&checkpoint=ADMIN_USER&domain=' + wfConfigId,
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json',
        async: false
    }).always(function (data) {
        if (data.allowed) {
            fn();
        } else {
            flashError('You are not an Administrator for the selected Workflow!  Please contact an Atlas Administrator.');
        }
    });
}

function encryptUID() {

    return function () {

        $('#error-messages').hide();
        $('#messages').hide();

        var uid = $('#uid').val();
        var passphrase = $('#passphrase').val();
        //var adminUserId = $('#adminUserId').val();
        var adminUserId = checkpointUserId;
        var wfConfigId = $('#wfConfigId').val();
        var userStatus = $('#userStatus').val();
        var generateBadge = $('#generateBadge').is(":checked");
        var wasBadgeGenerated = $('#wasBadgeGenerated').is(":checked");
        var badgeReason = $('#badgeReason').val();

        //hash password and compare to master
        var hash = CryptoJS.SHA3(passphrase).toString(CryptoJS.enc.Hex);
        console.log('Hash of master password: ' + hash);

        if (masterPwdHash == hash) {
            console.log('Encrypting UID: ' + uid);

            if (uid.trim() == '') {
                alert('You must enter the User ID for the barcode that will be generated');
                $('#uid').focus();
            } /*else if (adminUserId.trim() == '') {
             alert('You must enter your User ID as an Administrator');
             $('#adminUserId').focus();
             } */ else if (wfConfigId.trim() == '') {
                alert('You must enter the User ID for the barcode that will be generated');
                $('#wfConfigId').focus();
            } else if (generateBadge && wasBadgeGenerated && badgeReason.trim() == '') {
                alert('You must enter the reason for generating the badge again.');
                $('#badgeReason').focus();
            } else {
                isAdmin(validate(saveUserInfo()));
            }
        } else {
            flashError('The Atlas Master Password is not valid');
        }
    }
}

function installUIDCookie(path) {
    var passphrase = $('#passphrase').val();

    //hash password and compare to master
    var hash = CryptoJS.SHA3(passphrase).toString(CryptoJS.enc.Hex);
    console.log('Hash of master password: ' + hash);

    if (masterPwdHash==hash) {
        var uid = $('#uid').val();
        console.log('Installing UID Cookie: ' + uid);

        if (uid.trim()=='') {
            alert('You must enter the primary User ID for the workstation');
            $('#uid').focus();
        } else {
            var encrypted = CryptoJS.AES.encrypt(uid.trim().toUpperCase(), 'H5WYX7DB9cgeUaHa');
            console.log(encrypted);

            //install cookie
            $.cookie('ATLAS_UID', encrypted, {path:path, expires: 365});

            alert('User cookie installed');
        }
    } else {
        alert('The Atlas Master Password is not valid');
    }
}

function removeUIDCookie(path) {
    //remove any cookie
    $.cookie('ATLAS_UID', null, {path:path});

    alert('User cookie removed');
}

function queueReport(id,queueable) {
    //find all _param elements on page
    var jsonQueueReport = {
        reportSqlId:id,
        queueable:queueable,
        params:{}
    };

    var params = $("[name^='_param']");
    for (var i=0;i<params.length;i++) {
        jsonQueueReport.params[params[i].name.substr(6)] = $(params[i]).val();
    }

    checkpoint(queueReportFn(jsonQueueReport));
}

function queueReportFn(jsonQueueReport) {
    return function() {
        $.ajax({
            url: '../../../util/secure_checkpoint/?userId=' + checkpointUserId + '&checkpoint=QUEUE_REPORT',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json'
        }).always(function(data) {
                if (data.allowed) {
                    showProgress();

                    //user allowed, post changes to queue
                    jsonQueueReport.userId = checkpointUserId;

                    console.log(JSON.stringify(jsonQueueReport));

                    $.ajax({
                        url: '../queue/',
                        type: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify(jsonQueueReport),
                        processData: false,
                        dataType: 'json'
                    }).always(function(data) {
                            location.reload(true);
                        });
                } else {
                    flashError('You are not allowed to perform this action!  Please contact an Atlas Administrator.');
                    cancelBadgeScan();
                }
            });
    };
}

function postNewWorkflow() {
    $(document.activeElement).blur();

    //validates if all required fields are present
    var errors = new HashSet();

    //posts json to controller
    var jsonPost = {};

    if($('#newWorkflowName').val()) {
        var value = $.trim($('#newWorkflowName').val());
        var r = /^[\w\_\-\ ]+$/i;

        if( r.test( value ) ) {
            // test if not a duplicate? leave it to the server
            jsonPost.workflowName = value;
        } else {
            errors.add( 'The workflow name can only have letters, numbers, spaces, - and _ in it.');
        }
    } else {
        errors.add( 'Workflow name is required.');
    }

    if($('#newWorkflowDomain').val()) {
        var value = $.trim($('#newWorkflowDomain').val());
        var r = /^[\w\_\-]+$/i;

        if(r.test( value )) {
            // test if not a duplicate? leave it to the server
            jsonPost.workflowDomain = value;
        } else {
            errors.add( 'The workflow domain can only have letters, numbers, - and _ in it.');
        }
    } else {
        errors.add( 'Workflow domain is required.');
    }

    if($('#newWorkFlowAdmins').val()) {
        var value = $.trim($('#newWorkFlowAdmins').val());
        var r = /^[\w]+(,\ *[\w]+\ *)*$/i;

        if(r.test(value )) {
            var admins = value.split(",");
            $.map( admins, function( adminIndex, adminValue ) {
                return $.trim( adminValue )
            });
            jsonPost.workflowAdmins = admins;
        } else {
            errors.add( 'The admin list must be comma separated user names.');
        }

    } else {
        errors.add( 'At least one workflow admin is required.');
    }

    if( errors.isEmpty() ) {
       postAdminJson( jsonPost,
            function() {
                location.reload( true );
            }
        );
    } else {
        displayErrorMessages( errors.values() );
    }
}

function postNewWfStep( ) {
    $(document.activeElement).blur();

    //validates if all required fields are present
    var errors = new HashSet();

    //posts json to controller
    var jsonPost = {};

    if( $('#newStepName').val()) {
        jsonPost.wfStepName = $.trim( $('#newStepName').val() );
    } else {
        errors.add('You must provide a name for the new step.')
    }

    if( $('#newStepNumber').val()) {
        jsonPost.wfStepNumber = $.trim( $('#newStepNumber').val() );
    } else {
        errors.add( 'You must provide a number for the new step.')
    }

    jsonPost.wfConfigId = $('#wfConfigId').val();

    if( errors.isEmpty() ) {
        postAdminJson( jsonPost,
            function( response ) {
                $('#newStepName').val("");
                $('#newStepNumber').val("");

                if( atlasWorkflowGraph ) {
                    atlasWorkflowGraph.refresh();
                }
            },
            './step/'
        );
    } else {
        displayErrorMessages( errors.values() );
    }
}

function postAdminJson( jsonPost, validResponseCallback, url ) {
    checkpoint(
        function() {
            showProgress();

            jsonPost.createUser = checkpointUserId;

            $.ajax( {
                url: (url) ? url : '.',
                type: "POST",
                contentType: 'application/json',
                data: JSON.stringify( jsonPost ),
                processData: false,
                dataType: 'json'
            }).done( function( data ) {
                try {
                    if( isJsonResponseValid( data )) {
                        validResponseCallback( data )
                    }
                } catch (err) {
                    displayErrorMessages( err );
                }
            }).always( function() {
                hideProgress();
            });
        }
    );
}


function postNewWorkflowDataConfig(){
    $(document.activeElement).blur();

    var errors = new HashSet();
    var jsonPost = {};

    if($('#newDataConfigType').val()){
        jsonPost.wfDataConfigType = $('#newDataConfigType').val();
    } else {
        errors.add('You must select a Data Type');
    }

    if($('#newDataConfigLabel').val()){
        jsonPost.wfDataLabel = $('#newDataConfigLabel').val();
    } else {
        errors.add('You must input a Label');
    }

    if($('#newDataConfigIsSearchable').val()){
        jsonPost.wfDataConfigSearchable = $('#newDataConfigIsSearchable').val();
    } else {
        errors.add('You must select if the new Data Config is searchable');
    }

    if( errors.isEmpty() ) {
        postAdminJson( jsonPost, function() {
            location.reload( true );
        });
    } else {
        displayErrorMessages( errors.values() );
    }
}

function postNewWorkflowConfigProperty(){

    $(document.activeElement).blur();

    var errors = new HashSet();
    var jsonPost = {};

    if($('#newPropertyRefKey').val()){
        var value = $('#newPropertyRefKey').val();
        var r = /^[0-9]*$/i;

        if(r.test( value )) {
            jsonPost.refKey = value;
        } else {
            errors.add( 'The reference key can only have digits in it.');
        }
    }

    if($('#newDataType').val()){
        jsonPost.propertyType = $('#newDataType').val();
    } else {
        errors.add('You must select a Data Type');
    }

    if($('#newPropertyKey').val()){
        jsonPost.key = $('#newPropertyKey').val();
    } else {
        errors.add('You must input a Key');
    }

    if($('#newPropertyValue').val()){
        jsonPost.propertyValue = $('#newPropertyValue').val();
    } else if($('#newDataType').val() != 'REF_ID') {
        errors.add('You must input a Value');
    }

    if( errors.isEmpty() ) {

        postAdminJson( jsonPost, function() {
            location.reload( true );
        });
    } else {
        displayErrorMessages( errors.values() );
    }
}

/**
 *  EditDialog
 */

var EditDialog = function( ) {
    var _id;
    var _formId;
    var _titleId;
    var _saveBtnId;
    var _templates = [];

    var pub = function( id, parentElement ) {
        _id = (id.lastIndexOf( '#', 0 ) === 0 ? id.substring(1, id.length ) : id) + '-dialog';

        var modalId = _id;

        _formId = _id + '-form';
        _titleId = _id + '-title';
        _saveBtnId = _id + '-save-btn';

        var titleId = _titleId;

        var modalHeader = makeDivElement({
            class : 'modal-header'
        });
        modalHeader.append( '<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>')
        modalHeader.append( '<h4 class="modal-title" id="' + titleId + '"></h4> ');

        var modalBody = makeDivElement( {
            class : 'modal-body'
        } );
        modalBody.append( '<form class="form-horizontal" id="' + _formId + '" role="form"></form>' );

        var modalFooter = makeDivElement( {
            class : 'modal-footer'
        });
        modalFooter.append( '<button type="button" id="' + modalId + '-cancel-btn" class="btn btn-default dialog-cancel-btn" data-dismiss="modal">Cancel</button>' );
        modalFooter.append( '<button type="button" id="' + _saveBtnId + '" class="btn btn-primary dialog-save-btn" data-dismiss="modal"><span class="glyphicon glyphicon-save"></span> Save</button>');

        var modalContent = makeDivElement( {
            class : 'modal-content'
        });

        modalContent.append( modalHeader );
        modalContent.append( modalBody );
        modalContent.append( modalFooter );

        var modalDialog = makeDivElement({
            class : 'modal-dialog modal-lg'
        });
        modalDialog.append( modalContent );

        var modalRoot = makeDivElement({
            id : modalId,
            class : 'modal fade',
            tabIndex : -1,
            role : 'dialog',
            'aria-labelledby' : titleId,
            'aria-hidden' : true
        });
        modalRoot.append( modalDialog );

        if( parentElement ) {
            parentElement.append( modalRoot );
        } else {
            $('body').append( modalRoot );
        }
    };

    pub._getId = function() { return _id };
    pub._getFormId = function() { return _formId };
    pub._getFormElement = function() { return $( '#' + _formId ); }

    pub._getSaveBtnId = function() { return _saveBtnId };
    pub._getSaveBtnElement = function() { return $('#' + pub._getSaveBtnId()); }

    pub._setTitleText = function( text ) {
        $( '#' + _titleId ).text( text );
    }

    pub.addTemplate = function( templateId, template) {
        _templates[ templateId ] = template;
    }
    pub.getTemplate = function( templateId ) {
        return _templates[ templateId ];
    }

    pub.setToValue = function( element, value ) {
        if( element.attr( 'type' ) && element.attr( 'type' ) === 'checkbox' ) {
            element.prop('checked', value );
        } else {
            element.val( value );
        }
    }

    pub.setInitValue = function( element, value ) {
        element.data('init', value);
    }

    pub.getDefaultValue = function( element ) {
        return element.data('default') ? element.data('default') : '';
    }

    pub.makeFormLineLabel = function( label ) {
        if( label ) {
            var labelElement = $('<label></label>');
            labelElement.text( label.text );

            if( label.attr )
                labelElement.attr( label.attr );
            labelElement.addClass( "control-label col-xs-4" );

            return labelElement;
        }

        return null;
    }

    pub.makeInputOptionsFunction = function( inputElement ) {
        return function( inputOptions ) {
            $.each( inputOptions, function( index, inputOption) {
                var option = $('<option></option>');
                option.attr( inputOption.attr );
                option.text( inputOption.text );
                inputElement.append( option );
            });

            var selectedVal = inputElement.find(":selected").val();
            inputElement.data( 'default', selectedVal );

            if( typeof inputElement.data('init') !== 'undefined') {
                inputElement.val( inputElement.data('init') );
            }
        }
    }

    pub.makeGetterFunction = function( url, errorMessage ) {
        return function( callback ) {
            $.ajax( {
                url: url,
                type: "GET",
                processData: false,
                dataType: 'json'
            }).done( function( data ) {
                try {
                    if( isJsonResponseValid( data )) {
                        callback( data )
                    }
                } catch (err) {
                    displayErrorMessages( err );
                }
            }).fail( function() {
                displayErrorMessages( errorMessage );
            });
        }
    }

    pub.makeFormLine = function( formLine ) {
        var labelElement = pub.makeFormLineLabel( formLine.label );
        var inputElement = pub.makeFormLineInput( formLine.input );

        if( inputElement.attr('type') === 'hidden' ) {
            return inputElement;
        }

        var divInput = makeDivElement( { class : "col-xs-7"});
        divInput.append( inputElement );

        var divFormGroup = makeDivElement( { class : 'form-group'} );
        divFormGroup.append( labelElement );
        divFormGroup.append( divInput );

        return divFormGroup;
    }

    pub.makeFormLineInput = function( input, labelElement ) {
        var tag = (input.tag) ? input.tag : "input";
        var inputElement = $('<' + tag + ' id="' + input.id + '"></' + tag + '>');

        if( input.attr ) inputElement.attr( input.attr );

        inputElement.addClass( 'form-control' );
        if( input.attr && input.attr.type === 'checkbox' ) {
            inputElement.removeClass( 'form-control');
        }

        if( inputElement.data('init') ) {
            inputElement.val( inputElement.data('init') );
        }

        if( input.inputOptions ) {
            var makeInputOptions = pub.makeInputOptionsFunction( inputElement );
            if( input.inputOptions instanceof Array ) {
                makeInputOptions( input.inputOptions );
            } else if( input.inputOptions.url ) {
                var getOptionsFunction = pub.makeGetterFunction(
                    input.inputOptions.url,
                    "ERROR: " + (input.inputOptions.errorMessage ?  + input.inputOptions.errorMessage : "retrieving options" ) );
                getOptionsFunction( makeInputOptions );
            } else {
                throw "Invalid input options for " + input.id;
            }
        }

        if( input.outerElement ) {
            var outerElement = $( input.outerElement );
            outerElement.append( inputElement );
            inputElement = outerElement;
        }

        if( labelElement ) labelElement.attr( 'for', input.id );

        return inputElement;
    }

    pub.makePanelGroup = function( id ) {
        var panelGroup = makeDivElement( { id : id, class : 'panel-group' });
        pub._getFormElement().append( panelGroup );
        return panelGroup;
    }

    pub.makeFormLinesFromTemplate = function( templateId ) {
        if( _templates[ templateId ] ) {
            var template = _templates[templateId];
            var cloneElements = [];

            $.each( template.elements, function( index, element ) {
                var cloneElement = element.clone( true );
                $.each( element.data, function( dataKey, dataValue ) {
                    cloneElement.data( dataKey, dataValue );
                });
                cloneElements.push( cloneElement );
            });

            return cloneElements;

        } else {
            throw "No form template for id: " + templateId;
        }
    }

    return pub;
}();

EditDialog.prototype = {
    getId : function() { return EditDialog._getId() },
    getFormId : function() { return EditDialog._getFormId() },
    getSaveBtnId : function() { return EditDialog._getSaveBtnId() },
    getSaveBtn : function() { return EditDialog.getSaveBtn() },

    findInForm : function( selector ) {
        return EditDialog._getFormElement().find( selector );
    },

    fillInFormValues :  function( object, parentElement ) {
        $.each( object, function( objectProperty, objectPropertyValue) {
            var propertyElement = parentElement.find( '*[data-field="' + objectProperty + '"]');

            if( propertyElement && propertyElement.length > 0) {
                EditDialog.setToValue( propertyElement, objectPropertyValue);
                EditDialog.setInitValue( propertyElement, objectPropertyValue );
            }
        });
    },
    fillInFormValuesofDialog : function( object ) {
        this.fillInFormValues( object, EditDialog._getFormElement() );
    },
    setTitleText : function ( title ) {
        EditDialog._setTitleText( title )
    },
    clearFormData : function( ) {
        var formInputs = EditDialog._getFormElement().find( 'input, select');

        $.each( formInputs, function( index, formInput ) {
            var inputElement = $( formInput );
            var defaultValue = EditDialog.getDefaultValue( inputElement );
            EditDialog.setToValue( inputElement, defaultValue );
        });

        var collapsePanels = EditDialog._getFormElement().find( '.collapse');
        $.each( collapsePanels, function( index, panel ) {
            $(panel).removeClass( 'in' );
            $(panel).find('ul').find( 'li' ).remove();
        });
    },
    addFormLine : function( parentElement, formLine ) {
        var formLineGroup = EditDialog.makeFormLine( formLine );
        parentElement.append( formLineGroup );
    },
    addFormLines : function( parentElementId, formLines ) {
        var me = this;
        var parentElement = $( '#' + parentElementId );
        $.each( formLines, function( index, formLine) {
            me.addFormLine( parentElement, formLine );
        });
    },
    addFormLinesToDialogForm : function( lines ) {
        if( lines.url ) {
            var formElement = EditDialog._getFormElement();
            var placeHolderDiv = makeDivElement( {id : 'placeholder-' + formElement.children().length});
            formElement.append( placeHolderDiv );

            $.getJSON( lines.url,
                function( stepConfigForm ) {
                    $.each( stepConfigForm, function( index, formLine) {
                        var formLineGroup = EditDialog.makeFormLine( formLine );
                        placeHolderDiv.before( formLineGroup );
                    });

                    placeHolderDiv.remove();
                }
            );
        } else if( lines instanceof Array ) {
            var me = this;

            $.each( lines, function( index, formLine) {
                me.addFormLine( EditDialog._getFormElement(), formLine );
            });
        } else {
            throw "Form Lines arg not property formatted: Array of form lines or object with url proeprty to get JSON of form lines";
        }
    },
    addFormLinesFromTemplate : function( parentElement, template ) {
        var formLines = EditDialog.makeFormLinesFromTemplate( template );
        $.each( formLines, function( index, formLine ) {
            parentElement.append( formLine );
        });
    },
    addAccordionPanel : function( groupId, panelId, title ) {
        var panelGroup = $('#' + groupId );
        if( panelGroup.length < 1 ) {
            panelGroup = EditDialog.makePanelGroup( groupId );
        }

        var collapsiblePanelId = panelId + '-collapsible';
        var titleLink = $('<a></a>');
        titleLink.attr({
            'data-toggle' : 'collapse',
            'data-parent' : '#' + groupId ,
            href : '#' + collapsiblePanelId
        });
        titleLink.text( title );

        var panelTitleElement = makeDivElement( { class : 'panel-title'} );
        panelTitleElement.append( titleLink );

        var panelHeadingElement = makeDivElement( { class : 'panel-heading'});
        panelHeadingElement.append( panelTitleElement );

        var panelBodyElement = makeDivElement( { id : panelId, class : 'panel-body'});
        var panelCollapseElement = makeDivElement( { id : collapsiblePanelId, class : 'panel-collapse collapse' } )
        panelCollapseElement.append( panelBodyElement );

        var panelElement = makeDivElement( { class : 'panel panel-default'});
        panelElement.append( panelHeadingElement );
        panelElement.append( panelCollapseElement );

        panelGroup.append( panelElement );
        return panelBodyElement;
    },
    addFormTemplate : function( templateId, formConfig ) {
        var template = {};
        template.config = formConfig;
        template.elements = [];

        $.each( formConfig, function( index, formLineConfig ) {
            var formLine = EditDialog.makeFormLine( formLineConfig );
            template.elements.push( formLine );
        });

        EditDialog.addTemplate( templateId, template );
    },
    refreshTemplate : function( templateId ) {
        if( EditDialog.getTemplate( templateId ) ) {
            var config = EditDialog.getTemplate( templateId ).config;
            this.addFormTemplate( templateId, config );
        } else {
            throw "No form template for id: " + templateId;
        }
    },
    serializeForm : function( formFields, validationErrorsList ) {
        var serialObject = {};

        $.each( formFields, function( index, formField) {
            var formFieldElement = $( formField );
            var fieldValue = null;

            if( formFieldElement.attr('type') === 'checkbox') {
                fieldValue = formFieldElement.prop('checked');
            } else if( formFieldElement.prop('tagName') === 'SELECT' ) {
                if( formFieldElement.val() !== formFieldElement.data('default')) {
                    fieldValue = formFieldElement.val();
                } else if( formFieldElement.hasClass( 'required') && validationErrorsList ) {
                    validationErrorsList.add( '"' + formFieldElement.closest('form').find('label[for="' + formFieldElement.attr('id') + '"]').text() + '" requires selecting a value');
                }
            } else if( formFieldElement.val() ) {
                fieldValue = formFieldElement.val();
            } else if( formFieldElement.hasClass('required') && validationErrorsList ) {
                validationErrorsList.add( '"' + formFieldElement.closest('form').find('label[for="' + formFieldElement.attr('id') + '"]').text() + '" requires a value');
            }

            if( fieldValue || fieldValue === false) {
                serialObject[ formFieldElement.data('field') ] = fieldValue;
            }
        });

        return serialObject;
    }
};

/**
 * END Edit Dialog
 */

//on document ready
$(function() {
    //redirect on invalid browser
    if (!(navigator.userAgent.match(/Chrome/g))) {
        alert('Please restart Atlas in a Chrome browser session');
    }

    //datepicker
    try {
        $('.datepicker').datepicker({
            autoclose:true,
            todayHighlight:true
        });
    } catch (err ) {
        console.log( "DatePicker not found");
    }
});