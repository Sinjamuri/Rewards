package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class WfData {
  @DbColumn(field="wf_data_id")
  private Long wfDataId;
  @DbColumn(field="wf_data_config_id")
  private Long wfDataConfigId;
  @DbColumn(field="wf_id")
  private Long wfId;
  @DbColumn(field="wf_data_assoc_id")
  private Long wfDataAssocId;
    @DbColumn(field="wf_data_array_index")
  private Long wfDataArrayIndex;
    @DbColumn(field="wf_data_varchar2")
  private String wfDataVarchar2;
    @DbColumn(field="wf_data_number")
  private BigDecimal wfDataNumber;
    @DbColumn(field="wf_data_timestamp")
  private Timestamp wfDataTimestamp;
    @DbColumn(field="wf_data_blob")
  private byte[] wfDataBlob;
    @DbColumn(field="create_ts")
  private Timestamp createTs;

  public WfData(Long wfId, Long wfDataConfigId, String wfDataVarchar2) {
    this.wfId=wfId;
    this.wfDataConfigId = wfDataConfigId;
    this.wfDataVarchar2 = wfDataVarchar2;
  }

  public WfData(Long wfId, long wfDataConfigId, Timestamp wfDataTimestamp) {
    this.wfId=wfId;
    this.wfDataConfigId = wfDataConfigId;
    this.wfDataTimestamp = wfDataTimestamp;
  }

    public WfData() {

    }

    public Long getWfDataId() {
    return wfDataId;
  }

  public void setWfDataId(Long wfDataId) {
    this.wfDataId = wfDataId;
  }

  public Long getWfDataConfigId() {
    return wfDataConfigId;
  }

  public void setWfDataConfigId(Long wfDataConfigId) {
    this.wfDataConfigId = wfDataConfigId;
  }

  public Long getWfId() {
    return wfId;
  }

  public void setWfId(Long wfId) {
    this.wfId = wfId;
  }

  public Long getWfDataAssocId() {
    return wfDataAssocId;
  }

  public void setWfDataAssocId(Long wfDataAssocId) {
    this.wfDataAssocId = wfDataAssocId;
  }

  public Long getWfDataArrayIndex() {
    return wfDataArrayIndex;
  }

  public void setWfDataArrayIndex(Long wfDataArrayIndex) {
    this.wfDataArrayIndex = wfDataArrayIndex;
  }

  public String getWfDataVarchar2() {
    return wfDataVarchar2;
  }

  public void setWfDataVarchar2(String wfDataVarchar2) {
    this.wfDataVarchar2 = wfDataVarchar2;
  }

  public BigDecimal getWfDataNumber() {
    return wfDataNumber;
  }

  public void setWfDataNumber(BigDecimal wfDataNumber) {
    this.wfDataNumber = wfDataNumber;
  }

  public Timestamp getWfDataTimestamp() {
    return wfDataTimestamp;
  }

  public void setWfDataTimestamp(Timestamp wfDataTimestamp) {
    this.wfDataTimestamp = wfDataTimestamp;
  }

  public byte[] getWfDataBlob() {
    return wfDataBlob;
  }

  public void setWfDataBlob(byte[] wfDataBlob) {
    this.wfDataBlob = wfDataBlob;
  }

  public Timestamp getCreateTs() {
      return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
      this.createTs = createTs;
  }
}
