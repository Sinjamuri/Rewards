package com.monsanto.gwg.atlas.model.core;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */

// Top level of nested pojo structure for graph data.
public class WfGraph {

  private String title;
  private List<WfGraphAdjacency> wfGraphAdjacencies;
  private List<WfGraphLegendEntry> wfGraphLegendEntries;
  private boolean searchable;
  private String searchTitle;

  public WfGraph() {

  }

  public  WfGraph(String title, List<WfGraphAdjacency> wfGraphAdjacencies, List<WfGraphLegendEntry> wfGraphLegendEntries, boolean searchable, String searchTitle) {
    this.title = title;
    this.wfGraphAdjacencies = wfGraphAdjacencies;
    this.wfGraphLegendEntries = wfGraphLegendEntries;
    this.searchable = searchable;
    this.searchTitle = searchTitle;
  }

  public boolean isSearchable() {
    return searchable;
  }

  public void setSearchable(boolean searchable) {
    this.searchable = searchable;
  }

  public String getSearchTitle() {
    return searchTitle;
  }

  public void setSearchTitle(String searchTitle) {
    this.searchTitle = searchTitle;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public List<WfGraphLegendEntry> getWfGraphLegendEntries() {
    return wfGraphLegendEntries;
  }

  public void setWfGraphLegendEntries(List<WfGraphLegendEntry> wfGraphLegendEntries) {
    this.wfGraphLegendEntries = wfGraphLegendEntries;
  }

  public List<WfGraphAdjacency> getWfGraphAdjacencies() {
    return wfGraphAdjacencies;
  }

  public void setWfGraphAdjacencies(List<WfGraphAdjacency> wfGraphAdjacencies) {
    this.wfGraphAdjacencies = wfGraphAdjacencies;
  }

}