package com.monsanto.gwg.atlas.model.dpcr;

import java.math.BigDecimal;

/**
 * Created by PGROS1 on 1/6/2015.
 */
public class FilterResult {
    private long wfId;
    private String filterName;

    private boolean isReference;
//    private int[] histogram;
    private String resultsImageUrl;

    private Float[][][][] rawReadValues;
    private Float[][][][] normalizedReadValues;

    public String getFilterName() {
        return filterName;
    }

    public long getWfId() {
        return wfId;
    }

    public void setWfId(long wfId) {
        this.wfId = wfId;
    }

    public void setFilterName(String filterName) {
        this.filterName = filterName;
    }

    public boolean isReference() {
        return isReference;
    }

    public boolean getIsReference() { return isReference(); }

    public void setReference(boolean isReference) {
        this.isReference = isReference;
    }

//    public int[] getHistogram() {
//        return histogram;
//    }
//
//    public void setHistogram(int[] histogram) {
//        this.histogram = histogram;
//    }

    public Float[][][][] getRawReadValues() {
        return rawReadValues;
    }

    public void setRawReadValues(Float[][][][] rawReadValues) {
        this.rawReadValues = rawReadValues;
    }

    public String getResultsImageUrl() {
        return resultsImageUrl;
    }

    public void setResultsImageUrl(String resultsImageUrl) {
        this.resultsImageUrl = resultsImageUrl;
    }

    public Float[][][][] getNormalizedReadValues() {
        return normalizedReadValues;
    }

    public void setNormalizedReadValues(Float[][][][] normalizedReadValues) {
        this.normalizedReadValues = normalizedReadValues;
    }
}
