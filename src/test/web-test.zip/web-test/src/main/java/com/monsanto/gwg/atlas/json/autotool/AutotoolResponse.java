package com.monsanto.gwg.atlas.json.autotool;

/**
 * Created by syroth on 6/14/2017.
 */
public class AutotoolResponse {
    private Long robotJobId;
    private Integer numTasks;
    private String status;

    public String getStatus(){return status;}
    public void setStatus(String status){this.status = status;}

    public Long getRobotJobId(){return robotJobId;}
    public void setRobotJobId(Long robotJobId){this.robotJobId = robotJobId;}

    public Integer getNumTasks(){return numTasks;}
    public void setNumTasks(Integer numTasks){this.numTasks = numTasks;}

    @Override
    public String toString(){
        return String.format("Job ID: %d numTasks: %d Status: %s", this.getRobotJobId(),this.getNumTasks(), this.getStatus());
    }
}
