package com.monsanto.gwg.atlas.service.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.monsanto.gwg.atlas.model.Authentication.AccessTokenResponse;
import com.monsanto.gwg.atlas.model.Authentication.RestPostServiceProperties;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;

/**
 * Created by atpinz on 01/4/17.
 */
public class ServiceCommon {

  private static final Logger LOG = LoggerFactory.getLogger(ServiceCommon.class);

  public String ACCESS_TOKEN_BASE_URL;
  public String GRANT_TYPE;
  public String HTTPS_PROTOCOL_VALUE;

  public String CLIENT_ID;
  public String CLIENT_SECRET;

  public String AUTOTOOL_REST_BASE_URL;

  public ServiceCommon(String url_access_token, String client_id, String client_secret, String grant_type, String https_protocol_value, String url_auto_tool_sync) {

    ACCESS_TOKEN_BASE_URL = url_access_token;
    GRANT_TYPE = grant_type;
    HTTPS_PROTOCOL_VALUE = https_protocol_value;

    CLIENT_ID = client_id;
    CLIENT_SECRET = client_secret;

    AUTOTOOL_REST_BASE_URL = url_auto_tool_sync;
  }

  public static String getAccessToken(String baseUrl, String clientId, String secretKey, String grantType, String httpsProtocolsValue) {
    System.setProperty("https.protocols", httpsProtocolsValue);
    return getAccessToken(baseUrl, clientId, secretKey, grantType);
  }

  public static String getAccessToken(String baseUrl, String clientId, String secretKey, String grantType) {

    String accessToken = null;
    try {

      String queryParamsEncoded = "client_id=" + URLEncoder.encode(clientId, "UTF-8") +
          "&client_secret=" + URLEncoder.encode(secretKey, "UTF-8") +
          "&grant_type=" + URLEncoder.encode(grantType, "UTF-8");

      LOG.info("Encoded Url:" + queryParamsEncoded);


      LOG.info("Accessing Service at:" + baseUrl);
      WebResource webResource = getWebResource(baseUrl);
      ClientResponse serviceResponse = getEncodedServiceResponse(webResource, queryParamsEncoded);
      String output = serviceResponse.getEntity(String.class);
      LOG.info("Accessing Response:" + serviceResponse);

      AccessTokenResponse accessTokenResponse =
          new Gson().fromJson(output, AccessTokenResponse.class);
      accessToken = accessTokenResponse.getToken_type() + " " + accessTokenResponse.getAccess_token();

    } catch (IOException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();

    }
    return accessToken;
  }

  private static ClientResponse getEncodedServiceResponse(WebResource webResource, String queryParamsEncoded) throws Exception {
    ClientResponse response = webResource.accept("application/x-www-form-urlencoded")
        .type("application/x-www-form-urlencoded").post(ClientResponse.class, queryParamsEncoded);

    return response;
  }

  private static ClientResponse getServiceResponse(WebResource webResource, String accessToken) throws Exception {
    ClientResponse response = webResource.accept("application/json")
        .type("application/json").header("Authorization", accessToken).get(ClientResponse.class);

    return response;
  }

  public static ClientResponse getResponse(String accessToken, String baseUrl) throws Exception {

    LOG.info("Accessing Ancestry at:" + baseUrl + " with Token" + accessToken);
    WebResource webResource = getWebResource(baseUrl);
    ClientResponse serviceResponse = getServiceResponse(webResource, accessToken);
    LOG.info("Accessing Response:" + serviceResponse + " with Token:" + accessToken + " for URL:" + baseUrl);
    return serviceResponse;
  }

  private static WebResource getWebResource(String baseUrl) {
    Client client = Client.create();
    return client.resource(baseUrl);
  }


  /**
   * Shared method for invoking rest services that require a token and POST a request to get a response.
   *
   * @param props: buundled props for the desired call
   * @return caller casts to expected obj type per json implementation from server
   * @throws Exception
   */
  public static Object getResponse(RestPostServiceProperties props) throws Exception {

    LOG.info("invoking " + props.getServiceUrl());
    System.out.println(props.getServiceUrl());
    props.getRequestClass().cast(props.getRequestObj());
    Object responseObj = null;

    Gson gson = new GsonBuilder().create();
    String request = gson.toJson(props.getRequestObj());
    System.out.println("request: " + request);

    int responseCode = -1;

    try {
      HttpURLConnection urlConnection = (HttpURLConnection) (new URL(props.getServiceUrl()).openConnection());
      urlConnection.addRequestProperty("Authorization", props.getToken());
      urlConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
      urlConnection.setDoInput(true);
      urlConnection.setDoOutput(true);
      urlConnection.setRequestMethod("POST");

      OutputStream os = urlConnection.getOutputStream();
      os.write(request.getBytes("UTF-8"));
      os.flush();
      os.close();

      responseCode = urlConnection.getResponseCode();
      System.out.println(responseCode);

      BufferedReader inputStream = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
      String responseLine;
      StringBuffer jsonResponseString = new StringBuffer();
      while ((responseLine = inputStream.readLine()) != null) {
        jsonResponseString.append(responseLine);
      }

      responseObj = new Gson().fromJson(jsonResponseString.toString(), props.getResponseClass());

      inputStream.close();
      urlConnection.disconnect();


    } catch (Exception e) {
      LOG.error(e.toString());
      if (responseCode != -1) {
        LOG.error("\nResponse code sent from server: " + responseCode);
      }
      LOG.error(e.toString());
      e.printStackTrace();
      throw e;
    }

    return props.getResponseClass().cast(responseObj);

  }

  public static ClientResponse postRequest(String accessToken, String baseUrl, Object payload) throws Exception {

    LOG.info("Accessing Service at:" + baseUrl);
    System.out.println(baseUrl);
    System.out.println(accessToken);
    WebResource webResource = getWebResource(baseUrl);
    ClientResponse serviceResponse = getServiceResponse(webResource, accessToken, payload);
    LOG.info("Accessing Response:" + serviceResponse);
    System.out.println(serviceResponse);
    return serviceResponse;
  }

  private static ClientResponse getServiceResponse(WebResource webResource, String accessToken, Object payload) throws Exception {

    ClientResponse response = webResource.accept("application/json")
        .type("application/json").header("Authorization", accessToken).post(ClientResponse.class, payload);

    return response;
  }

}
