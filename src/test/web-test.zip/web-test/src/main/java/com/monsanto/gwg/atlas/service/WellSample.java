package com.monsanto.gwg.atlas.service;

/**
 * Created by ASHAR7 on 2/13/2015.
 */
public class WellSample {

    private String origin;
    private String wellName;
    private String fieldPlateBarcode;
    private String inventoryBarcodeNumber;
    private String generation;
    private String sampleNumber;
    private String pedigreeName;

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getWellName() {
        return wellName;
    }

    public void setWellName(String wellName) {
        this.wellName = wellName;
    }

    public String getFieldPlateBarcode() {
        return fieldPlateBarcode;
    }

    public void setFieldPlateBarcode(String fieldPlateBarcode) {
        this.fieldPlateBarcode = fieldPlateBarcode;
    }

    public String getInventoryBarcodeNumber() {
        return inventoryBarcodeNumber;
    }

    public void setInventoryBarcodeNumber(String inventoryBarcodeNumber) {
        this.inventoryBarcodeNumber = inventoryBarcodeNumber;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public String getSampleNumber() {
        return sampleNumber;
    }

    public void setSampleNumber(String sampleNumber) {
        this.sampleNumber = sampleNumber;
    }

    public String getPedigreeName() {
        return pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }
}
