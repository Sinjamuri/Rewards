package com.monsanto.gwg.atlas.model.core;

import org.codehaus.jackson.annotate.JsonIgnore;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by PGROS1 on 6/19/14.
 */
public class WfAsyncStatus {
    private AtomicLong wfAsyncStatusId = new AtomicLong();
    private AtomicLong wfConfigId = new AtomicLong();
    private AtomicLong progressValue = new AtomicLong();
    private AtomicLong maxProgressValue = new AtomicLong(1);    // Default to 1 to avoid division by 0 on get percentage
    private AtomicBoolean isDone = new AtomicBoolean();
    private AtomicBoolean isCancelled = new AtomicBoolean();
    private AtomicReference<String> message = new AtomicReference<String>();
    private AtomicReference<Timestamp> lastStatusChangeTs = new AtomicReference<Timestamp>();
    private AtomicReference<Timestamp> lastStatusCheckTs = new AtomicReference<Timestamp>();
    private AtomicReference<String> createUser = new AtomicReference<String>();
    private AtomicReference<Timestamp> createTs = new AtomicReference<Timestamp>();

    private List<String> errorMessages = new ArrayList<String>();


    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public long getWfAsyncStatusId() {
        return wfAsyncStatusId.get();
    }

    public void setWfAsyncStatusId(long wfAsyncStatusId) {
        this.wfAsyncStatusId.set( wfAsyncStatusId );
    }

    @JsonIgnore
    public long getWfConfigId() {
        return wfConfigId.get();
    }

    public void setWfConfigId(long wfConfigId) {
        this.wfConfigId.set( wfConfigId );
    }

    public long getProgressValue() {
        return progressValue.get();
    }

    public void setProgressValue(long progressValue ) {
        this.progressValue.set( progressValue );
    }

    public long getMaxProgressValue() {
        return maxProgressValue.get();
    }

    public void setMaxProgressValue(long maxProgressValue) {
        this.maxProgressValue.set( maxProgressValue );
    }

    public boolean getIsDone() {
        return isDone.get();
    }

    public void setIsDone(boolean isDone) {
        this.isDone.set( isDone );
    }

    public boolean getIsCancelled() {
        return isCancelled.get();
    }

    public void setIsCancelled(boolean isCancelled) {
        this.isCancelled.set( isCancelled );
    }

    public String getMessage() {
        return message.get();
    }

    public void setMessage(String message) {
        this.message.set( message );
    }

    @JsonIgnore
    public Timestamp getLastStatusChangeTs() {
        return lastStatusChangeTs.get();
    }

    public void setLastStatusChangeTs(Timestamp lastStatusChangeTs) {
        this.lastStatusChangeTs.set( lastStatusChangeTs );
    }

    @JsonIgnore
    public Timestamp getLastStatusCheckTs() {
        return lastStatusCheckTs.get();
    }

    public void setLastStatusCheckTs(Timestamp lastStatusCheckTs) {
        this.lastStatusCheckTs.set( lastStatusCheckTs );
    }

    @JsonIgnore
    public String getCreateUser() {
        return createUser.get();
    }

    public void setCreateUser(String createUser) {
        this.createUser.set( createUser );
    }

    @JsonIgnore
    public Timestamp getCreateTs() {
        return createTs.get();
    }

    public void setCreateTs(Timestamp createTs) {
        this.createTs.set( createTs );
    }

    public void incrementProgressValue() {
        this.progressValue.incrementAndGet();
    }

    public int getPercentComplete() {
        return (int)(progressValue.get() * 100f / maxProgressValue.get());
    }
}
