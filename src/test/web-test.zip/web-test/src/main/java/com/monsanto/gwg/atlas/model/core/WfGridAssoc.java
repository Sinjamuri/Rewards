package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

/**
 * Created by REGAMA on 9/16/14.
 */
public class WfGridAssoc {
    @DbColumn(field = "wf_grid_assoc_id")
    private Long wfGridAssocId;
    @DbColumn(field = "wf_config_id")
    private Long wfConfigId;
    @DbColumn(field = "wf_id")
    private Long wfId;
    @DbColumn(field = "wf_grid_id")
    private Long wfGridId;
    @DbColumn(field = "grid_row")
    private Integer gridRow;
    @DbColumn(field = "grid_col")
    private Integer gridCol;
    @DbColumn(field = "label")
    private String label;
    @DbColumn(field = "aggregate_group_id")
    private Long aggregateGroupId;
    @DbColumn(field = "status")
    private String status;

    public Long getWfGridAssocId() {
        return wfGridAssocId;
    }

    public void setWfGridAssocId(Long wfGridAssocId) {
        this.wfGridAssocId = wfGridAssocId;
    }

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public Long getWfId() {
        return wfId;
    }

    public void setWfId(Long wfId) {
        this.wfId = wfId;
    }

    public Long getWfGridId() {
        return wfGridId;
    }

    public void setWfGridId(Long wfGridId) {
        this.wfGridId = wfGridId;
    }

    public Integer getGridRow() {
        return gridRow;
    }

    public void setGridRow(Integer gridRow) {
        this.gridRow = gridRow;
    }

    public Integer getGridCol() {
        return gridCol;
    }

    public void setGridCol(Integer gridCol) {
        this.gridCol = gridCol;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Long getAggregateGroupId() {
        return aggregateGroupId;
    }

    public void setAggregateGroupId(Long aggregateGroupId) {
        this.aggregateGroupId = aggregateGroupId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
