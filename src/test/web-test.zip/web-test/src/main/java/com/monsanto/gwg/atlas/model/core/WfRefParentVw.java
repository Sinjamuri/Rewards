package com.monsanto.gwg.atlas.model.core;

/**
 * Created by REGAMA on 6/27/14.
 */
public class WfRefParentVw {
    private Long wfConfigId;
    private Long wfRefConfigParentId;
    private String wfParentRefKey;
    private String wfParentRefVarchar2;
    private Long wfRefConfigId;
    private String wfRefKey;
    private String wfRefVarchar2;
    private Long wfRefUiSortKey;
    private boolean wfRefActive;

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public Long getWfRefConfigParentId() {
        return wfRefConfigParentId;
    }

    public void setWfRefConfigParentId(Long wfRefConfigParentId) {
        this.wfRefConfigParentId = wfRefConfigParentId;
    }

    public String getWfParentRefKey() {
        return wfParentRefKey;
    }

    public void setWfParentRefKey(String wfParentRefKey) {
        this.wfParentRefKey = wfParentRefKey;
    }

    public String getWfParentRefVarchar2() {
        return wfParentRefVarchar2;
    }

    public void setWfParentRefVarchar2(String wfParentRefVarchar2) {
        this.wfParentRefVarchar2 = wfParentRefVarchar2;
    }

    public Long getWfRefConfigId() {
        return wfRefConfigId;
    }

    public void setWfRefConfigId(Long wfRefConfigId) {
        this.wfRefConfigId = wfRefConfigId;
    }

    public String getWfRefKey() {
        return wfRefKey;
    }

    public void setWfRefKey(String wfRefKey) {
        this.wfRefKey = wfRefKey;
    }

    public String getWfRefVarchar2() {
        return wfRefVarchar2;
    }

    public void setWfRefVarchar2(String wfRefVarchar2) {
        this.wfRefVarchar2 = wfRefVarchar2;
    }

    public Long getWfRefUiSortKey() {
        return wfRefUiSortKey;
    }

    public void setWfRefUiSortKey(Long wfRefUiSortKey) {
        this.wfRefUiSortKey = wfRefUiSortKey;
    }

    public boolean isWfRefActive() {
        return wfRefActive;
    }

    public void setWfRefActive(boolean wfRefActive) {
        this.wfRefActive = wfRefActive;
    }
}
