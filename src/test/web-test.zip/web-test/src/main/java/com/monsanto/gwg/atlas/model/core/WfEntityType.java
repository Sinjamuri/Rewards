package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;

public class WfEntityType {
    @DbColumn(field="wf_entity_type_id")
  private Long wfEntityTypeId;
    @DbColumn(field="wf_config_id")
  private Long wfConfigId;
    @DbColumn(field="wf_entity_type")
  private String wfEntityType;
    @DbColumn(field="sort_key")
  private Integer sortKey;
    @DbColumn(field="create_user")
  private String createUser;
    @DbColumn(field="create_ts")
  private Timestamp create_ts;
    @DbColumn(field="row_size")
    private Integer rowSize;
    @DbColumn(field="col_size")
    private Integer colSize;


  public Long getWfEntityTypeId() {
    return wfEntityTypeId;
  }

  public void setWfEntityTypeId(Long wfEntityTypeId) {
    this.wfEntityTypeId = wfEntityTypeId;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getWfEntityType() {
    return wfEntityType;
  }

  public void setWfEntityType(String wfEntityType) {
    this.wfEntityType = wfEntityType;
  }

  public Integer getSortKey() {
    return sortKey;
  }

  public void setSortKey(Integer sortKey) {
    this.sortKey = sortKey;
  }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getCreate_ts() {
        return create_ts;
    }

    public void setCreate_ts(Timestamp create_ts) {
        this.create_ts = create_ts;
    }

    public Integer getRowSize() {
        return rowSize;
    }

    public void setRowSize(Integer rowSize) {
        this.rowSize = rowSize;
    }

    public Integer getColSize() {
        return colSize;
    }

    public void setColSize(Integer colSize) {
        this.colSize = colSize;
    }
}
