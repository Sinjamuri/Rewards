package com.monsanto.gwg.atlas.json.core;

import java.util.List;

public class JsonProjectUpdate {
  String userId;
  private String limsId;
  List<JsonProjectUpdateEplate> includedEplates;
  private String mabProjectStatusId;

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getLimsId() {
    return limsId;
  }

  public void setLimsId(String limsId) {
    this.limsId = limsId;
  }

  public List<JsonProjectUpdateEplate> getIncludedEplates() {
    return includedEplates;
  }

  public void setIncludedEplates(List<JsonProjectUpdateEplate> includedEplates) {
    this.includedEplates = includedEplates;
  }

  public String getMabProjectStatusId() {
    return mabProjectStatusId;
  }

  public void setMabProjectStatusId(String mabProjectStatusId) {
    this.mabProjectStatusId = mabProjectStatusId;
  }


}
