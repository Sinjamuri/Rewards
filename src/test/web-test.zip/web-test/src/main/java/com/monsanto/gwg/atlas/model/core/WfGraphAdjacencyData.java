package com.monsanto.gwg.atlas.model.core;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */
public class WfGraphAdjacencyData {

    private String $color;
    private String $type;
    private long $dim;
    private List<WfGraphToolTip> graphToolTipsList;


  public WfGraphAdjacencyData(String color, String type, long dim, List<WfGraphToolTip> graphToolTipsList) {
    this.$color = color;
    this.$type = type;
    this.$dim = dim;
    this.graphToolTipsList = graphToolTipsList;
  }

  public WfGraphAdjacencyData() {
  }

  public List<WfGraphToolTip> getGraphToolTipsList() {
    return graphToolTipsList;
  }

  public void setGraphToolTipsList(List<WfGraphToolTip> graphToolTipsList) {
    this.graphToolTipsList = graphToolTipsList;
  }

    /*private String $percentHet;
    private String $pico;
    private String $qpcr;*/

/*  public String get$qpcr() {
    return $qpcr;
  }

  public void set$qpcr(String $qpcr) {
    this.$qpcr = $qpcr;
  }

  public String get$pico() {
    return $pico;
  }

  public void set$pico(String $pico) {
    this.$pico = $pico;
  }

  public String get$percentHet() {
    return $percentHet;
  }

  public void set$percentHet(String $percentHet) {
    this.$percentHet = $percentHet;
  }*/

  public String get$color() {
    return $color;
  }

  public void set$color(String $color) {
    this.$color = $color;
  }

  public String get$type() {
    return $type;
  }

  public void set$type(String $type) {
    this.$type = $type;
  }

  public long get$dim() {
    return $dim;
  }

  public void set$dim(long $dim) {
    this.$dim = $dim;
  }

}