package com.monsanto.gwg.atlas.service.util;

import com.monsanto.gwg.atlas.service.dpcr.DPcrConstants;

import java.util.regex.Pattern;

/**
 * Created by ASHAR7 on 12/19/2014.
 */
public class UtilityMethodsImpl implements DPcrConstants {

    /**
     * NOTE : Error Check/Exception handling should be done in the calling method
     * gets the String and returns the numeric position for it.
     * @param s String
     * @return String
     */
    public static String getNumericPosition(String s) {

        int length = s.length();
        int position = s.charAt(length-1) - 'A' + 1;
        position = position+(length-1)*26;

        // to get the literal value for each alphabet
        /*
        StringBuilder pos = new StringBuilder();
        for( int i = length-1; i > length-2; ++i) {
            int position = s.charAt(i) - 'a' + 1;
            pos.append(position);
        }*/

        return Integer.valueOf(position).toString();
    }

    /**
     * NOTE : Error Check/Exception handling should be done in the calling method
     * split the string between groups of alphabets and digits
     * @param s String
     * @return String[]
     */
    public static String[] splitStringToPositionArray(String s){

        Pattern pattern = Pattern.compile(PATTERN_SPLIT_STRING_NUMERIC_GROUP);
        String rowAndColumnArray[] = pattern.split(s.toUpperCase());

        return rowAndColumnArray;
    }

    /**
     * NOTE : Error Check/Exception handling should be done in the calling method
     * split the string and return the numeric position for the alphabet group
     * @param s String
     * @return String[
     */
    public static String[] splitAndGetNumericPosition(String s){

        String[] splitArray = splitStringToPositionArray(s);
        splitArray[0] = getNumericPosition(splitArray[0]);

        return splitArray;
    }

    public static String getAlphaNumericString(int gridRow, int gridCol){

        return String.valueOf((char)(gridRow+64)) + String.format("%02d",gridCol);
    }

/*    public static void main(String args[]){

        System.out.println(getAlphaNumericString(1,1));
        System.out.println(getAlphaNumericString(26,26));
        System.out.println(getAlphaNumericString(27,0));
        System.out.println(getAlphaNumericString(0,1));
        System.out.println(getAlphaNumericString(30,-1));
    }*/

}
