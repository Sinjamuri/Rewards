package com.monsanto.gwg.atlas.service.dpcr;

import com.google.gson.Gson;
import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.dao.dpcr.*;
import com.monsanto.gwg.atlas.json.admin.JsonWfConfigProperty;
import com.monsanto.gwg.atlas.json.dpcr.*;
import com.monsanto.gwg.atlas.json.dpcr.AnalysisRun;
import com.monsanto.gwg.atlas.model.core.*;
import com.monsanto.gwg.atlas.model.dpcr.*;
import com.monsanto.gwg.atlas.service.core.WfAsyncProcessService;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.dpcr.annotations.MethodOption;
import com.monsanto.gwg.atlas.service.util.ExcelFactory;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import javax.servlet.ServletOutputStream;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.Future;
import java.util.regex.Pattern;

/**
 * Created by pgros1 on 5/30/14.
 */
@Service
public class DPcrService implements DPcrConstants {

    private static final Logger LOG = LoggerFactory.getLogger(DPcrService.class);
    private static Map<String, Long> filterNameToWfGridDataConfigId = new HashMap<String, Long>();
    @Autowired
    private DPcrPlateDao dPcrPlateDao;
    @Autowired
    private WfDataDao wfDataDao;
    @Autowired
    private WellResultDao wellResultDao;
    @Autowired
    private WfGridDataTypeDao wfGridDataTypeDao;
    @Autowired
    private PartitionResultDao partitionResultDao;
    @Autowired
    private WfGridDataDao wfGridDataDao;
    @Autowired
    private WfDao wfDao;
    @Autowired
    private WfAsyncProcessService wfAsyncProcessService;
    @Autowired
    private ExcelFactory excelFactory;
    @Autowired
    private WriteExcel writeExcel;
    @Autowired
    private FilterResultDao filterResultDao;
    @Autowired
    private SampleDao sampleDao;
    @Autowired
    private AnalysisRunDao analysisRunDao;
    @Autowired
    private WfAssocDao wfAssocDao;
    @Autowired
    private WfService wfService;
    @Autowired
    private WfConfigPropertyDao wfConfigPropertyDao;
    @Autowired
    private WfRefConfigDao wfRefConfigDao;
    @Autowired
    private DataSourceTransactionManager txManager;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    private Map<Long, Sample[][]> plateSamplesCache = new HashMap<Long, Sample[][]>();
    private Map<Long, Map<String, FilterResult>> filterResultsCache = new HashMap<Long, Map<String, FilterResult>>();

    {
        filterNameToWfGridDataConfigId.put("ROX", DPCR_ROX_WF_GRID_DATA_TYPE_ID);
        filterNameToWfGridDataConfigId.put("FAM", DPCR_FAM_WF_GRID_DATA_TYPE_ID);
        filterNameToWfGridDataConfigId.put("VIC", DPCR_VIC_WF_GRID_DATA_TYPE_ID);
    }

    public AnalysisRun startAnalysisRun(AnalysisRun analysisRun) {
        try {

            normalizeFilterResults(analysisRun.getPlateWfId(), analysisRun.getPositiveCountThresholdAlgorithmParametersMap());

            analysisRun.setHistograms(getHistograms(analysisRun.getPlateWfId(), analysisRun.getPositiveCountThresholdAlgorithmParametersMap()));

            analysisRun.setPositiveCountThresholds(getPositiveCountThresholds(analysisRun.getPlateWfId(), analysisRun.getPositiveCountThresholdAlgorithm(),
                    analysisRun.getHistograms(), analysisRun.getPositiveCountThresholdAlgorithmParametersMap()));
            analysisRun.setScatterPlot(getScatterPlot(analysisRun.getPlateWfId(), analysisRun.getPositiveCountThresholds()));

            analysisRun.setPositiveCounts(getPositiveCounts(analysisRun.getPlateWfId(), analysisRun.getPositiveCountThresholds()));
            analysisRun.setCopyEstimates(getCopyEstimates(analysisRun.getPlateWfId(), analysisRun.getPositiveCounts(), analysisRun.getCopyEstimateAlgorithm()));

            analysisRun.setCopyRatios(getCopyRatios(analysisRun.getPlateWfId(), analysisRun.getCopyEstimates(), analysisRun.getTypedRatioMultipliers()));

            analysisRun.setRatioThresholds(getRatioThresholds(analysisRun.getCopyRatios(), analysisRun.getRatioThresholdAlgorithm(), analysisRun.getTypedFixedRatioThresholds()));
            analysisRun.setZygosityCalls(getZygosityCalls(analysisRun.getPlateWfId(), analysisRun.getCopyRatios(), analysisRun.getRatioThresholds()));

            String algorithmsString = getAlgorithmsString(analysisRun);
            analysisRun.setExportResultsFile(createAnalysisRunOutput(analysisRun.getPlateWfId(), analysisRun.getCopyEstimates(), analysisRun.getZygosityCalls(), algorithmsString));

            saveAnalysisRun(analysisRun);

          filterResultsCache.clear();

        } catch (Throwable t) {
            t.printStackTrace();
            throw new RuntimeException("Analysis Run: " + analysisRun.getAnalysisRunLabel() + " FAILED!", t);
        }

        return analysisRun;
    }

    public Map<String, int[]> getHistograms(long plateWfId, Map<String, String> positiveCountThresholdAlgorithmParameters) {
        Map<String, FilterResult> filterResults = getFilterResults(plateWfId);
        Float referenceFilterThreshold = getReferenceFilterThreshold(filterResults, positiveCountThresholdAlgorithmParameters);
        return getHistograms(filterResults, referenceFilterThreshold);
    }

    public Map<String, int[]> getHistograms(Map<String, FilterResult> filterResults, Float referenceFilterThreshold) {
        return getHistograms(filterResults, referenceFilterThreshold, 2560, 10.0f);
    }

    public Map<String, int[]> getHistograms(Map<String, FilterResult> filterResults, Float referenceFilterThreshold, int upperLimit, Float scaleFactor) {
        FilterResult referenceFilterResult = getReferenceFilterResult(filterResults);

        Map<String, int[]> filterHistogramMap = new HashMap<String, int[]>();
        for (Map.Entry<String, FilterResult> filterResultEntry : filterResults.entrySet()) {
            filterHistogramMap.put(filterResultEntry.getKey(), new int[upperLimit]);
        }

        Map<FilterResult, Float[]> filterToPartitionRowValueMap = new LinkedHashMap<FilterResult, Float[]>();

        System.out.println("Printing histogram");
        for (int wellRow = 0; wellRow < referenceFilterResult.getNormalizedReadValues().length; wellRow++) {
            Float[][][] referenceWellRowValues = referenceFilterResult.getNormalizedReadValues()[wellRow];

            for (int wellColumn = 0; wellColumn < referenceWellRowValues.length; wellColumn++) {
                Float[][] referencePartitions = referenceWellRowValues[wellColumn];

                for (int partitionRow = 0; partitionRow < referencePartitions.length; partitionRow++) {
                    Float[] referencePartitionRowValues = referencePartitions[partitionRow];

                    for (FilterResult filterResult : filterResults.values()) {
                        //System.out.println(filterResult.getNormalizedReadValues()[wellRow][wellColumn][partitionRow]);
                        filterToPartitionRowValueMap.put(
                                filterResult,
                                filterResult.getNormalizedReadValues()[wellRow][wellColumn][partitionRow]
                        );
                    }

                    for (int partitionColumn = 0; partitionColumn < referencePartitionRowValues.length; partitionColumn++) {
                        //Float referencePartitionValue = referencePartitionRowValues[partitionColumn];
                        //if (!isPartitionEmpty(referencePartitionValue, referenceFilterThreshold)) {

                            for (Map.Entry<FilterResult, Float[]> filterToPartitionRowValueEntry : filterToPartitionRowValueMap.entrySet()) {
                                Float partitionValue = filterToPartitionRowValueEntry.getValue()[partitionColumn];
                                Float scaledPartitionValue = partitionValue * scaleFactor;

                                // This truncates the decimal value and converts to an index
                                int histogramIndex = scaledPartitionValue.intValue();

                                if (partitionValue !=0) {
                                    filterHistogramMap.get(filterToPartitionRowValueEntry.getKey().getFilterName())[histogramIndex]++;
                                    //System.out.println("filter:"+filterToPartitionRowValueEntry.getKey().getFilterName()+
                                        //",histInd:"+histogramIndex+",Count:"+filterHistogramMap.get(filterToPartitionRowValueEntry.getKey().getFilterName())[histogramIndex]);
                                }
                            }
                        //}
                    }
                }
            }
        }

        for(String key : filterHistogramMap.keySet()){
          int[] hist = filterHistogramMap.get(key);
          System.out.println(key);
          for(int i=0; i < hist.length; i++){
            System.out.println("key="+key+"i="+i+",val="+hist[i]);
          }
        }
        return filterHistogramMap;
    }

    public byte[] getAnalysisRunExportResultsFile(long analysisRunWfId) {
        WfData wfData = wfDataDao.getValue(DPCR_EXPORTED_RESULTS_FILE, analysisRunWfId);
        return wfData.getWfDataBlob();
    }

    public String getAnalysisRunExportResultsFileName(long analysisRunWfId) {
        Wf analysisRun = wfDao.find(analysisRunWfId);
        return analysisRun.getWfEntityLabel() + " Results";
    }

    private String getAlgorithmsString(AnalysisRun analysisRun) {
        return StringUtils.join(new Object[]
                        {
                                analysisRun.getPositiveCountThresholdAlgorithm(),
                                analysisRun.getCopyEstimateAlgorithm(),
                                analysisRun.getRatioThresholdAlgorithm()
                        }, " : "
        );
    }

    private void saveAnalysisRun(final AnalysisRun analysisRun) {

        TransactionCallback<AnalysisRun> transactionCallback = new TransactionCallback<AnalysisRun>() {
            @Override
            public AnalysisRun doInTransaction(TransactionStatus transactionStatus) {
                return analysisRunDao.save(analysisRun);
            }
        };

        TransactionTemplate tt = new TransactionTemplate();
        tt.setTransactionManager(txManager);
        tt.execute(transactionCallback);
    }

    private String[][] getZygosityCalls(long plateWfId, Float[][] copyRatios, Map<String, Map<String, RatioThreshold>> ratioThreshold) {
        Sample[][] samples = getPlateSamples(plateWfId);
        String[][] zygosityCalls = new String[copyRatios.length][];

        for (int wellRow = 0; wellRow < copyRatios.length; wellRow++) {
            zygosityCalls[wellRow] = new String[copyRatios[wellRow].length];

            for (int wellCol = 0; wellCol < copyRatios[wellRow].length; wellCol++) {
                Sample sample = samples[wellRow][wellCol];
                try {
                    RatioThreshold threshold = ratioThreshold.get(sample.getMarker()).get(sample.getTissueType());

                    if (null != copyRatios[wellRow][wellCol]) {
                        zygosityCalls[wellRow][wellCol] = getZygosityCall(copyRatios[wellRow][wellCol], threshold);
                    }
                } catch (NullPointerException e) {
                    //continue
                } catch (Exception e) {
                    //continue
                }
            }
        }

        return zygosityCalls;
    }

    private String getZygosityCall(Float ratio, RatioThreshold threshold) {
        if (ratio.compareTo(threshold.getHemiMin()) < 0) {
            return "NEG";
        } else if (ratio.compareTo(threshold.getHemiMax()) < 0) {
            return "HEMI";
        } else {
            return "HOMO";
        }
    }

    private Map<String, Map<String, RatioThreshold>> getRatioThresholds(Float[][] copyRatios, String ratioThresholdAlgorithm, List<RatioThreshold> fixedRatioThresholds) {
        try {
            // Try static assignment first
            Method staticThresholdMethod = RatioThresholdAlgorithms.class.getDeclaredMethod(ratioThresholdAlgorithm, List.class);
            if (staticThresholdMethod != null) {
                return (Map<String, Map<String, RatioThreshold>>) staticThresholdMethod.invoke(null, fixedRatioThresholds);
            }
        } catch (NoSuchMethodException nsme) {
            // pass
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Could not invoke ratio estimate algorithm", e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException("Could not invoke ratio estimate algorithm", e);
        }

        try {

            Method ratioThresholdMethod = RatioThresholdAlgorithms.class.getDeclaredMethod(ratioThresholdAlgorithm, Float[][].class);
            return (Map<String, Map<String, RatioThreshold>>) ratioThresholdMethod.invoke(null, copyRatios);

        } catch (NoSuchMethodException nsme) {
            throw new RuntimeException("Could not find Ratio Estimate Algorithm: " + ratioThresholdAlgorithm);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Could not invoke ratio estimate algorithm", e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException("Could not invoke ratio estimate algorithm", e);
        }
    }

    private Float[][] getCopyRatios(long plateWfId, Map<String, Integer[][]> copyEstimates, List<RatioMultiplier> ratioMultipliers) {
        Map<String, Map<String, Float>> ratioMultipliersMap = getRatioMultipliersMap(ratioMultipliers);
        Sample[][] plateSamples = getPlateSamples(plateWfId);
        Float[][] copyRatios = new Float[plateSamples.length][];

        for (int wellRow = 0; wellRow < plateSamples.length; wellRow++) {
            copyRatios[wellRow] = new Float[plateSamples[wellRow].length];

            for (int wellCol = 0; wellCol < plateSamples[wellRow].length; wellCol++) {
                Sample sample = plateSamples[wellRow][wellCol];

                Float copyRatio = null;
                try {
                    Float ratioMultiplier = //getRatioMultiplier( plateSamples[wellRow][wellCol] );
                            ratioMultipliersMap.get(sample.getCropType()).get(sample.getTissueType());

                    Float famValue = new Float(copyEstimates.get("FAM")[wellRow][wellCol]);
                    Float vicValue = new Float(copyEstimates.get("VIC")[wellRow][wellCol]);

                    copyRatio = ratioMultiplier * (
                            famValue / vicValue);
                } catch (NullPointerException e) {
                    //continue
                } catch (Exception e) {
                    //continue
                }


                copyRatios[wellRow][wellCol] = copyRatio;
            }
        }

        return copyRatios;
    }

    private Sample[][] getPlateSamples(long plateWfId) {
        Sample[][] samples = plateSamplesCache.get(plateWfId);
        if (samples == null) {
            samples = sampleDao.getSamplesGrid(plateWfId);
            plateSamplesCache.put(plateWfId, samples);
        }
        return samples;
    }

    private Map<String, Map<String, Float>> getRatioMultipliersMap(List<RatioMultiplier> ratioMultipliers) {
        Map<String, Map<String, Float>> ratioMultipliersMap = new HashMap<String, Map<String, Float>>();
        for (RatioMultiplier ratioMultiplier : ratioMultipliers) {
            Map<String, Float> cropMultipliers = ratioMultipliersMap.get(ratioMultiplier.getCrop());
            if (cropMultipliers == null) {
                cropMultipliers = new HashMap<String, Float>();
                ratioMultipliersMap.put(ratioMultiplier.getCrop(), cropMultipliers);
            }

            cropMultipliers.put(ratioMultiplier.getTissueType(), ratioMultiplier.getMultiplier());
        }
        return ratioMultipliersMap;
    }

    private Map<String, Integer[][]> getCopyEstimates(long plateWfId, Map<String, Integer[][]> positiveCounts, String copyEstimateAlgorithm) {
        String referenceFilterName = getReferenceFilterName(plateWfId);
        Integer[][] referencePositiveCounts = positiveCounts.get(referenceFilterName);

        Map<String, Integer[][]> nonRefPositiveCounts = new HashMap<String, Integer[][]>();
        for (Map.Entry<String, Integer[][]> entry : positiveCounts.entrySet()) {
            if (!entry.getKey().equals(referenceFilterName)) {
                nonRefPositiveCounts.put(entry.getKey(), entry.getValue());
            }
        }

        try {
            Method copyEstimateMethod = CopyEstimateAlgorithms.class.getDeclaredMethod(copyEstimateAlgorithm, Integer[][].class, Map.class);
            return (Map<String, Integer[][]>) copyEstimateMethod.invoke(null, referencePositiveCounts, nonRefPositiveCounts);

        } catch (NoSuchMethodException nsme) {
            throw new RuntimeException("Could not find Copy Estimate Algorithm: " + copyEstimateAlgorithm);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Could not invoke copy estimate algorithm", e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException("Could not invoke copy estimate algorithm", e);
        }
    }

    private Map<String, Integer[][]> getPositiveCounts(Long plateWfId, Map<String, Float> positiveCountThresholds) {
        Map<String, FilterResult> filterResults = getFilterResults(plateWfId);

        FilterResult referenceFilterResult = getReferenceFilterResult(filterResults);
        Float[][][][] referenceRawReadValues = referenceFilterResult.getNormalizedReadValues();

        int wellRowCount = referenceRawReadValues.length;
        int wellColCount = referenceRawReadValues[0].length;

        Map<String, Float[]> partRowValuesMap = new HashMap<String, Float[]>();

        Map<String, Integer[][]> positiveCounts = new HashMap<String, Integer[][]>();
        for (Map.Entry<String, FilterResult> entry : filterResults.entrySet()) {
            positiveCounts.put(entry.getKey(), new Integer[wellRowCount][wellColCount]);
        }

        for (int wellRow = 0; wellRow < wellRowCount; wellRow++) {
            for (int wellCol = 0; wellCol < wellColCount; wellCol++) {
                for (int partRow = 0; partRow < referenceRawReadValues[wellRow][wellCol].length; partRow++) {

                    Float[] partRowValues = referenceRawReadValues[wellRow][wellCol][partRow];
                    for (Map.Entry<String, FilterResult> entry : filterResults.entrySet()) {
                        partRowValuesMap.put(entry.getKey(), entry.getValue().getNormalizedReadValues()[wellRow][wellCol][partRow]);
                    }

                    for (int partCol = 0; partCol < partRowValues.length; partCol++) {
                        for (Map.Entry<String, FilterResult> entry : filterResults.entrySet()) {
                            Float rawValue = partRowValuesMap.get(entry.getKey())[partCol];
                            Float threshold = positiveCountThresholds.get(entry.getKey());

                            Integer positiveCount = positiveCounts.get(entry.getKey())[wellRow][wellCol];
                            if (positiveCount == null) {
                                positiveCount = new Integer(0);
                                positiveCounts.get(entry.getKey())[wellRow][wellCol] = positiveCount;
                            }

                            if (null == rawValue || rawValue.compareTo(threshold) >= 0) {
                                positiveCounts.get(entry.getKey())[wellRow][wellCol] = positiveCount + 1;
                            }
                        }
                    }
                }
            }
        }
        return positiveCounts;
    }

    private List<String[]> getScatterPlot(Long plateWfId, Map<String, Float> positiveCountThresholds) {
        Map<String, FilterResult> filterResults = getFilterResults(plateWfId);
        LinkedList<String[]> scatterPlot = new LinkedList<String[]>();

        FilterResult referenceFilterResult = getReferenceFilterResult(filterResults);
        Float[][][][] referenceRawReadValues = referenceFilterResult.getRawReadValues();
        DecimalFormat rawValueStringFormat = new DecimalFormat("#0.##");

        for (int wellRow = 0; wellRow < referenceRawReadValues.length; wellRow++) {
            for (int wellCol = 0; wellCol < referenceRawReadValues[wellRow].length; wellCol++) {
                for (int partRow = 0; partRow < referenceRawReadValues[wellRow][wellCol].length; partRow++) {

                    // This is arbitrarily FAM (x) vs VIC (y), should be abstracted
                    Float[] partRowValues = referenceRawReadValues[wellRow][wellCol][partRow];
                    Float[] famRowValues = filterResults.get("FAM").getRawReadValues()[wellRow][wellCol][partRow];
                    Float[] vicRowValues = filterResults.get("VIC").getRawReadValues()[wellRow][wellCol][partRow];

                    for (int partCol = 0; partCol < partRowValues.length; partCol++) {
                        // Avoiding empty wells
                        if (partRowValues[partCol] != null) {
                            String[] point = new String[2];
                            point[0] = rawValueStringFormat.format(famRowValues[partCol]);
                            point[1] = rawValueStringFormat.format(vicRowValues[partCol]);
                            scatterPlot.add(point);
                        }
                    }
                }
            }
        }

        return scatterPlot;
    }

    private String getReferenceFilterName(long plateWfId) {
        return getReferenceFilterResult(plateWfId).getFilterName();
    }

    private FilterResult getReferenceFilterResult(long plateWfId) {
        return getReferenceFilterResult(getFilterResults(plateWfId));
    }

    private FilterResult getReferenceFilterResult(Map<String, FilterResult> filterResults) {
        for (FilterResult filterResult : filterResults.values()) {
            if (filterResult.isReference()) {
                return filterResult;
            }
        }

        return null;
    }

    public byte[] createAnalysisRunOutput(Long plateWfId, Map<String, Integer[][]> copyEstimates, String[][] zygosityCalls, String algorithm) {

        byte excelByteArray[] = writeExcel.createExcel(plateWfId, copyEstimates, zygosityCalls, algorithm);
        wfDataDao.save(plateWfId, DPCR_EXPORTED_RESULTS_FILE, excelByteArray);

        return excelByteArray;
    }

    /**
     * Breaks the map values to the required parameters and passes control to the WriteExcel class for further processing.
     *
     * @param out
     * @param valuesMap
     */
    public void createAnalysisRunOutput(ServletOutputStream out, Map<String, Object> valuesMap) throws IOException {

        Long plateWfId = (Long) valuesMap.get("plateWfId");

        WfData wfData = wfDataDao.getValue(DPCR_EXPORTED_RESULTS_FILE, plateWfId);

        out.write(wfData.getWfDataBlob());

    }

    private Map<String, FilterResult> getFilterResults(long wfId) {
        Map<String, FilterResult> filterResultMap = filterResultsCache.get(wfId);
        if (filterResultMap == null) {
            filterResultMap = new HashMap<String, FilterResult>();

            List<FilterResult> filterResults = filterResultDao.getFilterResults(wfId);

            for (FilterResult filterResult : filterResults) {
                filterResultMap.put(filterResult.getFilterName(), filterResult);
            }

            filterResultsCache.put(wfId, filterResultMap);
        }
        return filterResultMap;
    }

    private Float getReferenceFilterThreshold(Map<String, FilterResult> filterResults, Map<String, String> positiveCountThresholds) {
        String referenceFilterName = getReferenceFilterResult(filterResults).getFilterName();
        Float referenceFilterThreshold = new Float(positiveCountThresholds.get(referenceFilterName));
        return referenceFilterThreshold;
    }

    private void normalizeFilterResults(long plateWfId, Map<String, String> positiveCountThresholdAlgorithmParameters) {
        Map<String, FilterResult> filterResults = getFilterResults(plateWfId);
        Float referenceFilterThreshold = getReferenceFilterThreshold(filterResults, positiveCountThresholdAlgorithmParameters);
      System.out.println("referenceFilterThreshold:"+referenceFilterThreshold);
        normalizeFilterResults(filterResults, referenceFilterThreshold);
    }

    private void normalizeFilterResults(Map<String, FilterResult> filterResults, Float referenceFilterThreshold) {
        FilterResult referenceFilterResult = getReferenceFilterResult(filterResults);

        Float averageIntensityValueAboveThreshold = getAverageIntensityValueAboveThreshold(referenceFilterResult, referenceFilterThreshold);
      System.out.println("averageIntensityValueAboveThreshold/roxNorm:"+averageIntensityValueAboveThreshold);
        Float[][][][] referenceRawReadValues = referenceFilterResult.getRawReadValues();
        referenceFilterResult.setNormalizedReadValues(referenceRawReadValues);

        for (FilterResult filterResult : filterResults.values()) {
            if (!filterResult.isReference()) {
                Float[][][][] normalizedReadValues = new Float[referenceRawReadValues.length][][][];
                for (int wellRow = 0; wellRow < normalizedReadValues.length; wellRow++) {
                    normalizedReadValues[wellRow] = new Float[referenceRawReadValues[wellRow].length][][];
                }

                filterResult.setNormalizedReadValues(normalizedReadValues);
            }
        }

        int nonReferenceFilters = filterResults.size()-1;
        System.out.println("Printing normalized Partitions");

        for (int wellRow = 0; wellRow < referenceRawReadValues.length; wellRow++) {
            Float[][][] referenceWellRowValues = referenceRawReadValues[wellRow];

            for (int wellColumn = 0; wellColumn < referenceWellRowValues.length; wellColumn++) {

              for (FilterResult filterResult : filterResults.values()) {
                    if (!filterResult.isReference()) {
                        filterResult.getNormalizedReadValues()[wellRow][wellColumn] =
                                new Float
                                        [referenceWellRowValues[wellColumn].length][];
                    }
                }

              Float[][] referencePartitions = referenceWellRowValues[wellColumn];

              for (int partitionRow = 0; partitionRow < referencePartitions.length; partitionRow++) {
                    Float[] referencePartitionRowValues = referencePartitions[partitionRow];

                    /*// Extract the corresponding partition rows of any non-reference filter results
                    Float[][] nonRefFilterRawPartitionRowValues = new Float[nonReferenceFilters][];
                    Float[][] nonRefFilterNormalizedPartitionRowValues = new Float[nonReferenceFilters][];

                    int nonReferenceFilterIndex = 0;

                    for (FilterResult filterResult : filterResults.values()) {
                        if (!filterResult.isReference()) {
                            nonRefFilterRawPartitionRowValues[nonReferenceFilterIndex] = filterResult.getRawReadValues()[wellRow][wellColumn][partitionRow];
                            nonRefFilterNormalizedPartitionRowValues[nonReferenceFilterIndex] =
                                    new Float[referencePartitionRowValues.length];

                            // Setting up normalized value partition arrays
//                            filterResult.getNormalizedReadValues()[wellRow][wellColumn] =
//                                    new Float
//                                            [filterResult.getRawReadValues()[wellRow][wellColumn].length][];
                            filterResult.getNormalizedReadValues()[wellRow][wellColumn][partitionRow] =
                                    nonRefFilterNormalizedPartitionRowValues[nonReferenceFilterIndex];

                            nonReferenceFilterIndex++;
                        }
                    }*/

                    for (int partitionColumn = 0; partitionColumn < referencePartitionRowValues.length; partitionColumn++) {
                        Float referencePartitionValue = referencePartitionRowValues[partitionColumn];

                      for (FilterResult filterResult : filterResults.values()) {
                        if (!filterResult.isReference()) {
                          Float rawReadVal = filterResult.getRawReadValues()[wellRow][wellColumn][partitionRow][partitionColumn];
                          Float normalizeIntensityValue = normalizeIntensityValue(
                              rawReadVal,
                              referencePartitionValue,
                              averageIntensityValueAboveThreshold,
                              referenceFilterThreshold
                          );
                          if(normalizeIntensityValue >= 80.6 && normalizeIntensityValue<80.8){
                            System.out.println("Filter:"+filterResult.getFilterName()+",RawVal:"+rawReadVal+",NormVal:"+normalizeIntensityValue);
                          }
                          if(null == filterResult.getNormalizedReadValues()[wellRow][wellColumn][partitionRow]){
                            filterResult.getNormalizedReadValues()[wellRow][wellColumn][partitionRow] =
                                new Float[referencePartitionRowValues.length];
                          }

                          // Setting up normalized value partition arrays
//                            filterResult.getNormalizedReadValues()[wellRow][wellColumn] =
//                                    new Float
//                                            [filterResult.getRawReadValues()[wellRow][wellColumn].length][];
                          filterResult.getNormalizedReadValues()[wellRow][wellColumn][partitionRow][partitionColumn] =
                              new Float(normalizeIntensityValue);
                        }
                      }

                        // For each non-reference raw filter result, compute and store the normalized value for the current partition
                        /*for (nonReferenceFilterIndex = 0; nonReferenceFilterIndex < nonRefFilterRawPartitionRowValues.length; nonReferenceFilterIndex++) {
                          Float normalizeIntensityValue = normalizeIntensityValue(
                              nonRefFilterRawPartitionRowValues[nonReferenceFilterIndex][partitionColumn],
                              referencePartitionValue,
                              averageIntensityValueAboveThreshold,
                              referenceFilterThreshold
                          );
                          if(normalizeIntensityValue >= 80.6 && normalizeIntensityValue<80.8){
                            System.out.println("Ind:"+nonReferenceFilterIndex+"NormVal:"+normalizeIntensityValue);
                          }
                          nonRefFilterNormalizedPartitionRowValues[nonReferenceFilterIndex][partitionColumn] =
                              normalizeIntensityValue;

                        }*/
                    }
                }
            }
        }
      /*for(String filterName : filterResults.keySet()){
        FilterResult filterResult = filterResults.get(filterName);
        Float[][][][] normArr = filterResult.getNormalizedReadValues();
          for (int row = 0; row < normArr.length; row++) {
            Float[][][] rowArr = normArr[row];
            for (int col = 0; col < rowArr.length; col++) {
              Float[][] colArr = rowArr[col];
              for (int parRow = 0; parRow < colArr.length; parRow++) {
                Float[] parRowArr = colArr[parRow];
                for (int parCol = 0; parCol < parRowArr.length; parCol++) {
                  Float parColVal = parRowArr[parCol];
                  System.out.println("Row:" + row + ",Column:" + col + ",ParRow:" + parRow + ",ParCol:" + parCol +
                      ",Filter:" + filterName +
                      ",RawVal:" + filterResult.getRawReadValues()[row][col][parRow][parCol] +
                      ",NormVal:" + parColVal);
                }
              }
            }
          }
      }*/
    }

    private Float normalizeIntensityValue(Float intensityValue,
                                               Float refIntensityValue,
                                               Float avgRefIntensityValueAboveThreshold,
                                               Float refFilterThreshold) {
        if (isPartitionEmpty(refIntensityValue, refFilterThreshold)) {
            return getEmptyPartitionValue();
        } else {
            return (intensityValue / refIntensityValue) * (avgRefIntensityValueAboveThreshold);
        }
    }

    private Float getEmptyPartitionValue() {
        return 0f;
    }

    private boolean isPartitionEmpty(Float partitionValue) {
        return partitionValue == null || partitionValue.equals(getEmptyPartitionValue());
    }

    private boolean isPartitionEmpty(Float partitionValue, Float thresholdValue) {
        return isPartitionEmpty(partitionValue) || partitionValue.compareTo(thresholdValue) < 0;
    }

    private Float getAverageIntensityValueAboveThreshold(FilterResult filterResult, Float filterThreshold) {
        int countOfValuesAboveThreshold = 0;
        Float sumOfValuesAboveThreshold = 0f;

        for (Float[][][] wellRow : filterResult.getRawReadValues()) {
            for (Float[][] well : wellRow) {
                for (Float[] partitionRow : well) {
                    for (int partitionColumn = 0; partitionColumn < partitionRow.length; partitionColumn++) {
                        Float partitionValue = partitionRow[partitionColumn];

                        if (!isPartitionEmpty(partitionValue, filterThreshold)) {
                            countOfValuesAboveThreshold++;
                            sumOfValuesAboveThreshold = sumOfValuesAboveThreshold + (partitionValue);
                        } /*else {
                            // NOTE: Those beneath the threshold are considered 'EMPTY', and no data from this partition
                            // for any filter will be used. Hence we assign an empty value so we can later detect this
                            // and assign corresponding filter locations as empty.
                            partitionRow[partitionColumn] = getEmptyPartitionValue();
                        }*/
                    }
                }
            }
        }


        //return sumOfValuesAboveThreshold / (new Float(countOfValuesAboveThreshold));
        return sumOfValuesAboveThreshold / countOfValuesAboveThreshold;
    }

    protected Map<String, Float> getPositiveCountThresholds(long wfId, String positiveCountThresholdAlgorithm, Map<String, int[]> histograms,
                                                                 Map<String, String> positiveCountThresholdAlgorithmParameters) {
        Map<String, FilterResult> filterResults = getFilterResults(wfId);
        HashMap<String, Float> filterThresholdMap = new HashMap<String, Float>();

        // Try invoking manual method first
        try {
            Method manualThresholdAlgorithm = PositiveThresholdAlgorithms.class.getDeclaredMethod(positiveCountThresholdAlgorithm, Map.class);
            return (Map<String, Float>) manualThresholdAlgorithm.invoke(null, positiveCountThresholdAlgorithmParameters);
        } catch (NoSuchMethodException nsme) {
            // pass
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Could not invoke positive count threshold algorithm", e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException("Could not invoke positive count threshold algorithm", e);
        }

        // Now try automated methods
        try {
            Method thresholdAlgorithm = PositiveThresholdAlgorithms.class.getDeclaredMethod(positiveCountThresholdAlgorithm, int[].class);

            for (Map.Entry<String, FilterResult> filterResultEntry : filterResults.entrySet()) {
                // This handles the default reference threshold case, i.e., the threshold for the reference filter is
                // known before the others because of normalization, so we pick it up here..
                if (filterResultEntry.getValue().isReference()
                        && positiveCountThresholdAlgorithmParameters.containsKey(filterResultEntry.getKey())) {
                    filterThresholdMap.put(
                            filterResultEntry.getKey(),
                            new Float(positiveCountThresholdAlgorithmParameters.get(filterResultEntry.getKey())));
                } else {
                    Integer positiveCountThreshold = (Integer) thresholdAlgorithm.invoke(null, histograms.get(filterResultEntry.getKey()));
                    // Scaling necessary because the histograms range 0 to 2560, which equates to raw value range 0 to 256.0
                    Float scaledPositiveCountThreshold = (new Float(positiveCountThreshold /10.0));
                    filterThresholdMap.put(filterResultEntry.getKey(), scaledPositiveCountThreshold);
                }
            }

        } catch (NoSuchMethodException nsme) {
            throw new RuntimeException("Could not find Positive Count Threshold Algorithm: " + positiveCountThresholdAlgorithm);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Could not invoke positive count threshold algorithm", e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException("Could not invoke positive count threshold algorithm", e);
        }

        return filterThresholdMap;
    }

    public Map<Wf, List<FilterResult>> getPlateToFilterResults(List<Wf> dpcrPlates) {
        Map<Wf, List<FilterResult>> plateToFilterResultsMap = new HashMap<Wf, List<FilterResult>>();

        for (Wf dPcrPlate : dpcrPlates) {
            plateToFilterResultsMap.put(dPcrPlate, filterResultDao.getFilterResultsMetaData(dPcrPlate.getWfId()));
        }

        return plateToFilterResultsMap;
    }

    public Map<Wf, List<Wf>> getPlateAnalysisRunWfs(List<Wf> dpcrPlates) {
        return getAssocPlateWfs(dpcrPlates, DPCR_ANALYSIS_RUN_WF_ENTITY_TYPE_ID);
    }

    public Map<Wf, Float> getDefaultReferenceFilterThreshold(List<Wf> dPcrPlates) {
        Map<Wf, Float> plateToDefaultReferenceThresholdValue = new HashMap<Wf, Float>();
        for (Wf plateWf : dPcrPlates) {
            plateToDefaultReferenceThresholdValue.put(plateWf, getDefaultReferenceFilterThreshold(plateWf));
        }

        return plateToDefaultReferenceThresholdValue;
    }

    public Float getDefaultReferenceFilterThreshold(Wf dPcrPlate) {
//        return dPcrConfigDao.getDefaultReferenceThresholdValue( dPcrPlate.getWfId() );
        WfConfigProperty wfConfigProperty = wfConfigPropertyDao.findByWfConfigIdAndKey(DPCR_WF_CONFIG_ID, "DEFAULT_REFERENCE_THRESHOLD");
        Float referenceThresholdValue = wfConfigProperty.getValueNumber().floatValue();
        return referenceThresholdValue;
    }

    public Map<String, Map<String, Float>> getDefaultRatioMultiplierValues() {
        WfConfigProperty rootRatioMultiplierValuesConfig = getRefPropertyRoot(RATIO_MULTIPLIERS_PROPERTY_REF_ID);
        Map<String, Map<String, Float>> defaultRatioMultipliersMap = new HashMap<String, Map<String, Float>>();

        for (WfConfigProperty tissueTypeProperty : rootRatioMultiplierValuesConfig.getWfConfigPropertyList()) {
            String tissueType = tissueTypeProperty.getKey();

            for (WfConfigProperty cropProperty : tissueTypeProperty.getWfConfigPropertyList()) {
                String crop = cropProperty.getKey();

                Map<String, Float> tissueTypeMultiplierMap = defaultRatioMultipliersMap.get(crop);
                if (tissueTypeMultiplierMap == null) {
                    tissueTypeMultiplierMap = new HashMap<String, Float>();
                    defaultRatioMultipliersMap.put(crop, tissueTypeMultiplierMap);
                }

                Float multiplierValue = cropProperty.getValueNumber().floatValue();

                tissueTypeMultiplierMap.put(tissueType, multiplierValue);
            }
        }

        return defaultRatioMultipliersMap;
    }

    public Map<String, Map<String, Float[]>> getDefaultHemiRangeValuesMap() {
        WfConfigProperty rootHemiRangeValuesConfig = getRefPropertyRoot(HEMI_RATIO_THRESHOLDS_PROPERTY_REF_ID);
        Map<String, Map<String, Float[]>> defaultHemiRangeValuesMap = new HashMap<String, Map<String, Float[]>>();

        Gson gson = new Gson();

        for (WfConfigProperty tissueTypeProperty : rootHemiRangeValuesConfig.getWfConfigPropertyList()) {
            String tissueType = tissueTypeProperty.getKey();

            for (WfConfigProperty markerProperty : tissueTypeProperty.getWfConfigPropertyList()) {
                String marker = markerProperty.getKey();

                Map<String, Float[]> tissueTypeHemiRatioMap = defaultHemiRangeValuesMap.get(marker);

                if (tissueTypeHemiRatioMap == null) {
                    tissueTypeHemiRatioMap = new HashMap<String, Float[]>();
                    defaultHemiRangeValuesMap.put(marker, tissueTypeHemiRatioMap);
                }

                String hemiRangeString = markerProperty.getValueVarchar2();
                Float[] hemiRange = gson.fromJson(hemiRangeString, Float[].class);

                tissueTypeHemiRatioMap.put(tissueType, hemiRange);
            }
        }

        return defaultHemiRangeValuesMap;
    }

    public WfConfigProperty getRefPropertyRoot(long rootPropertyRefId) {
        List<WfConfigProperty> rootRefPropertyConfigs = wfService.getWfConfigPropertyTree(DPCR_WF_CONFIG_ID);

        for (WfConfigProperty wfConfigProperty : rootRefPropertyConfigs) {
            if (wfConfigProperty.getPropertyId() == rootPropertyRefId) {
                return wfConfigProperty;
            }
        }

        return null;
    }

    public Map<Wf, Map<String, Set<String>>> getCropsAndTissueTypesToAnalyze(List<Wf> dPcrPlates) {
        return dPcrPlateDao.getCropAndTissueTypesPairsInPlateSamples(dPcrPlates);
    }

    public Map<Wf, Map<String, Map<String, Set<String>>>> getMarkerCropsAndTissueTypesToAnalyze(List<Wf> dPcrPlates) {
        return dPcrPlateDao.getMarkerCropAndTissueTypeInPlateSamples(dPcrPlates);
    }

    //xxxxxxx

    public Map<Wf, Map<String, Set<String>>> getMarkerAndTissueTypesToAnalyze(List<Wf> dPcrPlates) {
        return dPcrPlateDao.getMarkerAndTissueTypeInPlateSamples(dPcrPlates);
    }

    private Map<Wf, List<Wf>> getAssocPlateWfs(List<Wf> plates, Long assocEntityTypeId) {
        Map<Wf, List<Wf>> assocWfMap = new HashMap<Wf, List<Wf>>();

        for (Wf plate : plates) {
            List<WfAssoc> assocsList = wfAssocDao.getAdjacencies(plate.getWfId(), assocEntityTypeId);
            List<Long> assocWfIds = new ArrayList<Long>();

            for (WfAssoc assoc : assocsList) {
                assocWfIds.add(assoc.getToWfId());
            }

            assocWfMap.put(plate, wfDao.findAllIn(assocWfIds));
        }

        return assocWfMap;
    }

    public WfAsyncStatus startResultsFileUpload(String resultsFileName, InputStream resultsFileInputStream, String createUser, String requestId) throws Exception {
        if (resultsFileName.endsWith(".pcr")) {
            return startRawResultsFileUpload(createUser, requestId, resultsFileInputStream);
        } else if (resultsFileName.endsWith(".csv")) {
            if (requestId == null) {
                throw new RuntimeException("ERROR: Request Name required for .csv results upload");
            }

            return startPositiveCountResultsFileUpload(requestId, createUser, resultsFileInputStream);
        } else if (resultsFileName.endsWith(".xlsx") || resultsFileName.endsWith(".xls")) {

            return startSampleDataUpload(resultsFileName, createUser, resultsFileInputStream);
        }

        throw new RuntimeException("ERROR: Unknown type of results file, not '.pcr' or '.csv'");
    }

    /**
     * calls the custom class to read the excel file and save the data
     *
     * @param createUser
     * @param resultsFileInputStream
     * @return
     */
    private WfAsyncStatus startSampleDataUpload(String resultsFileName, String createUser, InputStream resultsFileInputStream) {

        List<String> errorLogs = new ArrayList<String>();

        errorLogs = excelFactory.excelReader(resultsFileName, createUser, resultsFileInputStream,
                DPCR_SAMPLE_TEMPLATE_SHEET_NAME, DPCR_SAMPLE_TEMPLATE_USABLE_COLUMNS,"DPCR");

        WfAsyncStatus asyncProcessStatus = new WfAsyncStatus();
        if (errorLogs.isEmpty()) {
            asyncProcessStatus.setIsDone(true);
            asyncProcessStatus.setMessage("Sample Data File Uploaded Successfully.");
        } else {
            asyncProcessStatus.setErrorMessages(errorLogs);
        }

        return asyncProcessStatus;
    }

    public WfAsyncStatus startPositiveCountResultsFileUpload(String requestId, String uploadUser, InputStream resultsFileInputStream) throws Exception {
        Map<String, Long> posCountGridDataTypeIds = new HashMap<String, Long>();
        posCountGridDataTypeIds.put("ROX", DPCR_ROX_POS_CNT_WF_GRID_DATA_TYPE_ID);
        posCountGridDataTypeIds.put("FAM", DPCR_FAM_POS_CNT_WF_GRID_DATA_TYPE_ID);
        posCountGridDataTypeIds.put("VIC", DPCR_VIC_POS_CNT_WF_GRID_DATA_TYPE_ID);

        Map<String, Long> estimateGridDataTypeIds = new HashMap<String, Long>();
        estimateGridDataTypeIds.put("ROX", DPCR_ROX_EST_WF_GRID_DATA_TYPE_ID);
        estimateGridDataTypeIds.put("FAM", DPCR_FAM_EST_WF_GRID_DATA_TYPE_ID);
        estimateGridDataTypeIds.put("VIC", DPCR_VIC_EST_WF_GRID_DATA_TYPE_ID);

        DPcrPlate plate = new DPcrPlate();
        plate.setWfConfigId(DPCR_WF_CONFIG_ID);
        plate.setWfEntityTypeId(DPCR_PLATE_WF_ENTITY_TYPE_ID);
        plate.setPlateImagingId(requestId);
        plate.setWfStepConfigId(DPCR_COMPUTE_ESTIMATES_WF_STEP_CONFIG_ID);
        plate.setCreateUser(uploadUser);

        plate = dPcrPlateDao.save(plate);
        wfDataDao.save(plate.getWfId(), DPCR_PLATE_NAME_WF_DATA_CONFIG_ID, plate.getWfEntityLabel());

        List<WfGridData> wellResults = new ArrayList<WfGridData>();

        String fileContents = IOUtils.toString(resultsFileInputStream, "UTF-8");

        Pattern filterCountsLinePattern = Pattern.compile("^Filter.*well counts,*$", Pattern.CASE_INSENSITIVE);
        Pattern thresholdLinePattern = Pattern.compile("^Threshold,\\d+,*$", Pattern.CASE_INSENSITIVE);
        Pattern estimatesLinePattern = Pattern.compile("^.*template estimates,*$", Pattern.CASE_INSENSITIVE);
        Pattern resultsDataLinePattern = Pattern.compile("^((\\d+|over),){11}(\\d+|over)$");

        String referenceFilterName = null;
        FilterData currentFilter = null;
        long currentWfGridDataTypeId = Long.MIN_VALUE;
        int currentRow = Integer.MIN_VALUE;

        for (String line : fileContents.split("\n")) {
            line = line.trim();

            if (filterCountsLinePattern.matcher(line).matches()) {
                currentFilter = new FilterData();

                String[] tokens = line.split(" ");
                currentFilter.setFilterPairId(tokens[1]);
                currentWfGridDataTypeId = posCountGridDataTypeIds.get(currentFilter.getFilterPairId());

                plate.addFilterData(currentFilter);
                currentRow = 0;

                currentFilter.setIsReferenceFilter(line.contains("reference"));
                if (currentFilter.getIsReferenceFilter()) {
                    referenceFilterName = currentFilter.getReferenceFilter();
                } else {
                    currentFilter.setReferenceFilter(referenceFilterName);
                }

            } else if (thresholdLinePattern.matcher(line).matches()) {
                String[] tokens = line.split(",");
                currentFilter.setIntensityThreshold(Integer.parseInt(tokens[1]));

            } else if (estimatesLinePattern.matcher(line).matches()) {
                String[] tokens = line.split(" ");
                currentWfGridDataTypeId = estimateGridDataTypeIds.get(tokens[0]);
                currentRow = 0;

            } else if (resultsDataLinePattern.matcher(line).matches()) {
                currentRow++;
                String[] values = line.split(",");

                for (int currentCol = 1; currentCol <= values.length; currentCol++) {
                    WfGridData wfGridData = new WfGridData();
                    wfGridData.setGridRow(currentRow);
                    wfGridData.setGridCol(currentCol);
                    wfGridData.setWfGridDataConfigId(currentWfGridDataTypeId);
                    wfGridData.setWfId(plate.getWfId());

                    String stringValue = values[currentCol - 1];
                    try {
                        int value = Integer.parseInt(stringValue);
                        wfGridData.setValueNumber(new Double(value));

                    } catch (NumberFormatException ex) {
                        wfGridData.setValueVarchar2(stringValue);
                    }

                    wellResults.add(wfGridData);
                }
            }
        }

        wfGridDataDao.batchSaveGridData(wellResults);

        return null;
    }

    public WfAsyncStatus startRawResultsFileUpload(String uploadUser, String requestId, InputStream resultsFileInputStream) throws Exception {
        InputSource source = new InputSource(resultsFileInputStream);
        ConstellationResultsFileHandler plateResultsHandler = new ConstellationResultsFileHandler();

        XMLReader parser = XMLReaderFactory.createXMLReader();
        parser.setContentHandler(plateResultsHandler);
        parser.parse(source);

        DPcrPlate plate = plateResultsHandler.getPlates().get(0);

//        for(DPcrPlate plate : plateResultsHandler.getPlates() ) {
        plate.setCreateUser(uploadUser);
        plate.setWfStepConfigId(DPCR_EXPORT_RESULTS_WF_STEP_CONFIG_ID);
        plate.setWfConfigId(DPCR_WF_CONFIG_ID);
        plate.setWfEntityTypeId(DPCR_PLATE_WF_ENTITY_TYPE_ID);
        plate.setPlateImagingId(requestId);

        StoreConstellationResultsFileService storeConstellationResultsFileService = new StoreConstellationResultsFileService();
        storeConstellationResultsFileService.setPlate(plate);
        return wfAsyncProcessService.startWfAsyncProcess(DPCR_WF_CONFIG_ID, uploadUser, storeConstellationResultsFileService);
    }

    public List<Option> getPositiveThresholdAlgorithmOptions() {
        return getMethodOptions(PositiveThresholdAlgorithms.class);
    }

    public List<Option> getCopyEstimateAlgorithmOptions() {
        return getMethodOptions(CopyEstimateAlgorithms.class);
    }

    public List<Option> getEstimateThresholdAlgorithms() {
        return getMethodOptions(RatioThresholdAlgorithms.class);
    }

    public void updateDpcrDefaultProperty(JsonWfConfigProperty jsonWfConfigProperty) {

        WfConfigProperty newWfConfigProperty = new WfConfigProperty();

        newWfConfigProperty.setPropertyId(jsonWfConfigProperty.getPropertyId());
        newWfConfigProperty.setRefKey(jsonWfConfigProperty.getRefKey());
        newWfConfigProperty.setWfConfigId(jsonWfConfigProperty.getWfConfigId());
        newWfConfigProperty.setKey(jsonWfConfigProperty.getKey());
        newWfConfigProperty.setValueVarchar2(jsonWfConfigProperty.getValueVarchar2());
        newWfConfigProperty.setValueTimestamp(jsonWfConfigProperty.getValueTimestamp());
        newWfConfigProperty.setValueBlob(jsonWfConfigProperty.getValueBlob());
        newWfConfigProperty.setValueNumber(jsonWfConfigProperty.getValueNumber());
        newWfConfigProperty.setCreateTs(jsonWfConfigProperty.getCreateTs());
        newWfConfigProperty.setUpdateTs(jsonWfConfigProperty.getUpdateTs());

        wfConfigPropertyDao.update(newWfConfigProperty);
    }

    public void addDpcrDefaultProperty(JsonWfConfigProperty jsonWfConfigProperty) {

        //add ref Configs
        WfRefConfig newWfRefConfig = new WfRefConfig();
        newWfRefConfig.setWfConfigId(jsonWfConfigProperty.getWfConfigId());

        newWfRefConfig.setWfRefActive("Y");
        newWfRefConfig.setCreateUser("user");

        if(null != jsonWfConfigProperty.getCropType() &&
                !jsonWfConfigProperty.getCropType().isEmpty() &&
                !exists(jsonWfConfigProperty.getCropType(), WF_REF_CONFIG_KEY_CROP)){

            newWfRefConfig.setWfRefKey(jsonWfConfigProperty.getCropType());
            newWfRefConfig.setWfRefVarchar2(jsonWfConfigProperty.getCropType());

            newWfRefConfig.setWfRefConfigParentId(WF_REF_CROP_TYPE);
            wfRefConfigDao.insert(newWfRefConfig);
        }


        if(null != jsonWfConfigProperty.getTissueType() &&
                !jsonWfConfigProperty.getTissueType().isEmpty() &&
                !exists(jsonWfConfigProperty.getTissueType(), WF_REF_CONFIG_KEY_TISSUE)){

            newWfRefConfig.setWfRefKey(jsonWfConfigProperty.getTissueType());
            newWfRefConfig.setWfRefVarchar2(jsonWfConfigProperty.getTissueType());

            newWfRefConfig.setWfRefConfigParentId(WF_REF_TISSUE_TYPE);
            wfRefConfigDao.insert(newWfRefConfig);
        }


        //add property - check if tissue type exists- if yes, check if crop type exists -if no,insert.

        WfConfigProperty newWfConfigProperty = null;

        if(jsonWfConfigProperty.getKey().equals("HEMI_RANGE")){
            List<String> hemiRangeChildProperties = wfConfigPropertyDao.findKeyByWfConfigIdAndParentKey(DPCR_WF_CONFIG_ID,HEMI_RATIO_THRESHOLDS_PROPERTY_REF_ID);
            if(null != hemiRangeChildProperties && !hemiRangeChildProperties.isEmpty() &&
                    hemiRangeChildProperties.contains(jsonWfConfigProperty.getTissueType())){
                WfConfigProperty tissueType =
                        wfConfigPropertyDao.findByWfConfigIdAndKey(DPCR_WF_CONFIG_ID, HEMI_RATIO_THRESHOLDS_PROPERTY_REF_ID, jsonWfConfigProperty.getTissueType());

                List<String> tissueTypeChildProperties = wfConfigPropertyDao.
                        findKeyByWfConfigIdAndParentKey(DPCR_WF_CONFIG_ID,tissueType.getPropertyId());

                if(null == tissueTypeChildProperties || tissueTypeChildProperties.isEmpty() ||
                        !tissueTypeChildProperties.contains(jsonWfConfigProperty.getMarker())){
                    //insert marker
                    insertNewProperty(tissueType.getPropertyId(), DPCR_WF_CONFIG_ID, jsonWfConfigProperty.getMarker(),
                            jsonWfConfigProperty.getPropertyValue(), null);
                }else{
                    //error out as already exists
                }


            }else{
                //insert tissue type and then marker
                insertNewProperty(HEMI_RATIO_THRESHOLDS_PROPERTY_REF_ID, DPCR_WF_CONFIG_ID, jsonWfConfigProperty.getTissueType(),
                        null, null);

                WfConfigProperty tissueType =
                        wfConfigPropertyDao.findByWfConfigIdAndKey(DPCR_WF_CONFIG_ID, HEMI_RATIO_THRESHOLDS_PROPERTY_REF_ID, jsonWfConfigProperty.getTissueType());

                //insert marker
                insertNewProperty(tissueType.getPropertyId(), DPCR_WF_CONFIG_ID, jsonWfConfigProperty.getMarker(),
                        jsonWfConfigProperty.getPropertyValue(), null);
            }

        }else if(jsonWfConfigProperty.getKey().equals("MULTIPLIER")){
            List<String> multiplierProperties = wfConfigPropertyDao.findKeyByWfConfigIdAndParentKey(DPCR_WF_CONFIG_ID,RATIO_MULTIPLIERS_PROPERTY_REF_ID);
            if(null != multiplierProperties && !multiplierProperties.isEmpty() &&
                    multiplierProperties.contains(jsonWfConfigProperty.getTissueType())){
                WfConfigProperty tissueType =
                        wfConfigPropertyDao.findByWfConfigIdAndKey(DPCR_WF_CONFIG_ID, RATIO_MULTIPLIERS_PROPERTY_REF_ID, jsonWfConfigProperty.getTissueType());

                List<String> tissueTypeChildProperties = wfConfigPropertyDao.
                        findKeyByWfConfigIdAndParentKey(DPCR_WF_CONFIG_ID,tissueType.getPropertyId());

                if(null == tissueTypeChildProperties || tissueTypeChildProperties.isEmpty() ||
                        !tissueTypeChildProperties.contains(jsonWfConfigProperty.getCropType())){
                    //insert crop type
                    insertNewProperty(tissueType.getPropertyId(), DPCR_WF_CONFIG_ID, jsonWfConfigProperty.getCropType(),
                            null, new Float(jsonWfConfigProperty.getPropertyValue()));

                }else{
                    //error out as already exists
                }


            }else{
                //insert tissue type and then crop type
                insertNewProperty(RATIO_MULTIPLIERS_PROPERTY_REF_ID, DPCR_WF_CONFIG_ID, jsonWfConfigProperty.getTissueType(),
                        null, null);

                WfConfigProperty tissueType =
                        wfConfigPropertyDao.findByWfConfigIdAndKey(DPCR_WF_CONFIG_ID, RATIO_MULTIPLIERS_PROPERTY_REF_ID, jsonWfConfigProperty.getTissueType());

                //insert crop type
                insertNewProperty(tissueType.getPropertyId(), DPCR_WF_CONFIG_ID, jsonWfConfigProperty.getCropType(),
                        null, new Float(jsonWfConfigProperty.getPropertyValue()));
            }
        }
    }

    private void insertNewProperty(Long refKeyId, Long wfConfigId, String key,
                                   String varchar2, Float number ) {

        WfConfigProperty newWfConfigProperty = new WfConfigProperty();

        newWfConfigProperty.setRefKey(refKeyId);
        newWfConfigProperty.setWfConfigId(wfConfigId);

        newWfConfigProperty.setKey(key);
        newWfConfigProperty.setValueVarchar2(varchar2);
        newWfConfigProperty.setValueNumber(new BigDecimal(number));

        wfConfigPropertyDao.insert(newWfConfigProperty);
    }

    private boolean exists(String tissueType, String wfRefTissueType) {
        return wfRefConfigDao.getWfRefChildConfigForWfConfig(DPCR_WF_CONFIG_ID ,wfRefTissueType).contains(tissueType);
    }

    public Wf getPlateInfo(Long wfId) {
        return dPcrPlateDao.find(wfId);
    }

    public void streamResults_raw(PrintWriter pw, Map<String, Object> valuesMap) throws IOException, IllegalAccessException {
        StringBuilder out = new StringBuilder();

        Long wfId = Long.parseLong((String) valuesMap.get("wfId"));
        Wf dpcrPlateWf = dPcrPlateDao.find(wfId);
        out.append("Plate Name,").append(dpcrPlateWf.getWfEntityLabel()).append("\n");
        out.append("Plate Id,").append(dpcrPlateWf.getWfId()).append("\n");
        out.append("Upload Date,").append(dpcrPlateWf.getCreateTs()).append("\n");
        out.append("Export Date,").append(new Date()).append("\n");
        out.append("\n");

        out.append("WELL,")
                .append("PART_ROW,")
                .append("PART_COL,")
                .append("ROX,")
                .append("VIC,")
                .append("FAM")
                .append("\n");

        pw.write(out.toString());

        List<WfGridData> plateWells = wellResultDao.findAll("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", wfId, DPCR_WELL_WF_GRID_DATA_TYPE_ID);
        for (WfGridData plateWell : plateWells) {
            List<WfGridData> partitionResults = partitionResultDao.findAll("AGGREGATE_GROUP_ID = ?", plateWell.getWfGridDataId());
            WellResult wellResult = new WellResult();
            wellResult.setAllPartitionResults(new TreeMap<Integer, TreeMap<Integer, TreeMap<String, PartitionResult>>>());

            for (WfGridData partitionResult : partitionResults) {
                PartitionResult pr = new PartitionResult();
                pr.setPartitionRow(partitionResult.getGridRow());
                pr.setPartitionColumn(partitionResult.getGridCol());

                if (partitionResult.getWfGridDataConfigId().equals(DPCR_ROX_WF_GRID_DATA_TYPE_ID)) {
                    pr.setFilterName("ROX");
                } else if (partitionResult.getWfGridDataConfigId().equals(DPCR_FAM_WF_GRID_DATA_TYPE_ID)) {
                    pr.setFilterName("FAM");
                } else if (partitionResult.getWfGridDataConfigId().equals(DPCR_VIC_WF_GRID_DATA_TYPE_ID)) {
                    pr.setFilterName("VIC");
                }

                pr.setIntensityValue(new Float(partitionResult.getValueNumber()));

                wellResult.setPartitionResult(partitionResult.getGridRow(), partitionResult.getGridCol(), pr);
            }

            out = new StringBuilder();
            for (Integer partitionRow : wellResult.getAllPartitionResults().navigableKeySet()) {
                TreeMap<Integer, TreeMap<String, PartitionResult>> rowResult = wellResult.getAllPartitionResults().get(partitionRow);
                for (Integer partitionCol : rowResult.navigableKeySet()) {
                    TreeMap<String, PartitionResult> intensityResults = rowResult.get(partitionCol);

                    out.append(plateWell.getValueVarchar2()).append(",");
                    out.append(partitionRow).append(",");
                    out.append(partitionCol).append(",");
                    out.append(intensityResults.get("ROX").getIntensityValue()).append(",");
                    out.append(intensityResults.get("VIC").getIntensityValue()).append(",");
                    out.append(intensityResults.get("FAM").getIntensityValue()).append(",");
                    out.append("\n");
                }
            }
            pw.write(out.toString());
        }
    }

    public void streamResults_estimateByThreshold(PrintWriter pw, Map<String, Object> valuesMap) throws IOException {
        StringBuilder out = new StringBuilder();

        Long wfId = Long.parseLong((String) valuesMap.get("wfId"));
        Wf dpcrPlateWf = dPcrPlateDao.find(wfId);

        List<WfData> filters = wfDataDao.getList(DPCR_FILTER_WF_DATA_CONFIG_ID, wfId);
        WfData referenceFilter = wfDataDao.getValue(DPCR_REF_FILTER_WF_DATA_CONFIG_ID, wfId);
        String referenceFilterName = referenceFilter.getWfDataVarchar2();

        Map<String, Float> filterThresholds = new TreeMap<String, Float>();
        filterThresholds.put("ROX", new Float((String) valuesMap.get("wfdc" + DPCR_ROX_THRESHOLD_WF_DATA_CONFIG_ID)));
        filterThresholds.put("FAM", new Float((String) valuesMap.get("wfdc" + DPCR_FAM_THRESHOLD_WF_DATA_CONFIG_ID)));
        filterThresholds.put("VIC", new Float((String) valuesMap.get("wfdc" + DPCR_VIC_THRESHOLD_WF_DATA_CONFIG_ID)));

        out.append("Plate Name,").append(dpcrPlateWf.getWfEntityLabel()).append("\n");
        out.append("Plate Id,").append(dpcrPlateWf.getWfId()).append("\n");
        out.append("Upload Date,").append(new Date(dpcrPlateWf.getCreateTs().getTime())).append("\n");
        out.append("Export Date,").append(new Date()).append("\n");
        out.append("Reference Filter,").append(referenceFilter.getWfDataVarchar2()).append("\n");

        for (Map.Entry<String, Float> filterEntry : filterThresholds.entrySet()) {
            out.append(filterEntry.getKey())
                    .append(" Threshold,")
                    .append(filterEntry.getValue())
                    .append("\n");
        }

        out.append("WELL,");
        for (String filter : filterThresholds.keySet()) {
            if (!filter.equals(referenceFilterName)) {
                out.append(filter).append(",");
            }
        }

        out.append("RATIO,");

        for (String filter : filterThresholds.keySet()) {
            out.append(filter).append("_count").append(",");
        }
        out.append("\n");

        pw.write(out.toString());


        // This really should be the WF_GRID_DATA_TYPE_ID that corresponds to the reference filter,
        // we're assuming it's ROX. And we're loading these values first because we need the
        // reference filter for initial normalization of the raw results.
        long referenceFilterWfGridDataTypeId = DPCR_ROX_WF_GRID_DATA_TYPE_ID;

        Float averageReferenceFilterIntensityOverPlate = (wellResultDao.findAverageReferenceFilterIntensityOverPlate(wfId, referenceFilterWfGridDataTypeId)).floatValue();
        Float[][] referenceFilterIntensityForPartition;

        java.awt.Dimension dimension = wellResultDao.findWellDimensions(wfId);
        int numPartitionRows = dimension.height;
        int numPartitionCols = dimension.width;

        List<WfGridData> plateWells = wellResultDao.findAll("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", wfId, DPCR_WELL_WF_GRID_DATA_TYPE_ID);
        for (WfGridData plateWell : plateWells) {
            WellOutputResult wellResult = new WellOutputResult();
            wellResult.setWellLabel(plateWell.getValueVarchar2());

            List<WfGridData> partitionResults = partitionResultDao.findAll("AGGREGATE_GROUP_ID = ? AND WF_GRID_DATA_TYPE_ID = ?", plateWell.getWfGridDataId(), referenceFilterWfGridDataTypeId);
            referenceFilterIntensityForPartition = new Float[numPartitionRows][numPartitionCols];
            int partitionCount = 0;

            for (WfGridData referenceFilterPartitionResult : partitionResults) {
                referenceFilterIntensityForPartition
                        [referenceFilterPartitionResult.getGridRow() - 1]
                        [referenceFilterPartitionResult.getGridCol() - 1] = new Float(referenceFilterPartitionResult.getValueNumber());
                partitionCount++;

                if (referenceFilterPartitionResult.getValueNumber() > filterThresholds.get(referenceFilterName).doubleValue()) {
                    wellResult.incrementFilterCount(referenceFilterName);
                }
            }

            partitionResults = partitionResultDao.findAll("AGGREGATE_GROUP_ID = ? AND WF_GRID_DATA_TYPE_ID != ?", plateWell.getWfGridDataId(), referenceFilterWfGridDataTypeId);
            for (WfGridData partitionResult : partitionResults) {
                // Check the data grid type id to figure out which filter
                // using the map with the well, increment if the value is above the threshold for the filter

                String filterName = null;
                if (partitionResult.getWfGridDataConfigId().equals(DPCR_FAM_WF_GRID_DATA_TYPE_ID)) {
                    filterName = "FAM";
                } else if (partitionResult.getWfGridDataConfigId().equals(DPCR_VIC_WF_GRID_DATA_TYPE_ID)) {
                    filterName = "VIC";
                }

                Float rawFilterIntensityValue = new Float(partitionResult.getValueNumber());
                Float referenceFilterIntensityValue = referenceFilterIntensityForPartition[partitionResult.getGridRow() - 1][partitionResult.getGridCol() - 1];
                Float normalizedIntensityValue =
                        (rawFilterIntensityValue / (referenceFilterIntensityValue)) * (averageReferenceFilterIntensityOverPlate);

                if (normalizedIntensityValue.compareTo(filterThresholds.get(filterName)) > 0) {
                    wellResult.incrementFilterCount(filterName);
                }
            }

            Float totalPartitions = new Float(partitionCount);
            wellResult.setFilterValueEstimates(new TreeMap<String, Float>());


            Float denominator = new Float(
                    Math.log(
                            1 - new Double(1 / (totalPartitions))
                    )
            );

            for (String filter : filterThresholds.keySet()) {
                if (!filter.equals(referenceFilterName)) {
                    Float referenceFilterCount = new Float(wellResult.getFilterCount(referenceFilterName));
                    Float testFilterCount = new Float(wellResult.getFilterCount(filter));

                    Float numerator = 1 - (testFilterCount / (referenceFilterCount));
                    Float filterValueEstimate = null;
                    if (numerator.compareTo(0f) > 0) {
                        numerator = new Float(Math.log(numerator.doubleValue()));
                        filterValueEstimate = numerator / (denominator);
                    }

                    wellResult.setFilterValueEstimate(filter, filterValueEstimate);
                }
            }

            if (wellResult.getFilterValueEstimate("VIC") != null && wellResult.getFilterValueEstimate("VIC").compareTo(0f) > 0) {
                wellResult.setRatio(wellResult.getFilterValueEstimate("FAM") / (wellResult.getFilterValueEstimate("VIC")));
            } else {
                wellResult.setRatio(null);
            }

            // we have counts now, compute the estimated FAM, VIC
            // compute the ratio

            // do the output
            out = new StringBuilder();

            out.append(wellResult.getWellLabel()).append(", ");
            DecimalFormat valueFormat = new DecimalFormat();
            valueFormat.setMaximumFractionDigits(5);
            valueFormat.setGroupingUsed(false);

            for (String filter : filterThresholds.keySet()) {
                if (!filter.equals(referenceFilterName)) {
                    Float value = wellResult.getFilterValueEstimate(filter);
                    String valueOut = "undefined";

                    if (value != null) {
                        valueOut = valueFormat.format(value);
                    }

                    out.append(valueOut).append(",");
                }
            }

            Float value = wellResult.getRatio();
            String valueOut = "undefined";
            if (value != null) {
                valueOut = valueFormat.format(value);
            }
            out.append(valueOut).append(",");

            for (String filter : filterThresholds.keySet()) {
                out.append(wellResult.getFilterCount(filter)).append(",");
            }

            out.append("\n");

            pw.write(out.toString());
        }
    }

    private String createWellLabel(WellResult wellResult) {
        return createWellLabel(wellResult.getGridRow(), wellResult.getGridCol());
    }

    private String createWellLabel(int wellRow, int wellCol) {
        return (char) ((int) 'A' + wellRow - 1) + String.format("%02d", wellCol);
    }

    public List<Option> getExportAlgorithmOptions() {
        return getMethodOptions(DPcrService.class);
    }

    private List<Option> getMethodOptions(Class annotatedMethodsClass) {
        List<Option> options = new ArrayList<Option>();
        for (Method method : annotatedMethodsClass.getDeclaredMethods()) {
            if (method.isAnnotationPresent(MethodOption.class)) {
                MethodOption methodOption = method.getAnnotation(MethodOption.class);

                Option option = new Option();
                option.setText(methodOption.text());
                option.setValue(methodOption.value());

                options.add(option);
            }
        }

        return options;
    }

//    public List<Option> getExportAlgorithmOptions() {
//        List<Option> options  = new ArrayList<Option>();
//        for( Method method : this.getClass().getMethods() ) {
//            if( method.isAnnotationPresent( DPcrExportMethod.class ) ) {
//                DPcrExportMethod dPcrExportMethod = method.getAnnotation( DPcrExportMethod.class );
//                Option option = new Option();
//                option.setText( dPcrExportMethod.text() );
//                option.setValue( dPcrExportMethod.value() );
//
//                options.add( option );
//            }
//        }
//
//        return options;
//    }

    public void export_estimates(PrintWriter pw, Wf wf) {
        writeWellEstimateHeader(wf, pw);

        List<WfGridData> wellEstimates = wfGridDataDao.findAllOrdered("WF_ID = ? AND WF_GRID_DATA_TYPE_ID IN ( ?, ? )", "GRID_ROW, GRID_COL, WF_GRID_DATA_TYPE_ID",
                wf.getWfId(), DPCR_FAM_EST_WF_GRID_DATA_TYPE_ID, DPCR_VIC_EST_WF_GRID_DATA_TYPE_ID);

        Map<String, WellEstimateOutput> wellEstimateOutputMap = new HashMap<String, WellEstimateOutput>();
        String wellLabel = null;
        String value = null;

        int maxRow = Integer.MIN_VALUE;
        int maxColumn = Integer.MIN_VALUE;

        for (WfGridData wellEstimate : wellEstimates) {
            maxRow = Math.max(maxRow, wellEstimate.getGridRow());
            maxColumn = Math.max(maxColumn, wellEstimate.getGridCol());

            wellLabel = createWellLabel(wellEstimate.getGridRow(), wellEstimate.getGridCol());

            WellEstimateOutput wellEstimateOutput = wellEstimateOutputMap.get(wellLabel);
            if (wellEstimateOutput == null) {
                wellEstimateOutput = new WellEstimateOutput();
                wellEstimateOutputMap.put(wellLabel, wellEstimateOutput);
            }

            if (wellEstimate.getValueNumber() != null) {
                value = Integer.toString(wellEstimate.getValueNumber().intValue());
            } else {
                value = wellEstimate.getValueVarchar2();
            }

            wellEstimateOutput.estimateValues.put(wellEstimate.getWfGridDataConfigId(), value);
        }

        writeWellEstimateResults(wellEstimateOutputMap, maxColumn, maxRow, pw);
    }

    @MethodOption(text = "Log Ratio Test", value = "LNRatio", isDefault = true)
    public void export_LNRatio(PrintWriter pw, Wf wf) {
        writeWellEstimateHeader(wf, pw);

        List<WfGridData> wellPositiveCounts = wfGridDataDao.findAllOrdered("WF_ID = ? AND WF_GRID_DATA_TYPE_ID IN ( ?, ?, ? )", "GRID_ROW, GRID_COL, WF_GRID_DATA_TYPE_ID",
                wf.getWfId(), DPCR_ROX_POS_CNT_WF_GRID_DATA_TYPE_ID, DPCR_FAM_POS_CNT_WF_GRID_DATA_TYPE_ID, DPCR_VIC_POS_CNT_WF_GRID_DATA_TYPE_ID);

        Map<String, WellEstimateOutput> wellEstimateOutputMap = new HashMap<String, WellEstimateOutput>();
        String wellLabel = null;
        String value = null;

        int maxRow = Integer.MIN_VALUE;
        int maxColumn = Integer.MIN_VALUE;

        for (WfGridData wellPositiveCount : wellPositiveCounts) {
            maxRow = Math.max(maxRow, wellPositiveCount.getGridRow());
            maxColumn = Math.max(maxColumn, wellPositiveCount.getGridCol());

            wellLabel = createWellLabel(wellPositiveCount.getGridRow(), wellPositiveCount.getGridCol());

            WellEstimateOutput wellEstimateOutput = wellEstimateOutputMap.get(wellLabel);
            if (wellEstimateOutput == null) {
                wellEstimateOutput = new WellEstimateOutput();
                wellEstimateOutputMap.put(wellLabel, wellEstimateOutput);
            }

            wellEstimateOutput.positiveCounts.put(wellPositiveCount.getWfGridDataConfigId(), wellPositiveCount.getValueNumber().intValue());
        }

        // ln( 1 - ( 1 / 496 ) ), assuming 496 parititions in a well
        Float denominator = new Float(Math.log(1 - (1 / (new Float(496)))));

        for (WellEstimateOutput estimateOutput : wellEstimateOutputMap.values()) {
            Float roxCount = new Float(estimateOutput.positiveCounts.get(DPCR_ROX_POS_CNT_WF_GRID_DATA_TYPE_ID));
            Float famCount = new Float(estimateOutput.positiveCounts.get(DPCR_FAM_POS_CNT_WF_GRID_DATA_TYPE_ID));
            Float vicCount = new Float(estimateOutput.positiveCounts.get(DPCR_VIC_POS_CNT_WF_GRID_DATA_TYPE_ID));

            double logOfFamRatio = Math.log(1 - (famCount / (roxCount)));
            double logOfVicRatio = Math.log(1 - (vicCount / (roxCount)));

            String famEstimateValue = null;
            if (Double.isInfinite(logOfFamRatio) || Double.isNaN(logOfFamRatio)) {
                famEstimateValue = Double.toString(logOfFamRatio);
            } else {
                famEstimateValue = Integer.toString((int) (new Float(logOfFamRatio) / denominator));
            }

            String vicEstimateValue = null;
            if (Double.isInfinite(logOfVicRatio) || Double.isNaN(logOfVicRatio)) {
                vicEstimateValue = Double.toString(logOfVicRatio);
            } else {
                vicEstimateValue = Integer.toString((int)(new Float(logOfVicRatio) / denominator));
            }

            estimateOutput.estimateValues.put(DPCR_FAM_EST_WF_GRID_DATA_TYPE_ID, famEstimateValue);
            estimateOutput.estimateValues.put(DPCR_VIC_EST_WF_GRID_DATA_TYPE_ID, vicEstimateValue);
        }

        writeWellEstimateResults(wellEstimateOutputMap, maxColumn, maxRow, pw);
    }

    private void writeWellEstimateHeader(Wf wf, PrintWriter pw) {
        StringBuilder out = new StringBuilder();

        out.append("Request Id,").append(wf.getWfEntityLabel()).append("\n");
        out.append("ATLAS Id,").append(wf.getWfId()).append("\n");
        out.append("Upload Date,").append(String.format("%1$TD %1$TT", wf.getCreateTs())).append("\n");
        out.append("Export Date,").append(String.format("%1$TD %1$TT", new Date())).append("\n");
        out.append("\n");

        out.append("SAMPLE").append(",")
                .append("WELL").append(",")
                .append("FAM CP").append(",")
                .append("VIC CP").append(",")
                .append("RATIO").append(",")
                .append("RATIO * 2").append(",")
                .append("\n");

        pw.write(out.toString());
    }

    private void writeWellEstimateResults(Map<String, WellEstimateOutput> wellEstimateOutputMap, int columnCount, int rowCount, PrintWriter pw) {
        String wellLabel = null;

        int sampleCount = 1;
        for (int column = 1; column <= columnCount; column++) {
            for (int row = 1; row <= rowCount; row++) {
                wellLabel = createWellLabel(row, column);
                WellEstimateOutput wellEstimateOutput = wellEstimateOutputMap.get(wellLabel);

                StringBuilder lineBuilder = new StringBuilder();
                lineBuilder.append(sampleCount).append(", ");
                lineBuilder.append(wellLabel).append(", ");
                lineBuilder.append(wellEstimateOutput.estimateValues.get(DPCR_FAM_EST_WF_GRID_DATA_TYPE_ID)).append(", ");
                lineBuilder.append(wellEstimateOutput.estimateValues.get(DPCR_VIC_EST_WF_GRID_DATA_TYPE_ID));

                lineBuilder.append("\n");
                pw.write(lineBuilder.toString());

                sampleCount++;
            }
        }
    }

    public Map<String, Map<String, Float>> computeThresholds(Long wfId) {
        Map<String, Map<String, Float>> filterThresholdsMap = new TreeMap<String, Map<String, Float>>();
        Map<String, Float> roxFactorMap = new TreeMap<String, Float>();
        Map<Long, Float[][]> roxWellReads = new HashMap<Long, Float[][]>();

        String[] filterNames = new String[]{"ROX", "FAM", "VIC"};
        Long[] filterDataType = new Long[]{DPCR_ROX_WF_GRID_DATA_TYPE_ID, DPCR_FAM_WF_GRID_DATA_TYPE_ID, DPCR_VIC_WF_GRID_DATA_TYPE_ID};

        for (int filterIndex = 0; filterIndex < filterNames.length; filterIndex++) {
            List<WfGridData> filterReads = wellResultDao.findAllOrdered("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", "VALUE_NUMBER", wfId, filterDataType[filterIndex]);

            int[] histogram;


            if ("ROX".equals(filterNames[filterIndex])) {
                roxWellReads = fillRoxWellReads(filterReads, null);
//                histogram = createHistogram( filterReads, READ_VALUES, SCALE);
            } else {
//                histogram = createHistogram(filterReads, READ_VALUES, SCALE, roxWellReads);
            }


//            histogram = smoothHistogram( histogram );

            Map<String, Float> thresholdMap = new TreeMap<String, Float>();

            for (AutoThresholder.Method method : AutoThresholder.Method.values()) {
                if ("ROX".equals(filterNames[filterIndex])) {
                    histogram = createHistogram(filterReads);
                } else {
                    histogram = createHistogram(filterReads, roxWellReads, roxFactorMap.get(method.toString()));
                }

                AutoThresholder thresholder = new AutoThresholder();
                int threshold = thresholder.getThreshold(method, histogram);
                Float scaledThreshold = new Float(threshold) / (10f);
                thresholdMap.put(method.toString(), scaledThreshold);

                if ("ROX".equals(filterNames[filterIndex])) {
                    Float averageValueAboveThreshold = computeAverageValueAboveThreshold(filterReads, scaledThreshold);
                    roxFactorMap.put(method.toString(), averageValueAboveThreshold);
                }
            }

            filterThresholdsMap.put(filterNames[filterIndex], thresholdMap);
/*
            Float threshold = computeThreshold( histogram, filterReads.size(), new Float( SCALE ));

            ArrayList<Double> rawReads = new ArrayList<Double>();
            for( WfGridData read : filterReads ) {
                rawReads.add( read.getValueNumber() );
            }

            thresholdsMap.put( filterNames[filterIndex], threshold );
*/
//            int[] breaks = getJenksBreaks( rawReads, 2 );
//            for( int i = 0; i < breaks.length; i++ ) {
//                thresholdsMap.put( filterNames[filterIndex] + "_BREAK_" + i, new Float( rawReads.get( breaks[i] ) ));
//            }
        }

//        List<WfGridData> roxReads = wellResultDao.findAll("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", wfId, DPCR_ROX_WF_GRID_DATA_TYPE_ID);
//        int[] roxHistogram = createHistogram(roxReads, READ_VALUES, SCALE);
//        thresholdsMap.put( "ROX", computeThreshold( roxHistogram, roxReads.size(), new Float( SCALE )) );
//
//        List<WfGridData> famReads = wellResultDao.findAll("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", wfId, DPCR_FAM_WF_GRID_DATA_TYPE_ID);
//        int[] famHistogram = createHistogram(famReads, READ_VALUES, SCALE);
//        thresholdsMap.put( "FAM", computeThreshold( famHistogram, famReads.size(), new Float( SCALE )) );
//
//        List<WfGridData> vicReads = wellResultDao.findAll("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", wfId, DPCR_VIC_WF_GRID_DATA_TYPE_ID);
//        int[] vicHistogram = createHistogram(vicReads, READ_VALUES, SCALE);
//        thresholdsMap.put( "VIC", computeThreshold( vicHistogram, vicReads.size(), new Float( SCALE )) );

        return filterThresholdsMap;
    }

    public int[] getFilterHistogram(Long wfId, String filterName) {
        return getFilterHistogram(wfId, filterNameToWfGridDataConfigId.get(filterName));
    }

    public int[] getFilterHistogram(Long wfId, Long filterWfGridDataConfigId) {
        List<WfGridData> filterReads = wellResultDao.findAllOrdered("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", "VALUE_NUMBER", wfId, filterWfGridDataConfigId);
        int[] histogram = createHistogram(filterReads);

        return histogram;
    }

    public Map<String, int[]> getNonReferenceHistograms(Long wfId, Long refThreshold) {
        Map<String, int[]> nonReferenceHistogramsMap = new LinkedHashMap<String, int[]>();

        List<WfGridData> roxFilterReads = wellResultDao.findAllOrdered("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", "VALUE_NUMBER", wfId, filterNameToWfGridDataConfigId.get("ROX"));
        Map<Long, Float[][]> roxWellReads = fillRoxWellReads(roxFilterReads, null);
        Float averageROXValueAboveThreshold = computeAverageValueAboveThreshold(roxFilterReads, refThreshold.intValue());

        for (Map.Entry<String, Long> filterEntry : filterNameToWfGridDataConfigId.entrySet()) {
            if ("ROX".equals(filterEntry.getKey())) {
                continue;
            }

            List<WfGridData> filterReads = wellResultDao.findAllOrdered("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", "VALUE_NUMBER", wfId, filterEntry.getValue());
            int[] histogram = createHistogram(filterReads, roxWellReads, averageROXValueAboveThreshold);

            nonReferenceHistogramsMap.put(filterEntry.getKey(), histogram);
        }

        return nonReferenceHistogramsMap;
    }
/*
    // Otsu method
    private Float computeThreshold( int[] histogram, int numReads, Float scaleValue ) {
        Float totalReads = new Float( numReads );
        Float weightedSum = 0f;

        int[] logScaledHistogram = new int[ histogram.length ];
        for( int i = 0; i < histogram.length; i++ ) {
            logScaledHistogram[i] = (int) Math.ceil( histogram[i] != 0 ? Math.log( histogram[i] ): 0 );
        }
        histogram = logScaledHistogram;

        for( int t = 0; t < histogram.length; t++ ) {
            weightedSum = weightedSum.add( new Float( t * histogram[t]) );
        }

        Float sumB = 0f;
        Float wB = 0f;
        Float wF = 0f;

        Float varMax = 0f;
        Float threshold = 0f;

        for( int t = 0; t < histogram.length; t++ ) {
            wB = wB.add( new Float( histogram[t] ));
            if( wB.compareTo( 0f )== 0 ) continue;

            wF = totalReads - ( wB );
            if( wF.compareTo( 0f) == 0 ) break;

            sumB = sumB.add( new Float( t * histogram[t] ) );

            Float mB = sumB / ( wB, 10, RoundingMode.HALF_UP );
            Float mF = ( weightedSum - ( sumB )) / ( wF, 10, RoundingMode.HALF_UP );

            Float varBetween = wB * ( wF ) * ( mB - ( mF )) * ( mB - ( mF ));

            if( varBetween.compareTo( varMax ) > 0 ) {
                varMax = varBetween;
                threshold = new Float( t ) / (scaleValue);
            }
        }

        return threshold;
    }
 */

    private void foo(Long wfId, String refFilterName, Long refThreshold) {
   /*
    Long refFilterValueWfGridDataConfigId = filterNameToWfGridDataConfigId.get( refFilterName );

        Float averageRefFilterValueAboveThreshold = wellResultDao.getFilterAverageReadValueAboveThreshold( refFilterValueWfGridDataConfigId, refThreshold );
        Map<Long, Float[][]> refFilterValues = getRefFilterWellReads( refFilterValueWfGridDataConfigId, refThreshold );
        List<WfGridData> bar;
        Integer[][] refFilterWellCounts = getFilterWellCounts( refFilterValues, refThreshold );
        //         wfGridDataDao.batchSaveGridData(wellResults);

        for(Map.Entry<String, Long> filterEntry : filterNameToWfGridDataConfigId.entrySet() ) {
            if( refFilterName.equals( filterEntry.getKey()) ) {
                continue;
            }

            List<WfGridData> filterReads = wellResultDao.findAllOrdered("WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ? ", "VALUE_NUMBER", wfId, filterEntry.getValue());
            FilterValues filterValues = getFilterValues( filterReads, refFilterWellReads, averageRefFilterValueAboveThreshold );
            Integer[][] filterWellCounts = getFilterWellCounts( filterValues.wellToPartitionValueMap, filterValues.threshold );
            // Save positive well counts

            Integer[][] filterTemplateEstimates = getFilterTemplateEstimate( filterWellCounts, refFilterWellCounts );
            // Save the template estimates
        }
     */
    }

    private void foo(long wfId, Long refThreshold) {

    }

    public Map<String, Object> getNonReferencePlots(Long wfId, Long refThreshold) {
        Map<String, Object> plots = new LinkedHashMap<String, Object>();
        TreeMap<String, ArrayList<String>> scatterPlot = null;

        String limitingWhereClause =
                "WF_ID = ?" +
                        "  AND   WF_GRID_DATA_TYPE_ID = ?" +
                        "  AND   AGGREGATE_GROUP_ID IN (" +
                        "    SELECT  wf_grid_data_id" +
                        "    FROM    ATLAS.wf_grid_data" +
                        "    WHERE   WF_ID = ?" +
                        "      AND   wf_grid_data_type_id = 7" +
                        "      AND   GRID_ROW < 6" +
                        "      AND   GRID_COL < 6" +
                        ")";

        String normalWhereClause = "WF_ID = ? AND WF_GRID_DATA_TYPE_ID = ?";

        List<WfGridData> roxFilterReads = wellResultDao.findAllOrdered(normalWhereClause, "GRID_ROW, GRID_COL", wfId, filterNameToWfGridDataConfigId.get("ROX"));
        Map<Long, Float[][]> roxWellReads = fillRoxWellReads(roxFilterReads, refThreshold);
        Float averageROXValueAboveThreshold = computeAverageValueAboveThreshold(roxFilterReads, refThreshold.intValue());

        for (Map.Entry<String, Long> filterEntry : filterNameToWfGridDataConfigId.entrySet()) {
            if ("ROX".equals(filterEntry.getKey())) {
                continue;
            }

            List<WfGridData> filterReads = wellResultDao.findAllOrdered(normalWhereClause, "GRID_ROW, GRID_COL", wfId, filterEntry.getValue());
            if (scatterPlot == null) {
                scatterPlot = new TreeMap<String, ArrayList<String>>();
            }

            int filterIndex = ("FAM".equals(filterEntry.getKey()) ? 0 : 1);
            int[] histogram = createHistogram(filterReads, roxWellReads, averageROXValueAboveThreshold, scatterPlot, filterIndex);
            plots.put(filterEntry.getKey(), ArrayUtils.toObject(histogram));
            filterIndex++;
        }

        plots.put("FAM (x) vs VIC (y)", scatterPlot);

        return plots;
    }

    public Map<String, Integer> getThresholds(int[] histogram) {
        Map<String, Integer> thresholdMethodToValueMap = new TreeMap<String, Integer>();

        for (AutoThresholder.Method method : AutoThresholder.Method.values()) {
            AutoThresholder thresholder = new AutoThresholder();
            int threshold = thresholder.getThreshold(method, histogram);
            thresholdMethodToValueMap.put(method.toString(), threshold);
        }

        return thresholdMethodToValueMap;
    }

    public Map<String, int[]> getHistograms(Long wfId, Long refThreshold) {
        Map<String, int[]> histograms = new LinkedHashMap<String, int[]>();
        for (Map.Entry filterName : filterNameToWfGridDataConfigId.entrySet()) {

        }


        return histograms;
    }

    public int[] createHistogram(List<WfGridData> readData) {
        return createHistogram(readData, null, null);
    }

    public int[] createHistogram(List<WfGridData> readData, Map<Long, Float[][]> normalizingReads, Float normalizeFactor) {
        return createHistogram(readData, normalizingReads, normalizeFactor, null, 0);
    }

    public int[] createHistogram(List<WfGridData> readData, Map<Long, Float[][]> normalizingReads, Float normalizeFactor, Map<String, ArrayList<String>> rawValues, int rawIndex) {
        int READ_VALUES = 256;
        int SCALE_VALUE = 10;

        int[] readsHistogram = new int[READ_VALUES * SCALE_VALUE];
        Float bdScale = new Float(SCALE_VALUE);
        DecimalFormat rawValueStringFormat = new DecimalFormat("#0.##");

        for (WfGridData readDatum : readData) {
            Float scaledRawValue = new Float(readDatum.getValueNumber());

            if (normalizingReads != null && normalizeFactor != null) {
                Float normalizeReadValue = normalizingReads.get(readDatum.getAggregateGroupId())[readDatum.getGridRow() - 1][readDatum.getGridCol() - 1];
                if (normalizeReadValue == null) continue;

                Float scaledNormalizedReadValue = normalizeReadValue;
                scaledRawValue = scaledRawValue / (scaledNormalizedReadValue) * (normalizeFactor);
            }

            if (rawValues != null) {
                String valueIndex = Long.toString(readDatum.getAggregateGroupId()) + (16 * (readDatum.getGridRow() - 1)) + (readDatum.getGridCol() - 1);
                ArrayList<String> valuesArray = rawValues.get(valueIndex);
                if (valuesArray == null) {
                    valuesArray = new ArrayList<String>();
                    rawValues.put(valueIndex, valuesArray);
                }
                valuesArray.add(rawIndex, rawValueStringFormat.format(scaledRawValue));
            }
            // this is a truncate effectively
            int value = (int) (scaledRawValue * bdScale);
//            int value = (int) Math.floor( readDatum.getValueNumber() * scaleValue );
            if (value < readsHistogram.length)
                readsHistogram[value]++;
        }

        return readsHistogram;
    }

    private int[] smoothHistogram(int[] histogram) {
        int[] smoothedHistogram = new int[histogram.length];
        for (int i = 0; i < histogram.length; i++) {
            smoothedHistogram[i] = (histogram[i] > 0 ? (int) Math.log(histogram[i]) : 0);
        }

        return smoothedHistogram;
    }

    private Float computeAverageValueAboveThreshold(List<WfGridData> filterReads, int scaledThreshold) {
        Float threshold = (new Float(scaledThreshold)) / (10f);
        return computeAverageValueAboveThreshold(filterReads, threshold);
    }

    private Float computeAverageValueAboveThreshold(List<WfGridData> filterReads, Float threshold) {
        int aboveThresholdCount = 0;
        Float sumAboveThreshold = 0f;

        for (WfGridData read : filterReads) {
            Float value = new Float(read.getValueNumber());
            if (value.compareTo(threshold) > 0) {
                sumAboveThreshold = sumAboveThreshold + (value);
                aboveThresholdCount++;
            }
        }

        return sumAboveThreshold / (new Float(aboveThresholdCount));
    }

    private Map<Long, Float[][]> fillRoxWellReads(List<WfGridData> roxReads, Long roxThreshold) {
        Map<Long, Float[][]> roxWellReads = new HashMap<Long, Float[][]>();
        for (WfGridData read : roxReads) {
            Float[][] wellReads = roxWellReads.get(read.getAggregateGroupId());
            if (wellReads == null) {
                wellReads = new Float[31][16];
                roxWellReads.put(read.getAggregateGroupId(), wellReads);
            }

            Float roxReadValue = new Float(read.getValueNumber());

            wellReads[read.getGridRow() - 1][read.getGridCol() - 1] =
                    (roxThreshold == null || roxReadValue.doubleValue() > roxThreshold) ?
                            roxReadValue :
                            null;
//                    new Float( read.getValueNumber() );
        }

        return roxWellReads;
    }

    public List<Wf> getAllActivePlates() {
        return wfDao.findAllWfInWfConfig(DPCR_WF_CONFIG_ID, DPCR_PLATE_WF_ENTITY_TYPE_ID);
    }

    public List<Wf> getAllRoxTestPlates() {
        Object[] roxTestPrefixes = {"220814", "260814", "MON87460_SuperSC", "NK603_JohnS"};
        return wfDao.findAllOrdered("WF_ENTITY_LABEL LIKE ? || '%' OR WF_ENTITY_LABEL LIKE ? || '%' OR WF_ENTITY_LABEL LIKE ? || '%'OR WF_ENTITY_LABEL LIKE ? || '%'", "WF_ENTITY_LABEL", roxTestPrefixes);
    }

    public List<WfData> getAllAnalysisRuns() {
        String whereClause = "WF_DATA_CONFIG_ID=?";
        return wfDataDao.findAll(whereClause, DPCR_ANALYSIS_RUN_NAME);
    }

    public AnalysisRun getAnalysisRunInfo(Long analysisRunWfId) {

        List<WfData> wfDataList = wfDataDao.findAll("WF_ID=?", analysisRunWfId);

        AnalysisRun analysisRun = new AnalysisRun();
        List<Object> positiveCountThresholdParams = new ArrayList<Object>();
        for (WfData wfData : wfDataList) {

            if (wfData.getWfDataConfigId() == DPCR_POS_COUNT_THRESHOLD_ALGORITHM_WF_DATA_CONFIG_ID) {
                analysisRun.setPositiveCountThresholdAlgorithm(wfData.getWfDataVarchar2());
            }

            if (wfData.getWfDataConfigId() == DPCR_COPY_ESTIMATE_ALGORITHM_WF_DATA_CONFIG_ID) {
                analysisRun.setCopyEstimateAlgorithm(wfData.getWfDataVarchar2());
            }

            if (wfData.getWfDataConfigId() == DPCR_RATIO_THRESHOLD_ALGORITHM_WF_DATA_CONFIG_ID) {
                analysisRun.setRatioThresholdAlgorithm(wfData.getWfDataVarchar2());
            }

            if (wfData.getWfDataConfigId() == DPCR_ANALYSIS_RUN_NAME) {
                analysisRun.setAnalysisRunLabel(wfData.getWfDataVarchar2());
            }

            if (wfData.getWfDataConfigId() == DPCR_POS_COUNT_THRESHOLD_WF_DATA_CONFIG_ID) {
                positiveCountThresholdParams.add(wfData.getWfDataNumber());
            }

            if (wfData.getWfDataConfigId() == DPCR_RATIO_MULTIPLIERS_WF_DATA_CONFIG_ID) {
                try {
                    String value = new String(wfData.getWfDataBlob(), "UTF-8");
                    analysisRun.setRatioMultipliers(convertToMap(value));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            if (wfData.getWfDataConfigId() == DPCR_RATIO_THRESHOLDS_WF_DATA_CONFIG_ID) {
                try {
                    String value = new String(wfData.getWfDataBlob(), "UTF-8");
                    analysisRun.setFixedRatioThresholds(convertToMap(value));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        analysisRun.setPositiveCountThresholdAlgorithmParameters(positiveCountThresholdParams);

        return analysisRun;
    }

    private List<Object> convertToMap(String value) {

        List<Object> objectList = new ArrayList<Object>();

        List<String> splittedList = Arrays.asList(value.split("\\},\\{"));
        for (String str : splittedList) {
            Map<String, String> map = new HashMap<String, String>();
            String trimmedString = str.replaceAll("\\[|\\]|\"|\\{|\\}", "");
            String[] singleObject = trimmedString.split(",");
            for (int i = 0; i < singleObject.length; i++) {
                map.put(singleObject[i].split(":")[0], singleObject[i].split(":")[1]);
            }
            objectList.add(map);
        }
        return objectList;
    }

    class StoreConstellationResultsFileService extends AbstractWfAsyncProcess implements TransactionCallback<Future<WfAsyncStatus>> {
        private final static long DPCR_WF_CONFIG_ID = 26L;
        private static final long DPCR_WELL_WF_GRID_DATA_TYPE_ID = 7L;

        private final static long DPCR_PLATE_NAME_WF_DATA_CONFIG_ID = 462L;
        private final static long DPCR_REF_FILTER_WF_DATA_CONFIG_ID = 483L;
        private final static long DPCR_FILTER_WF_DATA_CONFIG_ID = 540L;

        private DPcrPlate plate;

        public void setPlate(DPcrPlate plate) {
            this.plate = plate;
        }

        public void handleCancelProcess() {
            // pass, the exception should cause rollback
        }

        public void startProcess() {
            TransactionTemplate tt = new TransactionTemplate();
            tt.setTransactionManager(txManager);
            tt.execute(this);
        }

        @Override
        public Future<WfAsyncStatus> doInTransaction(TransactionStatus transactionStatus) {
            AsyncResult<WfAsyncStatus> asyncResult = new AsyncResult<WfAsyncStatus>(getWfAsyncStatus());
            getWfAsyncStatus().setMaxProgressValue(plate.getWellRowCount() * plate.getWellColumnCount() + 2);
            updateStatus("[" + plate.getPlateImagingId() + "] " + "Saving plate...");

            try {
                // Saving Plate Daata
                dPcrPlateDao.save(plate);
                wfDataDao.save(plate.getWfId(), DPCR_PLATE_NAME_WF_DATA_CONFIG_ID, plate.getWfEntityLabel());
                wfDataDao.save(plate.getWfId(), DPCR_REF_FILTER_WF_DATA_CONFIG_ID, plate.getFilterDataList().get(0).getReferenceFilter());

                //                List<WfStepDataConfig> wfStepDataConfigs = wfStepDataConfigDao.findWfStepDataConfig( DPCR_EXPORT_RESULTS_WF_STEP_CONFIG_ID );

                // Saving the filter names for this plate
                int filterArrayIndex = 1;
                for (FilterData filterData : plate.getFilterDataList()) {
                    wfDataDao.saveArrayData(plate.getWfId(), DPCR_FILTER_WF_DATA_CONFIG_ID, filterData.getFilterPairId(), filterArrayIndex);
                    filterArrayIndex++;
                }

                updateStatus("[" + plate.getPlateImagingId() + "] " + "Saving wells...", true);

                // Setup the well information
                for (WellResult wellResult : plate.getWellResultsList()) {
                    wellResult.setWfId(plate.getWfId());
                    wellResult.setWfGridDataConfigId(DPCR_WELL_WF_GRID_DATA_TYPE_ID);
                    wellResult.setValueVarchar2(createWellLabel(wellResult));
                }

                // Save all wells at one time
                wellResultDao.batchSave(plate.getWellResultsList());

                // Creating a map of the data type to it's id, this is used to related the filter name to it's associated id
                List<WfGridDataType> gridDataTypeList = wfGridDataTypeDao.findAll("wf_config_id=? AND enabled='Y'", DPCR_WF_CONFIG_ID);
                Map<String, Long> gridDataTypeMap = new HashMap<String, Long>();
                for (WfGridDataType gridDataType : gridDataTypeList) {
                    gridDataTypeMap.put(gridDataType.getWfGridDataType(), gridDataType.getWfGridDataTypeId());
                }

                for (WellResult wellResult : plate.getWellResultsList()) {
                    updateStatus("[" + plate.getPlateImagingId() + "] " + "Saving partitions for well: " + wellResult.getValueVarchar2(), true);

                    List<PartitionResult> allPartitionResults = wellResult.getAllPartitionResultsList();
                    for (PartitionResult partitionResult : allPartitionResults) {
                        partitionResult.setWfId(plate.getWfId());
                        partitionResult.setWfGridDataConfigId(gridDataTypeMap.get(partitionResult.getFilterName() + " (Raw)"));
                        //partitionResult.setAggregateGroupId(wellResult.getWfGridDataId());
                    }

                    partitionResultDao.batchSave(allPartitionResults);
                }

                updateStatus("Uploading results for " + plate.getPlateImagingId() + " complete!", getWfAsyncStatus().getMaxProgressValue(), true);
            } catch (Throwable t) {
                updateStatus("EXCEPTION: " + t.getMessage());

                WfAsyncStatus status = new WfAsyncStatus();
                status.setMessage("EXCEPTION: " + t.getMessage());
                return new AsyncResult<WfAsyncStatus>(status);
            }
            return asyncResult;
        }
    }

    private class WellOutputResult {
        private String wellLabel;
        private TreeMap<String, IncrementableInt> partitionsIntensityAboveThresholdCount =
                new TreeMap<String, IncrementableInt>();
        private TreeMap<String, Float> filterValueEstimates;
        private Float ratio;

        public void incrementFilterCount(String filterName) {
            IncrementableInt count = partitionsIntensityAboveThresholdCount.get(filterName);
            if (count == null) {
                count = new IncrementableInt();
                partitionsIntensityAboveThresholdCount.put(filterName, count);
            }
            count.increment();
        }

        public void setFilterValueEstimate(String filterName, Float value) {
            filterValueEstimates.put(filterName, value);
        }

        public Float getFilterValueEstimate(String filterName) {
            return filterValueEstimates.get(filterName);
        }

        public int getFilterCount(String filterName) {
            IncrementableInt count = partitionsIntensityAboveThresholdCount.get(filterName);
            if (count == null) {
                count = new IncrementableInt();
                partitionsIntensityAboveThresholdCount.put(filterName, count);
            }
            return count.getValue();
        }

        public String getWellLabel() {
            return wellLabel;
        }

        public void setWellLabel(String wellLabel) {
            this.wellLabel = wellLabel;
        }

        public TreeMap<String, Float> getFilterValueEstimates() {
            return filterValueEstimates;
        }

        public void setFilterValueEstimates(TreeMap<String, Float> filterValueEstimates) {
            this.filterValueEstimates = filterValueEstimates;
        }

        public Float getRatio() {
            return ratio;
        }

        public void setRatio(Float ratio) {
            this.ratio = ratio;
        }

        private class IncrementableInt {
            private int value = 0;

            public void increment() {
                value++;
            }

            public int getValue() {
                return value;
            }
        }
    }

    private class WellEstimateOutput {
        Map<Long, Integer> positiveCounts = new HashMap<Long, Integer>();
        Map<Long, String> estimateValues = new HashMap<Long, String>();
    }

    class PositiveWellCount {
        Long aggregateGroupId;
        int positiveCount;
    }

    class FilterValues {
        int[] histogram;
        Long threshold;
        Map<Long, Float[][]> wellToPartitionValueMap;
    }
}