package com.monsanto.gwg.atlas.json.core;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */
public class JsonReagent {
  private long reagentId;
    private String reagentName;
    private String lotNumber;
    private long cost;
    private long workflowStepConfigId;
    private String task;
    private String userId;

    public long getWorkflowStepConfigId() {
      return workflowStepConfigId;
    }

    public void setWorkflowStepConfigId(long workflowStepConfigId) {
      this.workflowStepConfigId = workflowStepConfigId;
    }

    public long getReagentId() {
      return reagentId;
    }

    public void setReagentId(long reagentId) {
      this.reagentId = reagentId;
    }

    public String getReagentName() {
      return reagentName;
    }

    public void setReagentName(String reagentName) {
      this.reagentName = reagentName;
    }

    public String getLotNumber() {
      return lotNumber;
    }

    public void setLotNumber(String lotNumber) {
      this.lotNumber = lotNumber;
    }

    public long getCost() {
      return cost;
    }

    public void setCost(long cost) {
      this.cost = cost;
    }

    public String getTask() {
      return task;
    }

    public void setTask(String task) {
      this.task = task;
    }

    public String getUserId() {
      return userId;
    }

    public void setUserId(String userId) {
      this.userId = userId;
    }
  }