package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

public class WfGridDataType {
    @DbColumn(field="wf_grid_data_config_id")
  private Long wfGridDataTypeId;
    @DbColumn(field="wf_grid_data_type")
  private String wfGridDataType;
    @DbColumn(field="wf_config_id")
  private Long wfConfigId;
    @DbColumn(field="data_type")
  private String dataType;
    @DbColumn(field="sort_key")
  private Integer sortKey;
    @DbColumn(field="number_format")
  private String numberFormat;
    @DbColumn(field="timestamp_format")
  private String timestampFormat;
    @DbColumn(field="icon_png")
  private String iconPng;
    @DbColumn(field="enabled")
  private boolean enabled;

  public Long getWfGridDataTypeId() {
    return wfGridDataTypeId;
  }

  public void setWfGridDataTypeId(Long wfGridDataTypeId) {
    this.wfGridDataTypeId = wfGridDataTypeId;
  }

  public String getWfGridDataType() {
    return wfGridDataType;
  }

  public void setWfGridDataType(String wfGridDataType) {
    this.wfGridDataType = wfGridDataType;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getDataType() {
    return dataType;
  }

  public void setDataType(String dataType) {
    this.dataType = dataType;
  }

  public Integer getSortKey() {
    return sortKey;
  }

  public void setSortKey(Integer sortKey) {
    this.sortKey = sortKey;
  }

  public String getNumberFormat() {
    return numberFormat;
  }

  public void setNumberFormat(String numberFormat) {
    this.numberFormat = numberFormat;
  }

  public String getTimestampFormat() {
    return timestampFormat;
  }

  public void setTimestampFormat(String timestampFormat) {
    this.timestampFormat = timestampFormat;
  }

  public String getIconPng() {
    return iconPng;
  }

  public void setIconPng(String iconPng) {
    this.iconPng = iconPng;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }
}
