package com.monsanto.gwg.atlas.dao;

import org.springframework.jdbc.core.RowMapper;

/**
 * Created by pgros1 on 7/21/14.
 */
public class DaoUtils {
    private static final String TRUE_STRING = "Y";
    private static final String FALSE_STRING = "N";

    public static boolean getBooleanFromString( String value ) {
        return TRUE_STRING.equals( value );
    }

    public static String getStringFromBoolean( boolean value ) {
        return value ? TRUE_STRING : FALSE_STRING;
    }

    public static boolean isBooleanType( Class type ) {
        return type.isAssignableFrom( Boolean.class ) || type.equals( boolean.class );
    }
}
