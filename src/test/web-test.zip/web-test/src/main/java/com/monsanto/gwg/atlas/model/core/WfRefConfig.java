package com.monsanto.gwg.atlas.model.core;

import java.math.BigDecimal;
import java.sql.Timestamp;
import com.monsanto.gwg.atlas.model.annotations.DbColumn;

public class WfRefConfig {
  @DbColumn(field="wf_ref_config_id")
  private Long wfRefConfigId;
  @DbColumn(field="wf_config_id")
  private Long wfConfigId;
  @DbColumn(field="wf_ref_config_parent_id")
  private Long wfRefConfigParentId;
  @DbColumn(field="wf_ref_key")
  private String wfRefKey;
  @DbColumn(field="wf_ref_varchar2")
  private String wfRefVarchar2;
  @DbColumn(field="wf_ref_number")
  private BigDecimal wfRefNumber;
  @DbColumn(field="wf_ref_timestamp")
  private Timestamp wfRefTimestamp;
  @DbColumn(field="wf_ref_active")
  private String wfRefActive;
  @DbColumn(field="wf_ref_ui_sort_key")
  private Integer wfRefUiSortKey;
  @DbColumn(field="comments")
  private String comments;
  @DbColumn(field="create_user")
  private String createUser;
  @DbColumn(field="create_ts")
  private Timestamp createTs;

  public Long getWfRefConfigId() {
    return wfRefConfigId;
  }

  public void setWfRefConfigId(Long wfRefConfigId) {
    this.wfRefConfigId = wfRefConfigId;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public Long getWfRefConfigParentId() {
    return wfRefConfigParentId;
  }

  public void setWfRefConfigParentId(Long wfRefConfigParentId) {
    this.wfRefConfigParentId = wfRefConfigParentId;
  }

  public String getWfRefKey() {
    return wfRefKey;
  }

  public void setWfRefKey(String wfRefKey) {
    this.wfRefKey = wfRefKey;
  }

  public String getWfRefVarchar2() {
    return wfRefVarchar2;
  }

  public void setWfRefVarchar2(String wfRefVarchar2) {
    this.wfRefVarchar2 = wfRefVarchar2;
  }

  public BigDecimal getWfRefNumber() {
    return wfRefNumber;
  }

  public void setWfRefNumber(BigDecimal wfRefNumber) {
    this.wfRefNumber = wfRefNumber;
  }

  public Timestamp getWfRefTimestamp() {
    return wfRefTimestamp;
  }

  public void setWfRefTimestamp(Timestamp wfRefTimestamp) {
    this.wfRefTimestamp = wfRefTimestamp;
  }

  public String getWfRefActive() {
    return wfRefActive;
  }

  public void setWfRefActive(String wfRefActive) {
    this.wfRefActive = wfRefActive;
  }

  public Integer getWfRefUiSortKey() {
    return wfRefUiSortKey;
  }

  public void setWfRefUiSortKey(Integer wfRefUiSortKey) {
    this.wfRefUiSortKey = wfRefUiSortKey;
  }

  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }
}
