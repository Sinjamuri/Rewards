package com.monsanto.gwg.atlas.model.gbs;

import java.io.Serializable;
import java.util.Date;

public class MarkerAnalysis implements Serializable {
  private Long torrentAnalysisId;
  private Integer importFileLineNumber;
  private String limsId;
  private Integer sampleId;
  private String markerId;
  private Integer barcodeAdapter;
  private String call;
  private Double qualityScore;
  private Double totalCoverage;
  private Double percentCoverage;
  private Date createTs;
  private String control;
  private String blockBarcodeNbr;
  private Long wfId;
  private Long barcodeIndexPlate;
  private String projectInclude;
  private String uploadInclude;

  public Long getTorrentAnalysisId() {
    return torrentAnalysisId;
  }

  public void setTorrentAnalysisId(Long torrentAnalysisId) {
    this.torrentAnalysisId = torrentAnalysisId;
  }

  public Integer getImportFileLineNumber() {
    return importFileLineNumber;
  }

  public void setImportFileLineNumber(Integer importFileLineNumber) {
    this.importFileLineNumber = importFileLineNumber;
  }

  public String getLimsId() {
    return limsId;
  }

  public void setLimsId(String limsId) {
    this.limsId = limsId;
  }

  public Integer getSampleId() {
    return sampleId;
  }

  public void setSampleId(Integer sampleId) {
    this.sampleId = sampleId;
  }

  public String getMarkerId() {
    return markerId;
  }

  public void setMarkerId(String markerId) {
    this.markerId = markerId;
  }

  public Integer getBarcodeAdapter() {
    return barcodeAdapter;
  }

  public void setBarcodeAdapter(Integer barcodeAdapter) {
    this.barcodeAdapter = barcodeAdapter;
  }

  public String getCall() {
    return call;
  }

  public void setCall(String call) {
    this.call = call;
  }

  public Double getQualityScore() {
    return qualityScore;
  }

  public void setQualityScore(Double qualityScore) {
    this.qualityScore = qualityScore;
  }

  public Double getTotalCoverage() {
    return totalCoverage;
  }

  public void setTotalCoverage(Double totalCoverage) {
    this.totalCoverage = totalCoverage;
  }

  public Double getPercentCoverage() {
    return percentCoverage;
  }

  public void setPercentCoverage(Double percentCoverage) {
    this.percentCoverage = percentCoverage;
  }

  public Date getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Date createTs) {
    this.createTs = createTs;
  }

  public String getControl() {
    return control;
  }

  public void setControl(String control) {
    this.control = control;
  }

  public String getBlockBarcodeNbr() {
    return blockBarcodeNbr;
  }

  public void setBlockBarcodeNbr(String blockBarcodeNbr) {
    this.blockBarcodeNbr = blockBarcodeNbr;
  }

  public Long getWfId() {
    return wfId;
  }

  public void setWfId(Long wfId) {
    this.wfId = wfId;
  }

  public Long getBarcodeIndexPlate() {
    return barcodeIndexPlate;
  }

  public void setBarcodeIndexPlate(Long barcodeIndexPlate) {
    this.barcodeIndexPlate = barcodeIndexPlate;
  }

  public String getProjectInclude() {
    return projectInclude;
  }

  public void setProjectInclude(String projectInclude) {
    this.projectInclude = projectInclude;
  }

  public String getUploadInclude() {
    return uploadInclude;
  }

  public void setUploadInclude(String uploadInclude) {
    this.uploadInclude = uploadInclude;
  }
}
