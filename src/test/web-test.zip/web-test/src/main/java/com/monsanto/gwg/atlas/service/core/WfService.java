package com.monsanto.gwg.atlas.service.core;

import com.monsanto.gwg.atlas.agent.common.model.Sample;
import com.monsanto.gwg.atlas.bean.WorkflowReagent;
import com.monsanto.gwg.atlas.bean.core.WfGridDataBean;
import com.monsanto.gwg.atlas.bean.core.WfGridDataTypeBean;
import com.monsanto.gwg.atlas.bean.core.WfGridDataTypeBeanDimensioned;
import com.monsanto.gwg.atlas.dao.ReagentDao;
import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.json.core.JsonGridAssocData;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.json.labelprinting.JsonPrintRequest;
import com.monsanto.gwg.atlas.json.labelprinting.JsonPrintResponse;
import com.monsanto.gwg.atlas.model.core.*;
import com.monsanto.gwg.atlas.service.UtilService;
import com.monsanto.gwg.atlas.service.printer.LabelPrinterJob;
import com.monsanto.gwg.atlas.service.stltaqmanService.StltaqmanConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class WfService {

  private static final Logger LOG = LoggerFactory.getLogger(WfService.class);
  public final int GRAPH_ASSOC_LEFT = 0;
  public final int GRAPH_ASSOC_RIGHT = 1;
  @Autowired
  private WfConfigDao wfConfigDao;

  @Autowired
  private WfDao wfDao;

  @Autowired
  private WfEntityTypeDao wfEntityTypeDao;

  @Autowired
  private WfStepDataConfigVwDao wfStepDataConfigVwDao;

  @Autowired
  private WfRefConfigDao wfRefConfigDao;

  @Autowired
  private WfStepDao wfStepDao;

  @Autowired
  private WfDataDao wfDataDao;

  @Autowired
  private WfPrinterDao wfPrinterDao;

  @Autowired
  private WfDataConfigDao wfDataConfigDao;

  @Autowired
  private WfStepConfigDao wfStepConfigDao;

  @Autowired
  private WfMenuConfigDao wfMenuConfigDao;

  @Autowired
  private UtilService utilService;

  @Autowired
  private WfDetailDao wfDetailDao;

  @Autowired
  private ReagentDao reagentDao;

  @Autowired
  private WfGridDataTypeDao wfGridDataTypeDao;

  @Autowired
  private WfGridDataDao wfGridDataDao;

  @Autowired
  private WfGridDao wfGridDao;

  @Autowired
  private WfNcrConfigDao wfNcrConfigDao;

  @Autowired
  private WfStepAssocVwDao wfStepAssocVwDao;

  @Autowired
  private WfDataConfigTypeDao wfDataConfigTypeDao;

  @Autowired
  private WfRefParentVwDao wfRefParentVwDao;

  @Autowired
  private JdbcTemplate jdbcTemplate;

  @Autowired
  private WfSearchDao wfSearchDao;

  @Autowired
  private WfAssocDao wfAssocDao;

  @Autowired
  private WfAgentDao wfAgentDao;

  @Autowired
  private WfStepAssocDao wfStepAssocDao;

  @Autowired
  private WfGridAssocDao wfGridAssocDao;

  @Autowired
  private WfGridAssocVwDao wfGridAssocVwDao;

  @Autowired
  private WfConfigPropertyDao wfConfigPropertyDao;

  @Autowired
  private WriteWfExcel writeWfExcel;

  @Autowired
  private DataSourceTransactionManager txManager;
  @Autowired
  private LabelPrinterJob labelPrinterJob;
  @Autowired
  private WfPrintQueueDao wfprintqueuedao;

  public WfConfig findWfConfig(Long wfConfigId) {
    return wfConfigDao.find(wfConfigId);
  }

  public WfConfig findWfConfig(String wfConfig) {
    return wfConfigDao.findWfConfigId(wfConfig);
  }

  public List<WfConfig> findAllWfConfig() {
    return wfConfigDao.findActiveWfConfigs();
  }

  public List<WfDataConfigType> findAllWfDataConfigType() {
    return wfDataConfigTypeDao.findAll();
  }

  public List<WfDataConfig> findWfDataConfig(Long wfConfigId) {
    return wfDataConfigDao.findWfConfigId(wfConfigId);
  }

  public List<WfStepConfig> findAllWfStepConfig(String wfConfigDomain) {
    return wfStepConfigDao.findAllWfStepConfig(wfConfigDomain);
  }

  public List<WfStepConfig> findAllWfStepConfig(Long wfConfigId) {
    return wfStepConfigDao.findAllWfStepConfig(wfConfigId);
  }

  public WfStepConfig findWfStepConfig(Long wfStepConfigId) {
    return wfStepConfigDao.find(wfStepConfigId);
  }

  public List<WfStepDataConfigVw> filterStepDataConfigs(List<WfStepDataConfigVw> wfStepDataConfigList) {
    //filter what data fields will be collected at this step
    List<WfStepDataConfigVw> results = new ArrayList<WfStepDataConfigVw>();
    for (WfStepDataConfigVw wfStepDataConfig : wfStepDataConfigList) {
      if (!(wfStepDataConfig.isDisplayOnly())) {
        results.add(wfStepDataConfig);
      }
    }
    return results;
  }

  public List<Wf> findAllWf(WfStepConfig wfStepConfig, List<WfStepDataConfigVw> wfStepDataConfigList) {
    //load the list of workflows for this step
    List<Wf> wfList = wfDao.findAllWf(wfStepConfig.getWfStepConfigId());
    return appendWfDataConfigsForWf(wfList, wfStepDataConfigList);

/*    //extract what data elements to query
    Set<Long> wfDataConfigIdSet = new LinkedHashSet<Long>();
    Long scanLineKeyDataConfigId = null;
    Long scanLineSetIndexDataConfigId = null;
    for (WfStepDataConfigVw wfStepDataConfig: wfStepDataConfigList) {
      wfDataConfigIdSet.add(wfStepDataConfig.getWfDataConfigId());

      //capture which data config drives barcode scanning
      if (wfStepDataConfig.isScanLineKey()) {
        scanLineKeyDataConfigId = wfStepDataConfig.getWfDataConfigId();
        if (wfStepDataConfig.getWfDataConfigIdGroup()!=null) {
          scanLineSetIndexDataConfigId = wfStepDataConfig.getWfDataConfigIdGroup();
        }
      }
    }

    //load only necessary data
    loadWfData(wfList, wfDataConfigIdSet);

    //iterate workflows and assign a single scan line key and set group index if defined
    if (scanLineKeyDataConfigId!=null) {
      for (Wf wf:wfList) {
          List<WfData> wfDataList =  wf.getWfDataMap().get(scanLineKeyDataConfigId);
          if( wfDataList == null ) {
              wf.setScanLineKey( "NO_KEY_VALUE_" + String.valueOf(wf.getWfId()));
          } else {
            WfData wfDataScanLineKey = wfDataList.get(0);
              if (wfDataScanLineKey.getWfDataNumber()!=null) {
                  //numeric scan line keys are fine but still must be compared as strings
                  //this is because barcode scanning compares characters and doesn't care
                  //if the characters are numeric or not
                  wf.setScanLineKey(wfDataScanLineKey.getWfDataNumber().toString());
              } else {
                  wf.setScanLineKey(wfDataScanLineKey.getWfDataVarchar2().replace(" ", "_"));
              }
          }

        //assign scan line set index to enforce scanned groups to be passed together
        if (scanLineSetIndexDataConfigId!=null) {
          WfData wfDataScanLineSetIndex = wf.getWfDataMap().get(scanLineSetIndexDataConfigId).get(0);
          if (wfDataScanLineSetIndex.getWfDataNumber()!=null) {
            //numeric group key is fine but still must be compared as strings in javascript
            wf.setScanLineSetIndex(wfDataScanLineSetIndex.getWfDataNumber().toString());
          } else {
            wf.setScanLineSetIndex(wfDataScanLineSetIndex.getWfDataVarchar2());
          }
        } else {
          //default set index to workflow id if there is no group constraint defined
          wf.setScanLineSetIndex(String.valueOf(wf.getWfId()));
        }
      }
    }

    return wfList;
    */
  }

  protected List<Wf> appendWfDataConfigsForWf(List<Wf> wfList, List<WfStepDataConfigVw> wfStepDataConfigList) {
    //extract what data elements to query
    Set<Long> wfDataConfigIdSet = new LinkedHashSet<Long>();
    Long scanLineKeyDataConfigId = null;
    Long scanLineSetIndexDataConfigId = null;
    for (WfStepDataConfigVw wfStepDataConfig : wfStepDataConfigList) {
      wfDataConfigIdSet.add(wfStepDataConfig.getWfDataConfigId());

      //capture which data config drives barcode scanning
      if (wfStepDataConfig.isScanLineKey()) {
        scanLineKeyDataConfigId = wfStepDataConfig.getWfDataConfigId();
        if (wfStepDataConfig.getWfDataConfigIdGroup() != null) {
          scanLineSetIndexDataConfigId = wfStepDataConfig.getWfDataConfigIdGroup();
        }
      }
    }

    //load only necessary data
    loadWfData(wfList, wfDataConfigIdSet);

    //iterate workflows and assign a single scan line key and set group index if defined
    if (scanLineKeyDataConfigId != null) {
      for (Wf wf : wfList) {
        wf.setNote(getNotes(wf.getWfId()));
        Timestamp maxWfTs = wfStepDao.getMaxWfStepTimestamp(wf.getWfId(), wf.getWfStepConfigId());
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
        wf.setMaxWfStepTimestamp(sdf.format(maxWfTs));
        //Get Due Date for Taqman Plates. wf_data_config_id = 3010
        WfData wfData = wfDataDao.getValue(3010L,wf.getWfId());
        if(wfData != null){
            wf.setDueDateTimestamp(wfData.getWfDataTimestamp());
        }
        List<WfData> wfDataList = wf.getWfDataMap().get(scanLineKeyDataConfigId);
        if (wfDataList == null) {
          wf.setScanLineKey("NO_KEY_VALUE_" + String.valueOf(wf.getWfId()));
        } else {
          WfData wfDataScanLineKey = wfDataList.get(0);
          if (wfDataScanLineKey.getWfDataNumber() != null) {
            //numeric scan line keys are fine but still must be compared as strings
            //this is because barcode scanning compares characters and doesn't care
            //if the characters are numeric or not
            wf.setScanLineKey(wfDataScanLineKey.getWfDataNumber().toString());
          } else {
            wf.setScanLineKey(wfDataScanLineKey.getWfDataVarchar2().replace(" ", "_"));
          }
        }

        //assign scan line set index to enforce scanned groups to be passed together
        if (scanLineSetIndexDataConfigId != null) {
          WfData wfDataScanLineSetIndex = wf.getWfDataMap().get(scanLineSetIndexDataConfigId).get(0);
          if (wfDataScanLineSetIndex.getWfDataNumber() != null) {
            //numeric group key is fine but still must be compared as strings in javascript
            wf.setScanLineSetIndex(wfDataScanLineSetIndex.getWfDataNumber().toString());
          } else {
            wf.setScanLineSetIndex(wfDataScanLineSetIndex.getWfDataVarchar2());
          }
        } else {
          //default set index to workflow id if there is no group constraint defined
          wf.setScanLineSetIndex(String.valueOf(wf.getWfId()));
        }
      }
    }

    return wfList;
  }

  //pull all workflow data in one fetch and then map to appropriate workflow
  public void loadWfData(List<Wf> wfList, Set<Long> wfDataConfigIdSet) {

    //check for empty parameters
    if (wfList.size() == 0 || wfDataConfigIdSet.size() == 0) {
      return;
    }

    //collect all ids for a single optimized fetch
    Set<Long> wfIdSet = new HashSet<Long>();
    for (Wf wf : wfList) {
      wfIdSet.add(wf.getWfId());
    }

    //fetch and assign to associated workflows
    Map<Long, List<WfData>> wfDataFetchMap = wfDataDao.find(wfIdSet, wfDataConfigIdSet);
    for (Wf wf : wfList) {
      List<WfData> wfDataFetchList = wfDataFetchMap.get(wf.getWfId());
      if (wfDataFetchList != null) {
        for (WfData wfData : wfDataFetchList) {
          List<WfData> wfDataList = wf.getWfDataMap().get(wfData.getWfDataConfigId());
          if (wfDataList == null) {
            wfDataList = new ArrayList<WfData>();
          }
          wfDataList.add(wfData);
          wf.getWfDataMap().put(wfData.getWfDataConfigId(), wfDataList);
        }
      }
    }
  }

  public List<WfStepDataConfigVw> findWfStepDataConfig(Long wfStepConfigId) {
    return wfStepDataConfigVwDao.findWfStepDataConfig(wfStepConfigId);
  }

  public boolean isUserAllowed(String userId, Long wfStepConfigId, String wfConfigDomain) {
    //first check step configuration
    WfStepConfig wfStepConfig = wfStepConfigDao.find(wfStepConfigId);
    boolean isUserBlockedForWorkflow = utilService.isUserBlockedForWorkflow(userId, wfConfigDomain);
    if (isUserBlockedForWorkflow || wfStepConfigId == null) {
      //if the step config id is invalid, do not allow
      return false;
    } else {
      if (wfStepConfig.getWfStepPrivileges().isEmpty()) {
        //if no restrictions are defined for the step, allow
        return true;
      } else {
        //check step level privileges
        if (wfStepConfig.getWfStepPrivileges().contains(userId.trim().toUpperCase())) {
          return true;
        } else {
          //check to see if user is a workflow domain administrator
          WfConfig wfConfig = wfConfigDao.find(wfStepConfig.getWfConfigId());
          if (wfConfig.getWfConfigAdmins().contains(userId.trim().toUpperCase())) {
            return true;
          }
        }
        return false;
      }
    }
  }

  public JsonResponse passAllWf(JsonPost jsonPost, Long wfStepConfigId) {
    JsonResponse jsonResponse = new JsonResponse();

    List<Map<String, String>> rows = jsonPost.getRows();
    for (Map<String, String> row : rows) {
      try {
        passSingleWf(Long.parseLong(row.get("wfId")), jsonPost.getUserId(), wfStepConfigId);
      } catch (Exception ex) {
        jsonResponse.addError(utilService.getStackTrace(ex));
      }
    }

    return jsonResponse;
  }

  public void passSingleWf(Long wfId, String userId, Long wfStepConfigId) {
    //when the step config id to pass to is null, look up the default in the step configuration
    if (wfStepConfigId == null) {
      Wf wf = wfDao.find(wfId);

      WfStepAssoc wfStepAssoc = wfStepAssocDao.findDefaultNextStep(wf.getWfStepConfigId());
      wfStepConfigId = wfStepAssoc.getNextWfStepConfigId();

      if (wfStepConfigId == null) {
        LOG.error("No default NEXT_WF_STEP_CONFIG_ID exists for WF_STEP_ASSOC.WF_STEP_CONFIG_ID=" + wfStepConfigId);
        return;
      }
    }

    //wfStepDao.pass(wfStepConfigId, wfId, userId);
    wfDao.updateWfStatus( wfId,"C",userId);
    wfDao.UpdateWfStepConfig( wfId,wfStepConfigId,userId);

  }

  public JsonResponse holdAllWf(JsonPost jsonPost, Long wfStepConfigId) {
    JsonResponse jsonResponse = new JsonResponse();

    List<Map<String, String>> rows = jsonPost.getRows();
    for (Map<String, String> row : rows) {
      try {
        //passSingleWf(Long.parseLong(row.get("wfId")), jsonPost.getUserId(), wfStepConfigId);
        long wfId =  Long.parseLong(row.get("wfId"));
        //wfStepDao.holdStep(wfStepConfigId,wfId, jsonPost.getUserId());
        wfDao.updateWfStatus(wfId, "H",jsonPost.getUserId());
      } catch (Exception ex) {
        jsonResponse.addError(utilService.getStackTrace(ex));
      }
    }

    return jsonResponse;
  }


  public void savePostData(JsonPost jsonPost) {
    //extract and map all data types for efficiency
    Set<Long> wfdcIdSet = new HashSet<Long>();
    for (Map<String, String> postData : jsonPost.getRows()) {
      for (String key : postData.keySet()) {
        if (key.startsWith("wfdc")) {
          wfdcIdSet.add(Long.parseLong(key.substring(4)));
        }
      }
    }

    List<WfDataConfig> wfDataConfigs = wfDataConfigDao.get(wfdcIdSet);
    Map<Long, WfDataConfig> wfDataConfigMap = new HashMap<Long, WfDataConfig>();
    for (WfDataConfig wfDataConfig : wfDataConfigs) {
      wfDataConfigMap.put(wfDataConfig.getWfDataConfigId(), wfDataConfig);
    }

    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

      //loop through entries for wfdcId fields
      for (String key : postData.keySet()) {
        if (key.startsWith("wfdc")) {
          Long wfDataConfigId = Long.parseLong(key.substring(4));
          WfDataConfig wfDataConfig = wfDataConfigMap.get(wfDataConfigId);
          if ("NUMBER".equals(wfDataConfig.getWfDataConfigType())) {
            wfDataDao.save(wfId, wfDataConfigId, new BigDecimal(postData.get(key)));
          } else if ("VARCHAR2".equals(wfDataConfig.getWfDataConfigType())) {
            wfDataDao.save(wfId, wfDataConfigId, postData.get(key));
          } else if ("TIMESTAMP".equals(wfDataConfig.getWfDataConfigType())) {
            //@todo
          }
        }
      }
    }
  }

  public String getWfEntityLabel(Long wfId) {
    Wf wf = wfDao.find(wfId);
    WfEntityType wfEntityType = wfEntityTypeDao.find(wf.getWfEntityTypeId());

    return wfEntityType.getWfEntityType() + ": " + wf.getWfEntityLabel();
  }

  public Wf getWfInfo(Long wfId) {
    Wf wf = wfDao.find(wfId);
    return wf;
  }

  public String getWfDetails(long wfId) {
    StringBuilder sb = new StringBuilder();

    sb.append("<div id=\"dc-tab\" class=\"tab-content\" style=\"margin:10px 0;\">");
    buildWfDetail(sb, wfDetailDao.find(wfId), null, "Container Data");
    sb.append("</div>");

    sb.append("<div id=\"wf-chain-tab\" class=\"tab-content\" style=\"margin:10px 0;\">");
    buildWfRelationships(sb, wfAssocDao.getWfRelationships(wfId), null);
    sb.append("</div>");

    sb.append("<div id=\"history-tab\" class=\"tab-content\" style=\"margin:7px 0;\">");
    sb.append("<table id=\"workflowhistory\" class=\"table table-striped table-condensed table-bordered\">");
    sb.append("<tr><th>Action</th><th>Step Name</th><th>By</th><th>On</th></tr>");

    Map<Long, WfStepConfig> wfStepConfigMap = wfStepConfigDao.getMap();
    List<WfStep> wfSteps = wfStepDao.getWfStepDetail(wfId);
    for (WfStep wfStep : wfSteps) {
      //pull configuration from cache
      WfStepConfig wfStepConfig = wfStepConfigMap.get(wfStep.getWfStepConfigId());

      String wfStepName = wfStepConfig.getWfStepName();
      Integer wfStepNumber = wfStepConfig.getWfStepNumber();

      sb.append("<tr><td>");

      if (wfStep.getActionFlg().equals("I")) {
        sb.append("Initialized Step ").append(wfStepNumber);
      } else if (wfStep.getActionFlg().equals("C")) {
        sb.append("Completed Step ").append(wfStepNumber);
      } else if (wfStep.getActionFlg().equals("R")) {
        sb.append("Rollback To Step ").append(wfStepNumber);
      }
      sb.append("</td>");

      sb.append("<td>").append(wfStepName).append("</td>");
      sb.append("<td>").append(wfStep.getCreateUser()).append("</td>");
      sb.append("<td>").append(utilService.formatDateTimeAmPm(wfStep.getCreateTs())).append("</td>");
      sb.append("</tr>");
    }
    sb.append("</table>");
    sb.append("</div>");

    return sb.toString();
  }

  private void buildWfDetail(
      StringBuilder sb,
      Map<Long, WfDetail> wfDetailMap,
      Long wfDataAssocId,
      String parentLabel) {

    sb.append("<table id=\"workflowdetail\" class=\"table table-striped table-condensed ");
    if (wfDataAssocId == null) {
      sb.append("table-bordered");
    }
    sb.append("\"><tr><th>");

    sb.append(parentLabel).append("</th><th>Value</th></td>");

    for (Long wfDataId : wfDetailMap.keySet()) {
      WfDetail wfDetail = wfDetailMap.get(wfDataId);

      if ((wfDataAssocId == null && wfDetail.getWfDataAssocId() == null) ||
              (wfDataAssocId != null && wfDataAssocId.equals(wfDetail.getWfDataAssocId()))) {

        //check for children records
        boolean hasChildren = false;
        for (WfDetail wfDetailCheck : wfDetailMap.values()) {
          if (wfDetail.getWfDataId().equals(wfDetailCheck.getWfDataAssocId())) {
            hasChildren = true;
            break;
          }
        }

        appendWfDetailValue(sb, wfDetail);

        if (hasChildren) {
          sb.append("<tr><th></th><td></td><td style=\"padding:0 !important;\">");
          buildWfDetail(sb, wfDetailMap, wfDetail.getWfDataId(), "Associated Data");
          sb.append("</td></tr>");
        }
      }
    }

    sb.append("</table>");
  }

  private void buildWfRelationships(
          StringBuilder sb,
          List<WfAssoc> wfAssocList,
          Long wfDataAssocId) {

    sb.append("<table id=\"workflowchain\" class=\"table table-striped table-condensed ");
    if (wfDataAssocId == null) {
      sb.append("table-bordered");
    }
    sb.append("\"><tr><th>");

    sb.append("<tr><th>From</th><th>To</th></tr>");

    for (WfAssoc wfAssoc : wfAssocList) {
      sb.append("<tr>");
      sb.append("<td style=\"padding:0 !important;\">");

      if (!(wfAssoc.isActive())) {
        sb.append("<del>");
      }
      sb.append("<a target=\"_blank\" href=\"../wfDetail/?wfId=").append(wfAssoc.getFromWfId()).append("\">").append(wfAssoc.getFromWfLabel()).append("</a>");
      if (!(wfAssoc.isActive())) {
        sb.append("</del>");
      }

      sb.append("</td>");

      sb.append("<td style=\"padding:0 !important;\">");

      if (!(wfAssoc.isActive())) {
        sb.append("<del>");
      }
      sb.append("<a target=\"_blank\" href=\"../wfDetail/?wfId=").append(wfAssoc.getToWfId()).append("\">").append(wfAssoc.getToWfLabel()).append("</a>");
      if (!(wfAssoc.isActive())) {
        sb.append("</del>");
      }

      sb.append("</td>");
      sb.append("</tr>");

    }

    sb.append("</table>");
  }

  private void appendWfDetailValue(StringBuilder sb, WfDetail wfDetail) {

    sb.append("<tr>")
            .append("<td>")
            .append(wfDetail.getWfDataConfigLabel()).append("</td>")
            .append("<td><div style=\"max-width:600px;overflow:auto;\">");

    if ("VARCHAR2".equals(wfDetail.getWfDataType())) {
      sb.append(wfDetail.getWfDataVarchar2());
    } else if ("NUMBER".equals(wfDetail.getWfDataType())) {
      if (wfDetail.getWfDataNumber() != null) {
        sb.append(wfDetail.getWfDataNumber());
      }
    } else if ("TIMESTAMP".equals(wfDetail.getWfDataType())) {
      if (wfDetail.getWfDataTimestamp() != null) {
        sb.append(utilService.formatDateTimeAmPm(wfDetail.getWfDataTimestamp()));
      }
    } else if ("BLOB".equals(wfDetail.getWfDataType())) {
      if (wfDetail.getWfDataConfigId().equals(58L)) {
        //report.pdf
        WfData wfData = wfDataDao.getValue(51L, wfDetail.getWfId());
        if (wfData != null) {
          sb.append("<a target='_blank' href='../workflowDocument/?id=" + wfDetail.getWfDataId() +
                  "&mt=application/pdf&name=report.pdf&title=Chip%20Summary%20PDF%20-%20" +
                  wfData.getWfDataVarchar2() + "'>View</a>");
        }
      } else if (wfDetail.getWfDataConfigId().equals(59L)) {
        //basecaller.log
        WfData wfData = wfDataDao.getValue(51L, wfDetail.getWfId());
        if (wfDetail != null) {
          sb.append("<a target='_blank' href='../workflowDocument/?id=" + wfDetail.getWfDataId() +
                  "&mt=text/plain&name=basecaller.log&title=basecaller.log%20-%20" +
                  wfData.getWfDataVarchar2() + "'>View</a>");
        }
      } else if (wfDetail.getWfDataConfigId().equals(60L)) {
        //barcodeFilter.txt
        WfData wfData = wfDataDao.getValue(51L, wfDetail.getWfId());
        if (wfData != null) {
          sb.append("<a target='_blank' href='../workflowDocument/?id=" + wfDetail.getWfDataId() +
                  "&mt=text/plain&name=barcodeFilter.txt&title=barcodeFilter.txt%20-%20" +
                  wfData.getWfDataVarchar2() + "'>View</a>");
        }
      } else if (wfDetail.getWfDataConfigId().equals(64L)) {
        //analysis-error-stack.log
        WfData wfData = wfDataDao.getValue(51L, wfDetail.getWfId());
        if (wfData != null) {
          sb.append("<a target='_blank' href='../workflowDocument/?id=" + wfDetail.getWfDataId() +
                  "&mt=text/plain&name=analysis-error-stack.log&title=analysis-error-stack.csv%20-%20" +
                  wfData.getWfDataVarchar2() + "'>View</a>");
        }
      } else if (wfDetail.getWfDataConfigId().equals(65L)) {
        //analysis.csv
        WfData wfData = wfDataDao.getValue(51L, wfDetail.getWfId());
        if (wfData != null) {
          sb.append("<a target='_blank' href='../workflowDocument/?id=" + wfDetail.getWfDataId() +
                  "&mt=text/plain&name=analysis.csv&title=analysis.csv%20-%20" +
                  wfData.getWfDataVarchar2() + "'>View</a>");
        }
      } else if (wfDetail.getWfDataConfigId().equals(74L)) {
        //analysis.csv
        WfData wfData = wfDataDao.getValue(51L, wfDetail.getWfId());
        if (wfData != null) {
          sb.append("<a target='_blank' href='../workflowDocument/?id=" + wfDetail.getWfDataId() +
                  "&mt=text/plain&name=log.txt&title=log.txt%20-%20" +
                  wfData.getWfDataVarchar2() + "'>View</a>");
        }
      } else if (wfDetail.getWfDataConfigId().equals(75L)) {
        //analysis.csv
        WfData wfData = wfDataDao.getValue(51L, wfDetail.getWfId());
        if (wfData != null) {
          sb.append("<a target='_blank' href='../workflowDocument/?id=" + wfDetail.getWfDataId() +
                  "&mt=text/plain&name=error.log&title=error.log%20-%20" +
                  wfData.getWfDataVarchar2() + "'>View</a>");
        }
      } else if (wfDetail.getWfDataConfigId().equals(76L)) {
        //ViiA export.txt
        WfData wfData = wfDataDao.getAssociatedValue(4L, wfDetail.getWfDataAssocId());
        if (wfData != null) {
          sb.append("<a target='_blank' href='../workflowDocument/?id=" + wfDetail.getWfDataId() +
                  "&mt=text/plain&name=export.txt&title=export.txt%20-%20" +
                  wfData.getWfDataVarchar2() + "'>View</a>");
        }
      }
    }

    sb.append("</div></td></tr>");
  }

  public List<WorkflowReagent> getWorkflowReagentList(Long workflowId) {
    return reagentDao.getWorkflowReagentList(workflowId);
  }

  public WfGridDataType getWfGridType(Long wfGridDataTypeId) {
    return wfGridDataTypeDao.find(wfGridDataTypeId);
  }

  public WfGridDataTypeBeanDimensioned getWfGridDataTypes(Long wfId) {

    Wf wf = wfDao.find(wfId);
    WfEntityType wfEntityType = wfEntityTypeDao.find(wf.getWfEntityTypeId());

    // ATP: adding row/col so grid dimensions can be dynamically rendered
    WfGridDataTypeBeanDimensioned wfGridDataTypeBeanDimensioned = new WfGridDataTypeBeanDimensioned();
    wfGridDataTypeBeanDimensioned.setRowSize(wfEntityType.getRowSize());
    wfGridDataTypeBeanDimensioned.setColSize(wfEntityType.getColSize());

    List<WfGridDataType> wfGridDataTypeList = wfGridDataTypeDao.findGridDataTypes(wf.getWfStepConfigId());
    List<WfGridDataTypeBean> wfGridDataTypeBeanList = new ArrayList<WfGridDataTypeBean>(wfGridDataTypeList.size());
    for (WfGridDataType wfGridDataType : wfGridDataTypeList) {
      WfGridDataTypeBean wfGridDataTypeBean = new WfGridDataTypeBean();

      wfGridDataTypeBean.setWfGridDataTypeId(wfGridDataType.getWfGridDataTypeId());
      wfGridDataTypeBean.setWfGridDataType(wfGridDataType.getWfGridDataType());
      wfGridDataTypeBean.setIconPng(wfGridDataType.getIconPng());

      try {
        wfGridDataTypeBean.setFilterType(wfConfigPropertyDao.findByWfConfigIdAndKey(1L, wfGridDataType.getWfGridDataType().toUpperCase() + "_TYPE").getPropertyValue());
        wfGridDataTypeBean.setFilterValue(wfConfigPropertyDao.findByWfConfigIdAndKey(1L, wfGridDataType.getWfGridDataType().toUpperCase() + "_VALUE").getPropertyValue());
      } catch (Exception e) {

      }
      wfGridDataTypeBeanList.add(wfGridDataTypeBean);
    }

    wfGridDataTypeBeanDimensioned.setWfGridDataTypeBeanList(wfGridDataTypeBeanList);

    return wfGridDataTypeBeanDimensioned;
  }

  public List<WfGridDataBean> getWfGridData(Long wfId, Long gridDataTypeId) {
    //load grid data type
    WfGridDataType wfGridDataType = wfGridDataTypeDao.find(gridDataTypeId);
    List<WfGridData> wfGridDataList = new ArrayList<WfGridData>();

    //For the given wfId, use recursive function to fetch all associated wfIds..
    List<WfAssoc> wfAssocList = wfAssocDao.getAllWfRelationships(wfId);

    wfGridDataList = wfGridDataDao.findAllGridData_ByAssociations(wfAssocList, wfId, gridDataTypeId);
    //wfGridDataList = wfGridDataDao.findAllGridData(wfId, gridDataTypeId);

    List<WfGridDataBean> wfGridDataBeanList = new ArrayList<WfGridDataBean>(wfGridDataList.size());
    for (WfGridData wfGridData : wfGridDataList) {
      WfGridDataBean wfGridDataBean = new WfGridDataBean();

      wfGridDataBean.setGridRow(wfGridData.getGridRow());
      wfGridDataBean.setGridCol(wfGridData.getGridCol());
      wfGridDataBean.setWfgridId(wfGridData.getWfGridId());

      //format value based on formatting patterns defined for grid data type
      if (wfGridDataType.getDataType().equals("NUMBER")) {
        Double d = wfGridData.getValueNumber();
        if (d != null) {
          String numberFormat = wfGridDataType.getNumberFormat();
          if (numberFormat != null) {
            DecimalFormat decimalFormat = new DecimalFormat(numberFormat);
            wfGridDataBean.setValue(decimalFormat.format(d));
          } else {
            wfGridDataBean.setValue(String.valueOf(d));
          }
        } else {
          //show varchar2 results when row exists, number is expected and number is null
          wfGridDataBean.setValue(wfGridData.getValueVarchar2());
        }
      } else if (wfGridDataType.getDataType().equals("TIMESTAMP")) {
        Timestamp ts = wfGridData.getValueTimestamp();
        if (ts != null) {
          String tsFormat = wfGridDataType.getTimestampFormat();
          if (tsFormat != null) {
            DateFormat df = new SimpleDateFormat(tsFormat);
            wfGridDataBean.setValue(df.format(wfGridData.getValueTimestamp()));
          } else {
            wfGridDataBean.setValue(String.valueOf(wfGridData.getValueTimestamp()));
          }
        } else {
          //show varchar2 results when row exists, timestamp is expected and number is null
          wfGridDataBean.setValue(wfGridData.getValueVarchar2());
        }
      } else if (wfGridDataType.getDataType().equals("BLOB")) {
        //todo load value as hyperlink to display blob using value_varchar2 as mimetype
      } else {
        wfGridDataBean.setValue(wfGridData.getValueVarchar2());
      }

      wfGridDataBeanList.add(wfGridDataBean);
    }
    return wfGridDataBeanList;
  }

  public List<WfNcrConfig> getNcrConfigs(Long wfStepConfigId) {
    List<WfStepAssoc> wfStepAssocs = wfStepAssocDao.findAll("WF_STEP_CONFIG_ID = ? AND NEXT_WF_NCR_CONFIG_ID IS NOT NULL AND STATUS NOT IN ( 'I' )", wfStepConfigId);
    if (wfStepAssocs.size() == 0) {
      return new ArrayList<WfNcrConfig>();
    }

    List<Long> wfNcrConfigIds = new ArrayList<Long>();
    for (WfStepAssoc wfStepAssoc : wfStepAssocs) {
      wfNcrConfigIds.add(wfStepAssoc.getNextWfNcrConfigId());
    }

    return wfNcrConfigDao.findAllIn(wfNcrConfigIds);
  }

  public WfNcrConfig getNcrConfig(Long ncrConfigId) {
    return wfNcrConfigDao.find(ncrConfigId);
  }

  public boolean applyNcr(Long wfNcrConfigId, Long wfId, String wfNcrContext, String wfNcrComment, String userId, Long wfNcrReasonId) {
    WfNcrConfig wfNcrConfig = wfNcrConfigDao.find(wfNcrConfigId);
    if (true) {

      //apply NCR
      //@todo - possibly refactor to DAO? maybe not because the is the central place to apply NCR (DWW)
      final String INIT_NCR_SQL = "insert into ATLAS.wf_ncr_pending (" +
              "wf_ncr_pending_id,wf_ncr_config_id,wf_id,wf_ncr_context,wf_ncr_comment,create_user,create_ts,wf_ncr_reason_id" +
              ") values (" +
              "nextval('atlas.wf_ncr_pending_id_seq'),?,?,?,?,?,now(),?)";

      final String FLAG_WF_SQL = "update ATLAS.wf set wf_status='N',update_user=?,update_ts=now() where wf_id=?";

      jdbcTemplate.update(INIT_NCR_SQL, wfNcrConfigId, wfId, wfNcrContext, wfNcrComment, userId, wfNcrReasonId);
      jdbcTemplate.update(FLAG_WF_SQL,userId, wfId);

      return true;
    } else {
      LOG.warn(userId + " attempted to apply NCR code wf_ncr_config_id=" + wfNcrConfigId);
      return false;
    }
  }

  public String getStringValue(long wfDataConfigId, long wfId) {

    WfData wd = wfDataDao.getValue(wfDataConfigId, wfId);

    if (wd == null) {
      return "N//A";
    } else {
      return wd.getWfDataVarchar2();
    }
  }

  public String getNumberValue(long wfDataConfigId, long wfId) {

    WfData wd = wfDataDao.getValue(wfDataConfigId, wfId);

    if (wd == null) {
      return "N//A";
    } else {
      return String.valueOf(wd.getWfDataNumber());
    }

  }

  public Timestamp getTimeStampValue(long wfDataConfigId, long wfId) {

    WfData wd = wfDataDao.getValue(wfDataConfigId, wfId);

    if (wd == null) {
      return null;
    } else {
      return wd.getWfDataTimestamp();
    }

  }

  public Map<Long, String> getWfNcrReasonMap(String wfConfigDomain) {
    Map<Long, String> wfNcrReasonMap = new LinkedHashMap<Long, String>();

    //@todo - refactor to DAO (not sure where the best place is for this)
    SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet("select\n" +
            "  wnr.wf_ncr_reason_id,wfnrt.name||'/'||wnr.name wf_ncr_reason \n" +
            "from \n" +
            "  ATLAS.wf_ncr_reason wnr inner join ATLAS.wf_ncr_reason_type wfnrt on wnr.wf_ncr_reason_type_id=wfnrt.wf_ncr_reason_type_id\n" +
            "where\n" +
            "  wfnrt.wf_config_id=(select wf_config_id from ATLAS.wf_config where wf_config_domain=?)\n" +
            "order by \n" +
            "  wfnrt.name,wnr.name", wfConfigDomain);

    while (sqlRowSet.next()) {
      wfNcrReasonMap.put(sqlRowSet.getLong(1), sqlRowSet.getString(2));
    }

    return wfNcrReasonMap;
  }

  private List<WfGraphLegendEntry> getGraphLegend() {

    List<WfGraphLegendEntry> wfGraphLegendEntries = new ArrayList<WfGraphLegendEntry>();

    wfGraphLegendEntries.add(new WfGraphLegendEntry("Your Request:", WfGraphLegendEntry.GRAPH_LEGEND_SHAPE_POLYGON, "#00FF00"));
    wfGraphLegendEntries.add(new WfGraphLegendEntry("E Plate:", WfGraphLegendEntry.GRAPH_LEGEND_SHAPE_RECTANGLE, "#557EAA"));
    wfGraphLegendEntries.add(new WfGraphLegendEntry("L Plate:", WfGraphLegendEntry.GRAPH_LEGEND_SHAPE_RECTANGLE, "#909291"));
    wfGraphLegendEntries.add(new WfGraphLegendEntry("DL/AL Plate:", WfGraphLegendEntry.GRAPH_LEGEND_SHAPE_RECTANGLE, "#FF0000"));
    wfGraphLegendEntries.add(new WfGraphLegendEntry("Dil Block:", WfGraphLegendEntry.GRAPH_LEGEND_SHAPE_RECTANGLE, "#C74243"));
    wfGraphLegendEntries.add(new WfGraphLegendEntry("Clean Tube:", WfGraphLegendEntry.GRAPH_LEGEND_SHAPE_CIRCLE, "#83548B"));
    wfGraphLegendEntries.add(new WfGraphLegendEntry("Seq Block:", WfGraphLegendEntry.GRAPH_LEGEND_SHAPE_RECTANGLE, "#70A35E"));

    return wfGraphLegendEntries;

  }

  public WfGraph getSimpleJsonGraphExample() {
    // builds/returns simple relationship where One is linked to Two and Two is linked to Three
    // One has Tooltips, Two and Three do not

    WfGraph wfGraph = new WfGraph();
    wfGraph.setTitle("Test Graph Data");

    List<WfGraphAdjacency> wfGraphAdjacencies = new ArrayList<WfGraphAdjacency>();

    // node 1
    WfGraphAdjacency wfGraphAdjacency1 = new WfGraphAdjacency();
    wfGraphAdjacency1.setName("One");
    wfGraphAdjacency1.setId("One");

    WfGraphAdjacencyData wfGraphAdjacencyData1 = new WfGraphAdjacencyData();
    wfGraphAdjacencyData1.set$color("#00FF00");
    wfGraphAdjacencyData1.set$dim(6);
    wfGraphAdjacencyData1.set$type("square");

    List<WfGraphToolTip> wfGraphToolTips = new ArrayList<WfGraphToolTip>();
    WfGraphToolTip wfGraphToolTip1 = new WfGraphToolTip();
    wfGraphToolTip1.setName("disp info 1:");
    wfGraphToolTip1.setValue("35.2132132131221321");
    wfGraphToolTip1.setDecimalPlaces(5);
    wfGraphToolTips.add(wfGraphToolTip1);

    WfGraphToolTip wfGraphToolTip2 = new WfGraphToolTip();
    wfGraphToolTip2.setName("disp info 2:");
    wfGraphToolTip2.setValue("3.08990");
    wfGraphToolTip2.setDecimalPlaces(2);
    wfGraphToolTips.add(wfGraphToolTip2);
    wfGraphAdjacencyData1.setGraphToolTipsList(wfGraphToolTips);

    wfGraphAdjacency1.setData(wfGraphAdjacencyData1);

    List<WfGraphNode> wfGraphNodes1 = new ArrayList<WfGraphNode>();
    WfGraphNode wfGraphNode1 = new WfGraphNode();
    wfGraphNode1.setNodeFrom("One");
    wfGraphNode1.setNodeTo("Two");

    WfGraphNodeData wfGraphNodeData1 = new WfGraphNodeData();
    wfGraphNodeData1.set$color("#FFFFFF");
    wfGraphNode1.setData(wfGraphNodeData1);
    wfGraphNodes1.add(wfGraphNode1);

    wfGraphAdjacency1.setAdjacencies(wfGraphNodes1);

    wfGraphAdjacencies.add(wfGraphAdjacency1);

    // node 2
    WfGraphAdjacency wfGraphAdjacency2 = new WfGraphAdjacency();

    wfGraphAdjacency2.setName("Two");
    wfGraphAdjacency2.setId("Two");

    WfGraphAdjacencyData wfGraphAdjacencyData2 = new WfGraphAdjacencyData();
    wfGraphAdjacencyData2.set$color("#EBB056");
    wfGraphAdjacencyData2.set$dim(6);
    wfGraphAdjacencyData2.set$type("circle");

    List<WfGraphNode> wfGraphNodes2 = new ArrayList<WfGraphNode>();
    WfGraphNode wfGraphNode2 = new WfGraphNode();
    wfGraphNode2.setNodeFrom("Two");
    wfGraphNode2.setNodeTo("Three");

    WfGraphNodeData wfGraphNodeData2 = new WfGraphNodeData();
    wfGraphNodeData2.set$color("#FFFFFF");
    wfGraphNode2.setData(wfGraphNodeData2);
    wfGraphNodes2.add(wfGraphNode2);

    wfGraphAdjacency2.setAdjacencies(wfGraphNodes2);

    List<WfGraphToolTip> wfGTTs = new ArrayList<WfGraphToolTip>();
    wfGraphAdjacencyData2.setGraphToolTipsList(wfGTTs);
    wfGraphAdjacency2.setData(wfGraphAdjacencyData2);

    wfGraphAdjacencies.add(wfGraphAdjacency2);

    // node 3
    WfGraphAdjacency wfGraphAdjacency3 = new WfGraphAdjacency();

    wfGraphAdjacency3.setName("Three");
    wfGraphAdjacency3.setId("Three");

    WfGraphAdjacencyData wfGraphAdjacencyData3 = new WfGraphAdjacencyData();
    wfGraphAdjacencyData3.set$color("#909291");
    wfGraphAdjacencyData3.set$dim(6);
    wfGraphAdjacencyData3.set$type("square");

    List<WfGraphNode> wfGraphNodes3 = new ArrayList<WfGraphNode>();
    WfGraphNode wfGraphNode3 = new WfGraphNode();
    wfGraphNode3.setNodeFrom("Three");
    wfGraphNode3.setNodeTo("Two");

    WfGraphNodeData wfGraphNodeData3 = new WfGraphNodeData();
    wfGraphNodeData3.set$color("#FFFFFF");
    wfGraphNode3.setData(wfGraphNodeData3);
    wfGraphNodes3.add(wfGraphNode2);

    wfGraphAdjacency3.setAdjacencies(wfGraphNodes3);

    wfGraphAdjacencyData3.setGraphToolTipsList(wfGTTs);
    wfGraphAdjacency3.setData(wfGraphAdjacencyData3);

    wfGraphAdjacencies.add(wfGraphAdjacency3);


    wfGraph.setWfGraphAdjacencies(wfGraphAdjacencies);


    return wfGraph;
  }

  public List<Long> transFormWfIds(List<WfData> wfDataList) {

    List<Long> wfIds = new ArrayList<Long>();

    for (WfData wfData : wfDataList) {
      wfIds.add(wfData.getWfId());
    }

    return wfIds;
  }

  public List<WfPrinter> getActivePrinters(String wfConfigDomain) {
    return wfPrinterDao.getActivePrinters(wfConfigDomain);
  }

  public void printBarcode(Long printerId, String barcode) {

    WfPrinter wfPrinter = wfPrinterDao.getprinterDetails(printerId);

    //prevent incompatible barcode string lengths
    if (barcode.length() > 21) {
      barcode = barcode.substring(0, 21);
    }

    String printInstructions = labelPrinterJob.createPrintTemplateString(wfPrinter,barcode);

    JsonPrintRequest jsonPrintRequest = new JsonPrintRequest();
    jsonPrintRequest.setPrinterIP(wfPrinter.getIpAddress());
    jsonPrintRequest.setPrintInstructions(printInstructions);

    String printResponse = labelPrinterJob.getPrintResponse(
            labelPrinterJob.getPrintWebResource(findByWfConfigIdAndKey(1L, "CAB_NP_PRINT_SERVICE_URL").getPropertyValue()),
            jsonPrintRequest,
            //findByWfConfigIdAndKey(1L, "URL_ACCESS_TOKEN").getPropertyValue(),
            findByWfConfigIdAndKey(1L, "AZURE_URL_ACCESS_TOKEN").getPropertyValue(),
            findByWfConfigIdAndKey(1L, "AZURE_CLIENT_ID_ATLAS").getPropertyValue(),
            findByWfConfigIdAndKey(1L, "AZURE_CLIENT_SECRET_ATLAS").getPropertyValue(),
            findByWfConfigIdAndKey(1L, "GRANT_TYPE").getPropertyValue(),
            findByWfConfigIdAndKey(1L, "HTTPS_PROTOCOL_VALUE").getPropertyValue());
    System.out.println(printResponse);

    JsonPrintResponse jsonPrintResponse = new JsonPrintResponse();
    jsonPrintResponse.setPrintMessage(barcode);
    jsonPrintResponse.setPrinterID(printerId);
    jsonPrintResponse.setPrintResponse(printResponse);

    wfprintqueuedao.updatePrintJobDetails(jsonPrintResponse);
  }

  public List<WfStepAssocVw> findAllWfStepAssocForWfConfig(long wfConfigId) {
    return wfStepAssocVwDao.getWfStepAssocForWfConfig(wfConfigId);
  }

  public List<WfRefParentVw> findAllActiveWfRefConfig(long wfConfigId) {
    return wfRefParentVwDao.getActiveWfRefConfig(wfConfigId);
  }

  public List<WfRefConfig> findAllWfRefConfig(long wfConfigId) {
    return wfRefConfigDao.getWfRefConfigForWfConfig(wfConfigId);
  }

  public List<WfRefConfig> findWfRefConfigParents(long wfConfigId) {
    return wfRefConfigDao.getWfRefParentConfigForWfConfig(wfConfigId);
  }

  public List<WfAgent> getWfAgents(String wfConfigDomain) {
    return wfAgentDao.getWfAgents(wfConfigDomain);
  }

  public void reloadWfAgent(Long wfAgentId) {
    wfAgentDao.reloadAgent(wfAgentId);
  }

  public void toggleWfAgent(Long wfAgentId, String flag) {
    wfAgentDao.toggleWfAgent(wfAgentId,flag);
  }

  public WfContainer findContainerData(Long wfId) {
    WfContainer wfContainer = new WfContainer();
    Wf wf = wfDao.find(wfId);

    WfEntityType wfEntityType = wfEntityTypeDao.find(wf.getWfEntityTypeId());

    wfContainer.setWfId(wfId);
    wfContainer.setWfConfigId(wf.getWfConfigId());
    wfContainer.setLabel(wf.getWfEntityLabel());
    wfContainer.setEntityTypeLabel(wfEntityType.getWfEntityType());
    wfContainer.setRowSize(wfEntityType.getRowSize());
    wfContainer.setColSize(wfEntityType.getColSize());
    //todo
    // wfContainer.setWfDataList();

    wfContainer.setWfGridAssocVwList(wfGridAssocVwDao.getGridAssocs(wfId));
    return wfContainer;
  }

  public void saveGridAssoc(JsonGridAssocData jsonGridAssocData) {
    List<WfGridAssoc> gridAssocList = new ArrayList<WfGridAssoc>();
    for (Map<String, String> gridAssoc : jsonGridAssocData.getGridItems()) {
      WfGridAssoc wfGridAssoc = new WfGridAssoc();
      wfGridAssoc.setWfConfigId(jsonGridAssocData.getWfConfigId());
      wfGridAssoc.setWfId(jsonGridAssocData.getWfId());

      wfGridAssoc.setGridCol(Integer.parseInt(gridAssoc.get("col")));
      wfGridAssoc.setGridRow(Integer.parseInt(gridAssoc.get("row")));
      try {
        wfGridAssoc.setLabel(gridAssoc.get("label"));
      } catch (Exception ex) {
        wfGridAssoc.setLabel(null);
      }
      gridAssocList.add(wfGridAssoc);
    }

    try {
      wfGridAssocDao.batchSaveGridAssoc(gridAssocList);
    } catch (Exception ex) {
      wfGridAssocDao.batchUpdateGridAssoc(gridAssocList);
    }
  }

  public List<Wf> findLast10WfsInStep(WfStepConfig wfStepConfig, List<WfStepDataConfigVw> wfStepDataConfigList) {
    List<Wf> wfList = wfDao.findLast10WfAdded(wfStepConfig.getWfStepConfigId());
    return appendWfDataConfigsForWf(wfList, wfStepDataConfigList);
  }

  public List<WfConfigProperty> findWfConfigProperty(Long wfConfigId) {
    return wfConfigPropertyDao.findByWfConfigId(wfConfigId);
  }

  public List<WfConfigProperty> findByWfConfigIdAndKey(Long wfConfigId, Long refKeyId) {
    return wfConfigPropertyDao.findByWfConfigIdAndKey(wfConfigId, refKeyId);
  }

  public WfConfigProperty findByWfConfigIdAndKey(long wfConfigId, String key) {
    return wfConfigPropertyDao.findByWfConfigIdAndKey(wfConfigId, key);
  }

  public WfConfigProperty findByWfConfigIdAndKeyAndValue(String wfConfigDomain, String key, String valueVarchar2) {
    return wfConfigPropertyDao.findByWfConfigIdAndKeyAndValue(wfConfigDomain, key, valueVarchar2);
  }

  public List<WfConfigProperty> getWfConfigPropertyTree(Long wfConfigId) {

    List<WfConfigProperty> topHierarchyList;
    topHierarchyList = findByWfConfigIdAndKey(wfConfigId, 0L);

    setPropertyChildList(wfConfigId, topHierarchyList);

    return topHierarchyList;
  }

  private void setPropertyChildList(Long wfConfigId, List<WfConfigProperty> topHierarchyList) {

    for (WfConfigProperty wfConfigProperty : topHierarchyList) {
      if (null == wfConfigProperty.getPropertyValue() || wfConfigProperty.getPropertyValue().isEmpty()) {
        List<WfConfigProperty> childHierarchyList = findByWfConfigIdAndKey(wfConfigId, wfConfigProperty.getPropertyId());
        if (null != childHierarchyList && childHierarchyList.size() > 0) {
          setPropertyChildList(wfConfigId, childHierarchyList);
        }
        wfConfigProperty.setWfConfigPropertyList(childHierarchyList);
      }
    }
  }

  public List<String> getWfRefChildConfigForWfConfig(Long wfConfigId, String wfRefConfigKeyTissue) {
    return wfRefConfigDao.getWfRefChildConfigForWfConfig(wfConfigId, wfRefConfigKeyTissue);
  }

  public List findAllWfWithStatus(Long wfStepConfigId) {

    return wfDao.findAllWfWithStatus(wfStepConfigId);
  }

  public WfEntityType getEntityName(Long entityTypeId) {
    return wfEntityTypeDao.find(entityTypeId);
  }


  public void exportStepFilteredPlateIds(Long wfStepConfigId, String scannedPlateIds, OutputStream out) {

    Map<String, List<WfData>> scannedMap = new LinkedHashMap<String, List<WfData>>();
    List<String> scannedPlatesList = Arrays.asList(scannedPlateIds.split(","));

    List<WfStepDataConfigVw> wfStepDataConfigList = findWfStepDataConfig(wfStepConfigId);

    for (String plateId : scannedPlatesList) {
      List<WfData> wfDataList = wfDataDao.findAll(Long.valueOf(plateId));
      scannedMap.put(plateId, wfDataList);
    }
    writeWfExcel.createExcel(wfStepDataConfigList, scannedMap, out);
  }

  /**
   * move current workflow to next step
   *
   * @param userId
   * @param wfId
   * @param nextStepId
   * @param wfLabel
   * @param wfEntityTypeId
   * @return
   */
  public long completeThisStep(long wfConfigId, String userId, Long wfId, Long nextStepId, String wfLabel, long wfEntityTypeId) {

    Map<Long, String> fromWfIdMap = new HashMap<Long, String>();
    //get ePlateId generated in EXT_BPO_GBS_ASSOC table for this received plate id and mb id
    fromWfIdMap.put(wfId, wfLabel);
    //check if the entity already exists in the queue where it has to be saved  before it is saved.
    wfDao.UpdateWfStepConfig(wfId, nextStepId, userId);
    //combinedWfId = wfDao.combineTo(wfConfigId, wfLabel, fromWfIdMap, nextStepId, userId, wfEntityTypeId);
    // wfDataDao.copyDataWithDifferentWfId(wfId, combinedWfId);
    return wfId;
  }

  //SVANT: Need this to create E plate as a D quadrant entity.
  /**
   * move current workflow to next step
   *
   * @param userId
   * @param wfId
   * @param nextStepId
   * @param wfLabel
   * @param wfEntityTypeId
   * @return
   */
  public long completeThisStep_1(long wfConfigId, String userId, Long wfId, Long nextStepId, String wfLabel, long wfEntityTypeId) {

    Map<Long, String> fromWfIdMap = new HashMap<Long, String>();

    //get ePlateId generated in EXT_BPO_GBS_ASSOC table for this received plate id and mb id
    fromWfIdMap.put(wfId, wfLabel);
    //check if the entity already exists in the queue where it has to be saved  before it is saved.

    Long wfIdExists = wfDao.findWfInWfConfig(wfConfigId, wfEntityTypeId, wfLabel, nextStepId);

    Long combinedWfId = wfIdExists;
    if (wfIdExists == null) {
      combinedWfId = wfDao.combineTo(wfConfigId, wfLabel, fromWfIdMap, nextStepId, userId, wfEntityTypeId);
      wfDataDao.copyDataWithDifferentWfId(wfId, combinedWfId);
      //When E plate is saved as a D quadrant, copy the grid_assoc.
      wfGridAssocDao.copyGridAssocWithDifferentWfId(wfId, combinedWfId);
    }
    return combinedWfId;
  }

  public List<WfGridAssoc> getGridIInfo(long plateWfId) {
    return wfGridAssocDao.findAll(plateWfId);
  }

  public List<WfGridAssoc> getTaqmanGridInfo(long plateWfId) {
    return wfGridAssocDao.findAllActive(plateWfId);

  }

  /**
   * @param plateId
   * @return
   */
  public StringBuilder showGridAvailableSamples(Long plateId) {
    List<WfGridAssoc> wfGridAssocList = getGridIInfo(plateId);
    StringBuilder selectedCells = new StringBuilder();
    String[] samplesGrid = {"A01", "A02", "A03", "A04", "A05", "A06", "A07", "A08", "A09", "A10", "A11", "A12",
        "B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B09", "B10", "B11", "B12",
        "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C08", "C09", "C10", "C11", "C12",
        "D01", "D02", "D03", "D04", "D05", "D06", "D07", "D08", "D09", "D10", "D11", "D12",
        "E01", "E02", "E03", "E04", "E05", "E06", "E07", "E08", "E09", "E10", "E11", "E12",
        "F01", "F02", "F03", "F04", "F05", "F06", "F07", "F08", "F09", "F10", "F11", "F12",
        "G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10", "G11", "G12",
        "H01", "H02", "H03", "H04", "H05", "H06", "H07", "H08", "H09", "H10", "H11", "H12"};

    List<String> gridCellsList = new ArrayList<String>();

    for (String sampleName : samplesGrid) {
      for (WfGridAssoc wfGridAssoc : wfGridAssocList) {
        //selectedCells.append(wfGridAssoc.getLabel()).append(",");
        gridCellsList.add(wfGridAssoc.getLabel());
      }
    }

    for (String sample : samplesGrid) {
      if (!gridCellsList.contains(sample)) {
        selectedCells.append(sample).append(",");
      }
    }
    return selectedCells;
  }

  /**
   * @param plateId
   * @return
   */
  public StringBuilder showTaqmanGridAvailableSamples(Long plateId) {
    List<WfGridAssoc> wfGridAssocList = getTaqmanGridInfo(plateId);
    StringBuilder selectedCells = new StringBuilder();
    String[] samplesGrid = {"A01", "A02", "A03", "A04", "A05", "A06", "A07", "A08", "A09", "A10", "A11", "A12",
            "B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B09", "B10", "B11", "B12",
            "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C08", "C09", "C10", "C11", "C12",
            "D01", "D02", "D03", "D04", "D05", "D06", "D07", "D08", "D09", "D10", "D11", "D12",
            "E01", "E02", "E03", "E04", "E05", "E06", "E07", "E08", "E09", "E10", "E11", "E12",
            "F01", "F02", "F03", "F04", "F05", "F06", "F07", "F08", "F09", "F10", "F11", "F12",
            "G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10", "G11", "G12",
            "H01", "H02", "H03", "H04", "H05", "H06", "H07", "H08", "H09", "H10", "H11", "H12"};

    List<String> gridCellsList = new ArrayList<String>();

    for (String sampleName : samplesGrid) {
      for (WfGridAssoc wfGridAssoc : wfGridAssocList) {
           gridCellsList.add(wfGridAssoc.getLabel());
      }
    }

    for (String sample : samplesGrid) {
      if (!gridCellsList.contains(sample)) {
        selectedCells.append(sample).append(",");
      }
    }
    return selectedCells;
  }

  /**
   * save all sample grid data in a single transaction
   *
   * @param gridList
   * @param gridAssocList
   * @param gridDataList
   */
  public void saveSampleData(List<WfGrid> gridList, final List<WfGridAssoc> gridAssocList, final List<WfGridData> gridDataList) {

    TransactionCallback transactionCallback = new TransactionCallback() {
      @Override
      public Object doInTransaction(TransactionStatus transactionStatus) {
        if (null != gridList && !gridList.isEmpty()) {
          saveGridBaseData(gridList);
        }
        if (null != gridAssocList && !gridAssocList.isEmpty()) {
          saveGridAssocData(gridAssocList);
        }
        if (null != gridDataList && !gridDataList.isEmpty()) {
          saveGridData(gridDataList);
        }
        return null;
      }
    };

    TransactionTemplate tt = new TransactionTemplate();
    tt.setTransactionManager(txManager);
    tt.execute(transactionCallback);
  }

  private void saveGridBaseData(List<WfGrid> gridList) {
    wfGridDao.batchSaveGridData(gridList);
  }

  /**
   * saves the grid assoc list to database as a batch
   *
   * @param recordsList list of assoc records
   */
  private void saveGridAssocData(List<WfGridAssoc> recordsList) {

    wfGridAssocDao.deleteAllByContainerId(recordsList.get(0).getWfId());

    wfGridAssocDao.batchSaveGridAssoc(recordsList);
  }

  /**
   * saves the grid assoc list to database as a batch
   *
   * @param recordsList list of assoc records
   */
  private void saveGridData(List<WfGridData> recordsList) {

    wfGridDataDao.batchSaveGridData(recordsList);
  }

  public List<Wf> findAllWf(long wfConfigId, String entityLabel) {
    return wfDao.findAllWfInWfConfig(wfConfigId, entityLabel);
  }
  public List<Wf> findAllWfs(long wfConfigId, String entityLabel) {

    List<Long> toWfIds=new ArrayList<Long>();
    if((entityLabel.startsWith("M"))||(entityLabel.startsWith("A")))
    {
      Long wfId=wfDao.getWfId(entityLabel,300);

      if(wfId!=null)
      {
        toWfIds = wfAssocDao.getToWfIds(wfId);
      }
      return wfDao.findAllWfsInWfConfig(wfConfigId, entityLabel,toWfIds);
    }
    else
    {
      return wfDao.findAllWfsInWfConfig(wfConfigId, entityLabel);
    }


  }

  public Wf findWfForStep(int entityTypeId,String wfEntityLabel, Long wfStepConfigId){
    return wfDao.findWfForStep(entityTypeId,wfEntityLabel,wfStepConfigId);
  }

  public void queueAgent(String jsonRequest) throws Exception {

    final String SQL_INSERT = "insert into ATLAS.wf_agent_log (WF_AGENT_NAME ,ARGS ,CREATE_TS ,CREATE_USER ,STATUS) values (?,?,?,?,?)";

    jdbcTemplate.update(SQL_INSERT, "com.monsanto.gwg.atlas.agent.TriggerAgent", jsonRequest,
        new Timestamp((Calendar.getInstance().getTime()).getTime()), "ATLAS", "Initiated");

  }

  public List<WfMenuConfig> findAllWfMenuConfig(String wfConfigDomain) {
    return wfMenuConfigDao.findAllWfMenuConfig(wfConfigDomain);
  }

  public List<List<HashMap<String,Object>>> callStoredProcForPivotGridData(Long wfId, String wfGridDataConfigId) {

    List<List<HashMap<String,Object>>>  wfGridsObjectList = null;
    try {
      wfGridsObjectList = wfGridDao.callStoredProcForPivotGridData(wfId, wfGridDataConfigId);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return wfGridsObjectList;
  }

  public List<Sample> getGridDataAndMapToGridObject(Long wfId, String wfGridDataConfigId) {

    List<Sample> wfGridList = new ArrayList<>();
    try {
      List<List<HashMap<String,Object>>> wfGridsObjectList = callStoredProcForPivotGridData(wfId, wfGridDataConfigId);
      wfGridList = wfGridDao.mapResultToGrid(wfGridsObjectList);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return wfGridList;
  }

  public String getNotes(Long wfId) {

    Set<String> notesList = new HashSet<>();
    List<Long> wfIdList = new ArrayList<>();
    String notesStr = "";

    try {
      wfIdList.add(wfId);


      wfIdList.addAll(getAllActiveWfs(wfIdList));

      for (Long currWfId : wfIdList) {
        String varchar2ForWfId = wfDataDao.getVarchar2ForWfId(currWfId, 71L);
        if(null != varchar2ForWfId && !varchar2ForWfId.equals("")){
          notesList.add(varchar2ForWfId);
        }

      }
      notesStr = StringUtils.join(notesList,"<br>");
    }catch(Exception e){
      e.printStackTrace();
    }

    return notesStr;
  }

  private List<Long> getAllActiveWfs(List<Long> wfidList){

    List<Long> parentWfidList = new ArrayList<>();

    for(Long wfId : wfidList){
      parentWfidList.addAll(getActiveLeftWfIds(wfId));
    }
    if(null != parentWfidList && !parentWfidList.isEmpty()){
      List<Long> allActiveWfs = getAllActiveWfs(parentWfidList);
      if(null != allActiveWfs && !allActiveWfs.isEmpty()) {
        parentWfidList.addAll(allActiveWfs);
      }
    }

    return parentWfidList;
  }

  private List<Long> getActiveLeftWfIds(Long wfId) {

    List<Long> wfIdList = new ArrayList<>();

    List<WfAssoc> activeLeft = wfAssocDao.getActiveLeft(wfId);
    for(WfAssoc wfAssoc : activeLeft){
      wfIdList.add(wfAssoc.getFromWfId());
    }

    return wfIdList;
  }

  public void savePlateNote(Long wfId, Integer noteOption, String userId, String noteComment,Long wfConfigId) throws Exception {
    String noteSummary = "";
    if(null != userId){
      noteSummary += userId;
    }

    if(null != noteOption && noteOption != 0){
      WfRefParentVw wfRefParentVw = wfRefParentVwDao.find(noteOption.longValue());
        noteSummary += "-" + wfRefParentVw.getWfRefVarchar2()+ "<br>";

    }
    if(null != noteComment && !noteComment.isEmpty()){
        noteSummary += "-" +noteComment.trim()+ "<br>";
    }

    //Taqman - Store Notes on request level.
    if(wfConfigId==30L){
      //Get wf_id of Request
      long requestWfId=wfDao.getWfId(wfDataDao.getVarchar2ForWfId(wfId,StltaqmanConstants.REQUEST_DATA_CONFIG_ID),StltaqmanConstants.REQUEST_ENTITY_TYPE_ID,StltaqmanConstants.WF_CONFIG_ID);
      //get existing comments
      String existingNotes = wfDataDao.getVarchar2ForWfId(requestWfId,StltaqmanConstants.NOTES_DATA_CONFIG_ID);
      wfDataDao.save(requestWfId, StltaqmanConstants.NOTES_DATA_CONFIG_ID , existingNotes+noteSummary);
    }
    else{
      wfDataDao.save(wfId, 71L , noteSummary);
    }


    //else{
    //  wfDataDao.delete(wfId, 71L);
   // }
  }

  public List<Wf> findAllWf(WfStepConfig wfStepConfig, List<WfStepDataConfigVw> wfStepDataConfigList, Long wfEntityTypeId) {
    //load the list of workflows for this step
    List<Wf> wfList = wfDao.findAllWf(wfStepConfig.getWfStepConfigId(),wfEntityTypeId);
    return appendWfDataConfigsForWf(wfList, wfStepDataConfigList);
  }

  public Map<Long, String> getEntityTypesMap(List<Long> entityTypeIds, Long wfConfigId) {

    return wfEntityTypeDao.getEntityTypesMap(entityTypeIds,wfConfigId);

  }


  public void updateQCAction(Long wfId){

    //SVANT: Capture QC action taken attribute on the analyzed E plate. This will help clear up the Analysis Review queue.
    wfDataDao.save(wfId, 530L, "Y");
    //Fetch the Dquads associated with this Analyzed E plate
    List<Long> fromWfIds = wfAssocDao.getFromWfIds(wfId);
    for (Long analyzedDQuadWfId: fromWfIds) {
      //check if active in AnalysisReview and fetch all analyzedE's on it
      if("I".equalsIgnoreCase(wfDao.find(analyzedDQuadWfId).getWfStatus())) {
        List<Long> toWfIds = wfAssocDao.getToWfIds(analyzedDQuadWfId);
        boolean allEsQCd = true;
        for(Long analyzedEwFID: toWfIds) {
          WfData data = wfDataDao.getValue(530, analyzedEwFID);
          if(null == data) {
            allEsQCd = false;
            break;
          }
        }
        if(allEsQCd)
          wfDao.updateWfStatus(analyzedDQuadWfId, "C","ATLAS");
      }
    }
  }


}
