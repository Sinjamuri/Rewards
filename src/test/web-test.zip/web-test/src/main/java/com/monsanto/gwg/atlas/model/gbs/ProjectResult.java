package com.monsanto.gwg.atlas.model.gbs;

import com.monsanto.gwg.atlas.model.core.WfData;

import java.sql.Timestamp;
import java.util.List;

public class ProjectResult {

  public static final String TABLE_NAME = "gbs_project_result";
  public static final String FQ_SEQUENCE_NAME = "ATLAS.gbs_project_result_id_seq";
  public static final String PRIMARY_KEY = "gbs_project_result_id";
  public static final String ALL_FIELDS = PRIMARY_KEY + ",lims_id,block_barcode_nbr,torrent_analysis_id,barcode_index_plate,wf_id,combined_tube_id,clean_tube_id,low_marker_threshold_qc,low_marker_threshold_upload,active_sample_count," +
      "drop_sample_count,control_sample_count,valid_sample_count,low_marker_sample_count_qc,low_marker_sample_count_upload,control_marker_count," +
      "missing_barcode_sample_count,expected_eplate_count,completed_eplate_count,percent_het,include_in_project,upload_ts,percent_control_markers_found," +
      "primary_generation_name,primary_generation_percent,generation_info,workflow_progress,lplate_id,marker_count,mab_project_status_id,project_complete_ts,sample_delivery_date,(select count(*) from ATLAS.gbs_resummarization_queue where lims_id=ATLAS.gbs_project_result.lims_id and queue_complete_ts is null) resummarization_flg," +
      "project_priority_override,data_due_date,sample_count_3stddev,archived,torrent_reference_id_override,qc_threshold_override,po_status,snapshot_wf_id,all_samples_analyzed,raw_reads,sequencing_run_count";
  public static final String PROJECT_STATUS_IN_CLAUSE = "1052,848,45,121";
  private Long projectResultId;
  private String limsId;
  private String blockBarcodeNbr;
  private Long torrentAnalysisId;
  private Integer barcodeIndexPlate;
  private Long wfId;
  private String combinedTubeId;
  private String cleanTubeId;
  private Integer lowMarkerThresholdQc;
  private Integer lowMarkerThresholdUpload;
  private Integer activeSampleCount;
  private Integer dropSampleCount;
  private Integer controlSampleCount;
  private Integer validSampleCount;
  private Integer lowMarkerSampleCountQc;
  private Integer lowMarkerSampleCountUpload;
  private Integer controlMarkerCount;
  private Integer missingBarcodeSampleCount;
  private Integer expectedEplateCount;
  private Integer completedEplateCount;
  private Double percentHet;
  private Boolean includeInProject;
  private Timestamp uploadTs;
  private Double percentControlMarkersFound;
  private String primaryGenerationName;
  private Double primaryGenerationPercent;
  private String generationInfo;
  private String workflowProgress;
  private String lplateId;
  private Integer markerCount;
  private Integer resummarizationFlg;
  private Integer projectPriorityOverride;
  private Timestamp dataDueDate;
  private Integer sampleCount3stddev;
  private boolean archived;
  private int torrentReferenceIdOverride;
  private int qcThresholdOverride;
  private String poStatus;
  private Integer rawReadCount;
  private int childNodeCount;
  private Long ePlateWfId;
  private boolean cherrySelected;
  private boolean cherryPicked;
  private boolean mergeReady;
  private boolean mergeComplete;
  private String glPlate;
  private String sequencingContainer;
  private List<String> appliedNcrName;
  private Long snapshotWfId;
  private List<WfData> snapshotData;
  private Double po;
  private Integer mabProjectStatusId;
  private Timestamp projectCompleteTS;
  private Timestamp sampleDeliveryDate;
  private String torrentRunName;
  private String analysisEPlateWfId;
  private List<String[]> torrentData;
  private String noteSummary;
  private String noteComments;
  private boolean onHold;
  private List<String> ncrComments;
  private String allSamplesAnalyzed;
  private String sequencingRunCount;



  public Timestamp getSampleDeliveryDate() {
    return sampleDeliveryDate;
  }

  public void setSampleDeliveryDate(Timestamp sampleDeliveryDate) {
    this.sampleDeliveryDate = sampleDeliveryDate;
  }

  public Timestamp getProjectCompleteTS() {
    return projectCompleteTS;
  }

  public void setProjectCompleteTS(Timestamp projectCompleteTS) {
    this.projectCompleteTS = projectCompleteTS;
  }

  public Integer getMabProjectStatusId() {
    return mabProjectStatusId;
  }

  public void setMabProjectStatusId(Integer mabProjectStatusId) {
    this.mabProjectStatusId = mabProjectStatusId;
  }

  public Integer getSampleCount3stddev() {
    return sampleCount3stddev;
  }

  public void setSampleCount3stddev(Integer sampleCount3stddev) {
    this.sampleCount3stddev = sampleCount3stddev;
  }

  public Long getProjectResultId() {
    return projectResultId;
  }

  public void setProjectResultId(Long projectResultId) {
    this.projectResultId = projectResultId;
  }

  public String getLimsId() {
    return limsId;
  }

  public void setLimsId(String limsId) {
    this.limsId = limsId;
  }

  public String getBlockBarcodeNbr() {
    return blockBarcodeNbr;
  }

  public void setBlockBarcodeNbr(String blockBarcodeNbr) {
    this.blockBarcodeNbr = blockBarcodeNbr;
  }

  public Long getTorrentAnalysisId() {
    return torrentAnalysisId;
  }

  public void setTorrentAnalysisId(Long torrentAnalysisId) {
    this.torrentAnalysisId = torrentAnalysisId;
  }

  public Integer getBarcodeIndexPlate() {
    return barcodeIndexPlate;
  }

  public void setBarcodeIndexPlate(Integer barcodeIndexPlate) {
    this.barcodeIndexPlate = barcodeIndexPlate;
  }

  public Long getWfId() {
    return wfId;
  }

  public void setWfId(Long wfId) {
    this.wfId = wfId;
  }

  public String getCombinedTubeId() {
    return combinedTubeId;
  }

  public void setCombinedTubeId(String combinedTubeId) {
    this.combinedTubeId = combinedTubeId;
  }

  public String getCleanTubeId() {
    return cleanTubeId;
  }

  public void setCleanTubeId(String cleanTubeId) {
    this.cleanTubeId = cleanTubeId;
  }

  public Integer getLowMarkerThresholdQc() {
    return lowMarkerThresholdQc;
  }

  public void setLowMarkerThresholdQc(Integer lowMarkerThresholdQc) {
    this.lowMarkerThresholdQc = lowMarkerThresholdQc;
  }

  public Integer getLowMarkerThresholdUpload() {
    return lowMarkerThresholdUpload;
  }

  public void setLowMarkerThresholdUpload(Integer lowMarkerThresholdUpload) {
    this.lowMarkerThresholdUpload = lowMarkerThresholdUpload;
  }

  public Integer getActiveSampleCount() {
    return activeSampleCount;
  }

  public void setActiveSampleCount(Integer activeSampleCount) {
    this.activeSampleCount = activeSampleCount;
  }

  public Integer getDropSampleCount() {
    return dropSampleCount;
  }

  public void setDropSampleCount(Integer dropSampleCount) {
    this.dropSampleCount = dropSampleCount;
  }

  public Integer getControlSampleCount() {
    return controlSampleCount;
  }

  public void setControlSampleCount(Integer controlSampleCount) {
    this.controlSampleCount = controlSampleCount;
  }

  public Integer getValidSampleCount() {
    return validSampleCount;
  }

  public void setValidSampleCount(Integer validSampleCount) {
    this.validSampleCount = validSampleCount;
  }

  public Integer getLowMarkerSampleCountQc() {
    return lowMarkerSampleCountQc;
  }

  public void setLowMarkerSampleCountQc(Integer lowMarkerSampleCountQc) {
    this.lowMarkerSampleCountQc = lowMarkerSampleCountQc;
  }

  public Integer getLowMarkerSampleCountUpload() {
    return lowMarkerSampleCountUpload;
  }

  public void setLowMarkerSampleCountUpload(Integer lowMarkerSampleCountUpload) {
    this.lowMarkerSampleCountUpload = lowMarkerSampleCountUpload;
  }

  public Integer getControlMarkerCount() {
    return controlMarkerCount;
  }

  public void setControlMarkerCount(Integer controlMarkerCount) {
    this.controlMarkerCount = controlMarkerCount;
  }

  public Integer getMissingBarcodeSampleCount() {
    return missingBarcodeSampleCount;
  }

  public void setMissingBarcodeSampleCount(Integer missingBarcodeSampleCount) {
    this.missingBarcodeSampleCount = missingBarcodeSampleCount;
  }

  public Integer getExpectedEplateCount() {
    return expectedEplateCount;
  }

  public void setExpectedEplateCount(Integer expectedEplateCount) {
    this.expectedEplateCount = expectedEplateCount;
  }

  public Integer getCompletedEplateCount() {
    return completedEplateCount;
  }

  public void setCompletedEplateCount(Integer completedEplateCount) {
    this.completedEplateCount = completedEplateCount;
  }

  public Double getPercentHet() {
    return percentHet;
  }

  public void setPercentHet(Double percentHet) {
    this.percentHet = percentHet;
  }

  public Boolean getIncludeInProject() {
    return includeInProject;
  }

  public void setIncludeInProject(Boolean includeInProject) {
    this.includeInProject = includeInProject;
  }

  public Timestamp getUploadTs() {
    return uploadTs;
  }

  public void setUploadTs(Timestamp uploadTs) {
    this.uploadTs = uploadTs;
  }

  public Double getPercentControlMarkersFound() {
    return percentControlMarkersFound;
  }

  public void setPercentControlMarkersFound(Double percentControlMarkersFound) {
    this.percentControlMarkersFound = percentControlMarkersFound;
  }

  public String getPrimaryGenerationName() {
    return primaryGenerationName;
  }

  public void setPrimaryGenerationName(String primaryGenerationName) {
    this.primaryGenerationName = primaryGenerationName;
  }

  public Double getPrimaryGenerationPercent() {
    return primaryGenerationPercent;
  }

  public void setPrimaryGenerationPercent(Double primaryGenerationPercent) {
    this.primaryGenerationPercent = primaryGenerationPercent;
  }

  public String getGenerationInfo() {
    return generationInfo;
  }

  public void setGenerationInfo(String generationInfo) {
    this.generationInfo = generationInfo;
  }

  public String getWorkflowProgress() {
    return workflowProgress;
  }

  public void setWorkflowProgress(String workflowProgress) {
    this.workflowProgress = workflowProgress;
  }

  public String getLplateId() {
    return lplateId;
  }

  public void setLplateId(String lplateId) {
    this.lplateId = lplateId;
  }

  public Integer getMarkerCount() {
    return markerCount;
  }

  public void setMarkerCount(Integer markerCount) {
    this.markerCount = markerCount;
  }

  public Integer getResummarizationFlg() {
    return resummarizationFlg;
  }

  public void setResummarizationFlg(Integer resummarizationFlg) {
    this.resummarizationFlg = resummarizationFlg;
  }

  public Integer getProjectPriorityOverride() {
    return projectPriorityOverride;
  }

  public void setProjectPriorityOverride(Integer projectPriorityOverride) {
    this.projectPriorityOverride = projectPriorityOverride;
  }

  public Timestamp getDataDueDate() {
    return dataDueDate;
  }

  public void setDataDueDate(Timestamp dataDueDate) {
    this.dataDueDate = dataDueDate;
  }

  public boolean isArchived() {
    return archived;
  }

  public void setArchived(boolean archived) {
    this.archived = archived;
  }

  public int getTorrentReferenceIdOverride() {
    return torrentReferenceIdOverride;
  }

  public void setTorrentReferenceIdOverride(int torrentReferenceIdOverride) {
    this.torrentReferenceIdOverride = torrentReferenceIdOverride;
  }

  public int getQcThresholdOverride() {
    return qcThresholdOverride;
  }

  public void setQcThresholdOverride(int qcThresholdOverride) {
    this.qcThresholdOverride = qcThresholdOverride;
  }

  public String getPoStatus() {
    return poStatus;
  }

  public void setPoStatus(String poStatus) {
    this.poStatus = poStatus;
  }

  public Integer getRawReadCount() {
    return rawReadCount;
  }

  public void setRawReadCount(Integer rawReadCount) {
    this.rawReadCount = rawReadCount;
  }

  public int getChildNodeCount() {
    return childNodeCount;
  }

  public void setChildNodeCount(int childNodeCount) {
    this.childNodeCount = childNodeCount;
  }

    public Long getePlateWfId() {
        return ePlateWfId;
    }

    public void setePlateWfId(Long ePlateWfId) {
        this.ePlateWfId = ePlateWfId;
    }

  public boolean isCherrySelected() {
    return cherrySelected;
  }

  public void setCherrySelected(boolean cherrySelected) {
    this.cherrySelected = cherrySelected;
  }

  public boolean isCherryPicked() {
    return cherryPicked;
  }

  public void setCherryPicked(boolean cherryPicked) {
    this.cherryPicked = cherryPicked;
  }

  public boolean isMergeReady() {
    return mergeReady;
  }

  public void setMergeReady(boolean mergeReady) {
    this.mergeReady = mergeReady;
  }

  public boolean isMergeComplete() {
    return mergeComplete;
  }

  public void setMergeComplete(boolean mergeComplete) {
    this.mergeComplete = mergeComplete;
  }

  public String getGlPlate() {
    return glPlate;
  }

  public void setGlPlate(String glPlate) {
    this.glPlate = glPlate;
  }

  public String getSequencingContainer() {
    return sequencingContainer;
  }

  public void setSequencingContainer(String sequencingContainer) {
    this.sequencingContainer = sequencingContainer;
  }

  public List<String> getAppliedNcrName() {
    return appliedNcrName;
  }

  public void setAppliedNcrName(List<String> appliedNcrName) {
    this.appliedNcrName = appliedNcrName;
  }

  public Long getSnapshotWfId() {
    return snapshotWfId;
  }

  public void setSnapshotWfId(Long snapshotWfId) {
    this.snapshotWfId = snapshotWfId;
  }

  public List<WfData> getSnapshotData() {
    return snapshotData;
  }

  public void setSnapshotData(List<WfData> snapshotData) {
    this.snapshotData = snapshotData;
  }

  public Double getPo() {
    return po;
  }

  public void setPo(Double po) {
    this.po = po;
  }

  public String getTorrentRunName() {
    return torrentRunName;
  }

  public void setTorrentRunName(String torrentRunName) {
    this.torrentRunName = torrentRunName;
  }

  public String getAnalysisEPlateWfId() {
    return analysisEPlateWfId;
  }

  public void setAnalysisEPlateWfId(String analysisEPlateWfId) {
    this.analysisEPlateWfId = analysisEPlateWfId;
  }

  public List<String[]> getTorrentData() {
    return torrentData;
  }

  public void setTorrentData(List<String[]> torrentData) {
    this.torrentData = torrentData;
  }

  public String getNoteSummary() {
    return noteSummary;
  }

  public void setNoteSummary(String noteSummary) {
    this.noteSummary = noteSummary;
  }

  public String getNoteComments() {
    return noteComments;
  }

  public void setNoteComments(String noteComments) {
    this.noteComments = noteComments;
  }

  public boolean isOnHold() {    return onHold;  }

  public void setOnHold(boolean onHold) {    this.onHold = onHold;  }

  public List<String> getNcrComments() {
    return ncrComments;
  }

  public void setNcrComments(List<String> ncrComments) {
    this.ncrComments = ncrComments;
  }

  public String getAllSamplesAnalyzed() {
    return allSamplesAnalyzed;
  }

  public void setAllSamplesAnalyzed(String allSamplesAnalyzed) {
    this.allSamplesAnalyzed = allSamplesAnalyzed;
  }

  public String getSequencingRunCount() {
    return sequencingRunCount;
  }

  public void setSequencingRunCount(String sequencingRunCount) {
    this.sequencingRunCount = sequencingRunCount;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (projectResultId != null ? projectResultId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object o) {
    //make sure the compare object is of the same type
    if (!(o instanceof ProjectResult)) {
      return false;
    }

    //equals just compares the primary key
    //if the primary key is null in either this object
    //or the compare object, return false because
    //equality can not be determined
    ProjectResult compare = (ProjectResult) o;
    if (projectResultId == null || compare.projectResultId == null) {
      return false;
    } else {
      return projectResultId.equals(compare.projectResultId);
    }
  }

  @Override
  public String toString() {
    return getClass().getName() + "[" + (projectResultId!=null?projectResultId:"<<NULL>>") + "]";
  }
}
