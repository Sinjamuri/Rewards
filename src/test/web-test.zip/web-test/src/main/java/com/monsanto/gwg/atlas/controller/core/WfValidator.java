package com.monsanto.gwg.atlas.controller.core;

import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.dao.gbs.ProjectResultDao;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.model.core.Wf;
import com.monsanto.gwg.atlas.model.core.WfAssoc;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.model.core.WfStepConfig;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.gbs.GbsService;
import com.monsanto.gwg.atlas.service.pcrExt.PcrExtService;
import com.monsanto.gwg.atlas.service.stltaqmanService.StltaqmanConstants;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static com.monsanto.gwg.atlas.service.stltaqmanService.StltaqmanConstants.*;

/**
 * Created by ashar7 on 10/1/2015.
 */
@Service
public class WfValidator {

    @Autowired
    WfService wfService;

    @Autowired
    GbsService gbsService;

    @Autowired
    private WfDao wfDao;

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfGridDataDao wfGridDataDao;

    @Autowired
    private WfAssocDao wfAssocDao;

    @Autowired
    PcrExtService pcrExtService;

    @Autowired
    ProjectResultDao projectResultDao;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    WfStepConfigDao wfStepConfigDao;

    public JsonResponse validate(String wfConfigDomain, Long wfStepConfigId, JsonPost jsonPost) {

        final String METHOD_NAME = "validate" + wfStepConfigId;

        JsonResponse jsonResponse = new JsonResponse();
        try {
            //this.getClass().getMethod(METHOD_NAME, JsonPost.class).invoke(jsonPost);
             List<String> errorPlates = new ArrayList<String>();
             WfStepConfig wfStepConfig = wfStepConfigDao.find(wfStepConfigId);
             if(wfStepConfig.isNcrReasonMandatory()){
                 errorPlates = isNcrReasonPresent(jsonPost);
             }
             if(!errorPlates.isEmpty()){
                 for (String errorPlate:errorPlates) {
                     jsonResponse.addError(errorPlate+": Please select NCR Reason.");
                 }
             }
             else {
                Class c = getClass();
                Method method = c.getDeclaredMethod(METHOD_NAME, JsonPost.class);
                jsonResponse = (JsonResponse) method.invoke(this, jsonPost);
             }
        } catch (NoSuchMethodException e) {
            //e.printStackTrace();4
        } catch (InvocationTargetException e) {
            jsonResponse.addError("Error while validating. Please contact IT.");
            //e.printStackTrace();
        } catch (IllegalAccessException e) {
            jsonResponse.addError("Error while validating. Please contact IT.");
            //e.printStackTrace();
        } catch (Exception e) {
            jsonResponse.addError("Error while validating. Please contact IT.");
        }

        return jsonResponse;
    }

    public JsonResponse validate10(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        Map<String, String> glCropMap = new HashMap<String, String>();
        Map<String, String> glSampleTypeMap = new HashMap<String, String>();
        Map<String, List<Integer>> glPosMap = new HashMap<String, List<Integer>>();
        Map<String, List<Long>> glMap = new HashMap();
        List<Long> wfIds = null;

        for (Map<String, String> postData : jsonPost.getRows()) {

            Long wfId = Long.parseLong(postData.get("wfId"));

            String glPlateBarcode = postData.get("wfdc44");
            String biomekDeckPosition = postData.get("wfdc43");
            String cpPlateBarcode = postData.get("wfEntityLabel");
            String ncrCode = postData.get("ncrCode");

            if (ncrCode!=null && !ncrCode.isEmpty() && StringUtils.isNumeric(ncrCode)) { // NCR Validation...
               long wfNcrConfigId = Long.parseLong(ncrCode);
                if (wfNcrConfigId == 117) { // PCR status Validation
                    if (cpPlateBarcode != null && !cpPlateBarcode.startsWith("CP")) {
                        jsonResponse.addError("This NCR can be applied only on cherry picked plates");
                    }
                } else {
                    // Save validation (none)
                }
                return jsonResponse;
            }

            String glPlateBarcodeBase = glPlateBarcode.substring(0, glPlateBarcode.indexOf("-"));
            int pos = 0;

            //check for valid gl plate barcode
            if (glPlateBarcode.endsWith("-01")) {
                if (biomekDeckPosition.equals("PRECIP2")) {
                    pos = 1;
                } else if (biomekDeckPosition.equals("PRECIP3")) {
                    pos = 2;
                } else if (biomekDeckPosition.equals("PRECIP4")) {
                    pos = 3;
                } else if (biomekDeckPosition.equals("PRECIP5")) {
                    pos = 4;
                }
            } else if (glPlateBarcode.endsWith("-02")) {
                if (biomekDeckPosition.equals("PRECIP2")) {
                    pos = 5;
                } else if (biomekDeckPosition.equals("PRECIP3")) {
                    pos = 6;
                } else if (biomekDeckPosition.equals("PRECIP4")) {
                    pos = 7;
                } else if (biomekDeckPosition.equals("PRECIP5")) {
                    pos = 8;
                }
            } else if (glPlateBarcode.endsWith("-03")) {
                if (biomekDeckPosition.equals("PRECIP2")) {
                    pos = 9;
                } else if (biomekDeckPosition.equals("PRECIP3")) {
                    pos = 10;
                }
            } else {
                jsonResponse.addError("The GL Plate barcode is invalid");
            }

            if (null == glMap.get(glPlateBarcode)) {
                wfIds = new ArrayList<>();
            } else {
                wfIds = glMap.get(glPlateBarcode);
            }
            wfIds.add(wfId);
            glMap.put(glPlateBarcode, wfIds);
            //check if the glPlateBarcode has already been used.
            List<Wf> glWf = wfDao.findAll(glPlateBarcode);
            if (null != glWf && glWf.size() > 0) {
                jsonResponse.addError("The " + glPlateBarcode + " has already been used. Please generate a new barcode by clicking on 'Print Next Library Barcode Set'.");
            }

            List<Integer> positionList = glPosMap.get(glPlateBarcode);
            if (null == positionList) {
                positionList = new ArrayList<Integer>();
            }
            if (positionList.contains(pos)) {
                jsonResponse.addError("You have associated multiple E plates to the same GL and index. Please correct the relationship before saving.");
            } else {
                positionList.add(pos);
                glPosMap.put(glPlateBarcode, positionList);
            }

            WfData oligoPool = wfDataDao.getValue(7, wfId);
            WfData sampleType = wfDataDao.getValue(61, wfId);

            if (null != glCropMap && glCropMap.containsKey(glPlateBarcodeBase)) {
                if (!glCropMap.get(glPlateBarcodeBase).equals(oligoPool.getWfDataVarchar2())) {
                    jsonResponse.addError("The Library Plate is associated to E plates with different Crop Types. Please correct the relationship before saving.");
                }
            } else {
                glCropMap.put(glPlateBarcodeBase, oligoPool.getWfDataVarchar2());
            }

            if (null != glSampleTypeMap && glSampleTypeMap.containsKey(glPlateBarcodeBase)) {
                if ("CHIP".equalsIgnoreCase(sampleType.getWfDataVarchar2()) && !glSampleTypeMap.get(glPlateBarcodeBase).equals(sampleType.getWfDataVarchar2())) {
                    jsonResponse.addError("The Libarary plate is associated to E plates with different Sample Types. Please correct the relationship before saving.");
                }
            } else {
                //LIMS / Bulk (GBS) can still be combined
                glSampleTypeMap.put(glPlateBarcodeBase, sampleType.getWfDataVarchar2());
            }

            //check if this barcode and index already exists
            List<WfAssoc> childEPlates = gbsService.getChildEPlates(glPlateBarcodeBase);
            for (WfAssoc wfAssoc : childEPlates) {
                WfData wfData = wfDataDao.getValue(47, wfAssoc.getFromWfId());
                if (pos == wfData.getWfDataNumber().intValue()) {
                    jsonResponse.addError("An E plate is already associated to the same GL and index. Please correct the relationship before saving.");
                }
            }
        }
        //A GL plate should always have 4 E plates on it.
        for (Map.Entry<String, List<Long>> entry : glMap.entrySet()) {
            System.out.println(entry.getKey() + "/" + entry.getValue());
            if (entry.getValue().size() != 4) {
                jsonResponse.addError(entry.getKey() + " should always have 4 E plates on it.");
            }
        }
        return jsonResponse;
    }

    public JsonResponse validate50(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        Map<String, String> glCropMap = new HashMap<String, String>();
        Map<String, List<Integer>> glPosMap = new HashMap<String, List<Integer>>();

        for (Map<String, String> postData : jsonPost.getRows()) {

            Long wfId = Long.parseLong(postData.get("wfId"));
            List<WfAssoc> activeLeft = wfAssocDao.getActiveLeft(wfId);
            if (null == activeLeft || activeLeft.isEmpty()) {
                jsonResponse.addError("Gl cannot be created at this time as all required data is not yet available. Please try again later when the status is 'Ready to Create GL'");
                break;
            }
/*
      String glPlateBarcode = postData.get("wfdc44");
      String glPlateBarcodeBase = glPlateBarcode.substring(0, glPlateBarcode.indexOf("-"));

      int pos = 0;

  //check for valid gl plate barcode
      if (glPlateBarcode.endsWith("-01")) {

      } else if (glPlateBarcode.endsWith("-02")) {

      } else {
        jsonResponse.addError("The GL Plate barcode is invalid");
      }

      List<Integer> positionList = glPosMap.get(glPlateBarcode);
      if(null == positionList){
        positionList = new ArrayList<Integer>();
      }
      if(positionList.contains(pos)){
        jsonResponse.addError("You have associated multiple D plates to the same GL and index. Please correct the relationship before saving.");
      }else {
        positionList.add(pos);
        glPosMap.put(glPlateBarcode, positionList);
      }

      WfData oligoPool = wfDataDao.getValue(7, wfId);
      if(null != glCropMap && glCropMap.containsKey(glPlateBarcodeBase)){
        if(!glCropMap.get(glPlateBarcodeBase).equals(oligoPool.getWfDataVarchar2())){
          jsonResponse.addError("The GL is associated to E plates with different Crop Types. Please correct the relationship before saving.");
        }
      }else{
        glCropMap.put(glPlateBarcodeBase,oligoPool.getWfDataVarchar2());
      }

      //check if this barcode and index already exists
      List<WfAssoc> childEPlates = gbsService.getChildEPlates(glPlateBarcodeBase);
      for(WfAssoc wfAssoc : childEPlates){
        WfData wfData = wfDataDao.getValue(47, wfAssoc.getFromWfId());
        if(pos == wfData.getWfDataNumber().intValue()){
          jsonResponse.addError("A D plate is already associated to the same GL and index. Please correct the relationship before saving.");
        }
      }*/
        }

        return jsonResponse;
    }

   /* public JsonResponse validate12(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        String wfEntityLabel = null;
        for (Map<String, String> postData : jsonPost.getRows()) {

            Map<Integer, String> detailMap = new LinkedHashMap<Integer, String>();

            //extract wfId to associate data
            Long wfId = Long.parseLong(postData.get("wfId"));
            wfEntityLabel = postData.get("wfEntityLabel");
            if (wfEntityLabel.endsWith("-02")) {
                detailMap.put(5, postData.get("wfdc261"));
                detailMap.put(6, postData.get("wfdc262"));
                detailMap.put(7, postData.get("wfdc263"));
                detailMap.put(8, postData.get("wfdc264"));
            } else if (wfEntityLabel.endsWith("-01")) {
                detailMap.put(1, postData.get("wfdc261"));
                detailMap.put(2, postData.get("wfdc262"));
                detailMap.put(3, postData.get("wfdc263"));
                detailMap.put(4, postData.get("wfdc264"));
            }

            for (Integer cleanTubeIndex : detailMap.keySet()) {
                if (detailMap.get(cleanTubeIndex) == null || detailMap.get(cleanTubeIndex).isEmpty() ||
                        !(detailMap.get(cleanTubeIndex).startsWith(String.format("%02d", cleanTubeIndex)) ||
                                (wfEntityLabel.endsWith("-01") && detailMap.get(cleanTubeIndex).startsWith("09")) ||
                                (wfEntityLabel.endsWith("-02") && detailMap.get(cleanTubeIndex).startsWith("10")))) {
                    jsonResponse.addError("The clean tube entered does not match the index. Please verify the order.");
                }
            }
        }
        return jsonResponse;
    }*/

    public JsonResponse validate3030(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        Set<String> cyclers = new HashSet<String>();
        int plateCount = jsonPost.getRows().size();
        boolean isNcr=false;
        for (Map<String, String> postData : jsonPost.getRows()) {
            String ncrCode = postData.get("ncrCode");
            long wfNcrConfigId = 0;

            if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) { // NCR Validation...
                wfNcrConfigId = Long.parseLong(ncrCode);
                if(wfNcrConfigId==3004L)
                {
                    isNcr=true;
                }
            }
        }
        if(isNcr==false) {
        for (Map<String, String> postData : jsonPost.getRows()) {
            String cycler = postData.get("wfdc3089");
            if (!StringUtils.isEmpty(cycler)) {
                cyclers.add(cycler);
            } else {
                jsonResponse.addError(postData.get("wfEntityLabel") + ": Please select the Cycler.");
            }
        }
        if (jsonResponse.getErrorCnt() == 0) {
            if (cyclers.size() > 1) {
                jsonResponse.addError("Please select only one Cycler.");
            }
        }
        if (jsonResponse.getErrorCnt() == 0) {
            if (cyclers.size() == 1) {
                String[] cyclersArray = cyclers.toArray(new String[0]);
                String cyclerSelected = cyclersArray[0];

                if ("Waterbath".equalsIgnoreCase(cyclerSelected)) {
                    // Set the Limit to 120 per DSA-4326
                    if (plateCount > 120) {
                        jsonResponse.addError("You have exceeded the plate limit for Waterbath cycler.");
                    }
                    // Only One Cycling Condition for Waterbath
                    if (!isSingleCyclingCondition(jsonPost)) {
                        jsonResponse.addError("You have scanned plates with more than one Cycling Conditions.");
                    }
                } // end of Waterbath validations

                if ("Thermocyclers".equalsIgnoreCase(cyclerSelected)) {
                    Set<String> errorCyclerNames = new HashSet<String>();
                    Set<String> errorCyclingNames = new HashSet<String>();
                    if (jsonResponse.getErrorCnt() == 0) {
                        // cycler name is required
                        for (Map<String, String> postData : jsonPost.getRows()) {
                            if (StringUtils.isEmpty(postData.get("cyclerName"))) {
                                jsonResponse.addError(postData.get("wfEntityLabel") + ": Cycler Name for a Thermocycler is missing.");
                            }
                        }
                        // Maximum of two plates can be associated with one cycler name
                        for (Map<String, String> postData : jsonPost.getRows()) {
                            String cyclerName = postData.get("cyclerName");
                            if (!StringUtils.isEmpty(cyclerName)) {
                                // Loop through to get count of plates associated with this cycler name
                                int count = 0;
                                for (Map<String, String> plateData : jsonPost.getRows()) {
                                    if ((!StringUtils.isEmpty(plateData.get("cyclerName"))) && (cyclerName.equals(plateData.get("cyclerName")))) {
                                        count++;
                                    }
                                }
                                if (count > 2) {
                                    errorCyclerNames.add(cyclerName);
                                }
                            }
                        }
                        if (errorCyclerNames.size() > 0) {
                            for (String errorCycler : errorCyclerNames) {
                                jsonResponse.addError(errorCycler + " has more than two plates.");
                            }
                        }
                    }
                    // Plates associated to a cycler name should have same cycling condition
                    for (Map<String, String> postData : jsonPost.getRows()) {
                        String cyclerName = postData.get("cyclerName");
                        Long wfId = Long.parseLong(postData.get("wfId"));
                        String cyclingCondition = wfService.getStringValue(StltaqmanConstants.CYCLING_CONDITIONS_DATA_CONFIG_ID, wfId);
                        if (!StringUtils.isEmpty(cyclerName)) {
                            // Loop through to get cycling condition associated with this cycler name
                            for (Map<String, String> plateData : jsonPost.getRows()) {
                                if ((!StringUtils.isEmpty(plateData.get("cyclerName"))) && (cyclerName.equals(plateData.get("cyclerName")))) {
                                    Long plateWfId = Long.parseLong(plateData.get("wfId"));
                                    String plateCyclingCondition = wfService.getStringValue(StltaqmanConstants.CYCLING_CONDITIONS_DATA_CONFIG_ID, plateWfId);
                                    if (!cyclingCondition.equals(plateCyclingCondition)) {
                                        errorCyclingNames.add(cyclerName);
                                    }
                                }
                            }

                        }
                    }
                    if (errorCyclingNames.size() > 0) {
                        for (String errorCycling : errorCyclingNames) {
                            jsonResponse.addError(errorCycling + " has plates with diferrent Cycling Conditions.");
                        }
                    }
                } // end of Thermocycler validations

                if (jsonResponse.getErrorCnt() == 0) {
                    for (Map<String, String> postData : jsonPost.getRows()) {
                        if (("Waterbath".equalsIgnoreCase(cyclerSelected)) && (StringUtils.isEmpty(postData.get("cyclerName")))) {
                            postData.put("wfdc3091", postData.get("wfdc3089"));
                        } else {
                            postData.put("wfdc3091", postData.get("cyclerName"));
                        }
                    }
                }

            }
        }
        }

        return jsonResponse;
    }


    public JsonResponse validate1(JsonPost jsonPost) {

        // CP plates cannot be pushed to Cobra Run Ready
        // NCR to Normalize is only applicable for Es with status of Lab Call or FAILED PCR

        JsonResponse jsonResponse = new JsonResponse();
        try {
            for (Map<String, String> postData : jsonPost.getRows()) {

                Long wfId = Long.parseLong(postData.get("wfId"));
                String ncrCode = postData.get("ncrCode");
                long wfNcrConfigId = 0;
                String pcrStatus = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 158L);
                if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) { // NCR Validation...
                    wfNcrConfigId = Long.parseLong(ncrCode);
                    if (wfNcrConfigId == 50 || wfNcrConfigId == 121) { // PCR status Validation
                        if (!"3 Normalization Complete".equalsIgnoreCase(pcrStatus)) {
                            jsonResponse.addError("E Plate cannot be NCRd/forwarded .Status must be 3 Normalization Complete ");
                        }
                    }
                    if (wfNcrConfigId == 112) {
                        if (pcrStatus!=null  && pcrStatus.contains("Library")) {
                            jsonResponse.addError("E Plate cannot be NCRd for Re-Extraction, Rearray Process is already started for this Plate");
                        }
                    }
                    if (wfNcrConfigId == 50) { // Cobra Run Ready Validation
                        if (gbsService.isEPlateCherrySelected(wfId)) {
                            jsonResponse.addError("Cherry Picked plate cannot be NCRd/forwarded to Cobra Run Ready queue.");
                        }
                    } else if (wfNcrConfigId == 65) { // Normalize NCR
                        if (!pcrExtService.normalizeEligible(wfId)) {
                            jsonResponse.addError("Status must be Lab Call or FAILED PCR to force normalization.");
                        }
                    }
                } else {
                    // Save validation (none)
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return jsonResponse;
    }

    public JsonResponse validate39(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        List<String> poolTubesData = new ArrayList<String>();
        for (Map<String, String> postData : jsonPost.getRows()) {
            Long wfId = Long.parseLong(postData.get("wfId"));

            //Get the pooled tube names and add them in list
            poolTubesData.add(wfService.getStringValue(42, wfId));
            String ncrCode = postData.get("ncrCode");

            //validate Ncr when selected
            if (null != ncrCode && !ncrCode.isEmpty() && StringUtils.isNumeric(ncrCode) && Long.valueOf(ncrCode) == 42) {
                for (String tubeData : poolTubesData) {
                    if (null != tubeData && !tubeData.isEmpty() && StringUtils.isNumeric(tubeData.substring(0, 1))) {
                        int genotypingStatusValue = Integer.parseInt(tubeData.substring(0, 1));

                        //Do not allow Ncr when status value is greater than 5
                        if (genotypingStatusValue > 5) {
                            jsonResponse.addError("Ncr is not allowed for Genotyping Status greater than 5");
                        }
                    }
                }
            }
        }
        return jsonResponse;
    }

    public JsonResponse validate33(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        jsonResponse = validateDropboxCriteria(jsonPost);
        if (jsonResponse.getErrors().isEmpty()) {
            for (Map<String, String> postData : jsonPost.getRows()) {
                String location = postData.get("location");
                String wfdc461 = postData.get("wfdc461");
                // Set the  location value to wfdc461
                if (wfdc461 == null || wfdc461.length() == 0 && (location != null || location.length() != 0)) {
                    postData.put("wfdc461", location);
                }

            }
        }

        //get the grid data only when there are no errors
        if (jsonResponse.getErrors().isEmpty()) {
            jsonResponse = gbsService.getSampleData(jsonPost);
        }
        return jsonResponse;
    }

    public JsonResponse validate34(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        jsonResponse = validateDropboxCriteria(jsonPost);
        if (jsonResponse.getErrors().isEmpty()) {
            for (Map<String, String> postData : jsonPost.getRows()) {
                String location = postData.get("location");
                String wfdc461 = postData.get("wfdc461");
                // Set the  location value to wfdc461
                if (wfdc461 == null || wfdc461.length() == 0 && (location != null || location.length() != 0)) {
                    postData.put("wfdc461", location);
                }
            }
        }
        //get the grid data only when there are no errors
        if (jsonResponse.getErrors().isEmpty()) {
            jsonResponse = gbsService.getSampleData(jsonPost);
        }
        return jsonResponse;
    }

    public JsonResponse validate35(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        jsonResponse = validateDropboxCriteria(jsonPost);
        return jsonResponse;
    }

    public JsonResponse validate37(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        jsonResponse = validateDropboxCriteria(jsonPost);
        return jsonResponse;
    }

    public JsonResponse validate74(JsonPost jsonPost) {
        JsonResponse jsonResponse = validateDropboxCriteria(jsonPost);
        if (jsonResponse.getErrors().isEmpty()) {
            // Check for Storage Location value as it is mandatory
            for (Map<String, String> postData : jsonPost.getRows()) {
                String storageLocation = postData.get("storageLocation");
                String wfdc420 = postData.get("wfdc420");
                String wfEntityLabel = postData.get("wfEntityLabel");
                // Set the storage location value to wfdc420
                if ((wfdc420 == null || wfdc420.length() == 0) && (storageLocation == null || storageLocation.length() == 0)) {
                    jsonResponse.addError("Please enter F Plate Storage Location for " + wfEntityLabel);
                } else {
                    if (wfdc420 == null || wfdc420.length() == 0 && (storageLocation != null || storageLocation.length() != 0)) {
                        postData.put("wfdc420", storageLocation);
                    }
                }
            }
        }

        //get the grid data only when there are no errors
        if (jsonResponse.getErrors().isEmpty()) {
            jsonResponse = gbsService.getSampleData(jsonPost);
        }
        return jsonResponse;
    }

    public JsonResponse validateDropboxCriteria(JsonPost jsonPost) {
        JsonResponse jsonResponse = new JsonResponse();
        for (Map<String, String> postData : jsonPost.getRows()) {
            Long wfId = Long.parseLong(postData.get("wfId"));
            String ncrCode = postData.get("ncrCode");
            String ncrReason = postData.get("ncrReason");
            long wfNcrConfigId = 0;
            if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) {
                wfNcrConfigId = Long.parseLong(ncrCode);
            }
            String ncrComment = postData.get("ncrComment");
            Long wfNcrReasonId = null;
            //validate Ncr when selected
            if (wfNcrConfigId == 76) {
                if (ncrReason != null && !ncrReason.trim().isEmpty()) {
                    wfNcrReasonId = Long.parseLong(ncrReason);
                    if (!((wfNcrReasonId == 36) || (wfNcrReasonId == 37))) {
                        jsonResponse.addError("Please choose the reason for dropping box:(Lab drop/Breeder Drop)");
                    }
                    if (wfNcrReasonId == 36 && ncrComment.trim().isEmpty()) {
                        jsonResponse.addError("Please input NCR number in Additional notes.");
                    }
                } else {
                    jsonResponse.addError("Please choose the reason for dropping box:(Lab drop/Breeder Drop)");
                }
            }
        }
        return jsonResponse;
    }

    /**
     * Validate Save out of DNA Source Scan queue
     * All plates for a single project must be in the post.
     *
     * @param jsonPost
     * @return
     */
    public JsonResponse validate9000(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();

        Map<String, String> glCropMap = new HashMap<String, String>();
        Map<String, List<Integer>> glPosMap = new HashMap<String, List<Integer>>();

        String wfIdInClause = "";
        Set<String> uniqueProjects = new HashSet<String>();

        try {
            for (Map<String, String> postData : jsonPost.getRows()) {

                wfIdInClause += Long.parseLong(postData.get("wfId")) + ",";
                uniqueProjects.add(wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 2036));
            }

            for (String uniqueProject : uniqueProjects) {
                // all Ds for the project must be scanned
                if (wfIdInClause.length() > 0) {
                    long projectWfId = wfDao.getWfId(uniqueProject, 95);
                    List<String> dPlatesNotScanned = wfDao.findEntitiesLike(91, " and wf_status='I' and wf_step_config_id=9000 and wf_id in " +
                            "(select to_wf_id from ATLAS.wf_assoc where active='Y' and from_wf_id=" + projectWfId + ") and " +
                            "wf_id not in (" + wfIdInClause.substring(0, wfIdInClause.length() - 1) + ")");
                    String notScannedMsg = "";
                    if (dPlatesNotScanned.size() > 0) {
                        for (String dplate : dPlatesNotScanned) {
                            notScannedMsg += dplate + ", ";
                        }
                        notScannedMsg = notScannedMsg.substring(0, notScannedMsg.length() - 2);
                        jsonResponse.addError("Prior to saving, please scan all D Plates for " + uniqueProject + ", including:</br>" + notScannedMsg);
                    }
                }
            }
        } catch (Exception ex) {
            jsonResponse.addError("Unexpected Error:</br>" + ex.getMessage());
        }

        return jsonResponse;
    }


    /**
     * Validate Save out of Ready for Import queue
     * The Project Status should be DPCR_PROJECT_STATUS_UPLOAD_REQUEST_PENDING
     *
     * @param jsonPost
     * @return
     */
    public JsonResponse validate9011(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();

        try {
            for (Map<String, String> postData : jsonPost.getRows()) {

                String projectStatus = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 2100);

                if (!projectStatus.equals("DPCR_PROJECT_STATUS_UPLOAD_REQUEST_PENDING")) {
                    jsonResponse.addError("Only Project Status of Upload Request Pending  are eligible for upload.");
                }
            }
        } catch (Exception ex) {
            jsonResponse.addError("Unexpected Error:</br>" + ex.getMessage());
        }

        return jsonResponse;
    }

    public JsonResponse validate16(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        int lpCount = 0;
        int clicCount = 0;/*
    String oligo = null;
    String previousOligo = null;*/
        for (Map<String, String> postData : jsonPost.getRows()) {
            //extract wfId to associate data
            Long wfId = Long.parseLong(postData.get("wfId"));
            //Based on the wfId, decide if it is a LP/Clic, and give thems a barcode index
            if (null == wfDataDao.getValue(566, wfId)) {
                clicCount++;
            } else if (null == wfDataDao.getValue(565, wfId)) {
                lpCount++;
            }
            //get the AT status..can save only when status is default...
            try {
                String autoToolJobStatus = wfDataDao.getVarchar2ForWfId(wfId, 115L);
       /* if (!"1 Pending".equalsIgnoreCase(autoToolJobStatus)) {
          jsonResponse.addError("Save allowed only when the selected dilution blocks autotool status is Pending");
        }*/
                //SMBT - 1201 Remove crop restrictions for dilution block to PCR plate in qPCR Assembly queue
       /* oligo = wfDataDao.getVarchar2ForWfId(wfId,7L);
        if (null != previousOligo && !previousOligo.equalsIgnoreCase(oligo)) {
          jsonResponse.addError("Dilution blocks of same crop type should be on a PCR plate");
        }
        previousOligo = oligo;*/
                String ncrCode = postData.get("ncrCode");
                long wfNcrConfigId = 0;

                if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) { // NCR Validation...
                    wfNcrConfigId = Long.parseLong(ncrCode);
                    if ((!"1 Pending".equalsIgnoreCase(autoToolJobStatus)) && wfNcrConfigId == 43) { // Cobra Run Ready Validation
                        jsonResponse.addError("The NCR To: Gencell LC Plate creation is valid only when the autotool job status is 1 Pending");
                    } else if ((!"2 Assay Setup AT Pending".equalsIgnoreCase(autoToolJobStatus)) && wfNcrConfigId == 44) {
                        jsonResponse.addError("The NCR Rearray -qPCR is valid only when the autotool job status is 2 Assay Setup AT Pending");
                    }
                }

            } catch (Exception e) {
                jsonResponse.addError("Unexpected Error:</br>" + e.getMessage());
            }

        }

        //available to occupy -- 22*16 ...each LP needs 2*16 ...each clic needs 1*16...

        if ((lpCount * 64) + (clicCount * 32) > 352) {
            jsonResponse.addError("Not enough room on PCR plate. Please try again after removing few dilution blocks.");
        }
        return jsonResponse;
    }

    public JsonResponse validate17(JsonPost jsonPost) {
        JsonResponse jsonResponse = new JsonResponse();
        Set<String> errorGLs = new HashSet<String>();
        for (Map<String, String> postData : jsonPost.getRows()) {
            try {
                String ncrCode = postData.get("ncrCode");
                long wfNcrConfigId = 0;
                String fakeCleanTube = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 1240L);
                String glPlateNumber = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 27L);
                if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) { // NCR Validation...
                    wfNcrConfigId = Long.parseLong(ncrCode);
                    if (wfNcrConfigId == 113) { // Drop Fake Clean Tube NCR
                        if (!fakeCleanTube.equals("Y")) {
                            jsonResponse.addError("This NCR can be applied only to Fake Clean Tube.");
                        }
                    } else {
                        if (fakeCleanTube.equals("Y")) {
                            jsonResponse.addError("This NCR can not be applied  to Fake Clean Tube.");
                        }
                        // NCR validation for Ncr_118
                        if (wfNcrConfigId == 118) { // Qc-Review to Chip LC Plate
                            String errorGL = allCleanTubesScanned(jsonPost, glPlateNumber);
                            if (errorGL != null) {
                                errorGLs.add(errorGL);
                            }
                        }
                    }
                } else { //  DSA-1364     As ATLAS I need to add logic to prevent a fake plate from being delivered to the sequencing queue
                    if (fakeCleanTube.equals("Y")) {
                        jsonResponse.addError("Please drop the Fake Clean Tube " + postData.get("wfEntityLabel") + " before saving.");
                    }
                }
            } catch (Exception e) {
                jsonResponse.addError("Unexpected Error:</br>" + e.getMessage());
            }
        }
        if (errorGLs.size() != 0) {
            jsonResponse.addError("Please scan all Clean Tubes for " + errorGLs.toString());
        }
        return jsonResponse;
    }

    public JsonResponse validate11(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        for (Map<String, String> postData : jsonPost.getRows()) {
            try {
                String ncrCode = postData.get("ncrCode");
                String glPlate = postData.get("wfEntityLabel");
                long wfNcrConfigId = 0;

                if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) { // NCR Validation...
                    wfNcrConfigId = Long.parseLong(ncrCode);

                    // check for Chip Project
                    boolean isChipProject = false;

                    List<WfAssoc> childEPlates = gbsService.getChildEPlates(glPlate);
                    for (WfAssoc wfAssoc : childEPlates) {
                        if (wfAssoc.getEntityTypeIdentifier() == 52L) {
                            isChipProject = true;
                            break;
                        }
                    }

                    if (wfNcrConfigId == 114) { // To Chip LC Plate Creation  NCR
                        if (!isChipProject) {
                            jsonResponse.addError(glPlate + ": This NCR can be applied only to Chip Plates.");
                        }
                    } else {
                        if (isChipProject) {
                            jsonResponse.addError(glPlate + ": This NCR can not be applied  to Chip Plates.");
                        }
                    }
                }

            } catch (Exception e) {
                jsonResponse.addError("Unexpected Error:</br>" + e.getMessage());
            }

        }

        return jsonResponse;
    }


    public JsonResponse validate24(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();

        for (Map<String, String> postData : jsonPost.getRows()) {
            try {
                String ncrCode = postData.get("ncrCode");
                long wfNcrConfigId = 0;
                Long wfId = Long.parseLong(postData.get("wfId"));
                String analyzedDQuadrant = postData.get("wfEntityLabel");

                if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) {
                    wfNcrConfigId = Long.parseLong(ncrCode);
                    List<WfAssoc> wfAssocList = wfAssocDao.getActiveRightAdjacencies(wfId);
                    for (WfAssoc wa : wfAssocList) {
                        String qcAction = wfDataDao.getVarchar2ForWfId(wa.getToWfId(), 530L); //This checks for any NCRs from Project Review screen.
                        if ("Y".equalsIgnoreCase(qcAction)) {
                            jsonResponse.addError(analyzedDQuadrant + ": Samples on this quadrant have already been remediated.");
                            break;
                        }
                    }
                    // validate NCR 123- To: Re-Extration
                    if (wfNcrConfigId == 123) {
                        String ePlateId = wfDataDao.getVarchar2ForWfId(wfId,1);
                        if(StringUtils.isEmpty(ePlateId)){
                            jsonResponse.addError("Incorrect NCR..");
                        } else{
                            if(gbsService.isChipPlate(ePlateId)){
                                jsonResponse.addError("Please use To: Library Plate Creation NCR for Chip Plate");
                            }
                        }
                    }

                }
            } catch (Exception e) {
                jsonResponse.addError("Unexpected Error:</br>" + e.getMessage());
            }

        }

        return jsonResponse;
    }

    public JsonResponse validate27(JsonPost jsonPost)  {
        JsonResponse jsonResponse = new JsonResponse();
        Set<String> errorGLs = new HashSet<String>();
        for (Map<String, String> postData : jsonPost.getRows()) {
            try {
                String ncrCode = postData.get("ncrCode");
                long wfNcrConfigId = 0;
                String glPlateNumber = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 27L);
                if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) { // NCR Validation...
                    wfNcrConfigId = Long.parseLong(ncrCode);
                    // NCR validation for Ncr_122
                    if(wfNcrConfigId == 122) { // To: qPCR Assembly
                        String errorGL = allCleanTubesScannedForGLSet(jsonPost,glPlateNumber);
                        if(errorGL != null) {
                            errorGLs.add(errorGL);
                        }
                    }
                }
            } catch (Exception e) {
                jsonResponse.addError("Unexpected Error:</br>" + e.getMessage());
            }
        }
        if(errorGLs.size()!= 0){
            jsonResponse.addError("Please scan all Clean Tubes for " +errorGLs.toString() +" Set.");
        }
        return jsonResponse;
    }

    /**
     * Validate Save out of Ready for Design queue
     * This is to prohibit re-grouping and saving prior to the agent picking these up.
     *
     * @param jsonPost
     * @return
     */
    public JsonResponse validate9007(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();

        try {
            for (Map<String, String> postData : jsonPost.getRows()) {

                String pending = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 2072);

                if (pending.equals("Y")) {
                    jsonResponse.addError("Project is pending agent pickup and cannot be re-grouped/saved.");
                }
            }
        } catch (Exception ex) {
            jsonResponse.addError("Unexpected Error:</br>" + ex.getMessage());
        }

        return jsonResponse;
    }

    /**
     * Validate Save out of R: Ready for Design queue
     * This is to prohibit re-grouping and saving prior to the agent picking these up.
     *
     * @param jsonPost
     * @return
     */
    public JsonResponse validate9022(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();

        try {
            for (Map<String, String> postData : jsonPost.getRows()) {

                String pending = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 2119);

                if (pending.equals("Y")) {
                    jsonResponse.addError("Project is pending agent pickup and cannot be re-grouped/saved.");
                }
            }
        } catch (Exception ex) {
            jsonResponse.addError("Unexpected Error:</br>" + ex.getMessage());
        }

        return jsonResponse;
    }

    public JsonResponse validate3000(JsonPost jsonPost) {
        JsonResponse jsonResponse = new JsonResponse();
        if (!areAllNCRs(jsonPost)) {
            jsonResponse = validateAllPlatesScanned(jsonPost, StltaqmanConstants.READY_TO_RECEIVE_STEP_CONFIG_ID);
        }

        return jsonResponse;
    }

    public JsonResponse validate3005(JsonPost jsonPost) {
        JsonResponse jsonResponse = new JsonResponse();
        if (!areAllNCRs(jsonPost)) {
            jsonResponse = validateAllPlatesScanned(jsonPost, StltaqmanConstants.ARRIVED_STEP_CONFIG_ID);
        }

        return jsonResponse;
    }

    public JsonResponse validate3010(JsonPost jsonPost) {
        JsonResponse jsonResponse = new JsonResponse();
        if (!areAllNCRs(jsonPost)) {
            jsonResponse = validateAllPlatesScanned(jsonPost, StltaqmanConstants.SAMPLE_VERIFICATION_STEP_CONFIG_ID);
        }

        return jsonResponse;
    }

    public JsonResponse validate3015(JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        Map<String, List<Long>> ePlateMap = new HashMap();
        Map<String, List<Integer>> ePlatePosMap = new HashMap<String, List<Integer>>();
        List<Long> wfIds = null;

        for (Map<String, String> postData : jsonPost.getRows()) {

            Long wfId = Long.parseLong(postData.get("wfId"));
            String wfEntityLable = postData.get("wfEntityLabel");
            String request = wfEntityLable.substring(2, wfEntityLable.indexOf("-"));
            String ePlateBarcode = postData.get("wfdc3066");
            String biomekDeckPosition = postData.get("wfdc43");

            int pos = 0;
            if ((biomekDeckPosition.equals("PRECIP1")) || (biomekDeckPosition.equals("PRECIP5"))) {
                pos = 1;
            } else if ((biomekDeckPosition.equals("PRECIP2")) || (biomekDeckPosition.equals("PRECIP6"))) {
                pos = 2;
            } else if ((biomekDeckPosition.equals("PRECIP3")) || (biomekDeckPosition.equals("PRECIP7"))) {
                pos = 3;
            } else if ((biomekDeckPosition.equals("PRECIP4")) || (biomekDeckPosition.equals("PRECIP8"))) {
                pos = 4;
            }

            if (null == ePlateMap.get(ePlateBarcode)) {
                wfIds = new ArrayList<>();
            } else {
                wfIds = ePlateMap.get(ePlateBarcode);
            }
            wfIds.add(wfId);
            ePlateMap.put(ePlateBarcode, wfIds);

            List<Integer> positionList = ePlatePosMap.get(ePlateBarcode);
            if (null == positionList) {
                positionList = new ArrayList<Integer>();
            }
            if (positionList.contains(pos)) {
                jsonResponse.addError("You have associated multiple T plates to the same E and index. Please correct the relationship before saving.");
            } else {
                positionList.add(pos);
                ePlatePosMap.put(ePlateBarcode, positionList);
            }

            //check if the ePlateBarcode has already been used.
            List<Wf> ePlateWf = wfDao.findAll(ePlateBarcode);

            if (null != request && !ePlateBarcode.contains(request)) {
                jsonResponse.addError("RequestId " + request + " should contain in EPlate");
            }
            if (null != ePlateWf && ePlateWf.size() > 0) {
                jsonResponse.addError("The " + ePlateBarcode + " has already been used. Please generate a new barcode.");
            }

            //E plate should not exceed more than 4 F plates on it.
            for (Map.Entry<String, List<Long>> entry : ePlateMap.entrySet()) {
                System.out.println(entry.getKey() + "/" + entry.getValue());
                if (entry.getValue().size() >= 5) {
                    jsonResponse.addError(entry.getKey() + " should always have less than or equal to 4 T plates on it.");
                }
            }
        }
        return jsonResponse;
    }

    public JsonResponse validate3018(JsonPost jsonPost) {
        JsonResponse jsonResponse = new JsonResponse();
        //validate NCRs TODO
        return jsonResponse;
    }

    public JsonResponse validate3020(JsonPost jsonPost) {
        JsonResponse jsonResponse = new JsonResponse();
        Map<String, HashMap> plates = new HashMap<String, HashMap>();
        HashSet<String> assaySubstances = new HashSet<String>();
        HashSet<String> jobTypes = new HashSet<String>();
        HashSet<String> cropTypes = new HashSet<String>();
        String crop = null;
        ConcurrentHashMap<String, Integer> assaySubstanceOccurrenceMap = new ConcurrentHashMap<String, Integer>();

        boolean isNcr=false;
        for (Map<String, String> postData : jsonPost.getRows()) {
            String ncrCode = postData.get("ncrCode");
            long wfNcrConfigId = 0;

            if (ncrCode.length() != 0 && StringUtils.isNumeric(ncrCode)) { // NCR Validation...
                wfNcrConfigId = Long.parseLong(ncrCode);
                if(wfNcrConfigId==3005L)
                {
                    isNcr=true;
                }
            }
        }

        if(isNcr==false) {
            // Get source plate and assay substance for each pcr plate
            for (Map<String, String> jsonPostData : jsonPost.getRows()) {

                if (jsonPostData.get("wfdc3077").equals(null)) {
                    jsonResponse.addError("Error: A plate in this request is missing a job type.");
                    return jsonResponse;
                }

                HashMap<String, String> plateData = new HashMap<String, String>();
                Long pcrPlateWfId = Long.parseLong(jsonPostData.get("wfId"));
                String pcrPlateLabel = jsonPostData.get("wfEntityLabel");
                jobTypes.add(jsonPostData.get("wfdc3077"));

                try {
                    String assaySubstance = wfDataDao.getVarchar2ForWfId(pcrPlateWfId, StltaqmanConstants.LAN_NAME_DATA_CONFIG_ID);
                    crop = wfDataDao.getVarchar2ForWfId(pcrPlateWfId, StltaqmanConstants.CROP_DATA_CONFIG_ID);

                    assaySubstanceOccurrenceMap.computeIfPresent(assaySubstance.toUpperCase(), (key, value) -> value + 1);
                    assaySubstanceOccurrenceMap.putIfAbsent(assaySubstance.toUpperCase(), 1);

                    assaySubstances.add(assaySubstance);
                    cropTypes.add(crop);

                    plateData.put("wfId", pcrPlateWfId.toString());
                    plateData.put("jobType", jsonPostData.get("wfdc3077"));
                    plateData.put("assay", assaySubstance.toUpperCase());
                    plateData.put("crop", crop);

                    try {
                        if (crop.equals("SOYBEANS")) {
                            crop = "SOY";
                        }

                        List<Long> assayControlPlates = wfGridDataDao.getWfIdForVarchar2(FORECASTED_DATA_STEP_CONFIG_ID, CONTROL_PLATE_ENTITY_ID, "%" + crop + "_CTRL_AP%", LAN_NAME_GRID_DATA_TYPE_ID, "%" + assaySubstance + "%");
                        List<Long> assayPremixPlates = wfGridDataDao.getWfIdForVarchar2(FORECASTED_DATA_STEP_CONFIG_ID, PREMIX_PLATE_ENTITY_ID, "%" + crop + "_WS%", LAN_NAME_GRID_DATA_TYPE_ID, "%" + assaySubstance + "%");
                        List<Long> offlineAssayControlPlates = wfGridDataDao.getWfIdForVarchar2(FORECASTED_DATA_STEP_CONFIG_ID, CONTROL_PLATE_ENTITY_ID, "%" + crop + "_OFFLINE_CTRL_AP%", LAN_NAME_GRID_DATA_TYPE_ID, "%" + assaySubstance + "%");

                        if (assayControlPlates.size() < 1 && jsonPostData.get("wfdc3077").toUpperCase().contains("RAPTOR")) {
                            jsonResponse.addError("Error: No raptor control plate record exists for assay " + assaySubstance);
                        }

                        if (offlineAssayControlPlates.size() < 1 && jsonPostData.get("wfdc3077").toUpperCase().contains("OFFLINE")) {
                            jsonResponse.addError("Error: No offline control plate record exists for assay " + assaySubstance);
                        }

                        if (assayPremixPlates.size() < 1) {
                            jsonResponse.addError("Error: No premix record exists for assay " + assaySubstance);
                        }

                    } catch (Exception ex) {
                        jsonResponse.addError("Error locating control and premix plates for " + assaySubstance);
                    }

                    plates.put(pcrPlateLabel, plateData);
                } catch (Exception ex) {
                    jsonResponse.addError(ex.toString());
                    return jsonResponse;
                }
            }

            // Reject save if there are too many assay substances
            if (assaySubstances.size() > 24) {
                jsonResponse.addError("Cannot include more than 24 distinct assays");
            }

            if (jobTypes.size() > 2 || jobTypes.size() < 1) {
                jsonResponse.addError("Invalid job types: Make sure each plate is assigned a job type. Only one Raptor type is allowed.");
            }

            if (jobTypes.contains("Raptor1") && jobTypes.contains("Raptor2")) {
                jsonResponse.addError("Invalid job types: Cannot have both Raptor1 and Raptor2 job types.");
            }

            if (jobTypes.contains("Raptor1") && assaySubstances.size() > 12) {
                jsonResponse.addError("Error: You may not have more than 12 distinct assays when using 1 Tempest on Raptor");
            }

            // Only allow one crop type
            if (cropTypes.size() > 1) {
                jsonResponse.addError("You may only select one crop type.");
            }
        /*
        if (!areAllNCRs(jsonPost)) {
            JsonResponse allNcrJsonResponse = validateAllPlatesScanned(jsonPost, StltaqmanConstants.PRE_PCR_ASSEMBLY_STEP_CONFIG_ID);
            if (allNcrJsonResponse.getErrors().size() > 0) {
                jsonResponse.addError(allNcrJsonResponse.getErrors().get(0));
            }
        }
        */
        }
        return jsonResponse;
    }

    public JsonResponse validateAllPlatesScanned(JsonPost jsonPost, Long wfStepConfigId) {
        JsonResponse jsonResponse = new JsonResponse();
        Set<String> uniqueProjects = new HashSet<String>();
        try {

            for (Map<String, String> postData : jsonPost.getRows()) {
                String plateId = postData.get("wfEntityLabel");
                String project = plateId.split("-")[0];
                uniqueProjects.add(project);
            }

            for (String uniqueProject : uniqueProjects) {
                //Get the plates in queue for the project.
                List<String> plateList = new ArrayList<>();
                List<String> notScannedPlates = new ArrayList<>();
                if (wfStepConfigId != StltaqmanConstants.PRE_PCR_ASSEMBLY_STEP_CONFIG_ID) {
                    plateList = wfDao.findEntitiesLike(StltaqmanConstants.PLATE_ENTITY_ID, " and wf_status='I' and wf_step_config_id=" + wfStepConfigId + " and wf_entity_label like  '" +
                            uniqueProject + "%'");
                } else {
                    String entityLike = "'" + uniqueProject.replace(uniqueProject.charAt(1), '%') + "%'";
                    String whereClause = " wf_status='I' and wf_entity_label like  " + entityLike;
                    plateList = wfDao.findEntitiesLike(whereClause);
                }

                for (String plate : plateList) {
                    // all Plates for the project must be scanned
                    boolean plateInProject = false;
                    for (Map<String, String> postData1 : jsonPost.getRows()) {
                        if (plate.equals(postData1.get("wfEntityLabel"))) {
                            plateInProject = true;
                            break;
                        }
                    }
                    if (!plateInProject) {
                        notScannedPlates.add(plate);
                    }
                }

                String notScannedMsg = "";
                if (notScannedPlates.size() > 0) {
                    for (String plate : notScannedPlates) {
                        notScannedMsg += plate + ", ";
                    }
                    notScannedMsg = notScannedMsg.substring(0, notScannedMsg.length() - 2);
                    jsonResponse.addError("Prior to saving, please scan all  Plates for " + uniqueProject + ", including:</br>" + notScannedMsg);
                }
            }
        } catch (Exception ex) {
            jsonResponse.addError("Unexpected Error:</br>" + ex.getMessage());
        }


        return jsonResponse;
    }

    private boolean areAllNCRs(JsonPost jsonPost) {
        JsonResponse jsonResponse = new JsonResponse();
        boolean isAllNCRS = true;

        for (Map<String, String> postData : jsonPost.getRows()) {
            try {
                String ncrCode = postData.get("ncrCode");
                if (ncrCode.length() == 0 && StringUtils.isNumeric(ncrCode)) {
                    isAllNCRS = false;
                    break;
                }
            } catch (Exception ex) {
                jsonResponse.addError("Unexpected Error:</br>" + ex.getMessage());
            }
        }
        return isAllNCRS;
    }

    private String allCleanTubesScanned(JsonPost jsonPost, String glPlateNumber) {
        int cleanTubeCount = 4;
        for (Map<String, String> postData : jsonPost.getRows()) {
            try {
                String glPlateId = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 27L);
                if (glPlateNumber.equalsIgnoreCase(glPlateId)) {
                    cleanTubeCount = cleanTubeCount - 1;
                }
            } catch (Exception e) {
            }
        }
        if (cleanTubeCount != 0) {
            return glPlateNumber;
        } else {
            return null;
        }
    }

    private boolean isSingleCyclingCondition(JsonPost jsonPost) {

        Set<String> cyclingConditions = new HashSet<String>();
        boolean isValid = true;

        for (Map<String, String> postData : jsonPost.getRows()) {
            //extract wfId to associate data
            Long wfId = Long.parseLong(postData.get("wfId"));
            cyclingConditions.add(wfService.getStringValue(StltaqmanConstants.CYCLING_CONDITIONS_DATA_CONFIG_ID, wfId));
        }
        if (cyclingConditions.size() > 1) {
            isValid = false;
        }
        return isValid;

    }

    private String allCleanTubesScannedForGLSet(JsonPost jsonPost,String glPlateNumber){

        String glPlateNumberBase = glPlateNumber.substring(0, glPlateNumber.indexOf("-"));
        //Get count of active cleantubes associated with the GLBase
        List<WfAssoc> rightAssocs = wfAssocDao.getActiveCleanTubeForDilBlock(glPlateNumberBase);
        int cleanTubeCount=rightAssocs.size();
        for (Map<String, String> postData : jsonPost.getRows()) {
            try {
                String glPlateId = wfDataDao.getVarchar2ForWfId(Long.parseLong(postData.get("wfId")), 27L);
                String glPlateIdBase = glPlateId.substring(0, glPlateId.indexOf("-"));
                if(glPlateNumberBase.equalsIgnoreCase(glPlateIdBase)){
                    cleanTubeCount = cleanTubeCount -1;
                }
            } catch (Exception e) {
            }
        }
        if(cleanTubeCount != 0){
            return glPlateNumberBase;
        }else{
            return null;
        }
    }

    private List<String> isNcrReasonPresent(JsonPost jsonPost){
            List<String> plateList = new ArrayList<String>();
            for (Map<String, String> postData : jsonPost.getRows()) {
                if(StringUtils.isNotEmpty(postData.get("ncrCode")) && StringUtils.isEmpty(postData.get("ncrReason"))){
                    plateList.add(postData.get("wfEntityLabel"));
                }
            }
        return plateList;
    }
}
