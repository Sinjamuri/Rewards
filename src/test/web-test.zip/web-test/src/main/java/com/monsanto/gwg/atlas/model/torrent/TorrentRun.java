package com.monsanto.gwg.atlas.model.torrent;

import java.util.Date;

public class TorrentRun {
  private Long torrentRunId;
  private String torrentRunHost;
  private String torrentRunName;
  private Date indexTs;
  private String torrentRunStatus;
  private String archivedPath;

  public Long getTorrentRunId() {
    return torrentRunId;
  }

  public void setTorrentRunId(Long torrentRunId) {
    this.torrentRunId = torrentRunId;
  }

  public String getTorrentRunHost() {
    return torrentRunHost;
  }

  public void setTorrentRunHost(String torrentRunHost) {
    this.torrentRunHost = torrentRunHost;
  }

  public String getTorrentRunName() {
    return torrentRunName;
  }

  public void setTorrentRunName(String torrentRunName) {
    this.torrentRunName = torrentRunName;
  }

  public Date getIndexTs() {
    return indexTs;
  }

  public void setIndexTs(Date indexTs) {
    this.indexTs = indexTs;
  }

  public String getTorrentRunStatus() {
    return torrentRunStatus;
  }

  public void setTorrentRunStatus(String torrentRunStatus) {
    this.torrentRunStatus = torrentRunStatus;
  }

  public String getArchivedPath() {
    return archivedPath;
  }

  public void setArchivedPath(String archivedPath) {
    this.archivedPath = archivedPath;
  }
}
