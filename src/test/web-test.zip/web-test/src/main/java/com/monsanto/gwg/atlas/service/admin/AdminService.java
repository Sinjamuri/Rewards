package com.monsanto.gwg.atlas.service.admin;


import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.json.admin.*;
import com.monsanto.gwg.atlas.model.admin.WfGraphLink;
import com.monsanto.gwg.atlas.model.admin.WfGraphNode;
import com.monsanto.gwg.atlas.model.admin.WfGraphNodeFactory;
import com.monsanto.gwg.atlas.model.core.*;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.service.core.WfService;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.lang.reflect.Method;
import java.util.*;

@Service
public class AdminService {

  private static final Logger LOG = LoggerFactory.getLogger(AdminService.class);

  @Autowired
  private JdbcTemplate jdbcTemplate;

    @Autowired
    private WfConfigDao wfConfigDao;

    @Autowired
    private WfStepConfigDao wfStepConfigDao;

    @Autowired
    private WfDataConfigDao wfDataConfigDao;

    @Autowired
    private WfEntityTypeDao wfEntityTypeDao;

    @Autowired
    private WfRefConfigDao wfRefConfigDao;

    @Autowired
    private WfService wfService;

    @Autowired
    private WfStepAssocDao wfStepAssocDao;

    @Autowired
    private WfStepAssocVwDao wfStepAssocVwDao;

    @Autowired
    private WfGridDataTypeDao wfGridDataTypeDao;

    @Autowired
    private WfStepDataConfigDao wfStepDataConfigDao;

    @Autowired
    private WfConfigPropertyDao wfConfigPropertyDao;


    public int executeSqlUpdate(String sql) {
    // execute administrator sql against schema
    return jdbcTemplate.update(sql);
  }

    public boolean isValidNewWfConfig(JsonWfConfig jsonWfConfig, JsonResponse jsonResponse) {
        if( jsonWfConfig.getWorkflowDomain() == null || jsonWfConfig.getWorkflowDomain().equals( "" )) {
            jsonResponse.addError( "Workflow domain cannot be empty.");
            return false;
        }

        if( jsonWfConfig.getWorkflowName() == null || jsonWfConfig.getWorkflowName().equals( "" )) {
            jsonResponse.addError( "Workflow name cannot be empty.");
            return false;
        }

        for(WfConfig config : wfConfigDao.findAll() ) {
           if( config.getWfConfigDomain().compareToIgnoreCase( jsonWfConfig.getWorkflowDomain() ) == 0) {
               jsonResponse.addError( "Workflow domain name must be unique, " + jsonWfConfig.getWorkflowDomain() + " is already used.");
               return false;
           }
        }

        return true;
    }

    public void addNewWfConfig(JsonWfConfig jsonWfConfig, JsonResponse jsonResponse) {
        WfConfig newWfConfig = new WfConfig();
        newWfConfig.setWfConfigDomain( jsonWfConfig.getWorkflowDomain().toLowerCase() );
        newWfConfig.setWfConfigName(jsonWfConfig.getWorkflowName());
        newWfConfig.setWfConfigAdmins( StringUtils.join( jsonWfConfig.getWorkflowAdmins(), ",") );
        newWfConfig.setCreateUser( jsonWfConfig.getCreateUser() );

        try {
            wfConfigDao.insert( newWfConfig );
        } catch( DataAccessException dae) {
            jsonResponse.addError( "ERROR: Exception thrown when adding workflow.");
            return;
        }

        jsonResponse.addMessage( "Workflow successfully added.");
    }

    public boolean isValidNewWfDataConfig(JsonWfDataConfig jsonWfDataConfig, JsonResponse jsonResponse){
        if (jsonWfDataConfig.getWfConfigId() == null){
            jsonResponse.addError("Workflow Config ID cannot be empty");
            return false;
        }

        if (jsonWfDataConfig.getWfDataLabel() == null || jsonWfDataConfig.getWfDataLabel().equals( "" )){
            jsonResponse.addError("Data Label cannot be empty");
            return false;
        }

        if (jsonWfDataConfig.getWfDataConfigType() == null || jsonWfDataConfig.getWfDataConfigType().equals( "" )){
            jsonResponse.addError("Data Config Type cannot be empty");
            return false;
        }

        return true;
    }

    public WfDataConfig addNewWfDataConfig(JsonWfDataConfig jsonWfDataConfig){
        WfDataConfig newWfDataConfig = new WfDataConfig();
        newWfDataConfig.setWfConfigId(jsonWfDataConfig.getWfConfigId());
        newWfDataConfig.setWfDataConfigLabel(jsonWfDataConfig.getWfDataLabel());
        newWfDataConfig.setWfDataConfigSearchable(jsonWfDataConfig.getWfDataConfigSearchable());
        newWfDataConfig.setWfDataConfigType(jsonWfDataConfig.getWfDataConfigType());
        newWfDataConfig.setCreateUser(jsonWfDataConfig.getCreateUser());

        wfDataConfigDao.insert(newWfDataConfig);

        return newWfDataConfig;
    }

    private boolean isValidNewWfStepConfig( WfStepConfig newWfStepConfig) {

        return true;
    }


    public WfEntityType addNewWfEntityType(JsonWfEntityType jsonWfEntityType){
        WfEntityType newWfEntityType = new WfEntityType();

        newWfEntityType.setWfConfigId(jsonWfEntityType.getWfConfigId());
        newWfEntityType.setWfEntityType(jsonWfEntityType.getWfEntityType());
        newWfEntityType.setSortKey(jsonWfEntityType.getSortKey());
        newWfEntityType.setCreateUser(jsonWfEntityType.getCreateUser());
        newWfEntityType.setRowSize(jsonWfEntityType.getRowSize());
        newWfEntityType.setColSize(jsonWfEntityType.getColSize());

        wfEntityTypeDao.save(newWfEntityType);

        return newWfEntityType;
    }


    public WfStepConfig saveWfStepConfigAndDataConfigs( WfStepConfig wfStepConfig, List<WfStepDataConfig> wfStepDataConfigs, String createUser ) {
        if( isValidNewWfStepConfig( wfStepConfig )) {
            wfStepConfig.setCreateUser( createUser );
            wfStepConfig = wfStepConfigDao.save( wfStepConfig );

            for( WfStepDataConfig wfStepDataConfig : wfStepDataConfigs ) {
                wfStepDataConfig.setWfStepConfigId( wfStepConfig.getWfStepConfigId() );
                wfStepDataConfig.setCreateUser( createUser );
                wfStepDataConfigDao.save( wfStepDataConfig );
            }

            return wfStepConfig;
        }

        return null;
    }

      public WfStepConfig addNewWfStepConfig( WfStepConfig wfStepConfig ) {
        if( isValidNewWfStepConfig( wfStepConfig ) ) {
            return wfStepConfigDao.save(wfStepConfig);
        }

        return null;
    }

    public WfRefConfig addNewWfRefConfig (JsonWfRefConfig jsonWfRefConfig){
        WfRefConfig newWfRefConfig = new WfRefConfig();
        newWfRefConfig.setWfConfigId(jsonWfRefConfig.getWfConfigId());
        newWfRefConfig.setWfRefConfigParentId(jsonWfRefConfig.getWfRefConfigParentId());
        newWfRefConfig.setWfRefActive(jsonWfRefConfig.getWfRefActive());
        newWfRefConfig.setWfRefKey(jsonWfRefConfig.getWfRefKey());
        newWfRefConfig.setWfRefVarchar2(jsonWfRefConfig.getWfRefVarchar2());
        newWfRefConfig.setWfRefNumber(jsonWfRefConfig.getWfRefNumber());
        newWfRefConfig.setWfRefUiSortKey(jsonWfRefConfig.getWfRefUISortKey());
        newWfRefConfig.setComments(jsonWfRefConfig.getComments());
        newWfRefConfig.setCreateUser(jsonWfRefConfig.getCreateUser());

        wfRefConfigDao.insert(newWfRefConfig);
        return newWfRefConfig;
    }

    public java.util.List<WfGraphNode> getWfGraphNodes( long wfConfigId ) {
        List<WfStepAssocVw> wfStepAssocs = wfService.findAllWfStepAssocForWfConfig(wfConfigId);
        WfGraphNodeFactory wfGraphNodeFactory = new WfGraphNodeFactory();

        for( WfStepAssocVw wfStepAssoc : wfStepAssocs ) {
            WfGraphNode startNode = wfGraphNodeFactory.getGraphNode(wfStepAssoc.getStartWfType(), wfStepAssoc.getStartId());
            if( startNode.getNodeDescription() == null ) {
                startNode.setNodeDescription( wfStepAssoc.getStartName() );
            }
            if( startNode.getGraphNodeId() == null) {
                startNode.setGraphNodeId( getWfGraphNodeId( startNode ));
            }

            WfGraphNode nextNode = null;
            if( wfStepAssoc.getNextId() > Long.MIN_VALUE && !wfStepAssoc.getStatus().equalsIgnoreCase("I") ) {
                nextNode = wfGraphNodeFactory.getGraphNode( wfStepAssoc.getNextWfType(), wfStepAssoc.getNextId() );
                if( nextNode.getGraphNodeId() == null ) {
                    nextNode.setGraphNodeId( getWfGraphNodeId( nextNode ));
                }
            }

            if( nextNode != null ) {
                WfGraphLink wfGraphLink = new WfGraphLink();
                wfGraphLink.setWfStepAssocId(wfStepAssoc.getWfStepAssocId());
                wfGraphLink.setWfSourceGraphNodeId( startNode.getGraphNodeId() );
                wfGraphLink.setWfTargetGraphNodeId( nextNode.getGraphNodeId() );
                wfGraphLink.setStatus( wfStepAssoc.getStatus() );

                startNode.addChildNode( wfGraphLink, nextNode );
            }
        }

        return wfGraphNodeFactory.getOrderedGraphNodes();
    }


    public List<WfEntityType> findAllWfEntityType(Long wfConfigId){
        return wfEntityTypeDao.findWfConfigId(wfConfigId);
    }

    public List<WfGridDataType> findWfGridDataType (Long wfConfigId){
        return wfGridDataTypeDao.findAll("wf_config_id = ?", wfConfigId);
    }

    public void deleteWfRefConfig (Long wfRefConfigId){
        wfRefConfigDao.delete(wfRefConfigId);
    }

    public void deleteWfEntityType (Long wfEntityTypeId){
        wfEntityTypeDao.delete(wfEntityTypeId);
    }

    public void deleteWfDataConfig (Long wfDataConfigId){
        wfDataConfigDao.delete(wfDataConfigId);
    }

    public void updateWfEntityType (JsonWfEntityType jsonWfEntityType){
        WfEntityType wfEntityType = new WfEntityType();

        wfEntityType.setWfEntityTypeId(jsonWfEntityType.getWfEntityTypeId());
        wfEntityType.setWfConfigId(jsonWfEntityType.getWfConfigId());
        wfEntityType.setWfEntityType(jsonWfEntityType.getWfEntityType());
        wfEntityType.setSortKey(jsonWfEntityType.getSortKey());
        wfEntityType.setRowSize(jsonWfEntityType.getRowSize());
        wfEntityType.setColSize(jsonWfEntityType.getColSize());
        wfEntityTypeDao.update(wfEntityType);
    }

    public void updateWfRefConfig (JsonWfRefConfig jsonWfRefConfig){
        WfRefConfig wfRefConfig = new WfRefConfig();

        wfRefConfig.setWfConfigId(jsonWfRefConfig.getWfConfigId());
        wfRefConfig.setWfRefConfigId(jsonWfRefConfig.getWfRefConfigId());
        wfRefConfig.setWfRefConfigParentId(jsonWfRefConfig.getWfRefConfigParentId());
        wfRefConfig.setWfRefKey(jsonWfRefConfig.getWfRefKey());
        wfRefConfig.setWfRefVarchar2(jsonWfRefConfig.getWfRefVarchar2());
        wfRefConfig.setWfRefNumber(jsonWfRefConfig.getWfRefNumber());
        wfRefConfig.setWfRefActive(jsonWfRefConfig.getWfRefActive());
        wfRefConfig.setWfRefUiSortKey(jsonWfRefConfig.getWfRefUISortKey());
        wfRefConfig.setComments(jsonWfRefConfig.getComments());
        wfRefConfig.setCreateUser(jsonWfRefConfig.getCreateUser());

        wfRefConfigDao.update(wfRefConfig);
    }

    public void updateWfDataConfig (JsonWfDataConfig jsonWfDataConfig){
        WfDataConfig wfDataConfig = new WfDataConfig();

        wfDataConfig.setWfDataConfigId(jsonWfDataConfig.getWfDataConfigId());
        wfDataConfig.setWfDataConfigLabel(jsonWfDataConfig.getWfDataLabel());
        wfDataConfig.setWfDataConfigSearchable(jsonWfDataConfig.getWfDataConfigSearchable());

        wfDataConfigDao.update(wfDataConfig);
    }


    public void updateWfStepAssocs( java.util.List<WfGraphLink> wfGraphLinks, long wfConfigId, String createUser ) throws Exception {
        for( WfGraphLink wfGraphLink : wfGraphLinks ) {
            WfStepAssoc wfStepAssoc = convertWfGraphLinkToWfStepAssoc( wfGraphLink, wfConfigId );
            wfStepAssoc.setCreateUser( createUser );

            if( wfStepAssoc.getWfStepAssocId() != null ) {
                wfStepAssocDao.updateStatus( wfStepAssoc );
            } else {
                String sourceNodeGraphId = wfGraphLink.getWfSourceGraphNodeId();
                String sourceNodeGraphIdTokens[] = sourceNodeGraphId.split( WF_GRAPH_NODE_ID_DELIMITER );
                String nextNodeGraphId = wfGraphLink.getWfTargetGraphNodeId();
                String nextNodeGraphIdTokens[] = nextNodeGraphId.split( WF_GRAPH_NODE_ID_DELIMITER );

                WfStepAssocVw existingWfStepAssocVw = wfStepAssocVwDao.find(
                        "START_WF_TYPE = ? AND START_ID = ? AND NEXT_WF_TYPE = ? AND NEXT_ID = ?",
                       sourceNodeGraphIdTokens[0], sourceNodeGraphIdTokens[1],
                        nextNodeGraphIdTokens[0], nextNodeGraphIdTokens[1]
                );
                if( existingWfStepAssocVw != null) {
                    wfStepAssoc.setWfStepAssocId( existingWfStepAssocVw.getWfStepAssocId() );
                    wfStepAssocDao.updateStatus( wfStepAssoc );
                } else {
                    wfStepAssocDao.insert( wfStepAssoc );
                }
            }
        }
    }

    private final static String WF_GRAPH_NODE_ID_DELIMITER = "_";

    private WfStepAssoc convertWfGraphLinkToWfStepAssoc( WfGraphLink wfGraphLink, long wfConfigId ) throws Exception{
        WfStepAssoc wfStepAssoc = new WfStepAssoc();
        wfStepAssoc.setWfConfigId( wfConfigId );
        wfStepAssoc.setWfStepAssocId( wfGraphLink.getWfStepAssocId() );

        String sourceNodeGraphId = wfGraphLink.getWfSourceGraphNodeId();
        String sourceNodeGraphIdTokens[] = sourceNodeGraphId.split( WF_GRAPH_NODE_ID_DELIMITER );
        Method sourceSetterMethod = WfStepAssoc.class.getDeclaredMethod( "setWf" + WordUtils.capitalize( sourceNodeGraphIdTokens[0].toLowerCase() ) + "ConfigId", Long.class );
        sourceSetterMethod.invoke( wfStepAssoc, Long.parseLong( sourceNodeGraphIdTokens[1] ) );

        String nextNodeGraphId = wfGraphLink.getWfTargetGraphNodeId();
        String nextNodeGraphIdTokens[] = nextNodeGraphId.split( WF_GRAPH_NODE_ID_DELIMITER );
        Method nextSetterMethod = WfStepAssoc.class.getDeclaredMethod( "setNextWf" + WordUtils.capitalize( nextNodeGraphIdTokens[0].toLowerCase() ) + "ConfigId", Long.class );
        nextSetterMethod.invoke( wfStepAssoc, Long.parseLong( nextNodeGraphIdTokens[1] ) );

        wfStepAssoc.setStatus( wfGraphLink.getStatus() );

        return wfStepAssoc;
    }

    public String getWfGraphNodeId(WfGraphNode wfGraphNode) {
        return wfGraphNode.getNodeInternalType() + WF_GRAPH_NODE_ID_DELIMITER + wfGraphNode.getNodeInternalId();
    }

    public List<String> getWfViews(long wfConfigId, HttpSession session) {
        WfConfig wfConfig = wfService.findWfConfig( wfConfigId );

        String relativeViewsPath = File.separator + "WEB-INF" + File.separator + "views" + File.separator;
        String relativeDomainViewsPath = relativeViewsPath + wfConfig.getWfConfigDomain() + File.separator;
        String realViewsPath = session.getServletContext().getRealPath( relativeDomainViewsPath );

        java.io.File realViewsDir = new java.io.File( realViewsPath );
        java.util.ArrayList<String> relativeDomainViewFilePaths = new ArrayList<String>();

        if( realViewsDir.exists() ) {
            String[] viewFileExtensions = new String[] { "jsp" };

            java.util.Collection<java.io.File> viewFiles = FileUtils.listFiles(realViewsDir, viewFileExtensions, true);
            for( java.io.File viewFile : viewFiles ) {
                String relativeViewFilePathWithExtension = viewFile.getAbsolutePath().replace( realViewsPath + File.separator, "" );
                String relativeViewFilePath = FilenameUtils.removeExtension(relativeViewFilePathWithExtension);
                relativeDomainViewFilePaths.add( relativeViewFilePath );
            }
        }

        return relativeDomainViewFilePaths;
    }

    public List<WfStepDataConfig> getWfStepDataConfigsForStep( Long wfStepId ) {
        return wfStepDataConfigDao.findAll("WF_STEP_CONFIG_ID = ?", wfStepId);
    }

    public void deleteWfStepDataConfig( WfStepDataConfig wfStepDataConfig ) {
        wfStepDataConfigDao.delete( wfStepDataConfig );
    }

    public WfGridDataType addNewWfGridDataType(JsonWfGridDataType jsonWfGridDataType) {
        WfGridDataType wfGridDataType = new WfGridDataType();

        wfGridDataType.setWfConfigId(jsonWfGridDataType.getWfConfigId());
        wfGridDataType.setWfGridDataType(jsonWfGridDataType.getWfGridDataType());
        wfGridDataType.setDataType(jsonWfGridDataType.getDataType());
        wfGridDataType.setSortKey(jsonWfGridDataType.getSortKey());
        wfGridDataType.setNumberFormat(jsonWfGridDataType.getNumberFormat());
        wfGridDataType.setTimestampFormat(jsonWfGridDataType.getTimestampFormat());
        wfGridDataType.setIconPng(jsonWfGridDataType.getIconPng());
        wfGridDataType.setEnabled(jsonWfGridDataType.getEnabled().equals("Y"));

        wfGridDataTypeDao.save(wfGridDataType);

        return wfGridDataType;
    }

    public String getSequenceIds(Long numberOfIds) {

        String sequenceIdsList = wfConfigDao.getSequenceIds(numberOfIds);

        return sequenceIdsList;
    }

    public WfConfigProperty addNewWfConfigProperty(JsonWfConfigProperty jsonWfConfigProperty){
        WfConfigProperty newWfConfigProperty = new WfConfigProperty();

        newWfConfigProperty.setRefKey(jsonWfConfigProperty.getRefKey());
        newWfConfigProperty.setWfConfigId(jsonWfConfigProperty.getWfConfigId());
        newWfConfigProperty.setKey(jsonWfConfigProperty.getKey());
        newWfConfigProperty.setValueVarchar2(jsonWfConfigProperty.getValueVarchar2());
        newWfConfigProperty.setValueTimestamp(jsonWfConfigProperty.getValueTimestamp());
        newWfConfigProperty.setValueBlob(jsonWfConfigProperty.getValueBlob());
        newWfConfigProperty.setValueNumber(jsonWfConfigProperty.getValueNumber());
        newWfConfigProperty.setCreateTs(jsonWfConfigProperty.getCreateTs());
        newWfConfigProperty.setUpdateTs(jsonWfConfigProperty.getUpdateTs());

        wfConfigPropertyDao.insert(newWfConfigProperty);

        return newWfConfigProperty;
    }

    public void deleteWfConfigProperty(Long propertyId) {

        wfConfigPropertyDao.delete(propertyId);
    }

    public void updateWfConfigProperty(JsonWfConfigProperty jsonWfConfigProperty) {

        WfConfigProperty newWfConfigProperty = new WfConfigProperty();

        newWfConfigProperty.setPropertyId(jsonWfConfigProperty.getPropertyId());
        newWfConfigProperty.setRefKey(jsonWfConfigProperty.getRefKey());
        newWfConfigProperty.setWfConfigId(jsonWfConfigProperty.getWfConfigId());
        newWfConfigProperty.setKey(jsonWfConfigProperty.getKey());
        newWfConfigProperty.setValueVarchar2(jsonWfConfigProperty.getValueVarchar2());
        newWfConfigProperty.setValueTimestamp(jsonWfConfigProperty.getValueTimestamp());
        newWfConfigProperty.setValueBlob(jsonWfConfigProperty.getValueBlob());
        newWfConfigProperty.setValueNumber(jsonWfConfigProperty.getValueNumber());
        newWfConfigProperty.setCreateTs(jsonWfConfigProperty.getCreateTs());
        newWfConfigProperty.setUpdateTs(jsonWfConfigProperty.getUpdateTs());

        wfConfigPropertyDao.update(newWfConfigProperty);
    }


    public void saveBlobData(byte[] data, String key, Long wfConfigId) {
        WfConfigProperty config = new WfConfigProperty();
        config.setKey(key);
        config.setWfConfigId(wfConfigId);
        config.setValueBlob(data);
        wfConfigPropertyDao.insert(config);
    }

    public byte[] getWfConfigBlobData(Long propertyId) {
       return wfConfigPropertyDao.findBlobValueByKeyAndConfig(1L, propertyId);

    }

    public List<WfConfigProperty> getPreviouslyUploadedFiles(String key) {
        return wfConfigPropertyDao.findByKey(key);
    }

}
