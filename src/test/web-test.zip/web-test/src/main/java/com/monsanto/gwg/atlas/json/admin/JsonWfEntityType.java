package com.monsanto.gwg.atlas.json.admin;

/**
 * Created by regama on 6/18/14.
 */
public class JsonWfEntityType {
    private Long wfConfigId;
    private String wfEntityType;
    private Long wfEntityTypeId;
    private Integer sortKey;
    private String createUser;
    private Integer rowSize;
    private Integer colSize;

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public String getWfEntityType() {
        return wfEntityType;
    }

    public void setWfEntityType(String wfEntityType) {
        this.wfEntityType = wfEntityType;
    }

    public Integer getSortKey() {
        return sortKey;
    }

    public void setSortKey(Integer sortKey) {
        this.sortKey = sortKey;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Integer getRowSize() {
        return rowSize;
    }

    public void setRowSize(Integer rowSize) {
        this.rowSize = rowSize;
    }

    public Integer getColSize() {
        return colSize;
    }

    public void setColSize(Integer colSize) {
        this.colSize = colSize;
    }

    public Long getWfEntityTypeId() {
        return wfEntityTypeId;
    }

    public void setWfEntityTypeId(Long wfEntityTypeId) {
        this.wfEntityTypeId = wfEntityTypeId;
    }
}
