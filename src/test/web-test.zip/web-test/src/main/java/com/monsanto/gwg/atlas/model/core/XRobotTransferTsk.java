package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.math.BigDecimal;

/**
 * Created by regama on 3/20/15.
 */
public class XRobotTransferTsk {
    @DbColumn(field = "robot_trnsfr_tsk_id")
    private Long robotTrnsfrTskId;
    @DbColumn(field = "robot_job_id")
    private Long robotJobId;
    @DbColumn(field = "robot_trnsfr_type_id")
    private String robotTrnsfrTypeId;
    @DbColumn(field = "source_plate_type_id")
    private String sourcePlateTypeId;
    @DbColumn(field = "source_plate_name")
    private String sourcePlateName;
    @DbColumn(field = "source_well")
    private String sourceWell;
    @DbColumn(field = "target_plate_type_id")
    private String targetPlateTypeId;
    @DbColumn(field = "target_plate_name")
    private String targetPlateName;
    @DbColumn(field = "target_well")
    private String targetWell;
    @DbColumn(field = "process_by_quadrant")
    private String processByQuadrant;
    @DbColumn(field = "volume")
    private Double volume;
    //private BigDecimal volume;
    @DbColumn(field = "group_name")
    private String groupName;
    @DbColumn(field = "status")
    private String status;
    @DbColumn(field = "transfer_size")
    private Long transferSize;
    @DbColumn(field = "total_volume")
    private Long totalVolume;

    public Long getRobotTrnsfrTskId() {
        return robotTrnsfrTskId;
    }

    public void setRobotTrnsfrTskId(Long robotTrnsfrTskId) {
        this.robotTrnsfrTskId = robotTrnsfrTskId;
    }

    public Long getRobotJobId() {
        return robotJobId;
    }

    public void setRobotJobId(Long robotJobId) {
        this.robotJobId = robotJobId;
    }

    public String getRobotTrnsfrTypeId() {
        return robotTrnsfrTypeId;
    }

    public void setRobotTrnsfrTypeId(String robotTrnsfrTypeId) {
        this.robotTrnsfrTypeId = robotTrnsfrTypeId;
    }

    public String getSourcePlateTypeId() {
        return sourcePlateTypeId;
    }

    public void setSourcePlateTypeId(String sourcePlateTypeId) {
        this.sourcePlateTypeId = sourcePlateTypeId;
    }

    public String getSourcePlateName() {
        return sourcePlateName;
    }

    public void setSourcePlateName(String sourcePlateName) {
        this.sourcePlateName = sourcePlateName;
    }

    public String getSourceWell() {
        return sourceWell;
    }

    public void setSourceWell(String sourceWell) {
        this.sourceWell = sourceWell;
    }

    public String getTargetPlateTypeId() {
        return targetPlateTypeId;
    }

    public void setTargetPlateTypeId(String targetPlateTypeId) {
        this.targetPlateTypeId = targetPlateTypeId;
    }

    public String getTargetPlateName() {
        return targetPlateName;
    }

    public void setTargetPlateName(String targetPlateName) {
        this.targetPlateName = targetPlateName;
    }

    public String getTargetWell() {
        return targetWell;
    }

    public void setTargetWell(String targetWell) {
        this.targetWell = targetWell;
    }

    public String getProcessByQuadrant() {
        return processByQuadrant;
    }

    public void setProcessByQuadrant(String processByQuadrant) {
        this.processByQuadrant = processByQuadrant;
    }

    public Double getVolume() {
        return volume;
    }

    public void setVolume(Double volume) {
        this.volume = volume;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getTransferSize() {
        return transferSize;
    }

    public void setTransferSize(Long transferSize) {
        this.transferSize = transferSize;
    }

    public Long getTotalVolume() {
        return totalVolume;
    }

    public void setTotalVolume(Long totalVolume) {
        this.totalVolume = totalVolume;
    }
}
