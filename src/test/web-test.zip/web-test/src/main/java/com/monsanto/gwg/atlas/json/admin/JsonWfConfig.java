package com.monsanto.gwg.atlas.json.admin;

import java.util.List;

/**
 * Created by pgros1 on 5/19/14.
 */
public class JsonWfConfig {
    private String workflowName;
    private String workflowDomain;
    private java.util.List<String> workflowAdmins;
    private String createUser;

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public List<String> getWorkflowAdmins() {
        return workflowAdmins;
    }

    public void setWorkflowAdmins(List<String> workflowAdmins) {
        this.workflowAdmins = workflowAdmins;
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public void setWorkflowName(String workflowName) {
        this.workflowName = workflowName;
    }

    public String getWorkflowDomain() {
        return workflowDomain;
    }

    public void setWorkflowDomain(String workflowDomain) {
        this.workflowDomain = workflowDomain;
    }
}
