package com.monsanto.gwg.atlas.model.core;

import java.sql.Timestamp;

public class WfStepDataConfigVw {
  private Long wfStepConfigId;
  private Long wfDataConfigId;
  private Integer sortKey;
  private String label;
  private boolean scanLineKey;
  private boolean barcodeCapture;
  private boolean displayOnly;
  private boolean required;
  private Integer maxLength;
  private Long wfDataConfigIdGroup;
  private Long wfDataConfigIdMatch;
  private Long wfRefConfigId;
  private String numberFormat;
  private String dateFormat;
  private String cssClasses;
  private String regexMatch;
  private String wfDataConfigType;
  private String createUser;
  private Timestamp createTs;

  public Long getWfStepConfigId() {
    return wfStepConfigId;
  }

  public void setWfStepConfigId(Long wfStepConfigId) {
    this.wfStepConfigId = wfStepConfigId;
  }

  public Long getWfDataConfigId() {
    return wfDataConfigId;
  }

  public void setWfDataConfigId(Long wfDataConfigId) {
    this.wfDataConfigId = wfDataConfigId;
  }

  public Integer getSortKey() {
    return sortKey;
  }

  public void setSortKey(Integer sortKey) {
    this.sortKey = sortKey;
  }

  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public boolean isScanLineKey() {
    return scanLineKey;
  }

  public void setScanLineKey(boolean scanLineKey) {
    this.scanLineKey = scanLineKey;
  }

  public boolean isBarcodeCapture() {
    return barcodeCapture;
  }

  public void setBarcodeCapture(boolean barcodeCapture) {
    this.barcodeCapture = barcodeCapture;
  }

  public boolean isDisplayOnly() {
    return displayOnly;
  }

  public void setDisplayOnly(boolean displayOnly) {
    this.displayOnly = displayOnly;
  }

  public Long getWfDataConfigIdGroup() {
    return wfDataConfigIdGroup;
  }

  public void setWfDataConfigIdGroup(Long wfDataConfigIdGroup) {
    this.wfDataConfigIdGroup = wfDataConfigIdGroup;
  }

  public String getNumberFormat() {
    return numberFormat;
  }

  public void setNumberFormat(String numberFormat) {
    this.numberFormat = numberFormat;
  }

  public String getDateFormat() {
    return dateFormat;
  }

  public void setDateFormat(String dateFormat) {
    this.dateFormat = dateFormat;
  }

  public String getCssClasses() {
    return cssClasses;
  }

  public void setCssClasses(String cssClasses) {
    this.cssClasses = cssClasses;
  }

  public String getRegexMatch() {
    return regexMatch;
  }

  public void setRegexMatch(String regexMatch) {
    if (regexMatch!=null) {
      //this is required when dynamically writing the javascript in atlas.js
      //so w3c regex tryit scripts will work as tested
      this.regexMatch = regexMatch.replaceAll("\\\\","\\\\\\\\");
    } else {
      this.regexMatch = null;
    }
  }

  public String getWfDataConfigType() {
    return wfDataConfigType;
  }

  public void setWfDataConfigType(String wfDataConfigType) {
    this.wfDataConfigType = wfDataConfigType;
  }

  public boolean isRequired() {
    return required;
  }

  public void setRequired(boolean required) {
    this.required = required;
  }

  public Long getWfDataConfigIdMatch() {
    return wfDataConfigIdMatch;
  }

  public void setWfDataConfigIdMatch(Long wfDataConfigIdMatch) {
    this.wfDataConfigIdMatch = wfDataConfigIdMatch;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public Integer getMaxLength() {
    return maxLength;
  }

  public void setMaxLength(Integer maxLength) {
    this.maxLength = maxLength;
  }

  public Long getWfRefConfigId() { return wfRefConfigId; }

  public void setWfRefConfigId(Long wfRefConfigId) { this.wfRefConfigId = wfRefConfigId; }
}
