package com.monsanto.gwg.atlas.service;

import com.monsanto.gwg.atlas.bean.ReportSql;
import com.monsanto.gwg.atlas.bean.ReportSqlQueue;
import com.monsanto.gwg.atlas.dao.ReportSqlDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReportService {

  @Autowired
  ReportSqlDao reportSqlDao;

  public List<ReportSql> getReportSqlList(String wfConfigDomain) {
    return reportSqlDao.getReportSqlList(wfConfigDomain);
  }

  public ReportSql getReportSql(Long reportSqlId) {
    return reportSqlDao.getReportSql(reportSqlId);
  }

  public Long queueReport(Long reportSqlId, Map<String, String> params, String userId, Boolean queueable) {
    return reportSqlDao.queueReport(reportSqlId, params, userId, queueable);
  }

  public List<ReportSqlQueue> getQueueStatus(Long reportSqlId) {
    return reportSqlDao.getQueueStatus(reportSqlId);
  }

  public byte[] getReportResultCsv(Long reportSqlQueueId) {
    return reportSqlDao.getReportResultCsv(reportSqlQueueId);
  }

  public String getFileName(Long reportSqlQueueId) {
    return reportSqlDao.getFileName(reportSqlQueueId);
  }

  public List<Map<String,Object>> getReportResults(Long reportId) {

    StringBuilder sbParamInfo = new StringBuilder();
    Map<String, String> params = new HashMap<String, String>();

    String sqlTemplate = reportSqlDao.getSqlTemplateAndParams(reportId, params, sbParamInfo);

    List<Map<String,Object>> reportResults =  reportSqlDao.getReportResults(sqlTemplate);

    return reportResults;
  }
}
