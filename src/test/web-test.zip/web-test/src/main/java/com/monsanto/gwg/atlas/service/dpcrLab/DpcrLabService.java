package com.monsanto.gwg.atlas.service.dpcrLab;

/**
 * Entry point for any custom wf_step_config based processing coming from dpcrlab domain [wf_config_id=9]
 * Any pre-processing (validation) should go in WfValidator
 */

import com.monsanto.gwg.atlas.dao.core.WfConfigPropertyDao;
import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.dao.core.WfStepConfigDao;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.model.core.WfConfigProperty;
import com.monsanto.gwg.atlas.model.core.WfStepConfig;
import com.monsanto.gwg.atlas.service.UtilService;
import com.monsanto.gwg.atlas.service.annotations.WfDelegateMethod;
import com.monsanto.gwg.atlas.service.annotations.WfParam;
import com.monsanto.gwg.atlas.service.annotations.WfParamValue;
import com.monsanto.gwg.atlas.service.dpcr.DPcrConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
public class DpcrLabService {

  private static final Logger LOG = LoggerFactory.getLogger(DpcrLabService.class);

  public static final long WF_CONFIG_ID = 9L;

  @Autowired
  private WfDataDao wfDataDao;

  @Autowired
  private WfConfigPropertyDao wfConfigPropertyDao;

  @Autowired
  private WfStepConfigDao wfStepConfigDao;

  @Autowired
  private UtilService utilService;

   /**
   * Group projects into a mix vessel run based on user selection from Ready to Design (9007)
   *
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 9007)
  public JsonResponse post9007(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = null;
    try {

      BigDecimal groupId = BigDecimal.valueOf(System.currentTimeMillis());

      for (Map<String, String> postData : jsonPost.getRows()) {
        // flag user assignment as a group for agent to pickup
        Long projectWfId = Long.parseLong(postData.get("wfId"));
        wfDataDao.save(projectWfId, 2071L, groupId);
        wfDataDao.save(projectWfId, 2072L, "Y");
        wfDataDao.save(projectWfId, 2120L, userId);
      }
    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;
  }

  /**
     * Group p plates into a mix vessel run based on user selection from R: Ready to Design (9022)
     *
     * @param userId
     * @param jsonPost
     * @return
     */
    @WfDelegateMethod(wfStepConfigId = 9022)
    public JsonResponse post9022(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

      JsonResponse jsonResponse = null;
      try {

        BigDecimal groupId = BigDecimal.valueOf(System.currentTimeMillis());

        for (Map<String, String> postData : jsonPost.getRows()) {
          // flag user assignment as a group for agent to pickup
          Long pPlateWfId = Long.parseLong(postData.get("wfId"));
          wfDataDao.save(pPlateWfId, 2118L, groupId);
          wfDataDao.save(pPlateWfId, 2119L, "Y");
          wfDataDao.save(pPlateWfId, 2120L, userId);
        }
      } catch (Exception ex) {
        LOG.error("Method invocation error", ex);

        //send exception to the UI to be logged by console
        jsonResponse = new JsonResponse();
        jsonResponse.setException(utilService.getStackTrace(ex));
      }
      return jsonResponse;
    }
  /**
   * Change Project Status from  DPCR_PROJECT_STATUS_UPLOAD_REQUEST_PENDING to DPCR_PROJECT_STATUS_UPLOAD_REQUESTED
   *
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 9011)
  public JsonResponse post9011(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = null;
    try {

      for (Map<String, String> postData : jsonPost.getRows()) {
        Long projectWfId = Long.parseLong(postData.get("wfId"));
        wfDataDao.save(projectWfId, 2100L, DPcrConstants.DPCR_PROJECT_STATUS_UPLOAD_REQUESTED);
        // Get value for the key from wf_config_properties
        WfConfigProperty wfConfigProperty= wfConfigPropertyDao.findByWfConfigIdAndKey(9L, DPcrConstants.DPCR_PROJECT_STATUS_UPLOAD_REQUESTED );
        wfDataDao.save(projectWfId, 2099L, wfConfigProperty.getValueVarchar2());
      }
    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;
  }

  public List<WfStepConfig> getProjectStepRelationship(String project){

    return wfStepConfigDao.getProjectStepRelationship(project);
  }

}
