package com.monsanto.gwg.atlas.model.torrent;

import java.sql.Timestamp;

public class TorrentAnalysis {
  private Long torrentAnalysisId;
  private Long torrentRunId;
  private String markerReference;
  private String qcThreshold;
  private Integer barcodeIndexPlate;
  private String createUser;
  private Timestamp createTs;
  private Timestamp analysisStartTs;
  private String analysisStatus;
  private Timestamp analysisCompleteTs;

  public Long getTorrentAnalysisId() {
    return torrentAnalysisId;
  }

  public void setTorrentAnalysisId(Long torrentAnalysisId) {
    this.torrentAnalysisId = torrentAnalysisId;
  }

  public Long getTorrentRunId() {
    return torrentRunId;
  }

  public void setTorrentRunId(Long torrentRunId) {
    this.torrentRunId = torrentRunId;
  }

  public String getMarkerReference() {
    return markerReference;
  }

  public void setMarkerReference(String markerReference) {
    this.markerReference = markerReference;
  }

  public String getQcThreshold() {
    return qcThreshold;
  }

  public void setQcThreshold(String qcThreshold) {
    this.qcThreshold = qcThreshold;
  }

  public Integer getBarcodeIndexPlate() {
    return barcodeIndexPlate;
  }

  public void setBarcodeIndexPlate(Integer barcodeIndexPlate) {
    this.barcodeIndexPlate = barcodeIndexPlate;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public Timestamp getAnalysisStartTs() {
    return analysisStartTs;
  }

  public void setAnalysisStartTs(Timestamp analysisStartTs) {
    this.analysisStartTs = analysisStartTs;
  }

  public String getAnalysisStatus() {
    return analysisStatus;
  }

  public void setAnalysisStatus(String analysisStatus) {
    this.analysisStatus = analysisStatus;
  }

  public Timestamp getAnalysisCompleteTs() {
    return analysisCompleteTs;
  }

  public void setAnalysisCompleteTs(Timestamp analysisCompleteTs) {
    this.analysisCompleteTs = analysisCompleteTs;
  }
}
