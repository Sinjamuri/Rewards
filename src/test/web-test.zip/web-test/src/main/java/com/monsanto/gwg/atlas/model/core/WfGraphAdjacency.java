package com.monsanto.gwg.atlas.model.core;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */
public class WfGraphAdjacency {

  private String id;
  private String name;
  private List<WfGraphNode> adjacencies;
  private WfGraphAdjacencyData data;

  public WfGraphAdjacency(String id, String name, List<WfGraphNode> adjacencies, WfGraphAdjacencyData data) {
    this.id = id;
    this.name = name;
    this.adjacencies = adjacencies;
    this.data = data;
  }

  public WfGraphAdjacency() {
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<WfGraphNode> getAdjacencies() {
    return adjacencies;
  }

  public void setAdjacencies(List<WfGraphNode> adjacencies) {
    this.adjacencies = adjacencies;
  }

  public WfGraphAdjacencyData getData() {
    return data;
  }

  public void setData(WfGraphAdjacencyData wfJsonGraphAdjacencyData) {
    this.data = wfJsonGraphAdjacencyData;
  }

}