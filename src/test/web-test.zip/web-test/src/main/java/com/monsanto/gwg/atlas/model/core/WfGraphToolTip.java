package com.monsanto.gwg.atlas.model.core;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */

// Anything in here (linked to WfGraphAdjacenyData) gets displayed as <br> separated tooltip on mouse hover
public class WfGraphToolTip {

  private String name;
  private String value;
  private int decimalPlaces;

  public WfGraphToolTip(String name, String value, int decimalPlaces) {
    this.name = name;
    this.value = value;
    this.decimalPlaces = decimalPlaces;
  }

  public WfGraphToolTip() {
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public int getDecimalPlaces() {
    return decimalPlaces;
  }

  public void setDecimalPlaces(int decimalPlaces) {
    this.decimalPlaces = decimalPlaces;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

}