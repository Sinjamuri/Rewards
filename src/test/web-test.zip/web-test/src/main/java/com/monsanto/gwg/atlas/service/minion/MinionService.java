package com.monsanto.gwg.atlas.service.minion;

import com.monsanto.gwg.atlas.dao.core.WfAssocDao;
import com.monsanto.gwg.atlas.dao.core.WfDao;
import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.service.UtilService;
import com.monsanto.gwg.atlas.service.annotations.WfDelegateMethod;
import com.monsanto.gwg.atlas.service.annotations.WfParam;
import com.monsanto.gwg.atlas.service.annotations.WfParamValue;
import com.monsanto.gwg.atlas.service.core.WfService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class MinionService
{
    private static final Logger LOG = LoggerFactory.getLogger(MinionService.class);

    @Autowired
    private WfService wfService;

    @Autowired
    private UtilService utilService;

    @Autowired
    private WfDao wfDao;

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfAssocDao wfAssocDao;

    @WfDelegateMethod(wfStepConfigId = 10198)
    public JsonResponse post10198(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = new JsonResponse();
        try
        {
            for(Map<String, String> data : jsonPost.getRows())
            {
                String loc = data.get("wfdc615");
                String recBy = data.get("wfdc617");
                Long wfId = Long.valueOf(data.get("setIndex"));
                int nextSampleIndex = Integer.valueOf(wfDataDao.getValue(641L, wfId) != null ? wfDataDao.getValue(641L, wfId).getWfDataNumber().toString() : "0");

                WfData obj = wfDataDao.getValue(607L, wfId);
                int numOfSamples = Integer.valueOf(obj.getWfDataNumber().toString());

                if(loc.length() <= 0 || recBy.length() <= 0)
                {
                    jsonResponse.addError("Must have location and received by fields filled in to move to next step.");
                    return jsonResponse;
                }
                for(int i = 0; i < numOfSamples; i++)
                {
                    Long nextWfIdSeq = wfDao.getNextSeqId("wf_id_seq");
                    wfDao.save(10L, "sample-"+((nextSampleIndex++)+1), 10199L, userId, 201L, nextWfIdSeq);
                    wfAssocDao.save(wfId, nextWfIdSeq, "1");
                    wfDataDao.save(nextWfIdSeq, 615L, loc);
                    wfDataDao.save(nextWfIdSeq, 616L, wfDataDao.getValue(616L, wfId).getWfDataVarchar2());
                    wfDataDao.save(nextWfIdSeq, 617L, recBy);
                    wfDataDao.save(nextWfIdSeq, 618L, nextWfIdSeq.toString());
                    wfDataDao.save(nextWfIdSeq, 600L, wfId.toString());
                    wfDataDao.save(nextWfIdSeq, 601L, wfDataDao.getValue(601L, wfId).getWfDataVarchar2());
                    wfDataDao.save(nextWfIdSeq, 602L, wfDataDao.getValue(602L, wfId).getWfDataVarchar2());
                    wfDataDao.save(nextWfIdSeq, 603L, wfDataDao.getValue(603L, wfId).getWfDataVarchar2());
                    wfDataDao.save(nextWfIdSeq, 604L, wfDataDao.getValue(604L, wfId).getWfDataVarchar2());
                    wfDataDao.save(nextWfIdSeq, 605L, wfDataDao.getValue(605L, wfId).getWfDataTimestamp());
                    wfDataDao.save(nextWfIdSeq, 606L, wfDataDao.getValue(606L, wfId).getWfDataTimestamp());
                    wfDataDao.save(nextWfIdSeq, 608L, wfDataDao.getValue(608L, wfId).getWfDataVarchar2());
                }
                wfDao.updateWfStatus(wfId, "M", "GKZES");
                wfDataDao.save(wfId, 641L, nextSampleIndex);
                wfDataDao.save(wfId, 607L, 0);
            }
        } catch (Exception ex)
        {
            LOG.error("Method invocation error", ex);

            //send exception to the UI to be logged by console
            jsonResponse.setException(utilService.getStackTrace(ex));
        }
        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10199)
    public JsonResponse post10199(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;
        try
        {
            wfService.savePostData(jsonPost);
            wfService.passAllWf(jsonPost, null);
        } catch (Exception ex)
        {
            LOG.error("Method invocation error", ex);

            //send exception to the UI to be logged by console
            jsonResponse = new JsonResponse();
            jsonResponse.setException(utilService.getStackTrace(ex));
        }
        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10200)
    public JsonResponse post10200(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;

        for(Map<String, String> data : jsonPost.getRows())
        {
            Long wfId = Long.valueOf(data.get("wfId"));
            wfDataDao.save(wfId, 619L, data.get("wfdc619"));
            try
            {
                String passfaildrop = data.get("wfdc639");
                Long sampleWfId = Long.valueOf(data.get("wfId"));
                Long parentWfId = Long.valueOf(wfDataDao.getVarchar2ForWfId(sampleWfId, 600L));

                if (passfaildrop.length() <= 0)
                {
                    jsonResponse = new JsonResponse();
                    jsonResponse.addError("Must select pass/fail/drop before moving to next step.");
                    return jsonResponse;
                }
                processPassFailDrop(userId, passfaildrop, sampleWfId, parentWfId);
            } catch (Exception e)
            {
                e.printStackTrace();
                jsonResponse = new JsonResponse();
                jsonResponse.addError("Internal error, please forward the following stack trace to programming: -> " + e.getMessage());
                return jsonResponse;
            }
        }
        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10201)
    public JsonResponse post10201(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;

        for(Map<String, String> data : jsonPost.getRows())
        {
            Long wfId = Long.valueOf(data.get("wfId"));
            String concentrationByQubit = data.get("wfdc623");
            if (concentrationByQubit.length() <= 0)
            {
                jsonResponse = new JsonResponse();
                jsonResponse.addError("Must have concentration by qubit field filled in to move to next step.");
                return jsonResponse;
            }
            wfDataDao.save(wfId, 620L, data.get("wfdc620"));
            wfDataDao.save(wfId, 621L, data.get("wfdc621"));
            wfDataDao.save(wfId, 622L, data.get("wfdc622"));
            wfDataDao.save(wfId, 623L, concentrationByQubit);
            wfService.passSingleWf(wfId, userId, null);
        }
        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10202)
    public JsonResponse post10202(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;

        for(Map<String, String> data : jsonPost.getRows())
        {
            try
            {
                Long wfId = Long.valueOf(data.get("wfId"));
                String passfaildrop = data.get("wfdc639");
                Long sampleWfId = wfId;
                Long parentWfId = Long.valueOf(wfDataDao.getVarchar2ForWfId(sampleWfId, 600L));
                if (data.get("wfdc639").length() <= 0)
                {
                    jsonResponse = new JsonResponse();
                    jsonResponse.addError("Must select pass/fail/drop before moving to next step.");
                    return jsonResponse;
                }
                wfDataDao.save(wfId, 636L, data.get("wfdc636"));
                processPassFailDrop(userId, passfaildrop, sampleWfId, parentWfId);
            }catch(Exception e)
            {
                jsonResponse = new JsonResponse();
                jsonResponse.addError("Internal error, please contact programming with this message: " + e.getStackTrace());
                return jsonResponse;
            }
        }
        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10203)
    public JsonResponse post10203(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;
        for(Map<String, String> data : jsonPost.getRows())
        {
            Long wfId = Long.valueOf(data.get("wfId"));
            if (data.get("wfdc638").length() <= 0)
            {
                jsonResponse.addError("Must enter a value for Library Concentration Per Samplle by Qubit before moving to next step.");
                return jsonResponse;
            }
            wfDataDao.save(wfId, 624L, data.get("wfdc624"));
            wfDataDao.save(wfId, 625L, data.get("wfdc625"));
            wfDataDao.save(wfId, 626L, data.get("wfdc626"));
            wfDataDao.save(wfId, 638L, data.get("wfdc638"));
            wfService.passSingleWf(wfId, userId, null);
        }

        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10204)
    public JsonResponse post10204(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;

        for(Map<String, String> data : jsonPost.getRows())
        {
            try
            {
                Long wfId = Long.valueOf(data.get("wfId"));
                String passfaildrop = data.get("wfdc639");
                Long sampleWfId = wfId;
                Long parentWfId = Long.valueOf(wfDataDao.getVarchar2ForWfId(sampleWfId, 600L));
                if (data.get("wfdc639").length() <= 0)
                {
                    jsonResponse = new JsonResponse();
                    jsonResponse.addError("Must select pass/fail/drop before moving to next step.");
                    return jsonResponse;
                }
                wfDataDao.save(wfId, 637L, data.get("wfdc637"));
                wfDataDao.save(wfId, 627L, data.get("wfdc627"));
                processPassFailDrop(userId, passfaildrop, sampleWfId, parentWfId);
            }catch(Exception e)
            {
                jsonResponse = new JsonResponse();
                jsonResponse.addError("Internal error, contact programming with message: " + e.getStackTrace());
                return jsonResponse;
            }
        }
        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10205)
    public JsonResponse post10205(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;

        for(Map<String, String> data : jsonPost.getRows())
        {
            try
            {
                Long wfId = Long.valueOf(data.get("wfId"));
                String passfaildrop = data.get("wfdc639");
                Long sampleWfId = wfId;
                Long parentWfId = Long.valueOf(wfDataDao.getVarchar2ForWfId(sampleWfId, 600L));
                if (data.get("wfdc639").length() <= 0)
                {
                    jsonResponse = new JsonResponse();
                    jsonResponse.addError("Must select pass/fail/drop before moving to next step.");
                    return jsonResponse;
                }
                wfDataDao.save(wfId, 628L, data.get("wfdc628"));
                wfDataDao.save(wfId, 629L, data.get("wfdc629"));
                wfDataDao.save(wfId, 630L, data.get("wfdc630"));
                wfDataDao.save(wfId, 631L, data.get("wfdc631"));
                wfDataDao.save(wfId, 632L, data.get("wfdc632"));
                wfDataDao.save(wfId, 633L, data.get("wfdc633"));
                processPassFailDrop(userId, passfaildrop, sampleWfId, parentWfId);
            }catch(Exception e)
            {
                jsonResponse = new JsonResponse();
                jsonResponse.addError("Internal error, contact programming with message: " + e.getStackTrace());
                return jsonResponse;
            }
        }
        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10231)
    public JsonResponse post10231(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;
        for(Map<String, String> data : jsonPost.getRows())
        {
            try
            {
                Long wfId = Long.valueOf(data.get("wfId"));
                wfDataDao.save(wfId, 634L, data.get("wfdc634"));
                wfDataDao.save(wfId, 635L, data.get("wfdc635"));
                wfService.passSingleWf(wfId, userId, null);
            } catch (Exception e)
            {
                jsonResponse = new JsonResponse();
                jsonResponse.addError("Internal error, contact programming with message: " + e.getStackTrace());
                return jsonResponse;
            }
        }

        return jsonResponse;
    }

    @WfDelegateMethod(wfStepConfigId = 10232)
    public JsonResponse post10232(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost)
    {
        JsonResponse jsonResponse = null;

        for(Map<String, String> data : jsonPost.getRows())
        {
            try
            {
                Long wfId = Long.valueOf(data.get("wfId"));
                String completeCancel = data.get("wfdc640");
                if (completeCancel.length() <= 0)
                {
                    jsonResponse = new JsonResponse();
                    jsonResponse.addError("Must select complete/cancel before moving the sample to conclusion.");
                    return jsonResponse;
                }
                processCompleteCancel(userId, completeCancel, wfId);
            } catch (Exception e)
            {
                jsonResponse = new JsonResponse();
                jsonResponse.addError("Internal error, contact programming with message: " + e.getStackTrace());
                return jsonResponse;
            }
        }
        return jsonResponse;
    }

    private void processCompleteCancel(String userId, String completeCancel, Long wfId)
    {
        wfDataDao.save(wfId, 640L, completeCancel);
        wfDao.updateWfStatus(wfId, "D", "GKZES");
    }

    private void processPassFailDrop(
            @WfParam(WfParamValue.USER_ID) String userId,
            String passfaildrop, Long sampleWfId, Long parentWfId)
    {
        if("pass".equalsIgnoreCase(passfaildrop))
        {
            wfService.passSingleWf(sampleWfId, userId, null);
        }else if("fail".equalsIgnoreCase(passfaildrop))
        {
            int currentNumOfSamples = Integer.valueOf(wfDataDao.getValue(607L, parentWfId).getWfDataNumber().toString());
            wfDao.updateWfStatus(sampleWfId, "D", "GKZES");
            wfDataDao.save(parentWfId, 607L, currentNumOfSamples + 1);
            wfDao.updateWfStatus(parentWfId, "I", "GKZES");
            wfAssocDao.updateWfAssocStatusAndMatchKey(parentWfId, sampleWfId, "1", "N");
        }else
        {
            wfDao.updateWfStatus(sampleWfId, "D", "GKZES");
            wfAssocDao.updateWfAssocStatusAndMatchKey(parentWfId, sampleWfId, "1", "N");
        }
    }
}
