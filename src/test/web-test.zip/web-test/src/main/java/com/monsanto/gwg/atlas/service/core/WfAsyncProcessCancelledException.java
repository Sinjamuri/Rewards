package com.monsanto.gwg.atlas.service.core;

/**
 * Created by PGROS1 on 6/24/14.
 */
public class WfAsyncProcessCancelledException extends RuntimeException {
}
