package com.monsanto.gwg.atlas.model.admin;

import com.monsanto.gwg.atlas.model.core.WfStepAssocVw;

import java.util.*;

/**
 * Created by pgros1 on 6/9/14.
 */
public class WfGraphNodeFactory {
    private HashMap<NodeIdentifier, WfGraphNode> graphNodeMap = new HashMap<NodeIdentifier, WfGraphNode>();

    private class NodeIdentifier {
        private String nodeType;
        private Long nodeId;

        NodeIdentifier( String nodeType, long nodeId ) {
            this.nodeType = nodeType;
            this.nodeId = nodeId;
        }

        @Override
        public boolean equals(Object obj) {
            if( obj instanceof NodeIdentifier ) {
                NodeIdentifier identifier = (NodeIdentifier ) obj;
                return this.nodeType.compareToIgnoreCase(identifier.nodeType) == 0
                        && this.nodeId.equals(identifier.nodeId);
            }
            return false;
        }

        @Override
        public int hashCode() {
            return nodeType.hashCode() + nodeId.intValue();
        }
    }

    public WfGraphNode getGraphNode( String nodeType, long nodeId ) {
        NodeIdentifier id = new NodeIdentifier( nodeType, nodeId );
        WfGraphNode graphNode = graphNodeMap.get( id );

        if( graphNode == null ) {
            graphNode = new WfGraphNode();
            graphNode.setNodeInternalType( nodeType );
            graphNode.setNodeInternalId( nodeId );

            graphNodeMap.put( id, graphNode );
        }

        return graphNode;
    }

    public List<WfGraphNode> getGraphNodes() {
        return new ArrayList<WfGraphNode>(graphNodeMap.values());
    }

    public List<WfGraphNode> getOrderedGraphNodes() {
        List<WfGraphNode> unorderedNodes = getGraphNodes();
        HashSet<WfGraphNode> rootNodes = new HashSet<WfGraphNode>(unorderedNodes);
        LinkedHashSet<WfGraphNode> orderedNodes = new LinkedHashSet<WfGraphNode>();

        for( WfGraphNode graphNode : unorderedNodes ) {
            for( WfGraphNode childNode : graphNode.getChildNodes() ) {
                rootNodes.remove( childNode );
            }
        }

        for( WfGraphNode rootNode : rootNodes ) {
            findAndAddChildNodes( rootNode, orderedNodes);
        }

        return new ArrayList<WfGraphNode>( orderedNodes );
    }

    private void findAndAddChildNodes( WfGraphNode node, Set<WfGraphNode> addedNodes ) {
        addedNodes.add( node );
        for( WfGraphNode childNode : node.getChildNodes() ) {
            if( !addedNodes.contains( childNode ) ) {
                findAndAddChildNodes( childNode, addedNodes );
            }
        }
    }
}
