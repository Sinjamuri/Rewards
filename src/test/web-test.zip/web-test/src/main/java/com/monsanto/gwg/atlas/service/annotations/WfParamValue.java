package com.monsanto.gwg.atlas.service.annotations;

import com.monsanto.gwg.atlas.json.core.JsonPost;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Created by pgros1 on 5/21/14.
 */
public enum WfParamValue {
    USER_ID ( String.class ),
    JSON_POST (JsonPost.class ),
    SESSION (HttpSession.class ),
    REQUEST (HttpServletRequest.class ),
    RESPONSE (HttpServletResponse.class);

    private WfParamValue( Class cls ) { this.paramType = cls; }
    private Class paramType;
    public Class getParamType() { return paramType; }
}
