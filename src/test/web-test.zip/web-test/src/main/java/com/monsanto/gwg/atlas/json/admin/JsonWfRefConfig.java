package com.monsanto.gwg.atlas.json.admin;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * Created by regama on 6/30/14.
 */
public class JsonWfRefConfig {
    private Long wfConfigId;
    private Long wfRefConfigId;
    private Long wfRefConfigParentId;
    private String wfRefKey;
    private String wfRefVarchar2;
    private Timestamp wfRefTimestamp;
    private BigDecimal wfRefNumber;
    private String wfRefActive;
    private Integer wfRefUISortKey;
    private String comments;
    private String createUser;

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public Long getWfRefConfigParentId() {
        return wfRefConfigParentId;
    }

    public void setWfRefConfigParentId(Long wfRefConfigParentId) {
        this.wfRefConfigParentId = wfRefConfigParentId;
    }

    public String getWfRefKey() {
        return wfRefKey;
    }

    public void setWfRefKey(String wfRefKey) {
        this.wfRefKey = wfRefKey;
    }

    public String getWfRefVarchar2() {
        return wfRefVarchar2;
    }

    public void setWfRefVarchar2(String wfRefVarchar2) {
        this.wfRefVarchar2 = wfRefVarchar2;
    }

    public BigDecimal getWfRefNumber() {
        return wfRefNumber;
    }

    public void setWfRefNumber(BigDecimal wfRefNumber) {
        this.wfRefNumber = wfRefNumber;
    }

    public String getWfRefActive() {
        return wfRefActive;
    }

    public void setWfRefActive(String wfRefActive) {
        this.wfRefActive = wfRefActive;
    }

    public Integer getWfRefUISortKey() {
        return wfRefUISortKey;
    }

    public void setWfRefUISortKey(Integer wfRefUISortKey) {
        this.wfRefUISortKey = wfRefUISortKey;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getWfRefTimestamp() {
        return wfRefTimestamp;
    }

    public void setWfRefTimestamp(Timestamp wfRefTimestamp) {
        this.wfRefTimestamp = wfRefTimestamp;
    }

    public Long getWfRefConfigId() {
        return wfRefConfigId;
    }

    public void setWfRefConfigId(Long wfRefConfigId) {
        this.wfRefConfigId = wfRefConfigId;
    }
}
