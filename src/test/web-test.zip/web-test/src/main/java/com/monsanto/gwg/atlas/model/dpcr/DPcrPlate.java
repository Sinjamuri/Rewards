package com.monsanto.gwg.atlas.model.dpcr;

import com.monsanto.gwg.atlas.model.core.Wf;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by pgros1 on 6/10/14.
 */
public class DPcrPlate extends Wf{
//    private WellResult[][] wellResults;
//    private FilterData filterData;

    private TreeMap<Integer, TreeMap<Integer, WellResult>> wellResults;

    private List<FilterData> filterDataList;
    private String plateImagingId;
    private int wellRowCount;
    private int wellColumnCount;

    public void setWellResult(int wellRow, int wellColumn, WellResult wellResult ) {
//        WellResult currentWellResult = wellResults[wellRow][wellColumn];
//        if( currentWellResult == null ) {
//            wellResults[wellRow][wellColumn] = wellResult;
//        } else {
//            currentWellResult.addPartitionResults( wellResult.getPartitionResults() );
//        }
//
//        if( wellResults == null ) {
//            wellResults = new TreeMap<Integer, TreeMap<Integer, WellResult>>();
//        }

        TreeMap<Integer, WellResult> wellColumnMap = wellResults.get( wellRow );
        if( wellColumnMap == null ) {
            wellColumnMap = new TreeMap<Integer, WellResult>();
            wellResults.put( wellRow, wellColumnMap );
        }

        WellResult currentWellResult = wellColumnMap.get( wellColumn );
        if( currentWellResult == null ) {
            wellColumnMap.put( wellColumn, wellResult );
        } else {
            currentWellResult.setAllPartitionResults( wellResult.getAllPartitionResults() );
        }
    }

    public List<WellResult> getWellResultsList() {
        ArrayList<WellResult> wellResultsList = new ArrayList<WellResult>();

        for( Integer wellRow : wellResults.navigableKeySet() ) {
            TreeMap<Integer, WellResult> wellColumnMap = wellResults.get( wellRow );
            for( Integer wellCol : wellColumnMap.navigableKeySet() ) {
                wellResultsList.add( wellColumnMap.get( wellCol ));
            }
        }

        return wellResultsList;
    }

    public Map<Integer, ? extends Map< Integer, WellResult>> getWellResults() {
        return wellResults;
    }

    public void setWellResults( TreeMap< Integer, TreeMap<Integer, WellResult>> wellResultsMap ) {
        this.wellResults = wellResultsMap;
    }
//    public WellResult[][] getWellResults() {
//        return wellResults;
//    }
//
//    public void setWellResults(WellResult[][] wellResults) {
//        this.wellResults = wellResults;
//    }



    public void setFilterDataList( List<FilterData> filterDataList ) {
        this.filterDataList = filterDataList;
    }

    public List<FilterData> getFilterDataList() {
        return filterDataList;
    }

    public void addFilterData( FilterData filterData ) {
        if( filterDataList == null ) {
            filterDataList = new ArrayList<FilterData>();
        }

        filterDataList.add( filterData );
    }

//    public FilterData getFilterData() {
//        return filterData;
//    }
//
//    public void setFilterData(FilterData filterData) {
//        this.filterData = filterData;
//    }

    public String getPlateImagingId() {
        return getWfEntityLabel();
    }

    public void setPlateImagingId(String plateImagingId) {
        setWfEntityLabel( plateImagingId );
    }

    public int getWellRowCount() {
        return wellRowCount;
    }

    public void setWellRowCount(int wellRowCount) {
        this.wellRowCount = wellRowCount;
    }

    public int getWellColumnCount() {
        return wellColumnCount;
    }

    public void setWellColumnCount(int wellColumnCount) {
        this.wellColumnCount = wellColumnCount;
    }

}
