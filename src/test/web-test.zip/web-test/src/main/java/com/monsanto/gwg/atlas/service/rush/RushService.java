package com.monsanto.gwg.atlas.service.rush;

import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.dao.core.WfGridDataDao;
import com.monsanto.gwg.atlas.dao.core.WfGridDataTypeDao;
import com.monsanto.gwg.atlas.dao.dpcr.WellResultDao;
import com.monsanto.gwg.atlas.model.core.WfAsyncStatus;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.model.core.WfGridData;
import com.monsanto.gwg.atlas.model.dpcr.FilterData;
import com.monsanto.gwg.atlas.model.rush.RushSamplePlate;
import com.monsanto.gwg.atlas.service.core.WfAsyncProcessService;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.*;

import java.io.*;
import java.util.regex.Pattern;

@Service
public class RushService {

  private static final Logger LOG = LoggerFactory.getLogger(RushService.class);
        private final static long RUSH_SAMPLE_PLATE_NAME_WF_DATA_CONFIG_ID = 1060L;
        private final static long RUSH_TIS_PLATE_WELL_WF_DATA_CONFIG_ID = 1061L;
        private final static long RUSH_INV_BID_WF_DATA_CONFIG_ID = 1062L;
        private final static long RUSH_PEDIGREE_WF_DATA_CONFIG_ID = 1068L;
        private final static long RUSH_SEL_WF_DATA_CONFIG_ID = 1063L;
        private final static long RUSH_CONSTRUCT_WF_DATA_CONFIG_ID = 1007L;

        private final static long RUSH_GAMA_WFID_WF_DATA_CONFIG_ID = 1008L;
        private final static long RUSH_GENOTYPE_WF_DATA_CONFIG_ID = 1064L;
        private final static long RUSH_PROJECT_NAME_WF_DATA_CONFIG_ID = 1001L;
        private final static long RUSH_RANGE_WF_DATA_CONFIG_ID = 1065L;
        private final static long RUSH_ROW_WF_DATA_CONFIG_ID = 1066L;
        private final static long RUSH_PLOT_WF_DATA_CONFIG_ID = 1067L;
        private final static long RUSH_TARGET_DATE_WF_DATA_CONFIG_ID = 1009L;

        private static final long RUSH_PIC_WELL_WF_GRID_DATA_TYPE_ID = 11L;
        private static final long RUSH_PIC_CONCENTRATION_WF_GRID_DATA_TYPE_ID = 22L;
        private static final long RUSH_PIC_PLATE_NAME_WF_GRID_DATA_TYPE_ID = 33L;
        private static final long RUSH_TAQ_GOI_CT_ENR_WF_GRID_DATA_TYPE_ID = 44L;
        private static final long RUSH_TAQ_IC_CT_ENR_GRID_DATA_TYPE_ID = 55L;
        private static final long RUSH_TAQ_DCT_ENR_WF_GRID_DATA_TYPE_ID = 66L;
        private static final long RUSH_TAQ_GOI_CT_ADD_WF_GRID_DATA_TYPE_ID = 77L;
        private static final long RUSH_TAQ_IC_CT_ADD_GRID_DATA_TYPE_ID = 88L;
        private static final long RUSH_TAQ_DCT_ADD_WF_GRID_DATA_TYPE_ID = 99L;

        private final static long RUSH_WF_CONFIG_ID = 2L;
        private final static long RUSH_EXPORT_RESULTS_WF_STEP_CONFIG_ID = 520L;
        private final static long RUSH_SAMPLES_WF_ENTITY_TYPE_ID = 437L;
        private final static long RUSH_TIS_PLATE_WF_ENTITY_TYPE_ID = 431L;
        private final static long RUSH_SAMPLE_DATA_UPLOAD_WF_STEP_CONFIG_ID = 1001L;


    @Autowired
    private WfDataDao wfDataDao;
    @Autowired
    private WellResultDao wellResultDao;
    @Autowired
    private WfGridDataTypeDao wfGridDataTypeDao;
    @Autowired
    private WfGridDataDao wfGridDataDao;
    @Autowired
    private DataSourceTransactionManager txManager;
    @Autowired
    private WfAsyncProcessService wfAsyncProcessService;

//--file loading and validation...only need three parameters, request name, user, fileName
    public WfAsyncStatus startResultsFileUpload( String resultsFileName, InputStream resultsFileInputStream, String createUser, String requestId ) throws Exception {
            if( resultsFileName.endsWith(".csv")) {
            if( requestId == null ) {
                throw new RuntimeException( "ERROR: Request Name required for .csv Rush sample file upload");
            }
            return startRushSampleDataFileUpload( requestId, createUser, resultsFileInputStream );
        }
        throw new RuntimeException("ERROR: Unknown type of sample file file, not '.csv'");
    }
//--sample file parsing...read line by line and parse col by col
    public WfAsyncStatus startRushSampleDataFileUpload( String requestId, String uploadUser, InputStream resultsFileInputStream ) throws Exception {
 //   public WfAsyncStatus startRushSampleDataFileUpload( String requestId, String uploadUser, InputStream resultsFileInputStream ) throws Exception {
 //       Map<String, Long> posCountGridDataTypeIds = new HashMap<String, Long>();
        Map<String, Long> sampleDataTypeIds = new HashMap<String, Long>();
        sampleDataTypeIds.put( "SamplePlateName", RUSH_SAMPLE_PLATE_NAME_WF_DATA_CONFIG_ID );
        sampleDataTypeIds.put( "Well", RUSH_TIS_PLATE_WELL_WF_DATA_CONFIG_ID );
        sampleDataTypeIds.put( "INV_BID", RUSH_INV_BID_WF_DATA_CONFIG_ID );

     /*   Map<String, Long> estimateGridDataTypeIds = new HashMap<String, Long>();
        estimateGridDataTypeIds.put( "SamplePlateName", RUSH_ROX_EST_WF_GRID_DATA_TYPE_ID );
        estimateGridDataTypeIds.put( "Well", DPCR_FAM_EST_WF_GRID_DATA_TYPE_ID );
        estimateGridDataTypeIds.put( "INV_BID", DPCR_VIC_EST_WF_GRID_DATA_TYPE_ID );
*/
        RushSamplePlate plate = new RushSamplePlate();
        plate.setWfConfigId( RUSH_WF_CONFIG_ID );
        plate.setWfEntityTypeId(RUSH_TIS_PLATE_WF_ENTITY_TYPE_ID);
        plate.setSampleUploadId(requestId);
        plate.setWfStepConfigId( RUSH_SAMPLE_DATA_UPLOAD_WF_STEP_CONFIG_ID );
        plate.setCreateUser( uploadUser );

 //       plate = rushPlateDao.save( plate );
 //       wfDataDao.save( plate.getWfId(), RUSH_SAMPLE_PLATE_NAME_WF_DATA_CONFIG_ID, plate.getWfEntityLabel() );
    //    List<WfGridData> wellResults = new ArrayList<WfGridData>();
        List<WfData> wellResults = new ArrayList<WfData>();

        String fileContents = IOUtils.toString(resultsFileInputStream, "UTF-8");
//      String fileContents;
//      fileContents = IOUtils.toString(URI.create(resultsFileInputStream), "UTF-8");

        Pattern filterCountsLinePattern = Pattern.compile( "^Filter.*well counts,*$", Pattern.CASE_INSENSITIVE );
        Pattern thresholdLinePattern = Pattern.compile( "^Threshold,\\d+,*$", Pattern.CASE_INSENSITIVE );
        Pattern estimatesLinePattern = Pattern.compile( "^.*template estimates,*$", Pattern.CASE_INSENSITIVE );
        Pattern resultsDataLinePattern = Pattern.compile("^((\\d+|over),){11}(\\d+|over)$");

        String referenceFilterName = null;
        FilterData currentFilter = null;
        long currentWfGridDataTypeId = Long.MIN_VALUE;
        int currentRow = Integer.MIN_VALUE;

        for( String line : fileContents.split("\n")) {
            line = line.trim();

            if( filterCountsLinePattern.matcher( line ).matches() ) {
                currentFilter = new FilterData();

                String[] tokens = line.split( " " );
                currentFilter.setFilterPairId(tokens[1]);
                currentWfGridDataTypeId = sampleDataTypeIds.get( currentFilter.getFilterPairId() );

 //               plate.addFilterData( currentFilter );
                currentRow = 0;

                currentFilter.setIsReferenceFilter( line.contains( "reference" ) );
                if( currentFilter.getIsReferenceFilter() ) {
                    referenceFilterName = currentFilter.getReferenceFilter();
                } else {
                    currentFilter.setReferenceFilter(referenceFilterName);
                }

            } else if( thresholdLinePattern.matcher( line ).matches() ) {
                String[] tokens = line.split( "," );
                currentFilter.setIntensityThreshold( Integer.parseInt( tokens[1] ) );

            } else if( estimatesLinePattern.matcher( line ).matches() ) {
                String[] tokens = line.split( " " );
 //               currentWfGridDataTypeId = estimateGridDataTypeIds.get( tokens[0] );
                currentRow = 0;

            } else if( resultsDataLinePattern.matcher( line ).matches() ) {
                currentRow++;
                String[] values = line.split(",");

                for( int currentCol = 1; currentCol <= values.length; currentCol++ ) {
                    WfGridData wfGridData = new WfGridData();
                    wfGridData.setGridRow(currentRow);
                    wfGridData.setGridCol(currentCol);
                    wfGridData.setWfGridDataConfigId(currentWfGridDataTypeId);
 //                   wfGridData.setWfId( plate.getWfId() );
                    String stringValue = values[currentCol - 1];
                    try {
                        int value = Integer.parseInt( stringValue );
                        wfGridData.setValueNumber( new Double( value ));

                    } catch ( NumberFormatException ex ) {
                        wfGridData.setValueVarchar2( stringValue );
                    }
                    WfData wfData;
//                    wellResults.add( wfData );
                }
            }
        }
//        wfGridDataDao.batchSaveGridData(wellResults);

        return null;
    }

        public void startProcess() {
            TransactionTemplate tt = new TransactionTemplate();
            tt.setTransactionManager(txManager);
//            tt.execute(this);
        }

    public WfAsyncStatus startRushQCDataFileUpload( String requestId, String uploadUser, InputStream resultsFileInputStream ) throws Exception {
          return null;
    }
    }

 /*-   private void readWithCsvBeanReader(MultipartFile uploadedFile) throws Exception {
        ICsvBeanReader beanReader = null;
        try {
            beanReader = new CsvBeanReader(new InputStreamReader(uploadedFile.getInputStream()),
                    CsvPreference.STANDARD_PREFERENCE);
            // the header elements are used to map the values to the bean (names must match)
            final String[] header = beanReader.getHeader(true);
            // get Cell Processor
            final CellProcessor[] processors = getProcessors();
            }



 //--       private rushPlateDao rushPlateDao;
public WfAsyncStatus startRushSampleDataFileUpload(String fileName, String createUser, String requestId) {
    return new WfAsyncStatus();
    }
//--following method is NOT working yet
    public Boolean isValidNewWfDataConfig(JsonWfDataConfig jsonWfDataConfig, JsonResponse jsonResponse ){
        if( jsonWfDataConfig.getCreateUser() == null || jsonWfDataConfig.getCreateUser().equals( "" )) {
            jsonResponse.addError( "Crop for the project cannot be empty.");
            return false;
    }
          return false;
    }

    @Autowired
    private rushSamplePlateDao RushSamplePlateDao;

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WellResultDao wellResultDao;

//    private WfDataDao wfDataDao;
}


 /*-   public void test() throws FileNotFoundException, IOException {
        CSVParser parser = new CSVParser(
        new FileReader("test.csv"),
        CSVFormat.DEFAULT.withHeader());
        for (CSVRecord record : parser) {
            System.out.printf("%s\t%s\n",
                    record.get("COL1"),
                    record.get("COL2"));
        }
        parser.close();
    }

 -*/

