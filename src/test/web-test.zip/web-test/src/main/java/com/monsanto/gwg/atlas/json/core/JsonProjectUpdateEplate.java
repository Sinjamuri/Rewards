package com.monsanto.gwg.atlas.json.core;

import java.util.List;

public class JsonProjectUpdateEplate {
  private String blockBarcodeNbr;
  private Long workflowId;
  private String userId;
  private Integer noteOption;
  private String noteComment;
  private Long wfConfigId;

  public List<Long> getPooledTubeWfIdList() {
    return pooledTubeWfIdList;
  }

  public void setPooledTubeWfIdList(List<Long> pooledTubeWfIdList) {
    this.pooledTubeWfIdList = pooledTubeWfIdList;
  }

  private List<Long> pooledTubeWfIdList;

  public String getBlockBarcodeNbr() {
    return blockBarcodeNbr;
  }

  public void setBlockBarcodeNbr(String blockBarcodeNbr) {
    this.blockBarcodeNbr = blockBarcodeNbr;
  }

  public Long getWorkflowId() {
    return workflowId;
  }

  public void setWorkflowId(Long workflowId) {
    this.workflowId = workflowId;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public Integer getNoteOption() {
    return noteOption;
  }

  public void setNoteOption(Integer noteOption) {
    this.noteOption = noteOption;
  }

  public String getNoteComment() {
    return noteComment;
  }

  public void setNoteComment(String noteComment) {
    this.noteComment = noteComment;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }



}
