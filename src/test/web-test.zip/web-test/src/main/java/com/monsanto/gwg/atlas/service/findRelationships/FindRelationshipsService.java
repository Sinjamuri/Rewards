package com.monsanto.gwg.atlas.service.findRelationships;

import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.dao.gbs.CherryPickDao;
import com.monsanto.gwg.atlas.dao.gbs.MergedSampleDao;
import com.monsanto.gwg.atlas.dao.gbs.ProjectResultDao;
import com.monsanto.gwg.atlas.dao.ncr.NcrDao;
import com.monsanto.gwg.atlas.dao.torrent.TorrentRunDao;
import com.monsanto.gwg.atlas.model.core.*;
import com.monsanto.gwg.atlas.model.gbs.MergeSourceRuns;
import com.monsanto.gwg.atlas.model.gbs.RunBlock;
import com.monsanto.gwg.atlas.model.gbs.WfNcr;
import com.monsanto.gwg.atlas.model.gbs.WfRelationships;
import com.monsanto.gwg.atlas.service.UtilService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class FindRelationshipsService {

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfStepDataConfigVwDao wfStepDataConfigVwDao;

    @Autowired
    private WfStepConfigDao wfStepConfigDao;

    @Autowired
    private WfDao wfDao;

    @Autowired
    private WfAssocDao wfAssocDao;

    @Autowired
    private UtilService utilService;

    @Autowired
    private NcrDao ncrDao;

    @Autowired
    private TorrentRunDao torrentRunDao;

    @Autowired
    private ProjectResultDao projectResultDao;

    @Autowired
    private MergedSampleDao mergedSampleDao;

    @Autowired
    private CherryPickDao cherryPickDao;

    @Autowired
    private WfGridDataDao wfGridDataDao;

    private static final Logger LOG = LoggerFactory.getLogger(FindRelationshipsService.class);

    static final int LAST_YEAR = -1;
    static final int THIS_YEAR = 0;
    static final int NEXT_YEAR = 1;


  public List<WfEntityHistory> getWfRelationships(String entityIn) throws Exception {

    // currently supports eblock, cp block, project, or torrent run as entity

    List<WfEntityHistory> allHistory = new ArrayList<WfEntityHistory>();
    String[] entities = entityIn.split(","); // supports returning results from a comma separated list of entities

    for (String entity : entities) {

      String entitySearch = entity.trim();
      List<String> allAssociatedEblocks = wfGridDataDao.findAssociatedDataGridByData( entitySearch, 10167L);

      if(null == allAssociatedEblocks || allAssociatedEblocks.isEmpty()) {

        if (entityIsProject(entitySearch)) {
          // running this for every E linked to the project
          allAssociatedEblocks = findEBlocks(entitySearch);
        } else {
          // executing this for a torrent run (assumed)
          allAssociatedEblocks = wfGridDataDao.findAssociatedDataGridByData( entitySearch, 410L);
        }
      }

      for (String eBlock : allAssociatedEblocks) {
        WfEntityHistory wfEntityHistory = getEntityHistoryForEblock(eBlock,entitySearch);
        allHistory.add(wfEntityHistory);

        addCherryDestination(eBlock, allHistory);
      }

      WfEntityHistory wfEntityHistory = new WfEntityHistory();
      List<WfNcr> wfNcrs = getNcrs(entitySearch);
      wfEntityHistory.setWfNcrDetails(wfNcrs);
      allHistory.add(wfEntityHistory);

    }
    return allHistory;

  }

  /*private List<WfEntityHistory> getEntityHistoryForFblock(String entitySearch) throws Exception {

    List<WfEntityHistory> allHistory = new ArrayList<WfEntityHistory>();
    List<Long> activeWfInWfConfig = wfDao.findActiveWfInStep(1L, 9L, entitySearch, 38L, 1L);

    for(Long wf : activeWfInWfConfig){
      WfEntityHistory wfEntityHistory = getEntityHistoryForEblock(wfDao.find(wf).getWfEntityLabel(), entityIn);
      allHistory.add(wfEntityHistory);
    }

    List<WfNcr> wfNcrs = getNcrs(entitySearch);
    WfEntityHistory wfEntityHistory = new WfEntityHistory();
    wfEntityHistory.setWfNcrDetails(wfNcrs);
    allHistory.add(wfEntityHistory);

    return allHistory;
  }

  private List<WfEntityHistory> getEntityHistoryForCleanTube(String entitySearch) throws Exception {

    List<WfEntityHistory> allHistory = new ArrayList<WfEntityHistory>();

    List<String> allEntityForVarchar2 = wfGridDataDao.findAssociatedDataGridByData(10133L, entitySearch, 10172L);

    //String entityForVarchar2 = wfDataDao.getEntityForVarchar2(26, entitySearch, 1L, 1L);

    for(String entityForVarchar2 : allEntityForVarchar2){
      allHistory.add(getEntityHistoryForEblock(entityForVarchar2, entityIn));
    }

    List<WfNcr> wfNcrs = getNcrs(entitySearch);
    WfEntityHistory wfEntityHistory = new WfEntityHistory();
    wfEntityHistory.setWfNcrDetails(wfNcrs);
    allHistory.add(wfEntityHistory);

    return allHistory;
  }

  private List<WfEntityHistory> getEntityHistoryForGLorPCRblock(Wf entitySearch) throws Exception {
    List<WfAssoc> assocs = new ArrayList<WfAssoc>();
    List<WfEntityHistory> allHistory = new ArrayList<WfEntityHistory>();

    long leftWfId = 0;

    try {
      assocs = wfAssocDao.getActiveLeft(entitySearch.getWfId());
    }
    catch (NullPointerException npe) {
      //NPE expected if this part of the workflow hasn't occurred
    }
    for(WfAssoc wfAssoc : assocs){
      WfEntityHistory wfEntityHistory = getEntityHistoryForEblock(wfDao.find(wfAssoc.getFromWfId()).getWfEntityLabel(), entityIn);
      allHistory.add(wfEntityHistory);
    }

    List<WfNcr> wfNcrs = getNcrs(entitySearch.getWfEntityLabel());
    WfEntityHistory wfEntityHistory = new WfEntityHistory();
    wfEntityHistory.setWfNcrDetails(wfNcrs);
    allHistory.add(wfEntityHistory);

    return allHistory;
  }*/

  private void addCherryDestination(String blockBarcodeNbr, List<WfEntityHistory> allHistory) throws Exception {

    List<String> cherryDestinations = cherryPickDao.getCherryPlateName(blockBarcodeNbr);

    for (String cherryPlateBarcode : cherryDestinations) { // only expecting one...
      if (null != cherryPlateBarcode) {
        allHistory.add(getEntityHistoryForEblock(cherryPlateBarcode, blockBarcodeNbr));
      }
    }

  }

  public WfEntityHistory getEntityHistoryForEblock(String blockBarcodeNbr, String entitySearch) throws Exception {

      WfEntityHistory wfEntityHistory = new WfEntityHistory();

      List<Wf> wfs = wfDao.findWfForEntity(wfDao.ENTITY_TYPE_E_BLOCK, blockBarcodeNbr);

      if ((null == wfs) || (wfs.size() == 0)) {
          // invalid E
      }
      else {

//        for (Wf eWf : wfs) { // should only be 1 - leaving for now to reveal duplicates so they can be dealt with

          List<WfRelationships> wfRelationships = getRelationshipsForEBlock(wfs.get(0), entitySearch);
          //List<WfRelationships> wfEblockRuns = getEblockRuns(wfs.get(0));
          //List<WfNcr> wfNcrs = getNcrs(blockBarcodeNbr);
          //addActiveRelationship(wfRelationships, wfEblockRuns);

          // active relationships
          wfEntityHistory.setWfRelationships(wfRelationships);
          // run history
          //wfEntityHistory.setWfEblockRuns(wfEblockRuns);
          // NCRs
          //wfEntityHistory.setWfNcrDetails(wfNcrs);
  //      }

      }

      return wfEntityHistory;
    }

  private void addActiveRelationship(List<WfRelationships> wfRelationshipsList, List<WfRelationships> eBlockRuns) {
    // If the block has been NCRd and not sequenced yet, add that relationship to the list of "runs".
    // Otherwise, the last block in the list of "runs" IS the most recent (active) relationship (no action required).
    // This is important as it will effectively show where the E (or its associated entity) is currently at in the workflow

    for(WfRelationships wfRelationships : wfRelationshipsList){
      if ((eBlockRuns.size() == 0) ||
              (wfRelationships.getAnalyzedE()!= null && (
                      wfRelationships.getAnalyzedE().getLabel().equals("N/A") || null == wfRelationships.getAnalyzedE().getLabel()))) {
        WfRelationships activeRelationships = new WfRelationships();
        activeRelationships.setfBlock(wfRelationships.getfBlock());
        activeRelationships.seteBlock(wfRelationships.geteBlock());
        activeRelationships.setDilBlock(wfRelationships.getDilBlock());
        activeRelationships.setCleanTube(wfRelationships.getCleanTube());
        activeRelationships.setSequencingContainer(wfRelationships.getSequencingContainer());
        eBlockRuns.add(activeRelationships);
      }
    }
  }

    private List<WfRelationships> getRelationshipsForEBlock(Wf eBlockWf, String entitySearch) throws CloneNotSupportedException {

      WfRelationships relationships = new WfRelationships();

      // get/load F: only BPO will have an F, legacy LIMs do not
      long fBlockWfId = getLeftWfId(eBlockWf.getWfId());
      WfEntityDisplay entityF = new WfEntityDisplay();
      Wf fBlock = wfDao.find(fBlockWfId);
      if (null == fBlock || eBlockWf.getWfEntityLabel().startsWith("CP")) {
        fBlock = new Wf();
        fBlock.setWfEntityLabel("N/A");
      }
      else {
        entityF.setDisplay(getCreationInfo(fBlock) + "\n" + wfDataDao.getWfDataForToolTip(fBlockWfId));
      }
      entityF.setLabel(fBlock.getWfEntityLabel());
      entityF.setWfId(fBlockWfId);
      relationships.setfBlock(entityF);

      // get/load E
      relationships.seteBlock(getEntityDisplay(eBlockWf.getWfId()));

      //Map<wfEntityTypeId,List<entity labels>>
      Map<Long, List<String>> allAssociatedEntities = wfGridDataDao.findAssociatedDataGridListByData(
               entitySearch, "10133,10134,10166,10167,10168,10170,10171,10172,410");

      Map<Long, List<WfAssoc>> allActiveAssocsByWfId = new HashMap<>();
      allActiveAssocsByWfId = getAllAssocsByWfId(eBlockWf.getWfId(), allActiveAssocsByWfId);

      Map<Long,List<WfAssoc>> entityTypeMap = new HashMap<Long, List<WfAssoc>>();
      for(Long toWfId : allActiveAssocsByWfId.keySet()){
        for(WfAssoc wfAssoc : allActiveAssocsByWfId.get(toWfId)){
          List<WfAssoc> wfAssocs = new ArrayList<>();
          if(entityTypeMap.containsKey(wfAssoc.getToEntityTypeIdentifier())) {
            wfAssocs = entityTypeMap.get(wfAssoc.getToEntityTypeIdentifier());
          }
          wfAssocs.add(wfAssoc);
          entityTypeMap.put(wfAssoc.getToEntityTypeIdentifier(), wfAssocs);
        }
      }

      //get/load dilution block (named same as GL)
      //List<WfAssoc> activeRightAdjacencies = wfAssocDao.getActiveRightAdjacencies(eBlockWf.getWfId());
      List<WfRelationships> dilBlocksRelationshipList = new ArrayList<>();
        Set<Long> dilWfIds = getRequiredAssociation(3L, allAssociatedEntities, entityTypeMap.get(3L),null);
      for(Long wfId : dilWfIds){
        WfRelationships clonedwfRelationships = (WfRelationships) relationships.clone();
        clonedwfRelationships.setDilBlock(getEntityDisplay(wfId));
        dilBlocksRelationshipList.add(clonedwfRelationships);
      }
      if(dilBlocksRelationshipList.isEmpty()){
        dilBlocksRelationshipList.add(relationships);
      }

      //get/load clean tube
      List<WfRelationships> cleanTubeRelationshipList = new ArrayList<>();
      for(WfRelationships wfRelationship : dilBlocksRelationshipList) {
            Set<Long> cleanTubeWfIds = getRequiredAssociation(4L, allAssociatedEntities, entityTypeMap.get(4L), wfRelationship.getDilBlock());

        //activeRightAdjacencies = wfAssocDao.getActiveRightAdjacencies(wfRelationship.getDilBlock().getWfId());
        for (Long wfId : cleanTubeWfIds) {
          WfRelationships clonedwfRelationships = (WfRelationships) wfRelationship.clone();
          clonedwfRelationships.setCleanTube(getEntityDisplay(wfId));
          cleanTubeRelationshipList.add(clonedwfRelationships);
        }
        if(cleanTubeWfIds.isEmpty()){
          cleanTubeRelationshipList.add(wfRelationship);
        }
      }

      //get/load sequencing container
      List<WfRelationships> seqRelationshipList = new ArrayList<>();
      for(WfRelationships wfRelationship : cleanTubeRelationshipList) {
            Set<Long> sequencingContainerWfIds = getRequiredAssociation(6L, allAssociatedEntities, entityTypeMap.get(6L),wfRelationship.getCleanTube());
        //activeRightAdjacencies = wfAssocDao.getActiveRightAdjacencies(wfRelationship.getCleanTube().getWfId());
        for (Long wfId : sequencingContainerWfIds) {
          WfRelationships clonedwfRelationships = (WfRelationships) wfRelationship.clone();
          clonedwfRelationships.setSequencingContainer(getEntityDisplay(wfId));
          seqRelationshipList.add(clonedwfRelationships);
        }
        if(sequencingContainerWfIds.isEmpty()){
          seqRelationshipList.add(wfRelationship);
        }
      }

      //get/load analyzed E
      List<WfRelationships> analyzedERelationshipList = new ArrayList<>();
      Set<Long> analyzedEwfIds = getRequiredAssociation(8L, allAssociatedEntities, entityTypeMap.get(8L),null);
      for(WfRelationships wfRelationship : seqRelationshipList) {
        //activeRightAdjacencies = wfAssocDao.getActiveRightAdjacencies(wfRelationship.getSequencingContainer().getWfId());
        for (Long wfId : analyzedEwfIds) {
          Wf wf = wfDao.find(wfId);
          if(wf.getWfEntityLabel().equalsIgnoreCase(eBlockWf.getWfEntityLabel()) &&
                  wfAssocDao.getActivePoolTubeForAnalyEPlate(wfId).contains(wfRelationship.getSequencingContainer().getWfId())){
            WfRelationships clonedwfRelationships = (WfRelationships) wfRelationship.clone();
            clonedwfRelationships.setAnalyzedE(getEntityDisplay(wfId));
            analyzedERelationshipList.add(clonedwfRelationships);
                        break;
          }
        }
        if(analyzedEwfIds.isEmpty()){
          analyzedERelationshipList.add(wfRelationship);
        }
      }

      //get/load run
        Set<Long> analyzedQuadwfIds = getRequiredAssociation(10200L, allAssociatedEntities, entityTypeMap.get(10200L),null);
      String dataToolTip = "";
      if(null != analyzedQuadwfIds && !analyzedQuadwfIds.isEmpty()){
        dataToolTip = wfDataDao.getWfDataForToolTip(analyzedQuadwfIds.iterator().next());
      }

        WfRelationships wfRelationship= analyzedERelationshipList.get(0);
        List<RunBlock> runBlocks = torrentRunDao.getRuns(wfRelationship.geteBlock().getLabel());
        if(null != runBlocks && !runBlocks.isEmpty()){
            for (RunBlock runBlock : runBlocks) {
                if(runBlock.getTorrentRunName().contains("_Merge_")){
                    WfRelationships clonedwfRelationships =(WfRelationships) wfRelationship.clone();
                    clonedwfRelationships.setCleanTube(null);
                    clonedwfRelationships.setSequencingContainer(null);
                    clonedwfRelationships.setDilBlock(null);
                    clonedwfRelationships.setRunName(runBlock.getTorrentRunName());
                    clonedwfRelationships.setRunDisplay("N/A");
                    analyzedERelationshipList.add(clonedwfRelationships);
                }else{
                    for(WfRelationships wfRelationships: analyzedERelationshipList){

                        if(wfRelationships.getSequencingContainer() != null && runBlock.getTorrentRunName().contains(wfRelationships.getSequencingContainer().getLabel())){
                            wfRelationships.setRunName(runBlock.getTorrentRunName());
                            wfRelationships.setRunDisplay(dataToolTip);
                        }
                    }
                }

            }

            //wfRelationships.setRunDisplay(getMergeToolTip(runBlock.getTorrentAnalysisId()));
          }
          else {
            wfRelationship.setRunDisplay(dataToolTip);
          }

      return analyzedERelationshipList;
    }

  private Map<Long, Map<String, WfAssoc>> getAllAssocs(Long wfId) {
    Map<Long,Map<String,WfAssoc>> entityMap = new HashMap<>();
    List<WfAssoc> activeRightAdjacencies = wfAssocDao.getActiveRightAdjacencies(wfId);

    if(null != activeRightAdjacencies && !activeRightAdjacencies.isEmpty()){
      for(WfAssoc wfAssoc : activeRightAdjacencies) {
        Map<String, WfAssoc> wfAssocMap = new HashMap<>();
        if(entityMap.containsKey(wfAssoc.getToEntityTypeIdentifier())){
          wfAssocMap = entityMap.get(wfAssoc.getToEntityTypeIdentifier());
        }
        if(!wfAssocMap.containsKey(wfAssoc.getToWfLabel())){
          wfAssocMap.put(wfAssoc.getToWfLabel(),wfAssoc);
          entityMap.put(wfAssoc.getToEntityTypeIdentifier(),wfAssocMap);
          Map<Long, Map<String, WfAssoc>> allChildAssocs = getAllAssocs(wfAssoc.getToWfId());
          entityMap.putAll(allChildAssocs);
        }
      }
    }
    return entityMap;
  }

  private Map<Long, List<WfAssoc>> getAllAssocsByWfId(Long wfId, Map<Long,List<WfAssoc>> entityMap) {

    List<WfAssoc> activeRightAdjacencies = wfAssocDao.getActiveRightAdjacencies(wfId);

    if(null != activeRightAdjacencies && !activeRightAdjacencies.isEmpty() && !entityMap.containsKey(wfId)){
      entityMap.put(wfId, activeRightAdjacencies);

      for(WfAssoc wfAssoc : activeRightAdjacencies) {
        getAllAssocsByWfId(wfAssoc.getToWfId(), entityMap);
      }
    }
    return entityMap;
  }

    private Set<Long> getRequiredAssociation(Long wfEntityTypeId, Map<Long, List<String>> allAssociatedEntities, List<WfAssoc> activeRightAdjacencies,WfEntityDisplay entityBlock) {

    boolean foundAssoc = false;
    Set<Long> rightAssocWfIds = new HashSet<>();
    List<String> allAssociatedEntitiesLabel = new ArrayList<>();
    allAssociatedEntities.values().forEach(allAssociatedEntitiesLabel::addAll);

    if(null != activeRightAdjacencies && !activeRightAdjacencies.isEmpty()){
      for(WfAssoc wfAssoc : activeRightAdjacencies){
                if(entityBlock!=null){
                    if(wfAssoc.getToEntityTypeIdentifier().equals(wfEntityTypeId) && allAssociatedEntitiesLabel.contains(wfAssoc.getToWfLabel()) &&
                            entityBlock.getLabel().equalsIgnoreCase(wfAssoc.getFromWfLabel())){
                        foundAssoc = true;
                        rightAssocWfIds.add(wfAssoc.getToWfId());
                    }
                }else{
        if(wfAssoc.getToEntityTypeIdentifier().equals(wfEntityTypeId) && allAssociatedEntitiesLabel.contains(wfAssoc.getToWfLabel())){
          foundAssoc = true;
          rightAssocWfIds.add(wfAssoc.getToWfId());
        }
      }
    }
        }

    /*if(!foundAssoc){
      for(Long wfAssoc : rightAssocWfIds) {
        rightAssocWfIds = getRequiredAssociation(wfEntityTypeId, allAssociatedEntities, wfAssocDao.getActiveRightAdjacencies(wfAssoc));
      }
    }*/
    return rightAssocWfIds;
  }

  private WfEntityDisplay getEntityDisplay(long wfId) {

    WfEntityDisplay entityDisplay = new WfEntityDisplay();
    Wf wf = wfDao.find(wfId);
    if (null == wf) {
      entityDisplay.setLabel("N/A");
      entityDisplay.setDisplay("N/A");
    }
    else {
      entityDisplay.setWfId(wfId);
      entityDisplay.setLabel(wf.getWfEntityLabel());
      entityDisplay.setDisplay(getCreationInfo(wf) + "\n" + wfDataDao.getWfDataForToolTip(wfId));
    }

    return entityDisplay;
  }

  private WfEntityDisplay getEntityDisplay(long snapshotWfId, long wfDataConfigId, int entityTypeId) throws Exception {

    WfEntityDisplay entityDisplay = new WfEntityDisplay();
    Wf wf = getEntity(entityTypeId, wfDataDao.getVarchar2ForWfId(snapshotWfId, wfDataConfigId));
    if (null == wf) {
      entityDisplay.setLabel("N/A");
      entityDisplay.setDisplay("N/A");
    }
    else
    {
      entityDisplay.setWfId(wf.getWfId());
      entityDisplay.setLabel(wf.getWfEntityLabel());
      entityDisplay.setDisplay(getCreationInfo(wf) + "\n" + wfDataDao.getWfDataForToolTip(wf.getWfId()));
    }

    return entityDisplay;

  }

    private long getLeftWfId(long toWfId) {

      List<WfAssoc> assocs = new ArrayList<WfAssoc>();
      long leftWfId = 0;

      try {
        assocs = wfAssocDao.getActiveLeft(toWfId);
      }
      catch (NullPointerException npe) {
        //NPE expected if this part of the workflow hasn't occurred
      }

      if ((null == assocs) || (assocs.size() == 0) || (assocs.size() > 1)) {
        leftWfId = -1;
      }
      else {
        leftWfId = assocs.get(0).getFromWfId();
      }

      return leftWfId;

    }

    private long getRightWfId(long fromWfId) {

      List<WfAssoc> assocs = new ArrayList<WfAssoc>();
      long rightWfId = 0;

      try {
        assocs = wfAssocDao.getActiveRight(fromWfId, 0);
      }
      catch (NullPointerException npe) {
        //NPE expected if this part of the workflow hasn't occurred
      }

      if ((null == assocs) || (assocs.size() == 0) || (assocs.size() > 1)) {
        rightWfId = -1;
      }
      else {
        rightWfId = assocs.get(0).getToWfId();
      }

      return rightWfId;

    }

  private long getCleanTubeWfId(long dilBlockWfId, long eBlockWfid) {

    WfData wfData = wfDataDao.getValue(23, eBlockWfid);
    List<Long> wfs = new ArrayList<Long>();
    long cleanTubeWfId = 0;

    try {
      wfs = wfAssocDao.getActiveCleanTubeForDilBlock(dilBlockWfId, wfData.getWfDataNumber().intValue());
    }
    catch (NullPointerException npe) {
      //NPE expected if this part of the workflow hasn't occurred
    }

    if ((null == wfs) || (wfs.size() == 0) || (wfs.size() > 1)) {
      cleanTubeWfId = -1;
    }
    else {
      cleanTubeWfId = wfs.get(0);
    }

    return cleanTubeWfId;

      }

  private long getAnalyzeEWfId(long seqContainerWfId, long eBlockWfid) {

    WfData wfData = wfDataDao.getValue(23, eBlockWfid);

    List<Long> wfs = new ArrayList<Long>();
    long analyzedEWfId = 0;

    try {
      wfs = wfAssocDao.getActiveCleanTubeForDilBlock(seqContainerWfId, wfData.getWfDataNumber().intValue());
    }
    catch (NullPointerException npe) {
      //NPE expected if this part of the workflow hasn't occurred
    }

    if ((null == wfs) || (wfs.size() == 0) || (wfs.size() > 1)) {
      analyzedEWfId = -1;
    }
    else {
      analyzedEWfId = wfs.get(0);
    }

    return analyzedEWfId;

      }


    private List<WfNcr>  getNcrs(String blockBarcodeNbr) {
      // get the NCRs for every instance of the E
      //List<WfNcr> wfNcrs = ncrDao.findNCRsForEblock(blockBarcodeNbr);

       List<String> ncrdEntitiesList = wfGridDataDao.findNcrdEntityListByGridDataType(
              blockBarcodeNbr, "10133,10134,10166,10167,10168,10170,10171,10172");
      List<WfNcr> wfNcrsList = new ArrayList<>();
       for(String ncrBlock : ncrdEntitiesList){
         List<WfNcr> wfNcrs = ncrDao.findNCRsByAffectedEntity(ncrBlock);

         for (WfNcr ncr : wfNcrs) {
           try {
             ncr.setDisplay(getCreationInfo(ncr.getWfId()) + "\n" + wfDataDao.getWfDataForToolTip(ncr.getWfId()));
             wfNcrsList.add(ncr);
           }
           catch (Exception ex) {

           }

         }
       }



      // get the NCRs for every other entity in the chain
 /*     addNcrs(wfNcrs, wfRelationships.getfBlock().getLabel(), 9);
      addNcrs(wfNcrs, wfRelationships.getDilBlock().getLabel(), 3);
      addNcrs(wfNcrs, wfRelationships.getDilBlock().getLabel(), 5); // GL is the same label as Dil Block
      addNcrs(wfNcrs, wfRelationships.getCleanTube().getLabel(), 4);
      addNcrs(wfNcrs, wfRelationships.getSequencingContainer().getLabel(), 6);*/

      return wfNcrsList;

    }

    private void addNcrs(List<WfNcr> allNcrs, String entityLabel, int entityTypeId) {

      List<WfNcr> ncrs = ncrDao.findNCRsForEntity(entityLabel, entityTypeId);

      for (WfNcr wfNcr : ncrs) {
        allNcrs.add(wfNcr);
      }

    }

    private List<WfRelationships> getEblockRuns(Wf eBlockWf) throws Exception {
      // get a rec for each run this E has been on

      List<RunBlock> runBlocks = torrentRunDao.getRuns(eBlockWf.getWfEntityLabel());

      List<WfRelationships> runRelationships = new ArrayList<WfRelationships>();

      for (RunBlock runBlock : runBlocks) {
        WfRelationships wfRelationships = new WfRelationships();

        wfRelationships.setRunName(runBlock.getTorrentRunName());

        if (runBlock.getTorrentRunName().contains("_Merge_")) {
          wfRelationships.setRunDisplay("N/A");
          //wfRelationships.setRunDisplay(getMergeToolTip(runBlock.getTorrentAnalysisId()));
        }
        else {
          wfRelationships.setRunDisplay(wfDataDao.getWfDataForToolTip(runBlock.getSnapshotWfId()));
        }

        long fBlockWfId = getLeftWfId(eBlockWf.getWfId());
        WfEntityDisplay entityF = new WfEntityDisplay();
        Wf fBlock = wfDao.find(fBlockWfId);
        if (null == fBlock || runBlock.getBlockBarcodeNbr().startsWith("CP")) {
           fBlock = new Wf();
           fBlock.setWfEntityLabel("N/A");
         }
         else {
           entityF.setDisplay(getCreationInfo(fBlock) + "\n" + wfDataDao.getWfDataForToolTip(fBlockWfId));
         }
         entityF.setWfId(fBlockWfId);
         entityF.setLabel(fBlock.getWfEntityLabel());
         wfRelationships.setfBlock(entityF);

        WfEntityDisplay wfEntityEblock = new WfEntityDisplay();
        Wf wfEblock = new Wf();
        wfEblock.setWfEntityLabel(eBlockWf.getWfEntityLabel());
        wfEntityEblock.setWfId(eBlockWf.getWfId());
        wfEntityEblock.setLabel(wfEblock.getWfEntityLabel());
        wfEntityEblock.setDisplay(getCreationInfo(eBlockWf) + "\n" + wfDataDao.getWfDataForToolTip(eBlockWf.getWfId()));

        wfRelationships.seteBlock(wfEntityEblock);

        if (runBlock.getSnapshotWfId() != 0) {
          wfRelationships.setDilBlock(getEntityDisplay(runBlock.getSnapshotWfId(), 486, 3));

          WfEntityDisplay wfCleanTubeDisplay = getEntityDisplay(runBlock.getSnapshotWfId(), 485, 4);
          wfRelationships.setCleanTube(wfCleanTubeDisplay);

          WfEntityDisplay seqEntity = getEntityDisplay(runBlock.getSnapshotWfId(), 525, 6);

          if (seqEntity.getLabel().equals("N/A")) {
            // To populate this entity for runs before this data was being collected in snapshot.
            Wf cleanTubeWf = getEntity(4, wfCleanTubeDisplay.getLabel());
            if (null != cleanTubeWf) {
              long sequencingContainerWfId = getRightWfId(cleanTubeWf.getWfId());
              seqEntity = getEntityDisplay(sequencingContainerWfId);
            }
          }

          wfRelationships.setSequencingContainer(seqEntity);

        }

        WfEntityDisplay wfEntityAnalyzedE = new WfEntityDisplay();
        Wf wfAnalyzedE = new Wf();
        wfAnalyzedE.setWfEntityLabel(eBlockWf.getWfEntityLabel());
        if(null != wfRelationships.getSequencingContainer() && null != wfRelationships.getSequencingContainer().getWfId() && null != eBlockWf){
          wfEntityAnalyzedE.setWfId(getAnalyzeEWfId(wfRelationships.getSequencingContainer().getWfId(),eBlockWf.getWfId()));
        }
        wfEntityAnalyzedE.setLabel(wfEblock.getWfEntityLabel());
        wfEntityAnalyzedE.setDisplay(getRunDisplay(runBlock.getBlockBarcodeNbr(), runBlock.getTorrentAnalysisId()));

        wfRelationships.setAnalyzedE(wfEntityAnalyzedE);


        runRelationships.add(wfRelationships);
      }

      return runRelationships;
    }

  private Wf getEntity(int entityTypeId, String entityLabel) {

    System.out.println("finding: " + entityTypeId + "\t" + entityLabel);

    List<Wf> wfs = wfDao.findWfForEntity(entityTypeId, entityLabel);
    Wf entity = null;

    if (wfs.size() == 0) {
      //todo: error
    }
    else if (wfs.size() > 1) {
      //todo: erorr
    }
    else {
      entity = wfs.get(0);
    }

    return entity;
  }

  private boolean entityIsProject(String entityName) {
    return findEBlocks(entityName).size() > 0;
  }


  private List<String> findEBlocks(String entity) {
    return wfDao.findEntitiesLike(1, "and (wf_entity_label like 'E" + entity + "%'\n" +
                                                "or wf_entity_label like 'CP" +  entity + "%')\n");
  }
  private boolean entityIsEblock(String entityName) {

    if (entityName.startsWith("E")) {
      List<Wf> wfs = wfDao.findWfForEntity(1, entityName);
      if (wfs.size() == 0) {
        return false;
      }
      else {
        return true;
      }
    }
    else {
      return false;

  }

  }

  private String getRunDisplay(String blockBarcodeNbr, long torrentAnalysisId) {
    return  projectResultDao.getToolTip(blockBarcodeNbr, torrentAnalysisId);
  }

  private String getMergeToolTip(long mergeTorrentAnalysisId) {

      String toolTip = "Merged From:\n";

      MergeSourceRuns mergeSourceRuns = mergedSampleDao.findMerge(mergeTorrentAnalysisId);

      if (null == mergeSourceRuns) {
        toolTip += "N/A";
      }
      else {

        toolTip +=  torrentRunDao.getRunName(mergeSourceRuns.getTorrentAnalysisId1());
        toolTip += "\n";
        toolTip += torrentRunDao.getRunName(mergeSourceRuns.getTorrentAnalysisId2());
      }

      return toolTip;

    }

  private String getCreationInfo(Wf wf) {
    return "Created by:" + wf.getCreateUser() + "\n" +
           "Created on:" + wf.getCreateTs() + "\n" +
           "Last updated by:" + wf.getUpdateUser() + "\n" +
           "Last updated on:" + wf.getUpdateTs() + "\n";
  }

  private String getCreationInfo(long wfId) {

    Wf wf = wfDao.find(wfId);

    if (null != wf) {
      return "Created by:" + wf.getCreateUser() + "\n" +
           "Created on:" + wf.getCreateTs() + "\n" +
           "Last updated by:" + wf.getUpdateUser() + "\n" +
           "Last updated on:" + wf.getUpdateTs() + "\n";
    }
    else {
      return "";
    }

  }


}
