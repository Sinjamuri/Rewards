package com.monsanto.gwg.atlas.json.labelprinting;

/**
 * Created by syroth on 5/30/2017.
 */
public class JsonPrintResponse {

    private Long printerID;
    private String printMessage;
    private String printResponse;

    public Long getPrinterID(){return this.printerID;}

    public void setPrinterID(Long printerID){this.printerID = printerID;}

    public String getPrintMessage(){return this.printMessage;}

    public void setPrintMessage(String printMessage){this.printMessage = printMessage;}

    public String getPrintResponse(){return this.printResponse;}

    public void setPrintResponse(String printResponse){this.printResponse = printResponse;}

    @Override
    public String toString(){
        return "JsonPrintResponse [printerID=" + this.printerID + ", printMessage = " + this.printMessage +
                ", printResponse=" + this.printResponse + "]";
    }
}
