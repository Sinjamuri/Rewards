package com.monsanto.gwg.atlas.service.pcrExt;

import com.monsanto.gwg.atlas.dao.core.WfAssocDao;
import com.monsanto.gwg.atlas.dao.core.WfConfigPropertyDao;
import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.model.core.WfData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PcrExtService {

  private static final Logger LOG = LoggerFactory.getLogger(PcrExtService.class);

  @Autowired WfDataDao wfDataDao;

  @Autowired
  private WfAssocDao wfAssocDao;

  @Autowired
  private WfConfigPropertyDao wfConfigPropertyDao;

  private static final String PCR_EXT_STATUS_COMPLETE="PCR_EXT_STATUS_END";
  private static final String PCR_EXT_STATUS_LAB_CALL="PCR_EXT_STATUS_LAB_CALL";
  private static final String PCR_EXT_STATUS_FAILED_PCR="PCR_EXT_STATUS_FAILED_PCR";
  public static final String CONFIG_KEY_PCR_EXT_STATUS_RE_EXTRACT_PENDING = "PCR_EXT_STATUS_RE_EXTRACT_PENDING";


  public boolean validForPass(long eBlockwfId) {

    // if PCR is processed and the conc for the E block is between the thresholds, pass is allowed
    // PCR history is stored as right relationships to the PCR plate (entity_type_id=10)
    // The most recent PCR plate/conc is stored directly at the E level for queue display and status determination

      WfData wfData = wfDataDao.getValue(170, eBlockwfId); // get status for the E

      if (null == wfData) {
        return false;
      }
      else {
        return wfData.getWfDataVarchar2().equals(PCR_EXT_STATUS_COMPLETE);

      }
  }

  public boolean normalizeEligible(long eBlockwfId) {

    // Returns true if the E block has a status of Lab Call or FAILED PCR
    WfData wfData = wfDataDao.getValue(170, eBlockwfId); // get PCR Conc for the E

    if (null == wfData) {
      return false;
    }
    else {
      if (wfData.getWfDataVarchar2().equals(PCR_EXT_STATUS_LAB_CALL) || wfData.getWfDataVarchar2().equals(PCR_EXT_STATUS_FAILED_PCR)) {
        return true;
      }
      else {
        return false;
      }

    }

  }

  public boolean reExtractConfirmationEligibible(long eBlockwfId) {

    // Returns true if the E block has a status of Lab Call or FAILED PCR
    WfData wfData = wfDataDao.getValue(170, eBlockwfId); // get PCR Conc for the E

    if (null == wfData) {
      return false;
    }
    else {
      if (wfData.getWfDataVarchar2().equals(CONFIG_KEY_PCR_EXT_STATUS_RE_EXTRACT_PENDING)) {
        return true;
      }
      else {
        return false;
      }

    }

  }

}