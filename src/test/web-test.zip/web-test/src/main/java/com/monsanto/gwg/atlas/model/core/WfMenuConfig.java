package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;
import java.util.Set;
import java.util.TreeSet;

public class WfMenuConfig {
    @DbColumn(field="wf_menu_config_id")
  private Long wfMenuConfigId;
    @DbColumn(field="wf_config_id")
  private Long wfConfigId;
    @DbColumn(field="wf_menu_name")
  private String wfMenuName;
    @DbColumn(field="wf_menu_number")
  private Integer wfMenuNumber;
    @DbColumn(field="wf_menu_privileges")
  private Set<String> wfMenuPrivileges;
    @DbColumn(field="ui_custom_view")
  private String uiCustomView;
    @DbColumn(field="create_user")
  private String createUser;
    @DbColumn(field="create_ts")
  private Timestamp createTs;
    @DbColumn(field="active")
  private boolean active;

  public Long getWfMenuConfigId() {
    return wfMenuConfigId;
  }

  public void setWfMenuConfigId(Long wfMenuConfigId) {
    this.wfMenuConfigId = wfMenuConfigId;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getWfMenuName() {
    return wfMenuName;
  }

  public void setWfMenuName(String wfMenuName) {
    this.wfMenuName = wfMenuName;
  }

  public Integer getWfMenuNumber() {
    return wfMenuNumber;
  }

  public void setWfMenuNumber(Integer wfMenuNumber) {
    this.wfMenuNumber = wfMenuNumber;
  }

  public Set<String> getWfMenuPrivileges() {
    return wfMenuPrivileges;
  }

  public void setWfMenuPrivileges(String wfMenuPrivileges) {
    this.wfMenuPrivileges = new TreeSet<String>();

    //Menu privileges are by default unrestrictive
    if (wfMenuPrivileges!=null && wfMenuPrivileges.trim().length()>0) {
      String[] vals = wfMenuPrivileges.split(",");
      for (String val : vals) {
        if (val!=null && val.trim().length()>0) {
          this.wfMenuPrivileges.add(val.trim().toUpperCase());
        }
      }
    }
  }

  public String getUiCustomView() {
    return uiCustomView;
  }

  public void setUiCustomView(String uiCustomView) {
    this.uiCustomView = uiCustomView;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }
}
