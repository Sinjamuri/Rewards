package com.monsanto.gwg.atlas.model.sandwichshop;

/**
 * Created by REGAMA on 8/18/14.
 */
public class SandwichShopOrder {
    private Long orderId;
    private String pickUpName;
    private String orderLabel;
    private Integer totalSandwiches;
    private Integer completeSandwiches;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getPickUpName() {
        return pickUpName;
    }

    public void setPickUpName(String pickUpName) {
        this.pickUpName = pickUpName;
    }

    public String getOrderLabel() {
        return orderLabel;
    }

    public void setOrderLabel(String orderLabel) {
        this.orderLabel = orderLabel;
    }

    public Integer getTotalSandwiches() {
        return totalSandwiches;
    }

    public void setTotalSandwiches(Integer totalSandwiches) {
        this.totalSandwiches = totalSandwiches;
    }

    public Integer getCompleteSandwiches() {
        return completeSandwiches;
    }

    public void setCompleteSandwiches(Integer completeSandwiches) {
        this.completeSandwiches = completeSandwiches;
    }
}
