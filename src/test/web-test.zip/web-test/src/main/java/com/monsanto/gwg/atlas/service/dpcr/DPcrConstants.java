package com.monsanto.gwg.atlas.service.dpcr;

/**
 * Created by ASHAR7 on 12/22/2014.
 */
public interface DPcrConstants {

    public final static long DPCR_PLATE_NAME_WF_DATA_CONFIG_ID = 462L;
    public final static long DPCR_ROX_THRESHOLD_WF_DATA_CONFIG_ID = 480L;
    public final static long DPCR_VIC_THRESHOLD_WF_DATA_CONFIG_ID = 481L;
    public final static long DPCR_FAM_THRESHOLD_WF_DATA_CONFIG_ID = 482L;
    public final static long DPCR_REF_FILTER_WF_DATA_CONFIG_ID = 483L;
    public final static long DPCR_FILTER_WF_DATA_CONFIG_ID = 540L;
    public final static long DPCR_CROP_TYPE_WF_DATA_CONFIG_ID = 1120L;
    public final static long DPCR_TISSUE_TYPE_WF_DATA_CONFIG_ID = 1121L;
    public final static long DPCR_MARKER_WF_DATA_CONFIG_ID = 1122L;
    public final static long DPCR_CREATE_DATE_WF_DATA_CONFIG_ID = 1123L;
    public final static long DPCR_COMMENT_WF_DATA_CONFIG_ID = 1124L;
    public final static long DPCR_EXPORTED_RESULTS_FILE = 1146L;
    public final static long DPCR_ANALYSIS_RUN_NAME = 1220L;

    public static final long DPCR_ROX_WF_GRID_DATA_TYPE_ID = 180L;
    public static final long DPCR_FAM_WF_GRID_DATA_TYPE_ID = 177L;
    public static final long DPCR_VIC_WF_GRID_DATA_TYPE_ID = 178L;
    public static final long DPCR_WELL_WF_GRID_DATA_TYPE_ID = 179L;

    public static final long DPCR_ROX_POS_CNT_WF_GRID_DATA_TYPE_ID = 70L;
    public static final long DPCR_FAM_POS_CNT_WF_GRID_DATA_TYPE_ID = 71L;
    public static final long DPCR_VIC_POS_CNT_WF_GRID_DATA_TYPE_ID = 72L;
    public static final long DPCR_ROX_EST_WF_GRID_DATA_TYPE_ID = 73L;
    public static final long DPCR_FAM_EST_WF_GRID_DATA_TYPE_ID = 74L;
    public static final long DPCR_VIC_EST_WF_GRID_DATA_TYPE_ID = 75L;

    public final static long DPCR_WF_CONFIG_ID = 26L;
    public final static long DPCR_EXPORT_RESULTS_WF_STEP_CONFIG_ID = 520L;
    public final static long DPCR_PLATE_WF_ENTITY_TYPE_ID = 621L;

    public final static long DPCR_SAMPLE_WF_ENTITY_TYPE_ID = 631L;
    public final static long DPCR_FILTER_RESULT_WF_ENTITY_TYPE_ID = 611L;

    public final static long DPCR_COMPUTE_ESTIMATES_WF_STEP_CONFIG_ID = 822L;
    public final static long DPCR_ANALYSIS_RUNS_STEP_CONFIG_ID = 1180L;

    public final static long DPCR_WAIT_FOR_DATA_WF_STEP_CONFIG_ID = 1100L;

    public static long START_ANALYSIS_RUN_WF_STEP_CONFIG_ID = 1160L;
    public final static long DPCR_SAMPLE_WF_STEP_CONFIG_ID = 1140L;
    public final static long DPCR_SAMPLE_ASSOC_WF_STEP_CONFIG_ID = 1101L;

    public final static String DPCR_SAMPLE_TEMPLATE_SHEET_NAME = "Upload Sheet";
    public final static String PATTERN_SPLIT_STRING_NUMERIC_GROUP = "\"[^A-Z0-9]+|(?<=[A-Z])(?=[0-9])|(?<=[0-9])(?=[A-Z])\"";

    public final static int DPCR_SAMPLE_TEMPLATE_USABLE_COLUMNS = 8;

    public final static String WF_REF_CONFIG_KEY_CROP = "Crop Type";
    public final static String WF_REF_CONFIG_KEY_TISSUE = "Tissue Type";

    public static final long NORMALIZED_INTENSITY_VALUE_WF_GRID_DATA = 156L;

    public static final long FILTER_IS_REFERENCE_WF_DATA_CONFIG_ID = 483L;
    public static final long FILTER_HISTOGRAM_WF_DATA_CONFIG_ID = 1100L;
    public static final long FILTER_RESULTS_IMAGE_URL_WF_DATA_CONFIG_ID = 1101L;

    public final static String DATE_FORMAT = "mm/dd/yyyy";

    public final static String ANALYSIS__EXCEL_TEMPLATE = "/excelTemplates/AnalysisRunExportTemplate.xlsx";


    public final static long DPCR_ANALYSIS_RUN_WF_ENTITY_TYPE_ID = 651L;

    // Analysis runs data configs
    public final static long DPCR_POS_COUNT_THRESHOLD_WF_DATA_CONFIG_ID = 1140L;
    public final static long DPCR_POS_COUNT_THRESHOLD_ALGORITHM_WF_DATA_CONFIG_ID = 1141L;
    public final static long DPCR_SCATTER_PLOT_WF_DATA_CONFIG_ID = 1142L;
    public final static long DPCR_COPY_ESTIMATE_ALGORITHM_WF_DATA_CONFIG_ID = 1143L;
    public final static long DPCR_RATIO_MULTIPLIERS_WF_DATA_CONFIG_ID = 1160L;
    public final static long DPCR_RATIO_THRESHOLDS_WF_DATA_CONFIG_ID = 1144L;
    public final static long DPCR_RATIO_THRESHOLD_ALGORITHM_WF_DATA_CONFIG_ID = 1145L;
    public final static long DPCR_POS_COUNT_WF_GRID_DATA_TYPE_ID = 196L;
    public final static long DPCR_ZYGOSITY_CALL_WF_GRID_DATA_TYPE_ID = 197L;

    public final static long RATIO_MULTIPLIERS_PROPERTY_REF_ID = 81L;
    public final static long HEMI_RATIO_THRESHOLDS_PROPERTY_REF_ID = 90L;

    public final static long WF_REF_TISSUE_TYPE = 474L;
    public final static long WF_REF_CROP_TYPE = 470L;

    public static final String DPCR_PROJECT_STATUS_UPLOAD_REQUESTED = "DPCR_PROJECT_STATUS_UPLOAD_REQUESTED";

    public static final String CONFIG_KEY_DPCR_P_PLATE_STATUS_UPLOAD_PENDING="DPCR_P_PLATE_STATUS_UPLOAD_PENDING";
    public static final String CONFIG_KEY_DPCR_P_PLATE_STATUS_REDO_PENDING="DPCR_P_PLATE_STATUS_REDO_PENDING";


}

