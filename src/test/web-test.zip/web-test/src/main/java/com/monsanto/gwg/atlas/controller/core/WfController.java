package com.monsanto.gwg.atlas.controller.core;

import com.google.gson.Gson;
import com.monsanto.gwg.atlas.agent.common.AtlasAgent;
import com.monsanto.gwg.atlas.agent.common.utils.UtilCommon;
import com.monsanto.gwg.atlas.bean.core.WfGridDataBean;
import com.monsanto.gwg.atlas.bean.core.WfGridDataTypeBeanDimensioned;
import com.monsanto.gwg.atlas.constants.WfStepDataConfigConstants;
import com.monsanto.gwg.atlas.json.core.*;
import com.monsanto.gwg.atlas.model.containerlocation.ContainerLocation;
import com.monsanto.gwg.atlas.model.core.*;
import com.monsanto.gwg.atlas.service.UtilService;
import com.monsanto.gwg.atlas.service.annotations.WfDelegateMethod;
import com.monsanto.gwg.atlas.service.annotations.WfParam;
import com.monsanto.gwg.atlas.service.annotations.WfParamValue;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.tossQueue.TossQueueService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

@Controller
public class WfController {

    @Autowired
    private WfService wfService;

    @Autowired
    private UtilService utilService;

    @Autowired
    private WfValidator wfValidator;

    @Autowired
    private TossQueueService tossQueueService;


    // PGROS1: Added to find service beans for specialized workflows, this replaces previous private members for each workflow
    @Autowired
    private ListableBeanFactory listableBeanFactory;


    private static final Logger LOG = LoggerFactory.getLogger(WfController.class);

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String getWfConfigs(Model model) {
        model.addAttribute("WF_CONFIGS", wfService.findAllWfConfig());
        return "core/wf";
    }

    @RequestMapping(value = "/{wfConfigDomain}/wfDetail/", method = RequestMethod.GET)
    public String getWfDetail(@PathVariable("wfConfigDomain") String wfConfigDomain,
                              @RequestParam(required = true) Long wfId,
                              Model model
    ) {
        model.addAttribute("wfId", wfId);
        model.addAttribute("label", wfService.getWfEntityLabel(wfId));
        model.addAttribute("bufferedContent", wfService.getWfDetails(wfId));

        return "core/wfDetail";
    }

    @RequestMapping(value = "/{wfConfigDomain}/secure_checkpoint/", method = RequestMethod.POST)
    public
    @ResponseBody
    JsonSecureCheckpoint getSecureCheckpoint(
            @PathVariable("wfConfigDomain") String wfConfigDomain,
            @RequestParam(required = true) String userId,
            @RequestParam(required = true) Long wfStepConfigId,
            HttpServletResponse response) {

        //never cache security ajax calls
        response.setHeader("Pragma", "No-cache");
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", 0);

        //capture any error to diagnose errors
        JsonSecureCheckpoint jsonSecureCheckpoint = new JsonSecureCheckpoint();
        jsonSecureCheckpoint.setAllowed(wfService.isUserAllowed(userId, wfStepConfigId, wfConfigDomain));

        return jsonSecureCheckpoint;
    }

    @RequestMapping(value = "/{wfConfigDomain}/", method = RequestMethod.POST)
    public
    @ResponseBody
    JsonResponse postWfStep(
            @PathVariable("wfConfigDomain") String wfConfigDomain,
            @RequestParam Long wfStepConfigId,
            @RequestBody JsonPost jsonPost,
            HttpSession session,
            HttpServletRequest request,
            HttpServletResponse response) {

        //check to make sure user is allowed to post to this step
        JsonResponse jsonResponse = null;

        if (wfService.isUserAllowed(jsonPost.getUserId(), wfStepConfigId, wfConfigDomain)) {
            jsonResponse = wfValidator.validate(wfConfigDomain, wfStepConfigId, jsonPost);
            if (jsonResponse.isValid()) {
                jsonResponse = getJsonResponse(wfConfigDomain, wfStepConfigId, jsonPost, session, request, response);
            }
        } else {
            jsonResponse = new JsonResponse();
            jsonResponse.setAccessDenied();
        }

        return jsonResponse;
    }


    private JsonResponse getJsonResponse(String wfConfigDomain,
                                         long wfStepConfigId,
                                         JsonPost jsonPost,
                                         HttpSession session,
                                         HttpServletRequest request,
                                         HttpServletResponse response) {

        JsonResponse jsonResponse = null;

        //use reflection to delegate to the matching service call
        //this eliminates ongoing code maintenance driven by workflow changes when steps are added/removed
        final String METHOD_NAME = "post" + wfStepConfigId;
        try {
            //DOMAIN_CONFIG//

            Object domainService = null;

            // Get all service beans
            Map<String, Object> serviceBeans = listableBeanFactory.getBeansWithAnnotation(Service.class);

            // For each service bean we assume the config domain name matches the start of the name of the service
            // e.g., gbs config domain corresponds to a @service annotated GbsService class
            for (Map.Entry<String, Object> beanEntry : serviceBeans.entrySet()) {
                if (beanEntry.getKey().toLowerCase().startsWith(wfConfigDomain.toLowerCase())) {
                    domainService = beanEntry.getValue();
                    break;
                }
            }

            //process NCRs
            Iterator<Map<String, String>> rowIter = jsonPost.getRows().iterator();
            while (rowIter.hasNext()) {
                Map<String, String> values = rowIter.next();

                Long wfId = Long.parseLong(values.get("wfId"));
                String ncrCode = values.get("ncrCode");
                String ncrContext = values.get("ncrContext");
                String ncrReason = values.get("ncrReason");
                if (ncrCode != null && !ncrCode.trim().isEmpty()) {
                    String ncrComment = values.get("ncrComment");
                    //apply NCR
                    long wfNcrConfigId = Long.parseLong(ncrCode);
                    Long wfNcrReasonId = null;
                    if (ncrReason != null && !ncrReason.trim().isEmpty()) {
                        wfNcrReasonId = Long.parseLong(ncrReason);
                    }
                    wfService.applyNcr(wfNcrConfigId, wfId, ncrContext, ncrComment, jsonPost.getUserId(), wfNcrReasonId);

                    //remove this container from the post set
                    rowIter.remove();
                }
            }

            //delegate validation to isolated service (if validation method exists)

            //delegate to isolated service if a method exists
            try {
                Method serviceMethod = getDelegateServiceMethod(domainService, wfStepConfigId);

                ArrayList<Object> args = new ArrayList<Object>();
                Class[] parameterTypes = serviceMethod.getParameterTypes();
                Annotation[][] parameterAnnotations = serviceMethod.getParameterAnnotations();

                for (int i = 0; i < parameterTypes.length; i++) {
                    boolean hasWfParamAnnotation = false;

                    for (Annotation annotation : parameterAnnotations[i]) {
                        if (annotation instanceof WfParam) {
                            hasWfParamAnnotation = true;

                            if (((WfParam) annotation).value().getParamType().equals(parameterTypes[i])) {
                                Object arg;

                                switch (((WfParam) annotation).value()) {
                                    case USER_ID:
                                        arg = jsonPost.getUserId();
                                        break;
                                    case JSON_POST:
                                        arg = jsonPost;
                                        break;
                                    case SESSION:
                                        arg = session;
                                        break;
                                    case REQUEST:
                                        arg = request;
                                        break;
                                    case RESPONSE:
                                        arg = response;
                                        break;
                                    default:
                                        throw new EnumConstantNotPresentException(WfParamValue.class, "Service step method " + serviceMethod.getName() +
                                                " WfParam annotation value " + ((WfParam) annotation).value() + " has no object mapping.");
                                }

                                args.add(arg);
                            } else {
                                throw new IllegalArgumentException("Service step method " + serviceMethod.getName() +
                                        " has wrong parameter type for " + annotation);
                            }
                        }
                    }

                    if (!hasWfParamAnnotation) {
                        throw new IllegalArgumentException("Service step method " + serviceMethod.getName() +
                                " has parameter without WfParam annotation.");
                    }
                }

                Object[] argsArray = new Object[args.size()];
                args.toArray(argsArray);
                jsonResponse = (JsonResponse) serviceMethod.invoke(domainService, argsArray);

            } catch (NoSuchMethodException ex) {
                //custom method does not exist, so default pass to next step
                wfService.savePostData(jsonPost);
                wfService.passAllWf(jsonPost, null);
            }

        } catch (Exception ex) {
            LOG.error("Method invocation error", ex);

            //send exception to the UI to be logged by console
            jsonResponse = new JsonResponse();
            jsonResponse.setException(utilService.getStackTrace(ex));
        }

        return jsonResponse;
    }

    private Method getDelegateServiceMethod(Object domainService, long wfStepConfigId) throws NoSuchMethodException {
        if (domainService == null) {
            throw new NoSuchMethodException();
        }

        for (Method serviceMethod : domainService.getClass().getMethods()) {
            if (serviceMethod.isAnnotationPresent(WfDelegateMethod.class)) {
                if (serviceMethod.getAnnotation(WfDelegateMethod.class).wfStepConfigId() == wfStepConfigId
                        && JsonResponse.class.isAssignableFrom(serviceMethod.getReturnType())) {
                    return serviceMethod;
                }
            }
        }

        throw new NoSuchMethodException();
    }

    @RequestMapping(value = "/{wfConfigDomain}/grid_data_types/")
    public
    @ResponseBody
    WfGridDataTypeBeanDimensioned getWfGridDataTypes(@PathVariable("wfConfigDomain") String wfConfigDomain,
                                                     @RequestParam(required = true) Long wfId) {
        return wfService.getWfGridDataTypes(wfId);
    }

    @RequestMapping(value = "/{wfConfigDomain}/ncr_reasons/")
    public
    @ResponseBody
    Map<Long, String> getWfNcrReasonMap(@PathVariable("wfConfigDomain") String wfConfigDomain) {
        return wfService.getWfNcrReasonMap(wfConfigDomain);
    }

    @RequestMapping(value = "/{wfConfigDomain}/grid_data/")
    public
    @ResponseBody
    List<WfGridDataBean> getWfGridData(@PathVariable("wfConfigDomain") String wfConfigDomain,
                                       @RequestParam(required = true) Long wfId,
                                       @RequestParam(required = true) Long gridDataTypeId,
                                       @RequestParam(required = true) String filterValue) {
        List<WfGridDataBean> wfGridData = wfService.getWfGridData(wfId, gridDataTypeId);
        if (null != filterValue && !filterValue.isEmpty()) {
            try {
                filterWfGridData(gridDataTypeId, filterValue, wfGridData);
            } catch (Exception e) {

            }
        }

        return wfGridData;
    }

    private void filterWfGridData(Long gridDataTypeId, String filterValue, List<WfGridDataBean> wfGridData) {

        WfGridDataType wfGridDataType = wfService.getWfGridType(gridDataTypeId);
        String filterType = wfService.findByWfConfigIdAndKey(1L, wfGridDataType.getWfGridDataType().toUpperCase() + "_TYPE").getPropertyValue();

        for (WfGridDataBean wfGridDataBean : wfGridData) {
            wfGridDataBean.setMeetsThresholds(false);
            if (filterType.equals("&lt;")) {
                if (Double.parseDouble(wfGridDataBean.getValue()) < Double.parseDouble(filterValue)) {
                    wfGridDataBean.setMeetsThresholds(true);
                }
            } else {
                if (Double.parseDouble(wfGridDataBean.getValue()) > Double.parseDouble(filterValue)) {
                    wfGridDataBean.setMeetsThresholds(true);
                }
            }
        }
    }

    @RequestMapping(value = "/{wfConfigDomain}/", method = RequestMethod.GET)
    public String getWfStep(@PathVariable("wfConfigDomain") String wfConfigDomain,
                            @RequestParam(required = false) Long wfStepConfigId,
                            Model model, final RedirectAttributes redirectAttributes) {

        List<WfStepConfig> wfStepConfigs = wfService.findAllWfStepConfig(wfConfigDomain);
        List<WfMenuConfig> wfMenuConfigs = wfService.findAllWfMenuConfig(wfConfigDomain);
        model.addAttribute("WF_MENU_CONFIGS", wfMenuConfigs);
        // SMBT- 891 - As ATLAS, when agents are down for deployment I should indicate that within the workflow pages
        WfConfigProperty wfConfigProperty = wfService.findByWfConfigIdAndKeyAndValue(wfConfigDomain, "PAUSE_ALL_AGENTS", "Y");
        if (wfConfigProperty != null) {
            model.addAttribute("AGENT_MSG", "Agents are currently turned off for deployment.");
        }
        if (wfStepConfigs.size() == 0) {
            redirectAttributes.addFlashAttribute("UI_MSG", "The workflow domain you have specified does not exist. Please select a workflow configuration to continue.");
            return "redirect:/";
        } else {
            model.addAttribute("WF_STEP_CONFIGS", wfStepConfigs);

            if (wfStepConfigId != null) {
                //add wf data configs for ui rendering and data capture
                List<WfStepDataConfigVw> wfStepDataConfigList = wfService.findWfStepDataConfig(wfStepConfigId);
                model.addAttribute("WF_DATA_CONFIGS", wfStepDataConfigList);

                //first determine if the step config id passed in is valid
                Map<Long, WfStepConfig> wfStepConfigMap = new HashMap<Long, WfStepConfig>(wfStepConfigs.size());
                for (WfStepConfig wfStepConfig : wfStepConfigs) {
                    wfStepConfigMap.put(wfStepConfig.getWfStepConfigId(), wfStepConfig);
                }

                WfStepConfig wfStepConfig = wfStepConfigMap.get(wfStepConfigId);
                if (wfStepConfig != null) {
                    //add current step to model along with current workflows in queue
                    model.addAttribute("WF_CONFIG", wfService.findWfConfig(wfStepConfig.getWfConfigId()));
                    model.addAttribute("WF_STEP_CONFIG", wfStepConfig);
                    model.addAttribute("WF_LIST", wfService.findAllWf(wfStepConfig, wfStepDataConfigList));
                    model.addAttribute("WF_DATA_COLLECTION", wfService.filterStepDataConfigs(wfStepDataConfigList));
                    model.addAttribute("WF_NCR_CONFIGS", wfService.getNcrConfigs(wfStepConfigId));
                    model.addAttribute("WF_NCR_REASONS", wfService.getWfNcrReasonMap(wfConfigDomain));
                    model.addAttribute("WF_REF_CONFIGS", wfService.findAllActiveWfRefConfig(wfStepConfig.getWfConfigId()));

                    //sort based on queue comparator (if defined)
                    //@todo

                    //render custom view if defined
                    if (wfStepConfig.getUiCustomView() != null) {
                        Object domainController = null;
                        Map<String, Object> controllerBeans = listableBeanFactory.getBeansWithAnnotation(Controller.class);

                        // For each service bean we assume the config domain name matches the start of the name of the service
                        // e.g., gbs config domain corresponds to a @service annotated GbsService class
                        for (Map.Entry<String, Object> beanEntry : controllerBeans.entrySet()) {
                            if (beanEntry.getKey().toLowerCase().startsWith(wfConfigDomain.toLowerCase())) {
                                domainController = beanEntry.getValue();
                                break;
                            }
                        }

                        if (domainController != null) {
                            try {
                                Method domainGetWfStepMethod = domainController.getClass().getMethod("getWfStep", Long.class, Model.class);
                                domainGetWfStepMethod.invoke(domainController, wfStepConfigId, model);
                            } catch (NoSuchMethodException e) {
                                // pass
                            } catch (InvocationTargetException e) {
                                // pass
                            } catch (IllegalAccessException e) {
                                // pass
                            }
                        }

                        return wfConfigDomain + "/" + wfStepConfig.getUiCustomView();
                    }
                } else {
                    model.addAttribute("UI_MSG", "The workflow step does not exist.");
                }
            } else {

                Map<String, Object[]> stepsCount = new LinkedHashMap<String, Object[]>();
                for (WfStepConfig wfStepConfig : wfStepConfigs) {

                    Object[] stepDetail = new Object[3];
                    if (null != wfStepConfig.getWfEntityTypeId()) {
                        stepDetail[0] = wfService.getEntityName(wfStepConfig.getWfEntityTypeId()).getWfEntityType();
                    } else {
                        stepDetail[0] = "";
                    }
                    stepDetail[1] = wfService.findAllWfWithStatus(wfStepConfig.getWfStepConfigId());
                    stepDetail[2] = wfStepConfig.getWfStepConfigId();

                    stepsCount.put(wfStepConfig.getWfStepName(), stepDetail);
                }
                //add the workflow config
                model.addAttribute("WF_CONFIG", wfService.findWfConfig(wfStepConfigs.get(0).getWfConfigId()));
                model.addAttribute("WF_STEPS_OVERVIEW", stepsCount);
            }

            return "core/wfStep";
        }
    }

    @RequestMapping(value = "/ncrInfo/", method = RequestMethod.GET)
    public
    @ResponseBody
    JsonNcrConfigInfo getNcrConfigInfo(
            @RequestParam(required = true) Long ncrConfigId,
            HttpServletResponse response) {

        //never cache security ajax calls
        response.setHeader("Pragma", "No-cache");
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", 0);

        WfNcrConfig wfNcrConfig = wfService.getNcrConfig(ncrConfigId);
        JsonNcrConfigInfo jsonNcrConfigInfo = new JsonNcrConfigInfo();
        jsonNcrConfigInfo.setNcrName(wfNcrConfig.getNcrName());
        jsonNcrConfigInfo.setNcrDescription(wfNcrConfig.getNcrDescription());
        jsonNcrConfigInfo.setAllowedUsers(wfNcrConfig.getAllowedUsers());

        return jsonNcrConfigInfo;
    }

    @RequestMapping(value = "/ncrApply/", method = RequestMethod.GET)
    public
    @ResponseBody
    JsonSecureCheckpoint ncrApply(@RequestParam(required = true) Long wfId,
                                  @RequestParam(required = true) Long wfNcrConfigId,
                                  @RequestParam(required = true) String userId,
                                  @RequestParam(required = false) String wfNcrComment,
                                  @RequestParam(required = false) String wfNcrContext) {

        JsonSecureCheckpoint jsonSecureCheckpoint = new JsonSecureCheckpoint();
        jsonSecureCheckpoint.setAllowed(wfService.applyNcr(wfNcrConfigId, wfId, wfNcrContext, wfNcrComment, userId, null));
        wfService.updateQCAction(wfId);
        return jsonSecureCheckpoint;
    }

    @RequestMapping(value = "/{wfConfigDomain}/printBarcodes/", method = RequestMethod.GET)
    public String printBarcodesGet(Model model,
                                   @PathVariable("wfConfigDomain") String wfConfigDomain) {
        model.addAttribute("activePrinters", wfService.getActivePrinters(wfConfigDomain));
        return "core/printBarcodes";
    }

    @RequestMapping(value = "/{wfConfigDomain}/printBarcodes/", method = RequestMethod.POST)
    public String printBarcodesPost(@RequestParam(required = true) Long printerId,
                                    @RequestParam(required = true) String barcodeList) {

        String barcocodeListFormatted = barcodeList.replaceAll("\r", "\n");
        barcocodeListFormatted = barcocodeListFormatted.replaceAll("\n+", "\n");
        barcocodeListFormatted = barcocodeListFormatted.replaceAll("\t", "");

        //spool to printer
        String[] barcodes = barcocodeListFormatted.split("\n");
        for (String barcode : barcodes) {
            if (barcode.trim().length() > 0) {
                wfService.printBarcode(printerId, barcode);
            }
        }

        return "redirect:/printBarcodes/";
    }

    @RequestMapping(value = "/wfgraph/", method = RequestMethod.GET)
    public String getGraphPage(Model model, String domain) {

        model.addAttribute("WF_CONFIG", wfService.findWfConfig(domain));

        return "wfgraph/" + domain + "WfGraph";
    }

    @RequestMapping(value = "/wfGraphRequest/", method = RequestMethod.POST)
    public
    @ResponseBody
    WfGraph postGraph(@RequestBody WfGraph wfGraphData, Model model) {
        //    public String postGraph(Model model) {
        // model.addAttribute(wfGraphData);
        return wfGraphData; // "wfgraph/genericGraph";
    }

    @RequestMapping(value = "/wfGraphRequest/", method = RequestMethod.GET)
    public String getGraph() {
        return "wfgraph/genericGraph";
    }

    @RequestMapping(value = "/{wfConfigDomain}/wfAgents/", method = RequestMethod.GET)
    public String getWfAgents(Model model,
                              @PathVariable("wfConfigDomain") String wfConfigDomain) {
        model.addAttribute("wfAgents", wfService.getWfAgents(wfConfigDomain));

        if (wfConfigDomain.equals("dpcrlab")) {
            return "core/wfAgents9";
        } else {
            return "core/wfAgents";
        }

    }

    @RequestMapping(value = "/{wfConfigDomain}/wfAgents/{wfAgentId}/", method = RequestMethod.GET)
    public String getWfAgents(Model model,
                              @PathVariable("wfConfigDomain") String wfConfigDomain,
                              @PathVariable("wfAgentId") Long wfAgentId) {

        wfService.reloadWfAgent(wfAgentId);

        return "redirect:/wfAgents/";
    }

    @RequestMapping(value = "/{wfConfigDomain}/wfAgents/{wfAgentId}/{flag}", method = RequestMethod.GET)
    public String getWfAgents(Model model,
                              @PathVariable("wfConfigDomain") String wfConfigDomain,
                              @PathVariable("wfAgentId") Long wfAgentId,
                              @PathVariable("flag") String flag) {

        wfService.toggleWfAgent(wfAgentId, flag);

        return "redirect:/{wfConfigDomain}/wfAgents/";
    }

/*  @RequestMapping(value = "/wfGraphJsonRequest/", method = RequestMethod.GET)
        public @ResponseBody WfGraph getTestGraphJson () throws Exception {
          //return  getJsonGraphStructureForTesting();
          return getJsonGraphStructureForTesting();
        }*/

    // temp method to illustrate building a simple 3 node relationship (1 is related to 2, 2 is related to 3)
    // node 1 has tooltips, others do not
    // this object structure is required by JIT, specifically the POST to /wfGraphRequest/, above
    /*

     */
    @RequestMapping(value = "/wfgridview/", method = RequestMethod.GET)
    public String getGridView(Model model) {
        return "core/wfGridView";
    }

    @RequestMapping(value = "/wfgridview/grid", method = RequestMethod.GET, produces = {"application/json"})
    public
    @ResponseBody
    WfContainer getGridViewData(HttpServletRequest request, @RequestParam Long wfId, HttpServletResponse response) throws Exception {
        try {
            return wfService.findContainerData(wfId);
        } catch (Exception ex) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Data not found");
            return null;
        }
    }

    @RequestMapping(value = "/wfgridview/grid/", method = RequestMethod.POST)
    public
    @ResponseBody
    JsonResponse saveGridAssocData(@RequestBody JsonGridAssocData jsonGridAssocData) {
        JsonResponse jsonResponse = new JsonResponse();

        try {
            wfService.saveGridAssoc(jsonGridAssocData);
            jsonResponse.addMessage("Yeehaw!");
        } catch (Exception ex) {
            jsonResponse.addError("Error setting grid associations: " + ex.getMessage());
        }

        return jsonResponse;
    }

    @RequestMapping(value = "/exportStepFilteredPlateIds/", method = RequestMethod.GET)
    public void exportStepFilteredPlateIds(
            @RequestParam Long wfStepConfigId,
            @RequestParam String scannedPlateIds,
            HttpServletResponse response) throws IOException {

        Connection gbsConnection = null;
        PreparedStatement pstmtFindLimsId = null;
        ResultSet rsTemp = null;
        try {
            WfStepConfig wfStepConfig = wfService.findWfStepConfig(wfStepConfigId);
            String sqlSelect = "select wf_id from atlas.wf where wf_step_config_id = ? and wf_status='I' ";
            if (scannedPlateIds == null || scannedPlateIds.equals("")) {
                try {
                    gbsConnection = AtlasAgent.getGBSConnection();
                    pstmtFindLimsId = gbsConnection.prepareStatement(sqlSelect);
                    pstmtFindLimsId.setLong(1, wfStepConfigId);
                    rsTemp = pstmtFindLimsId.executeQuery();
                    while (rsTemp.next()) {
                        scannedPlateIds = scannedPlateIds + String.valueOf(rsTemp.getLong(1)) + ',';
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Expires:", "0"); // eliminates browser caching
            response.setHeader("Content-Disposition", "attachment; filename=" + wfStepConfig.getWfStepName() + "_" + new Date().getTime() + ".xlsx");
            OutputStream out = response.getOutputStream();
            wfService.exportStepFilteredPlateIds(wfStepConfigId, scannedPlateIds, out);
            out.flush();
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        } finally {
            UtilCommon.freeResource(gbsConnection);
            UtilCommon.freeResource(pstmtFindLimsId);
            UtilCommon.freeResource(rsTemp);
        }
    }

    @RequestMapping(value = "/exportTossedPlateIds/", method = RequestMethod.GET)
    public void exportTossedPlateIds(
            @RequestParam Long wfStepConfigId,
            @RequestParam String plateType,
            HttpServletResponse response) throws IOException {
        try {
            String scannedPlateIds="";
            List<ContainerLocation> containerLocsList = new ArrayList<ContainerLocation>();
            if(WfStepDataConfigConstants.F_PLATE.equalsIgnoreCase(plateType)) {
                containerLocsList=tossQueueService.getFPlateStorageLocationsToToss();
            } else if (WfStepDataConfigConstants.GL_PLATE.equalsIgnoreCase(plateType)) {
                containerLocsList = tossQueueService.getGLPlateStorageLocationsToToss();
            } else if (WfStepDataConfigConstants.CLEAN_TUBE.equalsIgnoreCase(plateType)) {
                containerLocsList = tossQueueService.getCTPlateStorageLocationsToToss();
            }
            for (ContainerLocation containerLocation:containerLocsList) {
                scannedPlateIds=scannedPlateIds+ containerLocation.getWfId() + ',';
            }

            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Expires:", "0"); // eliminates browser caching
            response.setHeader("Content-Disposition", "attachment; filename=Block Toss_"+plateType+"_" + new Date().getTime() + ".xlsx");
            OutputStream out = response.getOutputStream();
            wfService.exportStepFilteredPlateIds(wfStepConfigId, scannedPlateIds, out);
            out.flush();
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @RequestMapping(value = "/{wfConfigDomain}/holdWf/", method = RequestMethod.POST)
    public
    @ResponseBody
    JsonResponse postHoldWf(
            @PathVariable("wfConfigDomain") String wfConfigDomain,
            @RequestParam Long wfStepConfigId,
            @RequestBody JsonPost jsonPost,
            HttpSession session,
            HttpServletRequest request,
            HttpServletResponse response) {

        //check to make sure user is allowed to post to this step
        JsonResponse jsonResponse = null;
        if (wfService.isUserAllowed(jsonPost.getUserId(), wfStepConfigId, wfConfigDomain)) {
            jsonResponse = wfValidator.validate(wfConfigDomain, wfStepConfigId, jsonPost);

            //check for Hold NCR value entered -- mandatory.
            for (Map<String, String> postData : jsonPost.getRows()) {
                if (null != postData.get("wfdc543") && !"".equals(postData.get("wfdc543"))) {
                    //only then proceed, else throw error
                    wfService.savePostData(jsonPost);
                } else {
                    jsonResponse = new JsonResponse();
                    jsonResponse.addError("Please enter the Hold NCR number to put the plate on Hold.");
                    return jsonResponse;
                }
            }

            if (jsonResponse.isValid()) {
                //just update the workflow status to "H".
                jsonResponse = wfService.holdAllWf(jsonPost, wfStepConfigId);
            }
        } else {
            jsonResponse = new JsonResponse();
            jsonResponse.setAccessDenied();
        }

        return jsonResponse;
    }

    @RequestMapping(value = "/wfAgent/queue/", method = RequestMethod.POST)
    public @ResponseBody
    ResponseEntity queueReport(@RequestBody String jsonRequest) {

        ResponseEntity responseEntity = null;
        JsonQueueReport jsonQueueReport = new JsonQueueReport();
        try {
            wfService.queueAgent(jsonRequest);
            jsonQueueReport.setStatus("Success");


        } catch (Exception e) {
            jsonQueueReport.setStatus("Errored");
        }

        String json = new Gson().toJson(jsonQueueReport);
        responseEntity = new ResponseEntity(json, HttpStatus.OK);

        return responseEntity;
    }

    @RequestMapping(value = "/wf/getNotes/", method = RequestMethod.GET, produces = {"application/json"})
    public @ResponseBody
    JsonResponse getNotes (@RequestParam(required=true) Long wfId, HttpServletRequest request){
        JsonResponse jsonResponse = new JsonResponse();

        jsonResponse.addData(wfService.getNotes(wfId));

        return jsonResponse;
    }

    @RequestMapping(value = "/wf/savePlateNote/", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse saveProjectSummaryNote (
            @RequestBody JsonProjectUpdateEplate jsonProjectUpdateEplate) throws Exception {

        JsonResponse jsonResponse = new JsonResponse();

        wfService.savePlateNote(jsonProjectUpdateEplate.getWorkflowId(), jsonProjectUpdateEplate.getNoteOption(),
                jsonProjectUpdateEplate.getUserId(), jsonProjectUpdateEplate.getNoteComment(),jsonProjectUpdateEplate.getWfConfigId());
        jsonResponse.addMessage("Note Added Successfully");
        jsonResponse.addData(wfService.getNotes(jsonProjectUpdateEplate.getWorkflowId()));
        return jsonResponse;
    }
}
