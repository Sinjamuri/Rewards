package com.monsanto.gwg.atlas.model.core;

public class WfDataCondensed{

  private String wfDataConfigLabel;
  private String value;

  public String getWfDataConfigLabel() {
    return wfDataConfigLabel;
  }

  public void setWfDataConfigLabel(String wfDataConfigLabel) {
    this.wfDataConfigLabel = wfDataConfigLabel;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }
}
