package com.monsanto.gwg.atlas.model.core;

import java.sql.Timestamp;

public class WfStep {
  private Long wfStepId;
  private Long wfStepConfigId;
  private Long wfId;
  private String actionFlg;
  private String createUser;
  private Timestamp createTs;

  public Long getWfStepId() {
    return wfStepId;
  }

  public void setWfStepId(Long wfStepId) {
    this.wfStepId = wfStepId;
  }

  public Long getWfStepConfigId() {
    return wfStepConfigId;
  }

  public void setWfStepConfigId(Long wfStepConfigId) {
    this.wfStepConfigId = wfStepConfigId;
  }

  public Long getWfId() {
    return wfId;
  }

  public void setWfId(Long wfId) {
    this.wfId = wfId;
  }

  public String getActionFlg() {
    return actionFlg;
  }

  public void setActionFlg(String actionFlg) {
    this.actionFlg = actionFlg;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }
}
