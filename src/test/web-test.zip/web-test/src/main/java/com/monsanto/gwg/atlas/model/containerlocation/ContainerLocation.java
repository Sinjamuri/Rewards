package com.monsanto.gwg.atlas.model.containerlocation;

import java.util.LinkedHashMap;
import java.util.Map;

public class ContainerLocation {

    private Long wfId;
    private long wfStepConfigId;
    private String wfEntityLabel;
    private String plateType;
    private String location1;
    private String location2;
    private String location3;
    private String location4;

    public Long getWfId() {
        return wfId;
    }

    public void setWfId(Long wfId) {
        this.wfId = wfId;
    }

    public long getWfStepConfigId() {return wfStepConfigId;}

    public void setWfStepConfigId(long wfStepConfigId) {this.wfStepConfigId = wfStepConfigId;}

    public String getWfEntityLabel() {
        return wfEntityLabel;
    }

    public void setWfEntityLabel(String wfEntityLabel) {
        this.wfEntityLabel = wfEntityLabel;
    }

    public String getPlateType() {return plateType; }

    public void setPlateType(String plateType) {this.plateType = plateType;}

    public String getLocation1() {
        return location1;
    }

    public void setLocation1(String location1) {
        this.location1 = location1;
    }

    public String getLocation2() {
        return location2;
    }

    public void setLocation2(String location2) {
        this.location2 = location2;
    }

    public String getLocation3() {
        return location3;
    }

    public void setLocation3(String location3) {
        this.location3 = location3;
    }

    public String getLocation4() {
        return location4;
    }

    public void setLocation4(String location4) {
        this.location4 = location4;
    }
}
