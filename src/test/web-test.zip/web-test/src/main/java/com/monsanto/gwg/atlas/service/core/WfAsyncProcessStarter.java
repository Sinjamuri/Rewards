package com.monsanto.gwg.atlas.service.core;

import com.monsanto.gwg.atlas.model.core.AbstractWfAsyncProcess;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

/**
 * Created by PGROS1 on 6/24/14.
 */

@Component
@EnableAsync
public class WfAsyncProcessStarter {
    @Async
    public void start( AbstractWfAsyncProcess wfAsyncProcess ) {
        try {
            wfAsyncProcess.startProcess();
        } catch( WfAsyncProcessCancelledException pce ) {
            wfAsyncProcess.getWfAsyncStatus().setIsCancelled(true);
            wfAsyncProcess.handleCancelProcess();
        }
    }
}