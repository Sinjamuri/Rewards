package com.monsanto.gwg.atlas.json.dpcr;

import com.monsanto.gwg.atlas.model.core.Wf;
import com.monsanto.gwg.atlas.model.dpcr.RatioMultiplier;
import com.monsanto.gwg.atlas.model.dpcr.RatioThreshold;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by pgros1 on 1/15/2015.
 *
 * Why isn't this a model class? Because for some reason I couldn't get jackson to model map
 * this class when it was in the model package. Maybe it's a config option, but moving into
 * the json package made it work.
 */
public class AnalysisRun extends Wf {

    /* The following are fields filled by posting to the analysis-run url */
    private Long plateWfId;

    private String copyEstimateAlgorithm;
    private String positiveCountThresholdAlgorithm;
    private String ratioThresholdAlgorithm;

    private List<Object> positiveCountThresholdAlgorithmParameters;
    private List<Object> ratioMultipliers;
    private List<Object> fixedRatioThresholds;

    public String getAnalysisRunLabel() {
        return getWfEntityLabel();
    }

    public void setAnalysisRunLabel(String analysisRunLabel) {
        setWfEntityLabel( analysisRunLabel );
    }

    public String getCopyEstimateAlgorithm() {
        return copyEstimateAlgorithm;
    }

    public void setCopyEstimateAlgorithm(String copyEstimateAlgorithm) {
        this.copyEstimateAlgorithm = copyEstimateAlgorithm;
    }

    public String getPositiveCountThresholdAlgorithm() {
        return positiveCountThresholdAlgorithm;
    }

    public void setPositiveCountThresholdAlgorithm(String positiveCountThresholdAlgorithm) {
        this.positiveCountThresholdAlgorithm = positiveCountThresholdAlgorithm;
    }

    public String getRatioThresholdAlgorithm() {
        return ratioThresholdAlgorithm;
    }

    public void setRatioThresholdAlgorithm(String ratioThresholdAlgorithm) {
        this.ratioThresholdAlgorithm = ratioThresholdAlgorithm;
    }

    public Long getPlateWfId() {
        return plateWfId;
    }

    public void setPlateWfId(Long plateWfId) {
        this.plateWfId = plateWfId;
    }

    public List<Object> getPositiveCountThresholdAlgorithmParameters() {
        return positiveCountThresholdAlgorithmParameters;
    }

    public Map<String, String> getPositiveCountThresholdAlgorithmParametersMap( ) {
        Map<String, String> paramsMap = new HashMap<String, String>();
        for( Object param : positiveCountThresholdAlgorithmParameters ) {
            Map<String, String> paramValuesMap = (Map<String, String>)param;
            paramsMap.put( paramValuesMap.get("filter"), paramValuesMap.get("value") );
        }
        return paramsMap;
    }

    public void setPositiveCountThresholdAlgorithmParameters(List<Object> positiveCountThresholdAlgorithmParameters) {
        this.positiveCountThresholdAlgorithmParameters = positiveCountThresholdAlgorithmParameters;
    }

    public List<Object> getRatioMultipliers() {
        return ratioMultipliers;
    }

    public List<RatioMultiplier> getTypedRatioMultipliers() {
        List<RatioMultiplier> typedRatioMultiplierList = new ArrayList<RatioMultiplier>();
        for( Object ratioMultiplierMapObject : getRatioMultipliers() ) {
            Map ratioMultiplierMap = (Map)ratioMultiplierMapObject;
            typedRatioMultiplierList.add(new RatioMultiplier(ratioMultiplierMap));
        }

        return typedRatioMultiplierList;
    }

    public void setRatioMultipliers(List<Object> ratioMultipliers) {
        this.ratioMultipliers = ratioMultipliers;
    }

    public List<Object> getFixedRatioThresholds() {
        return fixedRatioThresholds;
    }

    public List<RatioThreshold> getTypedFixedRatioThresholds() {
        List<RatioThreshold> typedRatioThresholdsList = new ArrayList<RatioThreshold>();
        for( Object fixedRatioMapObject : getFixedRatioThresholds() ) {
            Map fixedRatioThresholdMap = (Map)fixedRatioMapObject;
            typedRatioThresholdsList.add( new RatioThreshold( fixedRatioThresholdMap ) );
        }

        return typedRatioThresholdsList;
    }

    public void setFixedRatioThresholds(List<Object> fixedRatioThresholds) {
        this.fixedRatioThresholds = fixedRatioThresholds;
    }


    /* The following are fields computed during the analysis run process */

    private Map<String, int[]> histograms;
    private List<String[]> scatterPlot;
    private Map<String, Float> positiveCountThresholds;
    private Map<String, Integer[][]> positiveCounts;
    private Map<String, Integer[][]> copyEstimates;

    private Float[][] copyRatios;
    private Map<String, Map<String, RatioThreshold>> ratioThresholds;
    private String[][] zygosityCalls;

    private byte[] exportResultsFile;

    public Map<String, int[]> getHistograms() {
        return histograms;
    }

    public void setHistograms(Map<String, int[]> histograms) {
        this.histograms = histograms;
    }

    public List<String[]> getScatterPlot() {
        return scatterPlot;
    }

    public void setScatterPlot(List<String[]> scatterPlot) {
        this.scatterPlot = scatterPlot;
    }

    public Map<String, Float> getPositiveCountThresholds() {
        return positiveCountThresholds;
    }

    public void setPositiveCountThresholds(Map<String, Float> positiveCountThresholds) {
        this.positiveCountThresholds = positiveCountThresholds;
    }

    public Map<String, Integer[][]> getPositiveCounts() {
        return positiveCounts;
    }

    public void setPositiveCounts(Map<String, Integer[][]> positiveCounts) {
        this.positiveCounts = positiveCounts;
    }

    public Map<String, Integer[][]> getCopyEstimates() {
        return copyEstimates;
    }

    public void setCopyEstimates(Map<String, Integer[][]> copyEstimates) {
        this.copyEstimates = copyEstimates;
    }

    public Float[][] getCopyRatios() {
        return copyRatios;
    }

    public void setCopyRatios(Float[][] copyRatios) {
        this.copyRatios = copyRatios;
    }

    public String[][] getZygosityCalls() {
        return zygosityCalls;
    }

    public void setZygosityCalls(String[][] zygosityCalls) {
        this.zygosityCalls = zygosityCalls;
    }

    public byte[] getExportResultsFile() {
        return exportResultsFile;
    }

    public void setExportResultsFile(byte[] exportResultsFile) {
        this.exportResultsFile = exportResultsFile;
    }

    public Map<String, Map<String, RatioThreshold>> getRatioThresholds() {
        return ratioThresholds;
    }

    public void setRatioThresholds(Map<String, Map<String, RatioThreshold>> ratioThresholds) {
        this.ratioThresholds = ratioThresholds;
    }
}
