package com.monsanto.gwg.atlas.service.containerlocation;

import com.monsanto.gwg.atlas.constants.WfStepConfigConstants;
import com.monsanto.gwg.atlas.constants.WfStepDataConfigConstants;
import com.monsanto.gwg.atlas.dao.containerlocation.ContainerLocationDao;
import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.model.containerlocation.ContainerLocation;
import com.monsanto.gwg.atlas.model.core.Wf;
import com.monsanto.gwg.atlas.model.core.WfAssoc;
import com.monsanto.gwg.atlas.model.core.WfDataConfig;
import com.monsanto.gwg.atlas.model.core.WfStepDataConfigVw;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Service
public class ContainerLocationService {

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfStepDataConfigVwDao wfStepDataConfigVwDao;

    @Autowired
    private WfStepConfigDao wfStepConfigDao;

    @Autowired
    private ContainerLocationDao containerLocDao;


    @Autowired
    private WfDataConfigDao wfDataConfigDao;

    @Autowired
    private WfAssocDao wfAssocDao;

    @Autowired
    private WfDao wfDao;

    /**
     *
     * @return
     */
    public List<ContainerLocation> getFPlateStorageLocations() {
        List<ContainerLocation> containerLocsList = new ArrayList<ContainerLocation>();

        // Fetch "READY_FOR_CLEAN_UP" WF_STEP_CONFIG_ID
        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.READY_FOR_CLEAN_UP);

        // Fetch F Plate Storage locations stored at "READY FOR CLEAN UP" QUEUE
        containerLocsList = containerLocDao.getPlateStorageLocations(WfStepDataConfigConstants.F_PLATE,
                wfStepConfigId,
                WfStepDataConfigConstants.F_LOCATION_1_DISPLAY);

        return containerLocsList;
    }

    /**
     *
     * @return
     */
    public List<WfStepDataConfigVw> getFPlateStorageDataConfigs() {
        List<WfStepDataConfigVw> wfStepDataConfigList = new ArrayList<WfStepDataConfigVw>();

        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.READY_FOR_CLEAN_UP);

        wfStepDataConfigList.addAll(wfStepDataConfigVwDao.findWfStepDataConfig(wfStepConfigId,
                WfStepDataConfigConstants.F_LOCATION_1_DISPLAY,
                WfStepDataConfigConstants.F_LOCATION_2_DISPLAY));

        return wfStepDataConfigList;
    }

    /**
     *
     * @return
     */
    public List<ContainerLocation> getEPlateStorageLocations(){
        List<ContainerLocation> containerLocsList = new ArrayList<ContainerLocation>();

        // Fetch "Gencell LC - Plate Creation" WF_STEP_CONFIG_ID
        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.GENCELL_LC_PLATE_CREATION);

        // Fetch E Plate Storage Locations from  "Gencell LC - Plate Creation" QUEUE. After this E Plate Storage locations will be trashed.
        containerLocsList = containerLocDao.getPlateStorageLocations(WfStepDataConfigConstants.E_PLATE,
                wfStepConfigId,
                WfStepDataConfigConstants.E_LOCATION_1_DISPLAY,
                WfStepDataConfigConstants.E_LOCATION_2_DISPLAY);

        return containerLocsList;
    }

    /**
     *
     * @return
     */
    public List<WfStepDataConfigVw> getEPlateStorageDataConfigs() {
        List<WfStepDataConfigVw> wfStepDataConfigList = new ArrayList<WfStepDataConfigVw>();

        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.EXTRACTION_COMPLETE);

        wfStepDataConfigList.addAll(wfStepDataConfigVwDao.findWfStepDataConfig(wfStepConfigId,
                WfStepDataConfigConstants.E_PLATE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.E_PLATE_LOCATION_2_LABEL));

        return wfStepDataConfigList;
    }

    /**
     *
     * @return
     */
    public List<ContainerLocation> getGLPlateStorageLocations(){
        List<ContainerLocation> containerLocsList = new ArrayList<ContainerLocation>();

        // Fetch "Gencell LC - Plate CrTEP_CONFIG_ID
      //  Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.GENCELL_LC_PLATE_CREATION);

        // GL Plate Storage Locations are stored at "Gencell LC - Plate Creation" queue.
        containerLocsList = containerLocDao.getGLPlateStorageLocations(WfStepDataConfigConstants.GL_PLATE,
                WfStepDataConfigConstants.GL_LOCATION_1_DISPLAY,
                WfStepDataConfigConstants.GL_LOCATION_2_DISPLAY);
        return containerLocsList;
    }

    /**
     *
     * @return
     */
    public List<WfStepDataConfigVw> getGLPlateStorageDataConfigs() {
        List<WfStepDataConfigVw> wfStepDataConfigList = new ArrayList<WfStepDataConfigVw>();

        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.GENCELL_LC_RECEIVED);

        wfStepDataConfigList.addAll(wfStepDataConfigVwDao.findWfStepDataConfig(wfStepConfigId,
                WfStepDataConfigConstants.GL_PLATE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.GL_PLATE_LOCATION_2_LABEL));

        return wfStepDataConfigList;
    }

    /**
     *
     * @return
     */
    public List<ContainerLocation> getCTPlateStorageLocations(){
        List<ContainerLocation> containerLocsList = new ArrayList<ContainerLocation>();

        // Fetch "Sequencing Group Pooling" WF_STEP_CONFIG_ID
        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.SEQUENCING_GRP_POOLING);

        // Fetch CLEAN TUBE storage locations from "Sequencing Grp Pooling" QUEUE.
        containerLocsList.addAll(containerLocDao.getPlateStorageLocations(WfStepDataConfigConstants.CLEAN_TUBE,
                wfStepConfigId,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_2_LABEL));

        // Fetch "Ion Chef - Run Ready" WF_STEP_CONFIG_ID
       /* wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.ION_CHEF_RUN_READY);

        // Fetch CLEAN TUBE storage locations from "ION CHEF - RUN READY" QUEUE.
        containerLocsList.addAll(containerLocDao.getPlateStorageLocations(WfStepDataConfigConstants.CLEAN_TUBE,
                wfStepConfigId,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_2_LABEL,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_3_LABEL));*/

        return containerLocsList;
    }

    /**
     *
     * @return
     */
    public List<WfStepDataConfigVw> getCTStorageDataConfigs() {
        List<WfStepDataConfigVw> wfStepDataConfigList = new ArrayList<WfStepDataConfigVw>();

        // Fetch "Sequencing Group Pooling" WF_STEP_CONFIG_ID
        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.SEQUENCING_GRP_POOLING);

        wfStepDataConfigList.addAll(wfStepDataConfigVwDao.findWfStepDataConfig(wfStepConfigId,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_2_LABEL));

        return wfStepDataConfigList;
    }

    public void saveContainerLocations(JsonPost jsonPost) {

        //extract and map all data types for efficiency
        Set<Long> wfdcIdSet = new HashSet<Long>();
        for (Map<String, String> postData : jsonPost.getRows()) {
            for (String key : postData.keySet()) {
                if (key.startsWith("wfdc")) {
                    wfdcIdSet.add(Long.parseLong(key.substring(4)));
                }
            }
        }

        List<WfDataConfig> wfDataConfigs = wfDataConfigDao.get(wfdcIdSet);
        Map<Long, WfDataConfig> wfDataConfigMap = new HashMap<Long, WfDataConfig>();
        for (WfDataConfig wfDataConfig : wfDataConfigs) {
            wfDataConfigMap.put(wfDataConfig.getWfDataConfigId(), wfDataConfig);
        }

        for (Map<String, String> postData : jsonPost.getRows()) {
            //extract wfId to associate data
            Long wfId = Long.parseLong(postData.get("wfId"));

            //loop through entries for wfdcId fields
            for (String key : postData.keySet()) {
                if (key.startsWith("wfdc")) {
                    Long wfDataConfigId = Long.parseLong(key.substring(4));

                    //get active left associations to be updated, if the plateType is a GL
                    Wf wf = wfDao.find(wfId);
                    if (wf.getWfEntityTypeId() == 3 || wf.getWfEntityTypeId() == 5 ) {
                        List<WfAssoc> wfAssocList = wfAssocDao.getActiveLeft(wfId);
                        for(WfAssoc leftWf: wfAssocList) {
                            long fromWfId = leftWf.getFromWfId();
                            WfDataConfig wfDataConfig = wfDataConfigMap.get(wfDataConfigId);
                            if ("NUMBER".equals(wfDataConfig.getWfDataConfigType())) {
                                wfDataDao.save(fromWfId, wfDataConfigId, new BigDecimal(postData.get(key)));
                            } else if ("VARCHAR2".equals(wfDataConfig.getWfDataConfigType())) {
                                wfDataDao.save(fromWfId, wfDataConfigId, postData.get(key));
                            } else if ("TIMESTAMP".equals(wfDataConfig.getWfDataConfigType())) {
                                //@todo
                            }
                        }
                    }

                    WfDataConfig wfDataConfig = wfDataConfigMap.get(wfDataConfigId);
                    if ("NUMBER".equals(wfDataConfig.getWfDataConfigType())) {
                        wfDataDao.save(wfId, wfDataConfigId, new BigDecimal(postData.get(key)));
                    } else if ("VARCHAR2".equals(wfDataConfig.getWfDataConfigType())) {
                        wfDataDao.save(wfId, wfDataConfigId, postData.get(key));
                    } else if ("TIMESTAMP".equals(wfDataConfig.getWfDataConfigType())) {
                        //@todo
                    }
                }
            }
        }

    }

}
