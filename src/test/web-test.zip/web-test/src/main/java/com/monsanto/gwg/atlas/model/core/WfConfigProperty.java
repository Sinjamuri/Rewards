package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

public class WfConfigProperty {
        @DbColumn(field="property_id")
    private Long propertyId;
        @DbColumn(field="ref_key")
    private Long refKey;
        @DbColumn(field="wf_config_id")
    private Long wfConfigId;
        @DbColumn(field="key")
    private String key;
        @DbColumn(field="value_varchar2")
    private String valueVarchar2;
        @DbColumn(field="value_timestamp")
    private Timestamp valueTimestamp;
        @DbColumn(field="value_blob")
    private byte[] valueBlob;
        @DbColumn(field="value_number")
    private BigDecimal valueNumber;
        @DbColumn(field="create_ts")
    private Timestamp createTs;
        @DbColumn(field="update_ts")
    private Timestamp updateTs;

    private String propertyType;
    private String propertyValue;
    private List<WfConfigProperty> wfConfigPropertyList;

    public Long getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(Long propertyId) {
        this.propertyId = propertyId;
    }

    public Long getRefKey() {
        return refKey;
    }

    public void setRefKey(Long refKey) {
        this.refKey = refKey;
    }

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValueVarchar2() {
        return valueVarchar2;
    }

    public void setValueVarchar2(String valueVarchar2) {
        this.valueVarchar2 = valueVarchar2;
    }

    public Timestamp getValueTimestamp() {
        return valueTimestamp;
    }

    public void setValueTimestamp(Timestamp valueTimestamp) {
        this.valueTimestamp = valueTimestamp;
    }

    public byte[] getValueBlob() {
        return valueBlob;
    }

    public void setValueBlob(byte[] valueBlob) {
        this.valueBlob = valueBlob;
    }

    public BigDecimal getValueNumber() {
        return valueNumber;
    }

    public void setValueNumber(BigDecimal valueNumber) {
        this.valueNumber = valueNumber;
    }

    public Timestamp getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Timestamp createTs) {
        this.createTs = createTs;
    }

    public Timestamp getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(Timestamp updateTs) {
        this.updateTs = updateTs;
    }

    public String getPropertyType() {

        String type = "";

        if(null != valueVarchar2 && !valueVarchar2.isEmpty()) {
            type = "VARCHAR2";
        }else if(null != valueTimestamp) {
            type = "TIMESTAMP";
        }else if(null != valueBlob && valueBlob.length > 0 ) {
            type = "BLOB";
        }else if(null != valueNumber) {
            type = "NUMBER";
        }else {
            type = "REF_ID";
        }
        return type;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public String getPropertyValue(){

        String value = "";

            try {
                if (null != valueVarchar2 && !valueVarchar2.isEmpty()) {
                    value = valueVarchar2;
                } else if (null != valueTimestamp) {
                    value = valueTimestamp.toString();
                } else if (null != valueBlob && valueBlob.length > 0) {
                    value = new String(valueBlob, "UTF-8");
                } else if (null != valueNumber) {
                    value = valueNumber.toPlainString();
                }
            }catch(UnsupportedEncodingException e){
                e.printStackTrace();
            }catch(Exception e){
                e.printStackTrace();
            }

        return value;
    }

    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }

    public List<WfConfigProperty> getWfConfigPropertyList() {
        return wfConfigPropertyList;
    }

    public void setWfConfigPropertyList(List<WfConfigProperty> wfConfigPropertyList) {
        this.wfConfigPropertyList = wfConfigPropertyList;
    }
}
