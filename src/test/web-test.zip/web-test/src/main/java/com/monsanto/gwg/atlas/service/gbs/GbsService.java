package com.monsanto.gwg.atlas.service.gbs;

import com.google.gson.Gson;
import com.monsanto.gwg.atlas.agent.common.AtlasAgent;
import com.monsanto.gwg.atlas.agent.common.model.*;
import com.monsanto.gwg.atlas.agent.common.utils.WfGridUtils;
import com.monsanto.gwg.atlas.agent.common.utils.WfUtilCommon;
import com.monsanto.gwg.atlas.bean.ResummarizationQueueRow;
import com.monsanto.gwg.atlas.constants.WfStepConfigConstants;
import com.monsanto.gwg.atlas.constants.WfStepDataConfigConstants;
import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.dao.gbs.*;
import com.monsanto.gwg.atlas.dao.torrent.TorrentAnalysisDao;
import com.monsanto.gwg.atlas.dao.torrent.TorrentRunDao;
import com.monsanto.gwg.atlas.json.autotool.XRobotTransferTskWrapper;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonProjectUpdate;
import com.monsanto.gwg.atlas.json.core.JsonProjectUpdateEplate;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.model.core.*;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.model.core.WfGridAssoc;
import com.monsanto.gwg.atlas.model.core.WfGridData;
import com.monsanto.gwg.atlas.model.core.XRobotTransferTsk;
import com.monsanto.gwg.atlas.model.gbs.*;
import com.monsanto.gwg.atlas.model.torrent.TorrentAnalysis;
import com.monsanto.gwg.atlas.model.torrent.TorrentRun;
import com.monsanto.gwg.atlas.service.DetailServiceResponse;
import com.monsanto.gwg.atlas.service.UtilService;
import com.monsanto.gwg.atlas.service.WellSample;
import com.monsanto.gwg.atlas.service.annotations.WfDelegateMethod;
import com.monsanto.gwg.atlas.service.annotations.WfParam;
import com.monsanto.gwg.atlas.service.annotations.WfParamValue;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.util.*;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class GbsService {

  public static final long WF_CONFIG_ID = 1L;
  private static final Logger LOG = LoggerFactory.getLogger(GbsService.class);

  @Autowired
  WfService wfService;

  @Autowired
  private WfDao wfDao;

  @Autowired
  private WfDataDao wfDataDao;

  @Autowired
  private WfEntityTypeDao wfEntityTypeDao;

  @Autowired
  private WfAssocDao wfAssocDao;

  @Autowired
  private WfStepConfigDao wfStepConfigDao;

  @Autowired
  private ProjectResultDao projectResultDao;

  @Autowired
  private MarkerAnalysisDao markerAnalysisDao;

  @Autowired
  private MergedSampleDao mergedSampleDao;

  @Autowired
  private JdbcTemplate jdbcTemplate;

  @Autowired
  private UtilService utilService;

  @Autowired
  private WfGridAssocDao wfGridAssocDao;

  @Autowired
  private WfGridDataDao wfGridDataDao;

  @Autowired
  private WfGridDao wfGridDao;

  @Autowired
  private CherryPickDao cherryPickDao;

  @Autowired
  private WfDataConfigDao wfDataConfigDao;

  @Autowired
  private WfStepDao wfStepDao;

  @Autowired
  private WfConfigPropertyDao wfConfigPropertyDao;

  @Autowired
  private BlockTrackingDao blockTrackingDao;

  @Autowired
  private XRobotJobDao xRobotJobDao;

  @Autowired
  private XRobotTransferTskDao xRobotTransferTskDao;

  @Autowired
  private WfPlateMapDao wfPlateMapDao;

  @Autowired
  private TorrentRunDao torrentRunDao;

  @Autowired
  private TorrentAnalysisDao torrentAnalysisDao;


  public enum Well { A1, B1, C1, D1, E1, F1, G1, H1, A2, B2 };


  @WfDelegateMethod(wfStepConfigId = 4)
  public JsonResponse post4(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost
  ) {

    Map<String, Set<Long>> lPlateWfIdMap = new HashMap<String, Set<Long>>();
    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

      //loop through entries for wfdcId fields
      for (String key : postData.keySet()) {
        if (key.equals("wfdc6")) {
          String lPlateId = postData.get(key);
          Set<Long> wfToIdSet = lPlateWfIdMap.get(lPlateId);
          if (wfToIdSet == null) {
            wfToIdSet = new LinkedHashSet<Long>();
          }
          wfToIdSet.add(wfId);

          lPlateWfIdMap.put(lPlateId, wfToIdSet);

          break;
        }
      }
    }

    //now that we have the map of eblocks to map to lplates
    //converge them into new workflows
    for (String lPlateId : lPlateWfIdMap.keySet()) {
      long combinedWfId = wfDao.combineTo(WF_CONFIG_ID, lPlateId, lPlateWfIdMap.get(lPlateId), 5L, userId, 2L);

      wfDataDao.save(combinedWfId, 6L, lPlateId);
      //wfDataDao.save(combinedWfId, 7L, "Maize");
    }

    return new JsonResponse();
  }

  @WfDelegateMethod(wfStepConfigId = 12)
  public JsonResponse post12(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    // Save the data submitted from the form.
    wfService.savePostData(jsonPost);

    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));
      String wfEntityLabel = postData.get("wfEntityLabel");

      Map<Long, String> detailMap = new LinkedHashMap<Long, String>();
      detailMap.put(1L, postData.get("wfdc261"));
      detailMap.put(2L, postData.get("wfdc262"));
      detailMap.put(3L, postData.get("wfdc263"));
      detailMap.put(4L, postData.get("wfdc264"));


      List<WfAssoc> activeLeftWithDataNumber = wfAssocDao.getActiveLeftWithDataNumber(wfId, 47L, 10199l);

      for(WfAssoc wfAssoc : activeLeftWithDataNumber){

        Long barcodeIndex = wfAssoc.getWfDataNumber();
        Long barcodeIndexNumber =null;

        try {
          String cleanTube = null;
          if(wfEntityLabel.endsWith("-02")) {
            cleanTube = detailMap.get(barcodeIndex - 4);
            barcodeIndexNumber = Long.valueOf(detailMap.get(barcodeIndex-4).substring(0,2));
            wfDataDao.save(wfAssoc.getFromWfId(), 23L, BigDecimal.valueOf(barcodeIndexNumber));
            wfDataDao.save(wfAssoc.getFromWfId(), 26L, cleanTube);
            wfDataDao.save(wfId, (260L + barcodeIndex - 4), detailMap.get(barcodeIndex - 4));
          } else {
            cleanTube = detailMap.get(barcodeIndex);
            barcodeIndexNumber = Long.valueOf(detailMap.get(barcodeIndex).substring(0,2));
            wfDataDao.save(wfAssoc.getFromWfId(), 23L, BigDecimal.valueOf(barcodeIndexNumber));
            wfDataDao.save(wfAssoc.getFromWfId(), 26L, cleanTube);
            wfDataDao.save(wfId, (260L + barcodeIndex), detailMap.get(barcodeIndex));
          }
          //wfAssocDao.updateWfAssocStatusAndMatchKey(wfAssoc.getFromWfId(), wfId, wfAssoc.getFromWfLabel(), "Y");
          //All samples on the dilution block have to be associated with their clean tubes.

          //SVANT: The clean tube should be stored on each sample its associated to...
          List<WfGridAssoc> gridAssocList = wfGridAssocDao.findAll(wfAssoc.getFromWfId());//WfGridUtils.fetchWfGridAssocByWfId(con,wfId);
          List<WfGridData> gridDataList = new ArrayList<>();
          for (WfGridAssoc gridAssoc : gridAssocList) {
            WfGridData gridData = new WfGridData();
            gridData.setWfGridId(gridAssoc.getWfGridId());
            gridData.setValueVarchar2(cleanTube);
            gridData.setWfGridDataConfigId(10133l); //config id for clean tube
            gridData.setWfId(wfAssoc.getFromWfId());
            gridDataList.add(gridData);

            gridData = new WfGridData();
            gridData.setWfGridId(gridAssoc.getWfGridId());
            gridData.setValueNumber(new Double(barcodeIndexNumber));
            gridData.setWfGridDataConfigId(42l); //config id for barcode index
            gridData.setWfId(wfAssoc.getFromWfId());
            gridDataList.add(gridData);
            //Commeneted because this is being used as barcode adapter value part of sequencing analysis
/*
            gridData = new WfGridData();
            gridData.setWfGridId(gridAssoc.getWfGridId());
            gridData.setValueNumber(new Double(barcodeIndex));
            gridData.setWfGridDataConfigId(41l); //config id for barcode index
            gridData.setWfId(wfId);

            gridDataList.add(gridData);*/
          }
          wfGridDataDao.batchSaveGridData(gridDataList);

        }catch(Exception e){
          e.printStackTrace();
          jsonResponse.addError("Incorrect relationships. Check if more E plates are associated to GL than expected.");
          return jsonResponse;
        }
        /*long cleanTubeId = wfDao.getNextId();
        wfDao.save(WF_CONFIG_ID, detailMap.get(wfAssoc.getWfDataNumber()), 13L, userId, 4L, cleanTubeId);
        wfDataDao.save(cleanTubeId, 26L, detailMap.get(wfAssoc.getWfDataNumber()));
        wfDataDao.save(cleanTubeId, 23L, new BigDecimal(wfAssoc.getWfDataNumber()));
        wfDataDao.save(cleanTubeId, 1L, wfAssoc.getFromWfLabel());
        wfDataDao.save(cleanTubeId, 5L, wfDataDao.getValue(5L, wfAssoc.getFromWfId()).getWfDataTimestamp());
        wfDataDao.save(cleanTubeId, 49L, wfDataDao.getValue(49L, wfAssoc.getFromWfId()).getWfDataVarchar2());
        wfStepDao.initStep(13L, cleanTubeId, userId);

        wfAssocDao.save(wfId,cleanTubeId,wfAssoc.getFromWfLabel());*/
      }

      try {
        wfDataDao.save(wfId, 27L, wfDataDao.getVarchar2ForWfId(wfId, 45L));
        //store intrument id
        wfDataDao.save(wfId, 565L, "Manual");

        //save GenCell run name for possible diagnostics
        wfDataDao.save(wfId, 48L, "Manual");

       // wfStepDao.completeCurrentStep(wfId, userId);

        wfDao.updateWfEntityTypeId(wfId, 3L);
        //wfDao.UpdateWfStepConfig(wfId,13L,userId);
       // wfStepDao.initStep(13L, wfId, userId);
        //wfDao.updateWfStatus(wfId,"M");

      } catch (Exception e) {
        e.printStackTrace();
      }

        wfService.passSingleWf(wfId, userId, null);
        wfDataDao.save(wfId, 115L, "1 Pending");
        Wf wfInfo = wfService.getWfInfo(wfId);
        String varchar2ForWfId = null;
        try {
          varchar2ForWfId = wfDataDao.getVarchar2ForWfId(wfId, 565L);
        } catch (Exception e) {
          e.printStackTrace();
        }
        if(null != varchar2ForWfId){
          //it is a Clic
          if(!wfInfo.getWfEntityLabel().contains("-02")){
            wfDao.updateWfStatus(wfId, "B",userId);
          }
        }else{
          //it is an LP
          if(!wfInfo.getWfEntityLabel().contains("-03")){
            wfDao.updateWfStatus(wfId, "B",userId);
          }
        }
    }
    return new JsonResponse();
  }

  public static Long getNineTenPos(Long barcodeIndex) throws Exception {

    if (barcodeIndex >= 1L && barcodeIndex <= 4L) {
      return 9L;
    } else if (barcodeIndex >= 5L && barcodeIndex <= 8L) {
      return 10L;
    } else throw new AssertionError("Invalid barcode index for re-association " + barcodeIndex);
  }


  @WfDelegateMethod(wfStepConfigId = 13)
  public JsonResponse post13(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    Map<String, Set<Long>> dilBlockIdMap = new HashMap<String, Set<Long>>();
    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

      wfService.passSingleWf(wfId, userId, null);
      wfDataDao.save(wfId, 115L, "1 Pending");
      Wf wfInfo = wfService.getWfInfo(wfId);
      String varchar2ForWfId = null;
      try {
        varchar2ForWfId = wfDataDao.getVarchar2ForWfId(wfId, 565L);
      } catch (Exception e) {
        e.printStackTrace();
      }
      if(null != varchar2ForWfId){
        //it is a Clic
        if(!wfInfo.getWfEntityLabel().contains("-02")){
          wfDao.updateWfStatus(wfId, "B",userId);
        }
      }else{
        //it is an LP
        if(!wfInfo.getWfEntityLabel().contains("-03")){
          wfDao.updateWfStatus(wfId, "B",userId);
        }
      }
      //loop through entries for wfdcId fields
      /*for (String key : postData.keySet()) {
        if (key.equals("wfdc27")) {
          String dilBlockId = postData.get(key);
          Set<Long> wfToIdSet = dilBlockIdMap.get(dilBlockId);
          if (wfToIdSet == null) {
            wfToIdSet = new LinkedHashSet<Long>();
          }

          wfToIdSet.add(wfId);

          dilBlockIdMap.put(dilBlockId, wfToIdSet);

          break;
        }
      }*/
    }

    //@todo check for duplicate rack position and match barcode index plate to rack position
    //@todo check for dilution block id against prior workflows

    //now that we have the map of tubes to map to the dilution block id
    //converge them into a new workflow
    /*for (String dilBlockId : dilBlockIdMap.keySet()) {
      Map<Long, String> fromWfIdMap = new HashMap<Long, String>();
      for (Long fromWfId : dilBlockIdMap.get(dilBlockId)) {
        fromWfIdMap.put(fromWfId, wfDataDao.getValue(26, fromWfId).getWfDataVarchar2());
      }

      long combinedWfId = wfDao.combineTo(WF_CONFIG_ID, dilBlockId, fromWfIdMap, 14L, userId, 3L);

      wfDataDao.save(combinedWfId, 27L, dilBlockId);
    }*/

    return new JsonResponse();
  }


  @WfDelegateMethod(wfStepConfigId = 28)
  public JsonResponse post28(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    // Save the data submitted by the form.
    // Clean Tube / Sequencing Tube locations will be saved at Sequencing Grp Pooling.
    wfService.savePostData(jsonPost);

    Map<String, Map<Long, String>> convergedBlockIdMap = new HashMap<String, Map<Long, String>>();
    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

      String cleanTubeId = wfDataDao.getValue(26, wfId).getWfDataVarchar2();
      String seqBlockId = wfDataDao.getValue(32, wfId).getWfDataVarchar2();

      Map<Long, String> wfIdToMap = convergedBlockIdMap.get(seqBlockId);
      if (wfIdToMap == null) {
        wfIdToMap = new LinkedHashMap<Long, String>();
      }
      wfIdToMap.put(wfId, cleanTubeId);

      convergedBlockIdMap.put(seqBlockId, wfIdToMap);
    }

    //now that we have the map of tubes to map to the dilution block id
    //converge them into a new workflow
    for (String seqBlockId : convergedBlockIdMap.keySet()) {
      long combinedWfId = wfDao.combineTo(WF_CONFIG_ID, seqBlockId, convergedBlockIdMap.get(seqBlockId), 20L, userId, 6L);

      wfDataDao.save(combinedWfId, 32L, seqBlockId);
      wfDataDao.save(combinedWfId, 33L, "Proton");
      wfDataDao.save(combinedWfId, 34L, "15 pM");

      Timestamp glTimestamp = null;
      List<WfAssoc> activeLeftAdjacencies = wfAssocDao.getActiveLeft(combinedWfId);
      for(WfAssoc wfAssoc : activeLeftAdjacencies){
        //get minimum due date
        WfData wfData = wfDataDao.getValue(5, wfAssoc.getFromWfId());
        if(null != wfData && null != wfData.getWfDataTimestamp() && (null == glTimestamp || wfData.getWfDataTimestamp().before(glTimestamp))){
          glTimestamp = wfData.getWfDataTimestamp();
        }
      }
      if(null != glTimestamp){
        wfDataDao.save(combinedWfId, 5L, glTimestamp);
      }
    }

    return new JsonResponse();
  }

  @Transactional
  @WfDelegateMethod(wfStepConfigId = 10)
  public JsonResponse post10(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    //create map of GL barcode
    Map<String, Map<Integer, Long>> glPlateMap = new HashMap<String, Map<Integer, Long>>();

    String glPlateBarcodeBase;
    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

      String glPlateBarcode = postData.get("wfdc44");
      String biomekDeckPosition = postData.get("wfdc43");

      int pos = 0;
      int setIndex = 0;
      Map<Integer, Long> data = glPlateMap.get(glPlateBarcode);
      if (data == null) {
        data = new HashMap<Integer, Long>();
      }
      if (glPlateBarcode.endsWith("-01")) {
        if (biomekDeckPosition.equals("PRECIP2")) {
          pos = 1;
        } else if (biomekDeckPosition.equals("PRECIP3")) {
          pos = 2;
        } else if (biomekDeckPosition.equals("PRECIP4")) {
          pos = 3;
        } else if (biomekDeckPosition.equals("PRECIP5")) {
          pos = 4;
        }
        setIndex = 1;
      } else if (glPlateBarcode.endsWith("-02")) {
        if (biomekDeckPosition.equals("PRECIP2")) {
          pos = 5;
        } else if (biomekDeckPosition.equals("PRECIP3")) {
          pos = 6;
        } else if (biomekDeckPosition.equals("PRECIP4")) {
          pos = 7;
        } else if (biomekDeckPosition.equals("PRECIP5")) {
          pos = 8;
        }
        setIndex = 2;
      } else if (glPlateBarcode.endsWith("-03")) {
        if (biomekDeckPosition.equals("PRECIP2")) {
          pos = 9;
        } else if (biomekDeckPosition.equals("PRECIP3")) {
          pos = 10;
        }
        setIndex = 3;
      } else {
        LOG.error("The GL Plate barcode is invalid");
      }

      data.put(pos, wfId);
      glPlateMap.put(glPlateBarcode, data);

      glPlateBarcodeBase = glPlateBarcode.substring(0, glPlateBarcode.indexOf("-"));
      //save position workflow before merge
      wfDataDao.save(wfId, 47L, pos);
      wfDataDao.save(wfId, 106L, pos - (4 * (setIndex - 1)));
      wfDataDao.save(wfId, 105L, setIndex);
      wfDataDao.save(wfId, 107L, glPlateBarcode);
      wfDataDao.save(wfId, 10564L, glPlateBarcodeBase+"-"+pos);

      //delete pre-assigned L plate id
      wfDataDao.delete(wfId, 6L);
    }

    Timestamp glTimestamp = null;
    String oligoPool = "";

    List<WfPlateMap> wfPlateMapList = wfPlateMapDao.getWfPlateMap(1L,"BIOCELL_96_TO_384");
    Map<Integer, List<WfPlateMap>> wfPlateMap = wfPlateMapList.stream().collect(Collectors.groupingBy(WfPlateMap::getSourceQuadrant));


    //create or append to existing GL plate run
    for (String glPlateBarcode : glPlateMap.keySet()) {
      Map<Long, String> fromWfIdMap = new HashMap<Long, String>();
      for (Long fromWfId : glPlateMap.get(glPlateBarcode).values()) {
        //SVANT: E plate name should be the value(match key)
        fromWfIdMap.put(fromWfId, null);
      }

      //SVANT: Here, we need to create individual D plate and the D plate set, with associations...
      glPlateBarcodeBase = glPlateBarcode.substring(0, glPlateBarcode.indexOf("-"));
      Map<Long, String> dQuadrantMap = null;
      Map<Integer, Map<Long, String>> dPlatesMap = new HashMap<>();

      Map<Long, String> dplateWfIdMap = new HashMap();
      long glPlateWfId = -1;
      try {
        glPlateWfId = jdbcTemplate.queryForObject("select wf_id from ATLAS.wf where wf_entity_type_id=5 and wf_entity_label=? and wf_status='I'", Long.class, glPlateBarcode);
        //throw new EmptyResultDataAccessException(0);
        // wfDao.combineTo(glPlateWfId, 1L, glPlateBarcode, fromWfIdMap, 11L, userId, 5L);
      } catch (EmptyResultDataAccessException ex) {
        //gl plate configuration doesn't exist, so create it
        /*glPlateWfId = wfDao.combineTo(1L, glPlateBarcode, fromWfIdMap, 11L, userId, 5L);*/
        //create D quandrants first for all data values (this contains position)
        Map<Integer, Long> data = glPlateMap.get(glPlateBarcode);
        // Create a map of all the 8 dQuadrantWfIds...
        for(Integer pos : data.keySet()) {
          long dQuadrantWfId = data.get(pos);
          // wfDao.combineTo(dQuadrantWfId,1L, glPlateBarcodeBase+"-"+pos, fromWfIdMap, 11L, userId, 10199L);
          //create in a step config that does not exist..or immediately change the status to "M".

          if (pos == 1 || pos == 2 || pos == 3 || pos == 4) {
            dQuadrantMap = dPlatesMap.get(1);
            if(null == dQuadrantMap) {
              dQuadrantMap = new HashMap<>();
            }
            dQuadrantMap.put(dQuadrantWfId, glPlateBarcodeBase+"-"+pos);
            dPlatesMap.put(1, dQuadrantMap);
          } else {
            dQuadrantMap = dPlatesMap.get(2);
            if (null == dQuadrantMap) {
              dQuadrantMap = new HashMap<>();
            }
            dQuadrantMap.put(dQuadrantWfId, glPlateBarcodeBase+"-"+pos);
            dPlatesMap.put(2, dQuadrantMap);
          }
        }
        for (Integer i : dPlatesMap.keySet()) {
          long dPlateWfID  = wfDao.combineTo(1L, glPlateBarcodeBase + "-0" + i, dPlatesMap.get(i), 11L, userId, 5L);
          //Insert wf_grid_assoc for dQuadrant to individual D plates...
          Map<Long, String> dQuadrantMap1 = dPlatesMap.get(i);
          for (Long dQuadWfId : dQuadrantMap1.keySet()) {
            //quadrant wf id will get the source row and source col for the sample...that samples destination row/col should be inserted into grid_assoc for individual dl plate..
            String dPlateName = dQuadrantMap1.get(dQuadWfId); // this will contain the quadrant position..1,2,3 or 4...
            String quadrantPos = dPlateName.substring(dPlateName.indexOf("-")+1);
            int originalQuadPos = Integer.valueOf(quadrantPos);
            int quadPos = originalQuadPos;
            if( originalQuadPos > 4) {
              quadPos = quadPos - 4;
            }
            List<WfPlateMap> wfPlateMapByQuadList = wfPlateMap.get(quadPos);
            Map<String, WfPlateMap> wfPlateMapByQuad = wfPlateMapByQuadList.stream().collect(Collectors.toMap(WfPlateMap::getSourceRowCol, Function.identity()));

            List<WfGridAssoc> wfGridAssocList =  wfGridAssocDao.findAll(dQuadWfId);
            List<WfGridAssoc> destWfGridAssocList = new ArrayList<>();
            List<WfGridData> gridDataList = new ArrayList<>();
            for (WfGridAssoc sourceGridAssoc : wfGridAssocList) {

              WfPlateMap destWfPlateMap = wfPlateMapByQuad.get(sourceGridAssoc.getGridRow()+""+sourceGridAssoc.getGridCol());

              WfGridAssoc destGrid = new WfGridAssoc();
              destGrid.setWfConfigId(1l);
              destGrid.setWfId(dPlateWfID);
              destGrid.setStatus(sourceGridAssoc.getStatus());
              destGrid.setWfGridId(sourceGridAssoc.getWfGridId());
              destGrid.setGridCol(destWfPlateMap.getDestCol());
              destGrid.setGridRow(destWfPlateMap.getDestRow());
              destGrid.setLabel(destWfPlateMap.getDestWellName());
              destWfGridAssocList.add(destGrid);
              //SVANT: We need to create a wf_grid_data entry for all samples being associated to this individual D plate ...
              WfGridData gridData = new WfGridData();
              gridData.setWfId(dPlateWfID);
              gridData.setWfGridId(sourceGridAssoc.getWfGridId());
              gridData.setValueVarchar2(glPlateBarcodeBase + "-0" + i);
              gridData.setWfGridDataConfigId(10134l);
              gridDataList.add(gridData);

              gridData = new WfGridData();
              gridData.setWfId(dQuadWfId);
              gridData.setWfGridId(sourceGridAssoc.getWfGridId());
              //this should be dQuad wf label
              gridData.setValueVarchar2(dPlateName);
              gridData.setWfGridDataConfigId(10170l);
              gridDataList.add(gridData);

              //save the position of the sample on dQuadrant...used for barcodeAdapter...grid_data_config...41

              gridData = new WfGridData();
              gridData.setWfId(dQuadWfId);
              gridData.setWfGridId(sourceGridAssoc.getWfGridId());
              //
              long pos = ((sourceGridAssoc.getGridCol() - 1) * 8) +sourceGridAssoc.getGridRow();
              gridData.setValueNumber(new Double(pos));
              gridData.setWfGridDataConfigId(402l);
              gridDataList.add(gridData);

            }
            wfGridAssocDao.batchSaveGridAssoc(destWfGridAssocList);
            wfGridDataDao.batchSaveGridData(gridDataList);
          }
          dplateWfIdMap.put(dPlateWfID, glPlateBarcodeBase + "-0" + i);

          //resort members of GL plate set
          jdbcTemplate.update("update ATLAS.wf_assoc set sort_key=(select wf_data_number from ATLAS.wf_data where wf_data_config_id=47 and wf_id=from_wf_id) where to_wf_id=?", dPlateWfID);
         //SVANT: Update match_key as well
          jdbcTemplate.update("update ATLAS.wf_assoc set match_key=(select wf_data_varchar2 from ATLAS.wf_data where wf_data_config_id=10564 and wf_id=from_wf_id) where to_wf_id=?", dPlateWfID);

        }
      }

      for (Long dPlateWfId : dplateWfIdMap.keySet()) {
        List<WfAssoc> activeLeftAdjacencies = wfAssocDao.getActiveLeftAdjacencies(dplateWfIdMap.get(dPlateWfId));
        for(WfAssoc wfAssoc : activeLeftAdjacencies) {
          WfData wfData = wfDataDao.getValue(5, wfAssoc.getFromWfId());
          if (null != wfData && null != wfData.getWfDataTimestamp() && (null == glTimestamp || wfData.getWfDataTimestamp().before(glTimestamp))) {
            glTimestamp = wfData.getWfDataTimestamp();
          }
          //get oligo pool
          if (oligoPool.isEmpty()) {
            WfData wfDataOligoPool = wfDataDao.getValue(7, wfAssoc.getFromWfId());
            if (null != wfDataOligoPool && null != wfDataOligoPool.getWfDataVarchar2()) {
              oligoPool = wfDataOligoPool.getWfDataVarchar2();
            }
          }
        }
        wfDataDao.save(dPlateWfId, 45L, dplateWfIdMap.get(dPlateWfId)); //D plate name
        wfDataDao.save(dPlateWfId, 5L, glTimestamp);
        wfDataDao.save(dPlateWfId, 7L, oligoPool);
      }

      //SVANT: Should also insert wf_grid_assoc to know the sample position on the individual D plate...
      //this might need some logic since it is a 96 - 384 plate... and a quadrant spread across the plate...
    }
    // E Plates are going to be a trashed after this step and E Plate storage locations shouldn't be displayed for redo's
    List<WfData> wfDataList = null;
    for (Map<String, String> postData : jsonPost.getRows()) {
      Long wfId = Long.parseLong(postData.get("wfId"));

      wfDataList = wfDataDao.getWfDataBasedOnWfDataConfigLabel(wfId, WfStepDataConfigConstants.E_PLATE_LOCATION_1_LABEL);
      // Delete the E PLate Storage Location as E Plate will be trashed after this step and E Plate storage location shouldn't be displayed for redo's
      if (null != wfDataList && wfDataList.size() > 0) {
        for (WfData wfData : wfDataList) {
          wfDataDao.delete(wfData.getWfDataId());
        }
      }

      wfDataList = wfDataDao.getWfDataBasedOnWfDataConfigLabel(wfId, WfStepDataConfigConstants.E_PLATE_LOCATION_2_LABEL);
      if (null != wfDataList && wfDataList.size() > 0) {
        for (WfData wfData : wfDataList) {
          wfDataDao.delete(wfData.getWfDataId());
        }
      }
    }

    return new JsonResponse();
  }

  @WfDelegateMethod(wfStepConfigId = 50)
  public JsonResponse post50(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    //create map of GL barcode
    Map<String, List<com.monsanto.gwg.atlas.model.core.WfGridAssoc>> dPlateGridMap = new HashMap<>();
    try {
      List<WfData> wfDataList = new ArrayList<>();
      for (Map<String, String> postData : jsonPost.getRows()) {
        //extract wfId to associate data
        WfData wfData = new WfData();
        Long wfId = Long.parseLong(postData.get("wfId"));
        wfService.savePostData(jsonPost);
        String pcrStatus = wfDataDao.getVarchar2ForWfId(wfId, 158L);
        if (null == pcrStatus || pcrStatus.isEmpty()) {
          //wfDataDao.save(wfId, 158L, "1 Inventory Loaded");
        }else if (pcrStatus.equals("1 Inventory Loaded")) {
          wfData = new WfData( wfId, 158L, "4 Library Plate Creation Grouping");
          wfDataList.add(wfData);
          wfDataDao.delete(wfId, 158L);
        }
        // dPlateGridMap.put(wfDao.find(wfId).getWfEntityLabel(), wfGridAssocDao.findAll(wfId));
      }
      wfDataDao.batchSaveWfData(wfDataList);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return new JsonResponse();
  }

  @WfDelegateMethod(wfStepConfigId = 49)
  public JsonResponse post49(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    //create map of GL barcode
    Map<String, List<com.monsanto.gwg.atlas.model.core.WfGridAssoc>> dPlateGridMap = new HashMap<>();
    try {

      for (Map<String, String> postData : jsonPost.getRows()) {
        //extract wfId to associate data
        Long wfId = Long.parseLong(postData.get("wfId"));
        wfService.savePostData(jsonPost);
        String location = postData.get("wfdc184"); //wfDataDao.getVarchar2ForWfId(wfId, 184L);
        if ("Ank".equalsIgnoreCase(location)) {
          wfDataDao.save(wfId, 158L, "1 Inventory Loaded");
        }
        wfService.passAllWf(jsonPost, null);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return new JsonResponse();
  }


  @WfDelegateMethod(wfStepConfigId = 31)
  public JsonResponse post31(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    Map<String, Set<Long>> combinedTubeIdMap = new HashMap<String, Set<Long>>();
    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

      String combinedTubeId = null;
      try {
        combinedTubeId = wfDataDao.getVarchar2ForWfId(wfId, 39L);   //postData.get(key);
      } catch (Exception e ) {
//LOG.error();
      }
      Set<Long> wfToIdSet = combinedTubeIdMap.get(combinedTubeId);
      if (wfToIdSet == null) {
        wfToIdSet = new LinkedHashSet<Long>();
      }
      wfToIdSet.add(wfId);
      combinedTubeIdMap.put(combinedTubeId, wfToIdSet);
    }

    //The wfIdSet size should be same as the size of WfDataList size for the combined tube

    for(Map.Entry<String, Set<Long>> entry : combinedTubeIdMap.entrySet()) {
      String combinedTube = entry.getKey();
      List wfDataList = wfDataDao.getWfDataByDataConfigIdAndData(39L, combinedTube);
      if(wfDataList.size() != entry.getValue().size()) {
        jsonResponse.addError("All clean tubes associated to the Combined Tube ID must be scanned at once");
      }
    }

    //if there are any validation errors, return the response
    if (jsonResponse.getErrorCnt() != 0) {
      return jsonResponse;
    }
    // Save the data submitted by the form.
    // Clean Tube / Sequencing Tube locations will be saved at Ion Chef - Run Ready
    // if user NCR to Ion Chef - Run Ready instead of user saving the record from Sequencing Grp Selection to Sequencing Group Pooling.
    wfService.savePostData(jsonPost);

    //now that we have the map of clean tubes to map to the combined tube id
    //converge them into a new workflow

    for (String combinedTubeId : combinedTubeIdMap.keySet()) {
      Map<Long, String> fromWfIdMap = new HashMap<Long, String>();
      for (Long fromWfId : combinedTubeIdMap.get(combinedTubeId)) {
        fromWfIdMap.put(fromWfId, wfDataDao.getValue(26, fromWfId).getWfDataVarchar2());
      }

      long combinedWfId = wfDao.combineTo(WF_CONFIG_ID, combinedTubeId, fromWfIdMap, 39L, userId, 6L);

      for (Long fromWfId: fromWfIdMap.keySet()) {
        //updating Sort_key
       // DSA-7183 Sort_Key in wf_assoc from  Clean tube to poolTube donot match
        BigDecimal wfDataNumber = wfDataDao.getValue(23, fromWfId).getWfDataNumber();
        wfAssocDao.updateWfAssocSortKey(fromWfId,combinedWfId,wfDataNumber.intValue());

      }

      wfDataDao.save(combinedWfId, 39L, combinedTubeId);

      //SVANT: associate all samples to the pooled tube...Also, save the combinedTube on all samples in wf_grid_data...

      for(Long cleanTubeWfId: fromWfIdMap.keySet()) {
        List<WfGridData> saveGridDataList = new ArrayList<>();
        WfGridData saveGridData = null;
        String cleanTube = fromWfIdMap.get(cleanTubeWfId);
        List<Long> gridDataList = wfGridDataDao.findAllGridByData(10133L, cleanTube);
        for(Long gridId: gridDataList) {
            saveGridData = new WfGridData();
            saveGridData.setWfGridId(gridId);
            saveGridData.setWfId(combinedWfId);
            saveGridData.setValueVarchar2(combinedTubeId);
            saveGridData.setWfGridDataConfigId(10166l);

            saveGridDataList.add(saveGridData);

        }
        wfGridDataDao.batchSaveGridData(saveGridDataList);
      }

      Timestamp glTimestamp = null;
      List<WfAssoc> activeLeftAdjacencies = wfAssocDao.getActiveLeft(combinedWfId);

      int cpPlateCount = 0;
      int totalPlateCount = 0;
      Map eWfMap = new HashMap();

      for (WfAssoc wfAssoc : activeLeftAdjacencies) {
        //get minimum due date
        WfData wfData = wfDataDao.getValue(5, wfAssoc.getFromWfId());
        if (null != wfData && null != wfData.getWfDataTimestamp() && (null == glTimestamp || wfData.getWfDataTimestamp().before(glTimestamp))) {
          glTimestamp = wfData.getWfDataTimestamp();
        }
      }

      if (null != glTimestamp) {
        wfDataDao.save(combinedWfId, 5L, glTimestamp);
      }

      //For each clean tube; get the associated E plate.
      Set fromwfIdSet = fromWfIdMap.keySet();
      Iterator fromwfIdSetIterator = fromwfIdSet.iterator();
      while(fromwfIdSetIterator.hasNext()) {
        //extract wfId to associate data
        Long wfId = (Long)fromwfIdSetIterator.next();//Long.parseLong(postData.get("wfId"));
        String ePlateLabel = wfAssocDao.getActiveLeftWithMatchKey(wfId);
        if (ePlateLabel.startsWith("CP")) {
          cpPlateCount = cpPlateCount + 1;
        }
        totalPlateCount = totalPlateCount + 1;
      }
      wfDataDao.save(combinedWfId, 1223L, new Timestamp(System.currentTimeMillis()));

      //TODO: to save the taxonomy ..E plate has this (or) clean tube
      //Genotyping status ..not sure if this needs to be set to a default.

      //Save a new wf data with number of CP plates / total number of plates
      wfDataDao.save(combinedWfId, 113L, cpPlateCount + "/"+ totalPlateCount);
    }

    return jsonResponse;
  }

  public String printDilutionBlockId() {
    final String ID_SQL = "select nextval('atlas.gbs_dilution_block_id_seq') dual";
    Long id = jdbcTemplate.queryForObject(ID_SQL, Long.class);
    String idFormatted = "DILB-" + String.format("%4d", id);

    Long printerId = wfStepConfigDao.getWfPrinterId(13L);

    //print 2 labels (one for the dilution block and a second for the qPCR 384
    wfService.printBarcode(printerId, idFormatted);
    wfService.printBarcode(printerId, idFormatted);
/*

    final String PRINT_SQL = "insert into ATLAS.wf_printer_queue (wf_prn_file,queue_enter_ts,printer_id) " +
            "(select " +
            " ?," +
            " now()," +
            " (select wf_printer_id from ATLAS.wf_step_config where wf_step_config_id=13) " +
            ")";

    //print 2 labels (one for the dilution block and a second for the qPCR 384
    jdbcTemplate.update(PRINT_SQL, idFormatted);
    jdbcTemplate.update(PRINT_SQL, idFormatted);
*/

    return idFormatted;
  }

  public String printGencellGLPlateIds(String runType) {
    final String ID_SQL = "select nextval('atlas.gbs_glplate_id_seq') dual";
    Long id = jdbcTemplate.queryForObject(ID_SQL, Long.class);
    // String idFormatted = "GL" + getCurrentYear() + "SP" + String.format("%4d", id);

    String idFormatted = null;
    try {
      idFormatted = "ML" + getCurrentYear() + getCurrentMonth() + String.format("%02d", getCurrentDay()) + "_" + "M" + String.format("%05d", id);

      Long printerId = wfStepConfigDao.getWfPrinterId(10L);
      //wfService.printBarcode(printerId, idFormatted);
      wfService.printBarcode(printerId, idFormatted + "-01");
      wfService.printBarcode(printerId, idFormatted + "-01");
      wfService.printBarcode(printerId, idFormatted + "-02");
      wfService.printBarcode(printerId, idFormatted + "-02");

    } catch (Exception e) {
      e.printStackTrace();
    }

    return idFormatted;
  }

  public String printChipGLPlateIds() {
    final String ID_SQL = "select nextval('atlas.gbs_glplate_id_seq') dual";
    Long id = jdbcTemplate.queryForObject(ID_SQL, Long.class);
    //String idFormatted = "GL" + getCurrentYear() + "_D" + D Plate;
   /* String runTypeStartLetter = "L";
    if ("Sneaker".equalsIgnoreCase(runType)) {
      runTypeStartLetter = "D";
    }
*/
    String idFormatted = null;
    try {
      idFormatted = "GL" + getCurrentYear() + getCurrentMonth() + String.format("%02d", getCurrentDay()) + "_DM" + String.format("%05d", id);

      Long printerId = wfStepConfigDao.getWfPrinterId(50L);
      //wfService.printBarcode(printerId, idFormatted);
      wfService.printBarcode(printerId, idFormatted + "-01");
      wfService.printBarcode(printerId, idFormatted + "-01");

      wfService.printBarcode(printerId, idFormatted + "-02");
      wfService.printBarcode(printerId, idFormatted + "-02");
    /*   if ("Clic".equalsIgnoreCase(runType)) {
        wfService.printBarcode(printerId, idFormatted + "-02");
      }
     else {
        wfService.printBarcode(printerId, idFormatted + "-03");
        wfService.printBarcode(printerId, idFormatted + "-03");
        wfService.printBarcode(printerId, idFormatted + "-03");
      } */
    } catch (Exception e) {
      e.printStackTrace();
    }

    return idFormatted;
  }
/*
    final String PRINT_SQL = "insert into ATLAS.wf_printer_queue (wf_prn_file,queue_enter_ts,printer_id) " +
            "(select " +
            " ?," +
            " now()," +
            " (select wf_printer_id from ATLAS.wf_step_config where wf_step_config_id=10) " +
            "from dual)";

    //print 2 labels (one for the dilution block and a second for the qPCR 384 well plate)
    //jdbcTemplate.update(PRINT_SQL, idFormatted);
    //jdbcTemplate.update(PRINT_SQL, idFormatted);
    //Trina- print 2 copies of each GL plate
    jdbcTemplate.update(PRINT_SQL, idFormatted + "-01");
    jdbcTemplate.update(PRINT_SQL, idFormatted + "-01");

    jdbcTemplate.update(PRINT_SQL, idFormatted + "-02");
    jdbcTemplate.update(PRINT_SQL, idFormatted + "-02");
    if("Clic".equalsIgnoreCase(runType)) {
      jdbcTemplate.update(PRINT_SQL, idFormatted + "-02");
    } else {
      jdbcTemplate.update(PRINT_SQL, idFormatted + "-03");
      jdbcTemplate.update(PRINT_SQL, idFormatted + "-03");
      jdbcTemplate.update(PRINT_SQL, idFormatted + "-03");
    }*/

  public String printSequencingBlockId() {
    final String ID_SQL = "select nextval('atlas.gbs_sequencing_block_id_seq') dual";
    Long id = jdbcTemplate.queryForObject(ID_SQL, Long.class);
    String idFormatted = "SEQB-" + String.format("%4d", id);

    Long printerId = wfStepConfigDao.getWfPrinterId(19L);
    wfService.printBarcode(printerId, idFormatted);
    /*
    final String PRINT_SQL = "insert into ATLAS.wf_printer_queue (wf_prn_file,queue_enter_ts,printer_id) " +
            "(select " +
            " ?," +
            " now()," +
            " (select wf_printer_id from ATLAS.wf_step_config where wf_step_config_id=19) " +
            ")";

    jdbcTemplate.update(PRINT_SQL, idFormatted);*/

    return idFormatted;
  }

  public void printLabelsAtLigation() {

    Long printerId = wfStepConfigDao.getWfPrinterId(7L);

    final String SQL = "select wf_data_varchar2||'-BEAD' as label from ATLAS.wf_data where \n" +
            "wf_id in (select wf_id from ATLAS.wf where wf_step_config_id=7) and \n" +
            "wf_data_config_id=6\n" +
            "union all \n" +
            "select wf_data_varchar2||'-CLN' as label from ATLAS.wf_data where \n" +
            "wf_id in (select wf_id from ATLAS.wf where wf_step_config_id=7) and \n" +
            "wf_data_config_id=6" ;

    List<String> labelList = jdbcTemplate.queryForList(SQL, String.class);
    for(String label : labelList){
      wfService.printBarcode(printerId, label);
    }
  }

  public void printManualLPlateIds() {

   /* final String SQL = "insert into ATLAS.wf_printer_queue (\n" +
            "  wf_prn_file,\n" +
            "  queue_enter_ts,\n" +
            "  printer_id\n" +
            ") (\n" +
            "select \n" +
            "  wf_entity_label,\n" +
            "  now(),\n" +
            "  (select wf_printer_id from ATLAS.wf_step_config where wf_step_config_id=4) \n" +
            "from \n" +
            "  ATLAS.wf \n" +
            "where \n" +
            "  wf_step_config_id=4 and wf_status='I'\n" +
            ")";

    jdbcTemplate.update(SQL);*/

    Long printerId = wfStepConfigDao.getWfPrinterId(4L);
    List<Wf> allWfInWfConfigStep = wfDao.findAllWfInWfConfigStep(WF_CONFIG_ID, 4L, true);

    for(Wf wf : allWfInWfConfigStep){
      wfService.printBarcode(printerId, wf.getWfEntityLabel());
    }
  }

  public List<ProjectResult> getProjectResults(Integer projectStatusId, String limsId, Set<String> limsIdList) {
    //find project result records and load supplementary data
    List<ProjectResult> projectResults = projectResultDao.findByProjectStatusId(projectStatusId, limsId);

    //set child node count to determine if the plate has multiple runs
    //that can be merged at the raw reads level

    try {
      //SVANT: To enable Merge icon, all samples that were remediated, need to be available for merge
      for (ProjectResult projectResult : projectResults) {
        if (projectResult.getBlockBarcodeNbr() != null && projectResult.getWfId() == null) {
          int childNodeCount = 0;
          boolean mergeComplete = false;
          boolean mergeReady = false;
          for (ProjectResult projectResultInner : projectResults) {
            if (projectResult.getBlockBarcodeNbr().equals(projectResultInner.getBlockBarcodeNbr())) {
              mergeReady = false;
              childNodeCount++;
              if(projectResultInner.getWfId() != null) {
                long wfId = wfDao.getWfId(projectResult.getBlockBarcodeNbr(), 1);
                List<List<HashMap<String, Object>>> wfGridDataList = wfGridDao.callStoredProcForPivotGridData(wfId, "17,40");
                List<Sample> samplesList = wfGridDao.mapResultToGrid(wfGridDataList);
                if (null != samplesList) {
                  samplesList = samplesList.stream().filter(s -> s.getTorrentAnalysisId() != null).collect(Collectors.toList());
                  //if every grid has an active run name..wf_grid_data_config_id = 39 =
                  if (samplesList.size() == wfGridAssocDao.findAllActive(wfId).size()) {
                    mergeReady = true;
                  }
                  if (projectResultInner.getLplateId() != null) mergeComplete = true;
                }
              }
            }
          }
          projectResult.setChildNodeCount(childNodeCount);
          projectResult.setMergeComplete(mergeComplete);
          projectResult.setMergeReady(mergeReady);
          //check if all samples have an active sequencingRunCount
          // long wfId = wfDao.getWfId(projectResult.getBlockBarcodeNbr(),1);

        }
        limsIdList.add(projectResult.getLimsId());
      }

      //load the raw reads count
      //and also the e plate wf Id for cherry picking
      for (ProjectResult projectResult : projectResults) {
        if (projectResult.getBlockBarcodeNbr() != null && projectResult.getWfId() != null) {
          //Now the raw_reads coming from gbs_project_result
        /*  projectResult.setRawReadCount(
                  projectResultDao.getEplateRawReadCount(
                          projectResult.getTorrentAnalysisId(),
                          projectResult.getBarcodeIndexPlate()
                  ) );*/


          Double po = 0D;
          if (null != projectResult.getPoStatus() && null != projectResult.getPoStatus() && projectResult.getPoStatus().indexOf("PO=") > -1) {
            String poStr = projectResult.getPoStatus().substring(projectResult.getPoStatus().indexOf("PO="));
            try {
              po = Double.valueOf(poStr.substring(3, poStr.indexOf("%")));
            } catch (Exception e) {

            }
          }
          projectResult.setPo(po);

          String[] plateDetails = projectResultDao.getPlateDetails(projectResult.getBlockBarcodeNbr(), projectResult.getWfId());
          if (null != plateDetails) {
            projectResult.setNoteSummary(plateDetails[0]);
            projectResult.setNoteComments(plateDetails[1]);
          }

          /*List<String[]> relatedWfs = getTorrentResults(projectResult.getTorrentRunName());
          projectResult.setTorrentData(relatedWfs);*/
          List<String> appliedNcrs = projectResultDao.getAppliedNCR(projectResult.getProjectResultId());
          List<String> ncrComments = projectResultDao.getNcrComments(projectResult.getProjectResultId());
          //When a dQuadrant is remediated, the associated E's should display the NCR names..
          List<Long> fromWfidsList = wfAssocDao.getFromWfIds(projectResult.getWfId());
          for (Long analyzedDWfId: fromWfidsList) {
            appliedNcrs.addAll(projectResultDao.getNCRs(analyzedDWfId));
            ncrComments.addAll(projectResultDao.getNcrCommentsByWfId(analyzedDWfId));
          }
          appliedNcrs = appliedNcrs.stream().distinct().collect(Collectors.toList());
          ncrComments = ncrComments.stream().distinct().collect(Collectors.toList());

          projectResult.setAppliedNcrName(appliedNcrs);


          if(appliedNcrs.size() > 0) {
            projectResult.setAllSamplesAnalyzed("N"); // setting this attribute will not allow users to NCR the samples again.
          }
          //SMBT-1035 As Atlas, display NCR comments on project review page
          projectResult.setNcrComments(ncrComments);

         /* if (null != projectResult.getSnapshotWfId()) {
            projectResult.setSnapshotData(wfDataDao.findAll(projectResult.getSnapshotWfId()));
          }*/

          if (projectResult.getIncludeInProject()) {
            projectResult.setePlateWfId(projectResult.getWfId());
            //projectResultDao.getWfIdForEPlate(projectResult.getBlockBarcodeNbr()));
            if (null != projectResult.getePlateWfId()) {
              projectResult.setCherrySelected(isEPlateCherrySelected(projectResult.getePlateWfId()));
              projectResult.setCherryPicked(isEPlateCherryPicked(projectResult.getePlateWfId()));
              //Check if there are more than 2 runs for an E plate, If yes, ready to merge.
              projectResult.setMergeReady((isEPlateCherryMergeReady(projectResult.getePlateWfId())));
              projectResult.setMergeComplete(isEPlateMergedWithCherryPlate(projectResult.getBlockBarcodeNbr()));
            }
          }
        }

        //For each ProjectResult entry... check if the E/F plate is on Hold.
        String ePlate = projectResult.getBlockBarcodeNbr();
        //Long torrentAnalysisId = projectResult.getTorrentAnalysisId();
        if (null != ePlate && !"".equals(ePlate) && projectResult.getePlateWfId()!=null) {
          try {
            Long ePlatewfId = wfDao.findWfWithStatus(1L, ePlate, "H");
            if (ePlatewfId != null) {
              //it means the E plate is on HOLD.
              projectResult.setOnHold(true);
            } else {
              List<WfAssoc> fromWfIds = wfAssocDao.getActiveLeftAdjacencies(ePlate, 1);
              if (null != fromWfIds && fromWfIds.size() > 0) {
                String fBlock = fromWfIds.get(0).getFromWfLabel();
                Long fWfId = wfDao.findWfWithStatus(1L, fBlock, "H");
                if (fWfId != null) {
                  ////it means the F block is on HOLD.
                  projectResult.setOnHold(true);
                }
              }
            }
          } catch (EmptyResultDataAccessException e) {
            LOG.info("No E plate found of entity type id: 1");
          }
        }
      }
    }catch(Exception e) {
      e.printStackTrace();
    }
    return projectResults;
  }

  private boolean isEPlateMergedWithCherryPlate(String blockBarcodeNbr) {

    boolean isEPlateMergedWithCherryPlate = false;
    List<String> cherryPlateNameList = cherryPickDao.getCherryPlateName(blockBarcodeNbr);
    for(String cherryPlateName : cherryPlateNameList){
      if(null != cherryPlateName && !cherryPlateName.isEmpty()) {
        List<ProjectResult> projectResultList = projectResultDao.findByBlockBarcodeNbr(cherryPlateName);

        if (null != projectResultList && !projectResultList.isEmpty() &&
                null != projectResultList.get(0) && null != projectResultList.get(0).getWfId()) {
          //Get the pooled tube wfid with left assocs of the analyzedEWfId.
          List<WfAssoc> analyzedDQuadWfIdAssoc = wfAssocDao.getActiveLeft(projectResultList.get(0).getWfId());
          for (WfAssoc assoc : analyzedDQuadWfIdAssoc) {
            List<WfAssoc> pooledTubeWfAssoc = wfAssocDao.getActiveLeft(assoc.getFromWfId());
            for (WfAssoc assoc1 : pooledTubeWfAssoc) {
              List<WfGridData> torrentAnalysisIdData = wfGridDataDao.findGridDataByTypeId(assoc1.getFromWfId(), 40L);
              isEPlateMergedWithCherryPlate = mergedSampleDao.isPlateMerged(blockBarcodeNbr, torrentAnalysisIdData.get(0).getValueNumber().longValue());
              if (isEPlateMergedWithCherryPlate) {
                break;
              }
            }
          }
        }
      }
    }
    return isEPlateMergedWithCherryPlate;
  }

  private List<String[]> getTorrentResults(String torrentRunName) {
    return wfDataDao.getTorrentResults(torrentRunName);
  }

  public List<ProjectResult> getProjectResultsForPriorityUpdate() {
    return projectResultDao.findAllPriorityUpdateEligible();
  }

  public void updateProjectResults(JsonProjectUpdate jsonProjectUpdate) {
    String limsId = jsonProjectUpdate.getLimsId();
    List<JsonProjectUpdateEplate> includedEplatesList = jsonProjectUpdate.getIncludedEplates();
    for(JsonProjectUpdateEplate ePlate : includedEplatesList) {
      long analyzedEWfId = ePlate.getWorkflowId();
      List<WfAssoc> analyzedDquadWfAssocList = wfAssocDao.getActiveLeft(analyzedEWfId);
      List<Long> pooledTubeWfIdsList = new ArrayList<>();
      for(WfAssoc assoc: analyzedDquadWfAssocList) {
        List<WfAssoc> pooledTubeWfAssocList = wfAssocDao.getActiveLeft( assoc.getFromWfId());
        for(WfAssoc assoc1: pooledTubeWfAssocList) {
          pooledTubeWfIdsList.add(assoc1.getFromWfId());
        }
      }
      ePlate.setPooledTubeWfIdList(pooledTubeWfIdsList);
    }
    projectResultDao.updateProjectResults(limsId, jsonProjectUpdate.getIncludedEplates(), jsonProjectUpdate.getMabProjectStatusId());
  }

  public void updateProjectResultsBPOQCStatus(JsonProjectUpdate jsonProjectUpdate, int newStatus) {
    String limsId = jsonProjectUpdate.getLimsId();
    projectResultDao.updateProjectResultsBPOQCStatus(limsId, jsonProjectUpdate.getIncludedEplates(), newStatus);

    //here, create a new wf_data entry to record the user who submitted the E plate to status of '-101' by QC team. -- This is for reporting purpose
    Iterator<JsonProjectUpdateEplate> iter = jsonProjectUpdate.getIncludedEplates().iterator();
    while (iter.hasNext()) {
      JsonProjectUpdateEplate includedEplate = iter.next();
      //get the original E plate id, and save the username against it
      Long wfId =  includedEplate.getWorkflowId();
      wfDataDao.save(wfId, 526L,jsonProjectUpdate.getUserId());
            wfService.updateQCAction(wfId);
    }
  }


  public List<ResummarizationQueueRow> getResummarizationQueue() {
    //if the queue is empty, return null since there is nothing to resummarize
    List<ResummarizationQueueRow> results = projectResultDao.getResummarizationQueue();
    if (results.isEmpty()) {
      return null;
    } else {
      return results;
    }
  }

  public void streamUploadFile(String limsId, String all, PrintWriter pw) throws IOException {
    List<MarkerAnalysis> uploadRecords = markerAnalysisDao.findByLimsIdAndBlockBarcodeNbr(limsId,all);

    pw.write("[Header],,,, \n" +
            "BSGT Version,3.0.27,,, \n" +
            "Processing Date, " + utilService.formatDateRubiconUpload(new Date()) + ",,,\n" +
            "Content,GS0000129-OPA.opa,,, \n" +
            "Num SNPs,1,,, \n" +
            "Total SNPs,1,,, \n" +
            "Num Samples,1,,, \n" +
            "Total Samples,1,,, \n" +
            "[Data],,,, \n" +
            "SNP Name,Sample ID,Allele1 - Forward,Allele2 - Forward,GC Score\n");

    for (MarkerAnalysis uploadRecord : uploadRecords) {
      //modified to stringbuilder append options for performance
      pw.write("S-" + uploadRecord.getMarkerId() + "," +
              String.format("%04d", uploadRecord.getSampleId()) + "," +
              uploadRecord.getCall().substring(0, 1) + "," +
              uploadRecord.getCall().substring(1, 2) + "," +
              "0\n");
    }
  }

  public void updateProjectOverride(long gbsProjectResultId, Integer overrideVal, Integer markerSet, Integer qcThresholdOverride) {
    projectResultDao.updateProjectOverride(gbsProjectResultId, overrideVal, markerSet, qcThresholdOverride);
  }


  public /*List<GbsSearchResult>*/ void findBarcode(String barcode) {


  }

  public Map<String, Sample> findRunDataForSamples(long analyzedEWfId) {
    List<List<HashMap<String,Object>>>  wfGridsObjectList = new ArrayList<>();
    try {
      wfGridsObjectList = wfGridDao.callStoredProcForPivotGridData_Merge(analyzedEWfId, "6,7,9,15,17,18,40,41,403,10103,10169");
    } catch (Exception e) {
      e.printStackTrace();
    }
    List<Sample> analyzedEsamplesList = wfGridDao.mapResultToGrid(wfGridsObjectList);
    Wf wf = wfDao.find(analyzedEWfId);
    Wf originalE = wfDao.findWfForStep(1,wf.getWfEntityLabel(),1l);
    for(Sample s: analyzedEsamplesList) {

      WfGridAssoc wga = wfGridAssocDao.findAllByGridIDWfID(originalE.getWfId(), s.getGridId());
      s.setRowNbr(wga.getGridRow());
      s.setColNbr(wga.getGridCol());;
      s.setSampleId(wfGridDao.find(s.getGridId()).getSampleId().intValue());
      s.setWfId(analyzedEWfId);
    }

    Map<String,Sample> sampleMap = analyzedEsamplesList.stream().collect(Collectors.toMap(Sample::getWellAddress, Function.identity()));


    //Map<String,List<Sample>> sampleMap = analyzedEsamplesList.stream().collect(Collectors.groupingBy(Sample::getWellAddress));
    return sampleMap;
  }


 /* public List<MergedSample> findPendingMergedSamples(String blockBarcodeNbr, long analyzedEWfId1, long analyzedEWfId2) {
    List<List<HashMap<String,Object>>>  wfGridsObjectList = new ArrayList<>();
    try {
      wfGridsObjectList = wfGridDao.callStoredProcForPivotGridData_Merge(analyzedEWfId1, "40,41,403,10169");
    } catch (Exception e) {
      e.printStackTrace();
    }
    List<Sample> analyzedEsamplesList1 = wfGridDao.mapResultToGrid(wfGridsObjectList);
    try {
      wfGridsObjectList = wfGridDao.callStoredProcForPivotGridData_Merge(analyzedEWfId2, "40,41,403,10169");
    } catch (Exception e) {
      e.printStackTrace();
    }
    List<Sample> analyzedEsamplesList2 = wfGridDao.mapResultToGrid(wfGridsObjectList);
    return mergedSampleDao.findPending(blockBarcodeNbr, analyzedEsamplesList1, analyzedEsamplesList2 );
  }*/

  public Map<String, CherryPickSample> getTorrentResultsAsCherryMap(String blockBarcodeNbr) {

    Long wfId = projectResultDao.getWfIdForEPlate(blockBarcodeNbr);
    ProjectResult projectResult = projectResultDao.getCherryPickProjectResult(blockBarcodeNbr);
    String limsId = projectResult.getLimsId();
   /* Long torrentAnalysisId = projectResult.getTorrentAnalysisId();
    Integer barcodeIndexPlate = projectResult.getBarcodeIndexPlate();*/
    List<List<HashMap<String,Object>>>  wfGridDataList = getGridDataAndMapToCherryObject(wfId, "7,9,15,17,18,40,41,10103");//will need 19...
    List<Sample> samplesList = wfGridDao.mapResultToGrid(wfGridDataList);

    Map<String, CherryPickSample> cherryPickSampleMap = populateIntoCherrySample(limsId, blockBarcodeNbr, samplesList);

    return cherryPickSampleMap;
  }

  public Map<String, CherryPickSample> populateIntoCherrySample(String limsId, String blockBarcodeNbr,List<Sample> samplesList ) {

    Map<String, CherryPickSample> cherryPickSampleMap = new LinkedHashMap<String, CherryPickSample>();
    //get the wfId of blockBarcodeNbr

    Long wfId = wfDao.findWfInWfConfig(1L, 8l, blockBarcodeNbr,  26l);
    for (Sample sample : samplesList) {

      //Based on the gridId, and wfId, fetch the row and Col...

      WfGridAssoc assoc = wfGridAssocDao.findAllByGridIDWfID(wfId, sample.getGridId());

      Integer gridRow = assoc.getGridRow();
      Integer gridCol = assoc.getGridCol();
      String wellAddress = UtilService.getWellAddress(gridRow + (gridCol - 1) * 8);
      CherryPickSample cherryPickSample = new CherryPickSample();
      if (cherryPickSampleMap.containsKey(wellAddress)) {
        cherryPickSample = cherryPickSampleMap.get(wellAddress);
      }
      cherryPickSample.setLimsId(limsId);
      cherryPickSample.setBarcodeAdapter(sample.getBarcodeAdapter());
      cherryPickSample.setBlockBarcodeNbr(blockBarcodeNbr);
      cherryPickSample.setWellAddress(wellAddress);
      //switch (wfGridData.getWfGridDataTypeId().intValue()) {
      //case 4:

      cherryPickSample.setSampleId(wfGridDao.find(sample.getGridId()).getSampleId().intValue());



      cherryPickSample.setPedigreeOrigin(sample.getPedigree());
      cherryPickSample.setHet(sample.getPercentHet());
      cherryPickSample.setPo(sample.getPctPo());
      cherryPickSample.setMarkerCount(Long.valueOf(sample.getMarkerCount()).intValue());
      cherryPickSample.setGeneration(sample.getGeneration());
      cherryPickSample.setTorrentAnalysisId(sample.getTorrentAnalysisId());
      if("DROP".equalsIgnoreCase(sample.getWellStatus())){
        cherryPickSample.setDropped(true);
      } else {
        cherryPickSample.setDropped(false);
      }
      cherryPickSample.setSampleOverrideEligible("N");

      if (null == cherryPickSample.getHet()) {
        cherryPickSample.setHet(0D);
      }
      if (null == cherryPickSample.getPo()) {
        cherryPickSample.setPo(0D);
      }
      if (null == cherryPickSample.getMarkerCount()) {
        cherryPickSample.setMarkerCount(0);
      }
      if (null == cherryPickSample.getSampleOverrideEligible()) {
        cherryPickSample.setSampleOverrideEligible("N");
      }
      //Added by Suma  --Based on generatoin and crop type, the HET threshold values are different.
     /* if(cherryPickSample.getMarkerCount() > 500 || cherryPickSample.getPo() < 10 || cherryPickSample.getHet() < 5) {
        cherryPickSample.setSampleOverrideEligible("Y");
      } else  {
        cherryPickSample.setSampleOverrideEligible("N");
      }*/


     // System.out.println(cherryPickSample.getSampleId() + ": "+cherryPickSample.getMarkerCount() + ": " + cherryPickSample.getBarcodeAdapter());

      cherryPickSampleMap.put(wellAddress, cherryPickSample);
    }
    return cherryPickSampleMap;
  }

  public List<Long> findEligibleAnalysisRuns(String blockBarcodeNbr) {
    return mergedSampleDao.findEligibleAnalysisRuns(blockBarcodeNbr);
  }

  public long updatePendingMergedSamples(String blockBarcodeNbr, List<MergedSample> mergedSampleList) {
    long mergedSampleGroupId = mergedSampleDao.savePending(blockBarcodeNbr, mergedSampleList);
    return mergedSampleGroupId;
  }

  public boolean runInProgress(String blockBarcodeNbr) {
    return mergedSampleDao.runInProgress(blockBarcodeNbr);
  }

  public boolean cherryPickInProgress(String blockBarcodeNbr) {
    return cherryPickDao.isEPlateCherryPicked(blockBarcodeNbr);
  }

  public String getCherryPickBlockBarcodeNbr(long wfId) {
    return wfDataDao.getValue(1L, wfId).getWfDataVarchar2();
  }

  public List<Wf> getAllAssociatedEPlates(String ePlate) {

   Long wfIdAtStep = null;
   //Cobra Run Ready queue will not exist in Re-array
   /*  try {
      wfIdAtStep = getActiveWfAtStep(1L, 10199L, ePlate, 30L);
    } catch (Exception e) {
    }

    if (null == wfIdAtStep) {
*/
      try {
        wfIdAtStep = getActiveWfAtStep(1L, 10199L, ePlate, 10L);
      } catch (Exception e) {

      }
    /*}*/
    List<Wf> allEPlates = new ArrayList<Wf>();
    final String whereClauseSQL = " WF_ID IN ( " +
            "select wf.WF_ID from ATLAS.WF wf INNER JOIN ATLAS.WF_DATA wd ON wd.WF_ID = wf.WF_ID INNER JOIN ATLAS.WF_ASSOC wa ON wa.FROM_WF_ID= wf.WF_ID " +
            "where wa.TO_WF_ID IN (select TO_WF_ID from ATLAS.WF_ASSOC where FROM_WF_ID=? and ACTIVE='Y') and wd.WF_DATA_CONFIG_ID=107 " +
            "and wd.WF_DATA_VARCHAR2 IN (select WF_DATA_VARCHAR2 from ATLAS.WF_DATA where WF_DATA_CONFIG_ID=107 and WF_ID=?)  and wa.ACTIVE='Y')";
    if (null != wfIdAtStep) {
      allEPlates = wfDao.findAll(whereClauseSQL, wfIdAtStep, wfIdAtStep);
    }

    return allEPlates;
  }

  public Long getActiveWfAtStep(Long wfConfigId, Long entityTypeId, String ePlate, Long wfStepConfigId) {

    return wfDao.findActiveWfInWfConfig(wfConfigId, entityTypeId, ePlate, wfStepConfigId);
  }

  public Long getWfAtStep(Long wfConfigId, Long entityTypeId, String ePlate, Long wfStepConfigId) {

    return wfDao.findWfInWfConfig(wfConfigId, entityTypeId, ePlate, wfStepConfigId);
  }

  public ProjectResult getCherryPickProjectResult(String blockBarcodeNbr) {
    ProjectResult projectResult = new ProjectResult();
    try{
      projectResult = projectResultDao.getCherryPickProjectResult(blockBarcodeNbr);
    }catch(AssertionError e){

    }catch(Exception e){

    }

    return projectResult;
  }

    /*@WfDelegateMethod(wfStepConfigId = 33)
  public JsonResponse post33(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    for (Map<String, String> postData : jsonPost.getRows()) {

      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

      //loop through entries for wfdcId fields
      for (String key : postData.keySet()) {
        //save the Big F cart location
        if (key.startsWith("wfdc")) {
          Long wfDataConfigId = Long.parseLong(key.substring(4));
          if(wfDataConfigId == 461L)
            wfDataDao.save(wfId, wfDataConfigId, postData.get(key));
          //save the original location
          wfDataDao.save(wfId, 463L, postData.get(key));
        }

      }
    }
    wfService.passAllWf(jsonPost, null);
    return jsonResponse;
    }*/

   /* @WfDelegateMethod(wfStepConfigId = 34)
  public JsonResponse post34(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    List<WfData> wfDataList = new ArrayList<>();
    List<WfGrid> gridList = new ArrayList<WfGrid>();
    List<WfGridAssoc> gridAssocList = new ArrayList<WfGridAssoc>();
    List<WfGridData> gridDataList = new ArrayList<WfGridData>();

    for (Map<String, String> postData : jsonPost.getRows()) {

      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

      //loop through entries for wfdcId fields
      for (String key : postData.keySet()) {
        //save the Big F cart location
        if (key.startsWith("wfdc")) {
          Long wfDataConfigId = Long.parseLong(key.substring(4));
          if(wfDataConfigId == 461L)
            wfDataList.add(new WfData(wfId, wfDataConfigId, postData.get(key)));
          //wfDataDao.save(wfId, wfDataConfigId, postData.get(key));
        }
      }

            addSampleData(jsonResponse, wfDataList, gridList, gridAssocList, gridDataList, wfId,userId);
    }
        wfDataDao.batchSaveWfData(wfDataList);
    wfService.saveSampleData(gridList, gridAssocList, gridDataList);

    wfService.passAllWf(jsonPost, null);
    return jsonResponse;
    }*/

  private void addSampleData(JsonResponse jsonResponse, List<WfData> wfDataList, List<WfGrid> gridList, List<WfGridAssoc> gridAssocList, List<WfGridData> gridDataList, Long wfId,String userId) {

    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:s");

    WfData plate = wfDataDao.getValue(64l, wfId);

    DetailServiceResponse detailServiceResponse = getPlateDetailFromWebService(plate.getWfDataVarchar2());

    if (null != detailServiceResponse &&
            null != detailServiceResponse.getWellSamples() && !detailServiceResponse.getWellSamples().isEmpty()) {
      try {
        if (null != detailServiceResponse.getFieldPlateStatus() &&
                detailServiceResponse.getFieldPlateStatus().equalsIgnoreCase("Dropped")) {

          wfDataList.add(new WfData(wfId, 69L, "Dropped"));
          wfDao.updateWfStatus(wfId, "D",userId);
        }

        wfDataList.add(new WfData(wfId, 63L, detailServiceResponse.getKernelNumber()));
        try {
          wfDataList.add(new WfData(wfId, 5L, new Timestamp((format.parse(detailServiceResponse.getDueDate())).getTime())));
          wfDataList.add(new WfData(wfId, 68L, new Timestamp((format.parse(detailServiceResponse.getDueDate())).getTime())));
        } catch (ParseException e) {
          e.printStackTrace();
        }

        /*
        JIRA-7400 : remove 21 day calculation.
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 21);  // number of days to add
        wfDataList.add(new WfData(wfId, 5L, new Timestamp(c.getTimeInMillis())));
*/

        String projectId = wfDataDao.getVarchar2ForWfId(wfId, 59L);

        boolean isControlPresent = false;
        List<WellSample> samplesList = detailServiceResponse.getWellSamples();

        for (WellSample sample : samplesList) {
          try {
            if (sample.getSampleNumber() == null || sample.getSampleNumber().equals("0")) {
              isControlPresent = true;
              sample.setSampleNumber("0");
              sample.setGeneration("INBRED");
              sample.setOrigin("LH82 origin");
            }

            WfGrid wfGrid = new WfGrid();
            wfGrid.setWfGridId(wfGridDao.getNextSeqId("WF_GRID_ID_SEQ"));
            wfGrid.setProjectId(projectId);
            wfGrid.setSampleId(Long.valueOf(sample.getSampleNumber()));
            wfGrid.setWfConfigId(WF_CONFIG_ID);
            wfGrid.setSourceWfId(wfId);
            gridList.add(wfGrid);

            WfGridAssoc wfGridAssoc = new WfGridAssoc();
            String rowAndColumnArray[] = UtilityMethodsImpl.splitAndGetNumericPosition(sample.getWellName());
            wfGridAssoc.setGridRow(Integer.valueOf(rowAndColumnArray[0]));
            wfGridAssoc.setGridCol(Integer.valueOf(rowAndColumnArray[1]));
            wfGridAssoc.setLabel(sample.getWellName());
            wfGridAssoc.setWfConfigId(WF_CONFIG_ID);
            wfGridAssoc.setWfId(wfId);
            wfGridAssoc.setWfGridId(wfGrid.getWfGridId());
            gridAssocList.add(wfGridAssoc);

            //set pedigree
            WfGridData wfGridData = new WfGridData();
            wfGridData.setWfId(wfId);
            wfGridData.setWfGridId(wfGrid.getWfGridId());
            wfGridData.setWfGridDataConfigId(15l);
            wfGridData.setValueVarchar2(sample.getOrigin());
            gridDataList.add(wfGridData);

            //set inventory barcodeInv
            WfGridData wfGridDatainv = new WfGridData();
            wfGridDatainv.setWfId(wfId);
            wfGridData.setWfGridId(wfGrid.getWfGridId());
            wfGridDatainv.setWfGridDataConfigId(16l);
            wfGridDatainv.setValueVarchar2(sample.getInventoryBarcodeNumber());
            gridDataList.add(wfGridDatainv);

            //set generation
            WfGridData wfGridDataGen = new WfGridData();
            wfGridDataGen.setWfId(wfId);
            wfGridData.setWfGridId(wfGrid.getWfGridId());
            wfGridDataGen.setWfGridDataConfigId(18l);
            wfGridDataGen.setValueVarchar2(sample.getGeneration());
            gridDataList.add(wfGridDataGen);

          } catch (Exception e) {

          }
        }
        if (!isControlPresent) {
          addControlWell("A01", gridList, gridAssocList, gridDataList, wfId, projectId);
        }

      } catch(Exception e){
        e.printStackTrace();
      }
    } else {
      jsonResponse.addError("No Samples returned for Plate : " + plate.getWfDataVarchar2());
    }
  }

  private void addControlWell(String wellName, List<WfGrid> gridList, List<WfGridAssoc> gridAssocList, List<WfGridData> gridDataList, long wfId, String projectId) {

    WfGrid wfGrid = new WfGrid();
    wfGrid.setWfGridId(wfGridDao.getNextSeqId("WF_GRID_ID_SEQ"));
    wfGrid.setProjectId(projectId);
    wfGrid.setSampleId(0L);
    wfGrid.setWfConfigId(WF_CONFIG_ID);
    wfGrid.setSourceWfId(wfId);
    gridList.add(wfGrid);

    WfGridAssoc wfGridAssoc = new WfGridAssoc();
    String rowAndColumnArray[] = UtilityMethodsImpl.splitAndGetNumericPosition(wellName);
    wfGridAssoc.setGridRow(Integer.valueOf(rowAndColumnArray[0]));
    wfGridAssoc.setGridCol(Integer.valueOf(rowAndColumnArray[1]));
    wfGridAssoc.setLabel(wellName);
    wfGridAssoc.setWfConfigId(WF_CONFIG_ID);
    wfGridAssoc.setWfId(wfId);
    wfGridAssoc.setWfGridId(wfGrid.getWfGridId());
    gridAssocList.add(wfGridAssoc);

    //set pedigree
    WfGridData wfGridData = new WfGridData();
    wfGridData.setWfId(wfId);
    wfGridData.setWfGridId(wfGrid.getWfGridId());
    wfGridData.setWfGridDataConfigId(15l);
    wfGridData.setValueVarchar2("LH82 origin");
    gridDataList.add(wfGridData);

    //set inventory barcodeInv
    WfGridData wfGridDatainv = new WfGridData();
    wfGridDatainv.setWfId(wfId);
    wfGridData.setWfGridId(wfGrid.getWfGridId());
    wfGridDatainv.setWfGridDataConfigId(16l);
    wfGridDatainv.setValueVarchar2(null);
    gridDataList.add(wfGridDatainv);

    //set generation
    WfGridData wfGridDataGen = new WfGridData();
    wfGridDataGen.setWfId(wfId);
    wfGridData.setWfGridId(wfGrid.getWfGridId());
    wfGridDataGen.setWfGridDataConfigId(18l);
    wfGridDataGen.setValueVarchar2("INBRED");
    gridDataList.add(wfGridDataGen);
  }

  @WfDelegateMethod(wfStepConfigId = 35)
  public JsonResponse post35(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));

            markSelectedCellsAsDropped(postData);

      //completeAndSaveStepData(userId, postData, 38L, 9L, plate.getWfDataVarchar2(), gridAssocList, gridDataList);
      Long numberOfColumns = wfGridAssocDao.countDistinctColumns(wfId);
      Long numberOfSamples = wfGridAssocDao.countAllByWf(wfId);
      wfDataDao.save(wfId, 4L, new BigDecimal(numberOfColumns));
      wfDataDao.save(wfId, 3L, new BigDecimal(numberOfSamples));

    }
    wfService.passAllWf(jsonPost, 37L);

    return jsonResponse;
  }

    private void markSelectedCellsAsDropped(Map<String, String> postData) {

    //extract wfId to associate data
    Long wfId = Long.parseLong(postData.get("wfId"));
        if (postData.keySet().contains("selectedCells")) {

    List<WfGridAssoc> wfGridAssocList = wfGridAssocDao.findAll(wfId);
            List<WfGridData> wfGridDataList = new ArrayList<>();
            List<WfGridAssoc> wfGridAssocListToUpdate = new ArrayList<>();

      for (String key : postData.keySet()) {
        if (key.equals("selectedCells")) {
          String selectedCells = postData.get("selectedCells");
          List<String> selectedCellsList = Arrays.asList(selectedCells.split(","));

          for (WfGridAssoc wfGridAssoc : wfGridAssocList) {
                        if ("A01".equals(wfGridAssoc.getLabel())) {
                            continue;
                        }
            if (selectedCellsList.contains(wfGridAssoc.getLabel())) {
              WfGridData wfGridData = new WfGridData();
              wfGridData.setWfGridId(wfGridAssoc.getWfGridId());
              wfGridData.setWfGridDataConfigId(5L);
              wfGridData.setValueVarchar2("DROP");
              wfGridData.setWfId(wfId);

              wfGridAssoc.setStatus("D");
              wfGridAssocListToUpdate.add(wfGridAssoc);

              wfGridDataList.add(wfGridData);
            }
          }
        }
      }

            wfGridAssocDao.batchUpdateGridAssoc(wfGridAssocListToUpdate);
            wfService.saveSampleData(null, null, wfGridDataList);
    }
  }

    /*@WfDelegateMethod(wfStepConfigId = 37)
  public JsonResponse post37(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();
        //List<WfGridAssoc> wfGridAssocList = new ArrayList<>();
    for (Map<String, String> postData : jsonPost.getRows()) {

      //extract wfId to associate data
            //Long wfId = Long.parseLong(postData.get("wfId"));

            //WfData plate = wfDataDao.getValue(64l, wfId);
            wfService.passAllWf(jsonPost, 38L);

            //completeAndSaveStepData(userId, postData, 38L, 9L, plate.getWfDataVarchar2(), wfGridAssocList);
    }
        //wfService.saveSampleData(null, wfGridAssocList, null);

    return jsonResponse;
    }*/

  /**
   * create grid data list and drop out samples
     *
   * @param userId
   * @param postData
   * @param nextStepId
   * @param wfEntityTypeId
   * @param wfLabel
   * @param gridAssocList
   */
  public long completeAndSaveStepData(String userId, Map<String, String> postData, long nextStepId, long wfEntityTypeId,
                                      String wfLabel, List<WfGridAssoc> gridAssocList) {

    //extract wfId to associate data
    Long wfId = Long.parseLong(postData.get("wfId"));

    long newPlateId = wfService.completeThisStep(WF_CONFIG_ID, userId, wfId, nextStepId, wfLabel, wfEntityTypeId);
    List<WfGridAssoc> wfGridAssocList = wfGridAssocDao.findAll(wfId);

    if(newPlateId!=0)
    {
      if (postData.keySet().contains("selectedCells")) {
        for (String key : postData.keySet()) {
          if (key.equals("selectedCells")) {
            String selectedCells = postData.get("selectedCells");
            List<String> selectedCellsList = Arrays.asList(selectedCells.split(","));

            for (WfGridAssoc wfGridAssoc : wfGridAssocList) {
              if (!selectedCellsList.contains(wfGridAssoc.getLabel())) {
                wfGridAssoc.setWfId(newPlateId);
                gridAssocList.add(wfGridAssoc);
              }
            }
          }
        }
      } else {
        for (WfGridAssoc wfGridAssoc : wfGridAssocList) {
          wfGridAssoc.setWfId(newPlateId);
          gridAssocList.add(wfGridAssoc);
        }
      }
    }

    return newPlateId;
  }

  /**
   * access the web service method and get the object
     *
   * @return
   * @throws Exception
   */
  private DetailServiceResponse getPlateDetailFromWebService(String plateId) {

    LOG.debug("GBSService - getPlateDetailFromWebService method");

    DetailServiceResponse plateDetail = null;
    //hit the web service and get the JSON response back
    String output = "";

    WfConfigProperty url = wfService.findByWfConfigIdAndKey(1L, "URL_BPO_DETAIL_SERVICE");

    String accessToken = AuthenticationUtil.getAccessToken(
            wfService.findByWfConfigIdAndKey(1L, "AZURE_URL_ACCESS_TOKEN").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "AZURE_CLIENT_ID_ATLAS").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "AZURE_CLIENT_SECRET_ATLAS").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "GRANT_TYPE").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "HTTPS_PROTOCOL_VALUE").getPropertyValue());

    ClientResponse response = null;
    try {
      response = AuthenticationUtil.getResponse(accessToken, url.getPropertyValue()+plateId);
    } catch (Exception e) {
      e.printStackTrace();
    }

    if (response.getStatus() != 200 && response.getStatus() != 201) {
      LOG.info("Failed : HTTP error code : "+ response.getStatus());
      if("Y".equalsIgnoreCase(wfService.findByWfConfigIdAndKey(1L, "USE_PING_AUTH").getPropertyValue())) {
        accessToken = AuthenticationUtil.getAccessToken(
                wfService.findByWfConfigIdAndKey(1L, "URL_ACCESS_TOKEN").getPropertyValue(),
                wfService.findByWfConfigIdAndKey(1L, "CLIENT_ID").getPropertyValue(),
                wfService.findByWfConfigIdAndKey(1L, "CLIENT_SECRET").getPropertyValue(),
                wfService.findByWfConfigIdAndKey(1L, "GRANT_TYPE").getPropertyValue(),
                wfService.findByWfConfigIdAndKey(1L, "HTTPS_PROTOCOL_VALUE").getPropertyValue());
        try {
          response = AuthenticationUtil.getResponse(accessToken, url.getPropertyValue() + plateId);
          if (response.getStatus() != 200 && response.getStatus() != 201) {
            LOG.info("Failed : HTTP error code : " + response.getStatus());
          } else {
            output = response.getEntity(String.class);
            LOG.info("Success Response:" + output);
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    }else{
      output = response.getEntity(String.class);
      LOG.info("Success Response:"+output);
    }

    if (output.contains("Error: ")) {
      LOG.debug("GBSService - error in response output");
    } else {
      plateDetail = parseResponse(output);
    }

    return plateDetail;
  }

  /**
   * hit the web service and get the JSON response back
   * @param webResource
   * @return
   * @throws Exception
   */
  public String getPlateDetail(WebResource webResource) throws Exception {

    LOG.debug("Receiving details on plate");

    ClientResponse response = webResource.accept("application/json")
            .type("application/json").get(ClientResponse.class);

    if (response.getStatus() != 200) {
      LOG.debug("Invalid Response from Detail service");
      throw new RuntimeException("Failed : HTTP error code : "
              + response.getStatus());
    }

    return response.getEntity(String.class);
  }

  /**
   * parse response into object
   * @param output
   * @return
   */
  private DetailServiceResponse parseResponse(String output) {
    LOG.debug("Parsing Detail Plate Response");
    return new Gson().fromJson(output, DetailServiceResponse.class);
  }

  /**
   * get the web service
   * @return
   */
  public WebResource getWebResource(String plateId) {
    Client client = Client.create();
    WfConfigProperty url = wfService.findByWfConfigIdAndKey(1L, "URL_BPO_DETAIL_SERVICE");
    return client.resource(url.getPropertyValue() + plateId);
  }

  public Set<String> saveCherryPickedSamples(String userId, String sourceBlock, String selectedSamples) throws Exception {

    List<String> cherryPickedSamples = Arrays.asList(selectedSamples.split(","));
    List<CherryPickSample> cherryPickSampleList = new ArrayList<CherryPickSample>();
    Set<String> glPlates = new HashSet<String>();
    Wf wf = getWfInfo(sourceBlock, 1L);
    //Below code not required after change to get based on wfEntityTypeId
/*
    if (null == wf) {
      wf = getWfInfo(sourceBlock, 10L);
    }
*/
    if(null == wf){
      //jsonResponse.addError("E plate relationship is incorrect for "+plateActionArr[0]+". Please send the error to an Atlas administrator for correction.");
      throw new Exception();
    }

    //String limsId = wfService.getStringValue(8L, wf.getWfId());
    String limsId = wfService.getStringValue(59L, wf.getWfId());
    if(null == limsId || limsId.isEmpty() || limsId.equalsIgnoreCase("N//A")){
     // limsId = wfService.getStringValue(59L, wf.getWfId());
      limsId = wfService.getStringValue(8L, wf.getWfId());
    }
    // wf = getWfInfo(sourceBlock, 10199L);
    //WfData wfData = wfDataDao.getValue(107, wf.getWfId()); // 106 and 107 are on the Dquad wfid ...
    //WfData wfQuadrantData = wfDataDao.getValue(106, wf.getWfId());

    for (String sample : cherryPickedSamples) {
      CherryPickSample cherryPickSample = new CherryPickSample();
      Integer sampleId = Integer.parseInt(sample.split("-")[0]);
      Long wfGridId =   (wfGridDao.findAllByProjectAndSample(sampleId.longValue(),limsId)).get(0).getWfGridId(); //todo
      cherryPickSample.setLimsId(limsId);
      cherryPickSample.setSampleId(Integer.parseInt(sample.split("-")[0]));
      cherryPickSample.setRound(1);
      cherryPickSample.setStatus("1");
      cherryPickSample.setBlockBarcodeNbr(sourceBlock);
      cherryPickSample.setWellAddress(sample.split("-")[1]);
      cherryPickSample.setSelectedTs(new Timestamp(new Date().getTime()));
      //cherryPickSample.setGlPlateId(wfData.getWfDataVarchar2());
      String glPlateId =   wfGridDataDao.findGridDataByGridIdTypeId(wfGridId,10134L).get(0);
      cherryPickSample.setGlPlateId(glPlateId);
      //cherryPickSample.setGlPlateQuad(wfQuadrantData.getWfDataNumber().intValue());
      String dQuad= wfGridDataDao.findGridDataByGridIdTypeId(wfGridId,10170L).get(0);
      cherryPickSample.setGlPlateQuad(Integer.valueOf(dQuad.split("-")[1]));
      cherryPickSample.setDueDate(wfDataDao.getValue(5L, wf.getWfId()).getWfDataTimestamp());
      cherryPickSample.setUserId(userId);
      // Do not add  control samples to cherry_pick table
      if((cherryPickSample.getSampleId().intValue() != 0) && (!cherryPickSample.getWellAddress().equals("A01"))){
        cherryPickSampleList.add(cherryPickSample);
      }
      glPlates.add(glPlateId);
    }

    cherryPickDao.save(sourceBlock, cherryPickSampleList);

    return glPlates;

  }

  public Map<String, List<CherryPickSample>> getCherryPickedPlates(Integer status) {

    Map<String, List<CherryPickSample>> cherryMap = new HashMap<String, List<CherryPickSample>>();

    List<CherryPickSample> cherryPickSampleList = cherryPickDao.findAllCherries(status);
    String prevCherryBlockNumber = null;
    for (CherryPickSample cherryPickSample : cherryPickSampleList) {
      List<CherryPickSample> cherriesPerPlate = null;
      // Get Count of Cherry Pick Samples for E-Block
      Integer eBlockSampleTotal = cherryPickDao.getCountForEPlate(cherryPickSample.getBlockBarcodeNbr());
      cherryPickSample.setBlockSampleTotal(eBlockSampleTotal);
      // SMBT-827 - As ATLAS I want to add the number of samples below 1 ng/uL of the gDNA in the cherry picked queue where it shows the sample count in the E-block
      // SMBT-1014 - Display PCR-Ext Passed count and Percent in the cherry picked queue where it shows the sample count in the E-block
      //MBTSUPPORT-233 - CP % passed has incorrect values
      //Get Count of Cherry Pick Samples Passed


      Integer eBlockSamplesPassed = 0;
      if(null != prevCherryBlockNumber && !prevCherryBlockNumber.equalsIgnoreCase(cherryPickSample.getBlockBarcodeNbr())) {
        eBlockSamplesPassed = cherryPickDao.getSamplesPassedCount(cherryPickSample.getBlockBarcodeNbr());
      }
      prevCherryBlockNumber = cherryPickSample.getBlockBarcodeNbr();
      cherryPickSample.setBlockSamplesPassed(eBlockSamplesPassed);
      //set Percent of Cherry Pick Samples Passed
      if(eBlockSampleTotal != 0 && eBlockSamplesPassed != 0 ){
        double eBlockSamplesPassedPercent = (eBlockSamplesPassed.doubleValue()/eBlockSampleTotal.doubleValue() )* 100;
        cherryPickSample.setBlockSamplesPassedPercent(Math.floor(eBlockSamplesPassedPercent));
      }

      if (cherryMap.containsKey(cherryPickSample.getBlockBarcodeNbr())) {
        cherriesPerPlate = cherryMap.get(cherryPickSample.getBlockBarcodeNbr());
      } else {
        cherriesPerPlate = new ArrayList<CherryPickSample>();
      }

      Wf wf = getWfInfo(cherryPickSample.getBlockBarcodeNbr(), 1L);
      //Below code not required after change to get based on wfEntityTypeId
      /*if (null == wf) {
        wf = getWfInfo(cherryPickSample.getBlockBarcodeNbr(), 10L);
      }*/
      if (null != wf) {
        //WfData wfData = wfDataDao.getValue(107,wf.getWfId());
        //cherryPickSample.setGlPlateId(wfData.getWfDataVarchar2());
        WfData wfData = wfDataDao.getValue(5L, wf.getWfId());
        if(null != wfData) {
          cherryPickSample.setDueDate(wfData.getWfDataTimestamp());
          //cherryPickSample.setWellPosition(wfDataDao.getValue(106L,wfData.getWfId()).getWfDataNumber().intValue());
          cherriesPerPlate.add(cherryPickSample);
          cherryMap.put(cherryPickSample.getBlockBarcodeNbr(), cherriesPerPlate);
        }
      }
    }

    return cherryMap;

  }

  //public void saveWfData(WfData wfData, int numberOfSamples, String userId) {
  public void saveWfData(Set<String> glPlates, int numberOfSamples, String userId) {
    for (String glPlate:glPlates) {

      //see if gl palte id exists for this step with active wf
      //Wf glWf = wfDao.find("WF_CONFIG_ID = ? AND WF_STEP_CONFIG_ID = ? AND WF_ENTITY_LABEL = ? AND WF_STATUS='I'", 1L, 51L, wfData.getWfDataVarchar2());
      Wf glWf = wfDao.find("WF_CONFIG_ID = ? AND WF_STEP_CONFIG_ID = ? AND WF_ENTITY_LABEL = ? AND WF_STATUS='I'", 1L, 51L, glPlate);
      Long glPlateWfId = wfDao.getWfId(glPlate,3,1L);
      //if no - create a new wf
      if (null == glWf) {
        glWf = new Wf();
        glWf.setWfConfigId(1L);
        glWf.setWfEntityLabel(glPlate);
        glWf.setWfEntityTypeId(5L);
        glWf.setWfStatus("I");
        glWf.setWfStepConfigId(51L);
        glWf.setCreateUser(userId);
        glWf.setCreateTs(new Timestamp(new Date().getTime()));

        glWf = wfDao.save(glWf);

        wfStepDao.initStep(51L, glWf.getWfId(), userId );

        wfDataDao.save(glWf.getWfId(), 107L, glWf.getWfEntityLabel());
        wfDataDao.save(glWf.getWfId(), 65L, 1);
        wfDataDao.save(glWf.getWfId(), 3L, numberOfSamples);
        wfDataDao.save(glWf.getWfId(), 5L, wfDataDao.getValue(5L, glPlateWfId).getWfDataTimestamp());
        /*
          //Jira SMBT-575
          List<WfAssoc> activeRight = wfAssocDao.getActiveRight(wfData.getWfId(), 3);
          WfData glLoc1 = wfDataDao.getValue(422, activeRight.get(0).getToWfId());
          WfData glLoc2 = wfDataDao.getValue(423, activeRight.get(0).getToWfId());
          wfDataDao.save(glWf.getWfId(), 422L, glLoc1.getWfDataVarchar2());
          wfDataDao.save(glWf.getWfId(), 423L, glLoc2.getWfDataVarchar2());
        */
        wfDataDao.save(glWf.getWfId(), 422L, wfDataDao.getValue(422L, glPlateWfId).getWfDataVarchar2());
        wfDataDao.save(glWf.getWfId(), 423L, wfDataDao.getValue(423L, glPlateWfId).getWfDataVarchar2());

      } else {

        // update gl plate count for this
        String count = cherryPickDao.getCountForGlPlate(glWf.getWfEntityLabel());
        if(null != count && !count.isEmpty() && count.indexOf("-") > -1) {
          String[] countArr = count.split("-");

          Timestamp existingTs = wfDataDao.getValue(5L, glWf.getWfId()).getWfDataTimestamp();

          wfDataDao.save(glWf.getWfId(), 65L, Integer.valueOf(countArr[0]));
          wfDataDao.save(glWf.getWfId(), 3L, Integer.valueOf(countArr[1]));
          if (existingTs.after(wfDataDao.getValue(5L, glPlateWfId).getWfDataTimestamp())) {
            wfDataDao.delete(glWf.getWfId(), 5L);
            wfDataDao.save(glWf.getWfId(), 5L, wfDataDao.getValue(5L, glPlateWfId).getWfDataTimestamp());
          }
        }
      }
    }
  }

  public List<CherryPickSample> getCherryPickedPlates(Integer status, String selectedPlates) {

    return cherryPickDao.findAllCherriesForPlate(status, selectedPlates);
  }

  public Wf getWfInfo(String barCode, Long wfEntityTypeId) {

    return wfDao.find("wf_entity_label = ? and WF_ENTITY_TYPE_ID = ? and WF_STATUS IN ('M','I') limit 1 ", barCode, wfEntityTypeId);

  }

  /**
   * created this custom step just to avoid storing of the data collected before save
   * Data colelcetd : Enforce scanning of all plates associated with the Cherry Picked palte
   * We do not have to store these as the mapping is already present in CHERRY_PICK table
   *
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 51)
  public JsonResponse post51(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    String message = "";
    //get the scanned plates and create the cherry picked plate.
    for (Map<String, String> postData : jsonPost.getRows()) {

      try {
        String selectedPlates = postData.get("wfdc_selectedeplates_1");

        //extract wfId to associate data
        Long originalWfId = Long.parseLong(postData.get("wfId"));

        for (String plate : Arrays.asList(selectedPlates.split(","))) {
          String[] plateActionArr = plate.split("-");
          if(plateActionArr[1].equalsIgnoreCase("save")){

            cherryPickDao.verifySamplesFromGlPlate(plateActionArr[0]);

          }else {
                // validate for Chip Plate
                if (isChipPlate(plateActionArr[0])) {
                    jsonResponse.addError("This NCR option is not valid for Chip Plates");
                    throw new Exception();
                } else{
                String ncrComment = "";
                Wf wf = getWfInfo(plateActionArr[0], 1L);
                //Below code not required after change to get based on wfEntityTypeId
                /*if (null == wf) {
                  wf = getWfInfo(plateActionArr[0], 10L);
                }*/
                if (null == wf) {
                  jsonResponse.addError("E plate relationship is incorrect for " + plateActionArr[0] + ". " +
                          "Please send the error to an Atlas administrator for correction.");
                  throw new Exception();
                }

                cherryPickDao.updateStatus(plateActionArr[0], "0");

                if (plateActionArr[1].equalsIgnoreCase("ncrLV")) {
                  ncrComment = "Low Volume";
                } else if (plateActionArr[1].equalsIgnoreCase("ncrHsf")) {
                  ncrComment = "High Sample Failure";
                } else {
                  ncrComment = "Lost Plate";
                }
                wfService.applyNcr(61L, wf.getWfId(), null, ncrComment, jsonPost.getUserId(), null);
              }
           // }
          }
        }

        Wf wf = wfDao.find(originalWfId);
        String count = cherryPickDao.getCountForGlPlate(wf.getWfEntityLabel());

        if(null != count && !count.isEmpty() && count.indexOf("-") > -1 && Integer.valueOf(count.split("-")[1]) > 0) {
          LOG.info("there is a pending E plate within the GL to take action on. Keep this plate open.");
          String[] countArr = count.split("-");

          wfDataDao.save(originalWfId, 65L, Integer.valueOf(countArr[0]));
          wfDataDao.save(originalWfId, 3L, Integer.valueOf(countArr[1]));

        }else{
          //wfStepDao.completeCurrentStep(originalWfId, userId);
          wfDao.updateWf(originalWfId,userId);
        }

      }catch(Exception e){

      }
    }
    return jsonResponse;
  }

  /**
   * post74. save method for "Library Creation Receive F Block"
   * post74 method is implemented to save F Plate storage locations to "Ready for CleanUp" queue for redo's
   * @param userId
   * @param jsonPost
   * @return*/
  @WfDelegateMethod(wfStepConfigId = 74)
  public JsonResponse post74(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    //extract and map all data types for efficiency
    Set<Long> wfdcIdSet = new HashSet<Long>();
    for (Map<String, String> postData : jsonPost.getRows()) {
      for (String key : postData.keySet()) {
        if (key.startsWith("wfdc")) {
          wfdcIdSet.add(Long.parseLong(key.substring(4)));
        }
      }
    }

    List<WfDataConfig> wfDataConfigs = wfDataConfigDao.get(wfdcIdSet);
    Map<Long, WfDataConfig> wfDataConfigMap = new HashMap<Long, WfDataConfig>();
    for (WfDataConfig wfDataConfig : wfDataConfigs) {
      wfDataConfigMap.put(wfDataConfig.getWfDataConfigId(), wfDataConfig);
    }

    // Fetch "Ready for CleanUp" queue.
    Long readyForCleanUpStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.READY_FOR_CLEAN_UP);

    for (Map<String, String> postData : jsonPost.getRows()) {
      // Update WF Status so that F Plate will be hidden from "Library Creation Receive F block"
      Long wfId = Long.parseLong(postData.get("wfId"));
      //wfStepDao.completeCurrentStep(wfId,userId);
      wfDao.updateWf(wfId,userId);


      List<Long> fromWfIdList = wfAssocDao.getFromWfIds(wfId);
      if (null != fromWfIdList && fromWfIdList.size() > 0) {
        for (Long fromWfId : fromWfIdList) {
          Wf wf = wfDao.find(fromWfId);
          // Save the data only if from queue is "Ready for CleanUp". Hence the below if condition.
          if (null != wf && null != wf.getWfStepConfigId() &&
                  wf.getWfStepConfigId().equals(readyForCleanUpStepConfigId)) {
            //loop through entries for wfdcId fields
            for (String key : postData.keySet()) {
              if (key.startsWith("wfdc")) {
                Long wfDataConfigId = Long.parseLong(key.substring(4));
                WfDataConfig wfDataConfig = wfDataConfigMap.get(wfDataConfigId);
                if ("NUMBER".equals(wfDataConfig.getWfDataConfigType())) {
                  wfDataDao.save(fromWfId, wfDataConfigId, new BigDecimal(postData.get(key)));
                } else if ("VARCHAR2".equals(wfDataConfig.getWfDataConfigType())) {
                  wfDataDao.save(fromWfId, wfDataConfigId, postData.get(key));
                }
              }
            }
          }
          break;
        }
      }
    }
    return jsonResponse;
  }

  /**
   * post11 method is implemented to save GL Plate Storage Locations to "Gencell LC - Plate Creation" for redo's
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 11)
  public JsonResponse post11(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();


    // Save the data submitted from the form.
    wfService.savePostData(jsonPost);

    // Fetch "Gencell LC Plate Creation" queue WF_STEP_CONFIG_ID.
    Long plateCreationStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.GENCELL_LC_PLATE_CREATION);

    // For 1 GL Plate, there can be more than one E Plates. Copy GL Plate storage locations to "Gencell LC - Plate Creation" queue for redos
    for (Map<String, String> postData : jsonPost.getRows()) {
      Long wfId = Long.parseLong(postData.get("wfId"));

      List<Long> fromWfIdList = wfAssocDao.getFromWfIds(wfId);
      if (null != fromWfIdList && fromWfIdList.size() > 0) {
        for (Long fromWfId : fromWfIdList) {
          Wf wf = wfDao.find(fromWfId);
          // Copy the data only if from queue is "Gencell LC _ Plate Creation". Hence the below if condition.
          // Removing the below if condition as the GL could be created from Cobra Run ready too. - Defect raised by Trina: not able to distinguish the redo E plate.
        /*  if (null != wf && null != wf.getWfStepConfigId() &&
              wf.getWfStepConfigId().equals(plateCreationStepConfigId)) {*/
          // Copy data entered at "Gencell LC - Received" to "Gencell LC - Plate Creation" queue to display GL Plate storage locations when plates are performed NCR.
          wfDataDao.copyDataCollectedAtOneToAnotherStep(wfId, fromWfId);
          /*  }*/
        }
      }
    }

    // Pass ALL WF data.
    wfService.passAllWf(jsonPost, null);

    return jsonResponse;
  }


  public void updateCherryPickedSamples(List<CherryPickSample> cherryPickedSamples, String wfEntityLabel) {

    cherryPickDao.batchUpdate(cherryPickedSamples, wfEntityLabel);
  }

  public List<WfAssoc> getChildEPlates(String selectedPlate) {

    List<WfAssoc> wfAssocList = wfAssocDao.getActiveLeftAdjacencies(selectedPlate);
    return wfAssocList;
  }

  /**
   * E Plate Id for the original plate
   *
   * @param blockBarcodeNbr
   * @return
   */
  public Map<String, CherryPickSample> getTorrentResultsForCherryPlate(String blockBarcodeNbr) {

    //get samples picked for the original plate
    List<CherryPickSample> cherrySamplesForThisPlate = cherryPickDao.findAllCherriesForPlate(4, blockBarcodeNbr);

    Map<String, CherryPickSample> currentEPlateSamples = new HashMap<String, CherryPickSample>();
    Map<String, Map<String, CherryPickSample>> ePlateTorrentRunResults = new HashMap<String, Map<String, CherryPickSample>>();

    //return only those samples which are for the original palte- by mapping based on well address.
    for (CherryPickSample cherryPickSample : cherrySamplesForThisPlate) {

      Map<String, CherryPickSample> completeCherryPlate = null;

      //get wf id for the destination block
      String cherryPlateBlockBarcodeNbr = cherryPickSample.getDestBlock();

      if (ePlateTorrentRunResults.containsKey(cherryPlateBlockBarcodeNbr)) {
        completeCherryPlate = ePlateTorrentRunResults.get(cherryPlateBlockBarcodeNbr);
      } else {
        //load all data for this new cherry picked plate
        completeCherryPlate = getTorrentResultsAsCherryMap(cherryPlateBlockBarcodeNbr);
        ePlateTorrentRunResults.put(cherryPlateBlockBarcodeNbr, completeCherryPlate);
      }

      currentEPlateSamples.put(cherryPickSample.getWellAddress(), completeCherryPlate.get(cherryPickSample.getDestWell()));
    }

    return currentEPlateSamples;
  }


  public void mergeRunSamples(String userId, String blockBarcodeNbr, String overrideSamples, String mergeSamples, long wfId) throws Exception {


    List<MergedSample> mergedSampleList = new ArrayList<MergedSample>();
    MergedSample mergedSample = null;

    //create a mergedSampleList assuming the first run to be selected on each samples.
    //Then override the values with the selections made on overrideSamples and mergeSamples.

    TorrentAnalysis torrentAnalysis = createTorrentRecords();
    Map<String, Sample> sampleWellMap = findRunDataForSamples(wfId);

    for( String well: sampleWellMap.keySet()) {
      Sample s = sampleWellMap.get(well);
      mergedSample = new MergedSample();
      mergedSample.setSampleId(s.getSampleId());
      mergedSample.setBlockBarcodeNbr(blockBarcodeNbr);
      mergedSample.setUserId(userId);
      mergedSample.setMergeTorrentAnalysisId(torrentAnalysis.getTorrentAnalysisId());
      mergedSample.setMergeTorrentRunId(torrentAnalysis.getTorrentRunId());
      mergedSample.setTorrentAnalysisId1(s.getTorrentAnalysisId());
      mergedSample.setBarcodeAdapter1(s.getBarcodeAdapter());
      mergedSampleList.add(mergedSample);
    }

    //Will need to combine override/merged samples and make sure all samples on the E plate have been selected...
    //Validate to make sure the same sampleId has not occured more than once, incase of override...and not more than twice in case of merge
    if(null != overrideSamples && !"".equals(overrideSamples)) {
      String[] sampleTorrentAnalyisArrayOverride = overrideSamples.split(",");
      Set sampleIdSet = new HashSet();
      for (String sampleTAOverride :
              sampleTorrentAnalyisArrayOverride) {

        String[] sampleTorrentAnalyisOverride = sampleTAOverride.split("-");
        int sampleId = Integer.valueOf(sampleTorrentAnalyisOverride[0]);
        long torrentAnlaysisId = Long.valueOf(sampleTorrentAnalyisOverride[1]);
        int barcodeAdapter = Integer.valueOf(sampleTorrentAnalyisOverride[2]);
      //  sampleIdSet.add(sampleId);

        mergedSample = mergedSampleList.stream().filter(s -> s.getSampleId() == sampleId).findFirst().orElse(null);
        if(null == mergedSample) {
          mergedSample = new MergedSample();
          mergedSampleList.add(mergedSample);
        }
        mergedSample.setSampleId(sampleId);
        mergedSample.setBlockBarcodeNbr(blockBarcodeNbr);
        if (mergedSample.getSampleId() == 0) {
          mergedSample.setControl(true);
        }
        mergedSample.setTorrentAnalysisId1(torrentAnlaysisId);
        mergedSample.setBarcodeAdapter1(barcodeAdapter);
        mergedSample.setTorrentAnalysisId2(null);
        mergedSample.setBarcodeAdapter2(null);
        mergedSample.setUserId(userId);
        mergedSample.setMergeTorrentAnalysisId(torrentAnalysis.getTorrentAnalysisId());
        mergedSample.setMergeTorrentRunId(torrentAnalysis.getTorrentRunId());
      }
    }


    if(null != mergeSamples && !"".equals(mergeSamples)) {
      String[] sampleTorrentAnalysisArrayMerged = mergeSamples.split(",");
      // Set sampleIdSet = new HashSet();
      for (String sampleTAMerged :
              sampleTorrentAnalysisArrayMerged) {

        String[] sampleTorrentAnalyisMerged = sampleTAMerged.split("-");
        int sampleId = Integer.valueOf(sampleTorrentAnalyisMerged[0]);
        long torrentAnalysisId = Long.valueOf(sampleTorrentAnalyisMerged[1]);
        int barcodeAdapter = Integer.valueOf(sampleTorrentAnalyisMerged[2]);
        // sampleIdSet.add(sampleId);
        Map<Integer, MergedSample> sampleMap = mergedSampleList.stream().collect(Collectors.toMap(MergedSample::getSampleId, Function.identity()));
        mergedSample = sampleMap.get(sampleId);
        if (mergedSample == null) {
          mergedSample = new MergedSample();
          mergedSampleList.add(mergedSample);
          mergedSample.setUserId(userId);
          mergedSample.setMergeTorrentAnalysisId(torrentAnalysis.getTorrentAnalysisId());
          mergedSample.setMergeTorrentRunId(torrentAnalysis.getTorrentRunId());

          mergedSample.setBlockBarcodeNbr(blockBarcodeNbr);
        }
        mergedSample.setSampleId(sampleId);
        if (mergedSample.getSampleId() == 0) {
          mergedSample.setControl(true);
        }
        if (null == mergedSample.getTorrentAnalysisId1()) {
          mergedSample.setTorrentAnalysisId1(torrentAnalysisId);
          mergedSample.setBarcodeAdapter1(barcodeAdapter);
        } else {
          mergedSample.setTorrentAnalysisId2(torrentAnalysisId);
          mergedSample.setBarcodeAdapter2(barcodeAdapter);
        }
      }
    }

    //set the merged barcode adapter after sorting the list by sampleId
    //MBTSUPPORT - 1304
    Collections.sort(mergedSampleList, new Comparator<MergedSample>() {
      @Override
      public int compare(MergedSample o1, MergedSample o2) {
        if (o1.isControl()) {
          return -1;
        } else if (o2.isControl()) {
          return 1;
        } else {
          if (o1.getSampleId()==0) {
            return 1;
          } else if (o2.getSampleId()==0) {
            return -1;
          } else {
            return new Integer(o1.getSampleId()).compareTo(new Integer(o2.getSampleId()));
          }
        }
      }
    });

    int mergeBarcodeAdapter = 1;
    for (MergedSample mergedSample1 :mergedSampleList ) {
      mergedSample1.setMergeBarcodeAdapter(mergeBarcodeAdapter++);
    }

    updatePendingMergedSamples(blockBarcodeNbr, mergedSampleList);
    //update the status of last run data to "N"..
    List<Wf> wfList = wfDao.findAll(blockBarcodeNbr);
    wfList = wfList.stream().filter(wf -> wf.getWfEntityTypeId() == 8L).collect(Collectors.toList());  //max(Comparator.comparing(Wf::getCreateTs)).orElse(null);
    for (Wf w: wfList) {
      //the analyzedDquadWfID and PooledTubeWfId related grid_data should be set to "N"
      List<Long> listOfWfIds = new ArrayList<>();
      List<Long> fromWfIDs = wfAssocDao.getFromWfIds(w.getWfId());
      listOfWfIds.add(w.getWfId());
      listOfWfIds.addAll(fromWfIDs);
      for (Long fromWfID : fromWfIDs) {
        listOfWfIds.addAll(wfAssocDao.getFromWfIds(fromWfID));
      }

      wfGridDataDao.updateSampleStatusOnMerge(w.getWfId(), listOfWfIds, "N");
    }
    startStepFunctionsExecution(torrentAnalysis);
  }

  public void mergeCherryPickedSamples(String userId, Long currentWfId, String overrideSamples, String mergeSamples) throws Exception {

    int mergeBarcodeAdapter = 1;
    List<MergedSample> mergedSampleList = new ArrayList<MergedSample>();

    //get the block barcode
    String blockBarcodeNbr = getCherryPickBlockBarcodeNbr(currentWfId);
    TorrentAnalysis torrentAnalysis = createTorrentRecords();

    Map<String, CherryPickSample> originalSamplesResultsMap = getTorrentResultsAsCherryMap(blockBarcodeNbr);
    Map<String, CherryPickSample> cpSamplesResultsMap = getTorrentResultsAsCherryMap(blockBarcodeNbr);

    for (String wellAddress : originalSamplesResultsMap.keySet()) {
      Integer destPosition = null;
      try {
        CherryPickSample originalSample = originalSamplesResultsMap.get(wellAddress);

        //insert into gbs_merged_sample table
        MergedSample mergedSample = new MergedSample();
        mergedSample.setSampleId(originalSample.getSampleId());
        mergedSample.setBlockBarcodeNbr(originalSample.getBlockBarcodeNbr());
        if(originalSample.getSampleId() == 0) {
          mergedSample.setControl(true);
        }

        mergedSample.setUserId(userId);
        mergedSample.setMergeTorrentAnalysisId(torrentAnalysis.getTorrentAnalysisId());
        mergedSample.setMergeTorrentRunId(torrentAnalysis.getTorrentRunId());

        if (overrideSamples.indexOf(wellAddress) > -1) {
          // MarkerAnalysis destBarcodeNbr = markerAnalysisDao.findByBlockBarcodeNbr(destLimsId, cherryPickSample.getDestBlock(), destPosition);
          //find for that sample in the cpSamplesResultsMap
          if(cpSamplesResultsMap.containsKey(wellAddress)) {
            CherryPickSample cpSample = cpSamplesResultsMap.get(wellAddress);

            mergedSample.setTorrentAnalysisId1(cpSample.getTorrentAnalysisId());
            mergedSample.setBarcodeAdapter1(cpSample.getBarcodeAdapter());
          } else {
            mergedSample.setTorrentAnalysisId1(originalSample.getTorrentAnalysisId());
            mergedSample.setBarcodeAdapter1(originalSample.getBarcodeAdapter());
          }
          mergedSample.setTorrentAnalysisId2(null);
          mergedSample.setBarcodeAdapter2(null);

        } else if (mergeSamples.indexOf(wellAddress) > -1) {
          mergedSample.setBarcodeAdapter1(originalSample.getBarcodeAdapter());

          if(cpSamplesResultsMap.containsKey(wellAddress)) {
            CherryPickSample cpSample = cpSamplesResultsMap.get(wellAddress);
            mergedSample.setTorrentAnalysisId1(cpSample.getTorrentAnalysisId());
            mergedSample.setBarcodeAdapter1(cpSample.getBarcodeAdapter());
          } else {
            mergedSample.setTorrentAnalysisId2(null);
            mergedSample.setBarcodeAdapter2(null);
          }
        } else {

          mergedSample.setTorrentAnalysisId1(originalSample.getTorrentAnalysisId());
          mergedSample.setBarcodeAdapter1(originalSample.getBarcodeAdapter());
          mergedSample.setTorrentAnalysisId2(null);
          mergedSample.setBarcodeAdapter2(null);
        }
        //set the merged barcode adapter after sorting the list by sampleId
        //mergedSample.setMergeBarcodeAdapter(mergeBarcodeAdapter++);
        mergedSample.setCreateTs(new Timestamp(new Date().getTime()));
        if (mergedSample.getTorrentAnalysisId1() != null && mergedSample.getBarcodeAdapter1() != null) {
          mergedSampleList.add(mergedSample);
        }
      }catch (Exception e) {
        e.printStackTrace();
        throw e;
      }
    }

    //set the merged barcode adapter after sorting the list by sampleId
    //MBTSUPPORT - 1304
    Collections.sort(mergedSampleList, new Comparator<MergedSample>() {
      @Override
      public int compare(MergedSample o1, MergedSample o2) {
        if (o1.isControl()) {
          return -1;
        } else if (o2.isControl()) {
          return 1;
        } else {
          if (o1.getSampleId()==0) {
            return 1;
          } else if (o2.getSampleId()==0) {
            return -1;
          } else {
            return new Integer(o1.getSampleId()).compareTo(new Integer(o2.getSampleId()));
          }
        }
      }
    });

    for (MergedSample mergedSample :mergedSampleList ) {
      mergedSample.setMergeBarcodeAdapter(mergeBarcodeAdapter++);
    }

    updatePendingMergedSamples(blockBarcodeNbr, mergedSampleList);
    startStepFunctionsExecution(torrentAnalysis);

  }

  public boolean isEPlateCherrySelected(Long wfId) {
    Wf wf = wfDao.find(wfId);
    String wfEntityLabel = wf.getWfEntityLabel();
    if(wf.getWfEntityTypeId() == 9){
      List<WfAssoc> adjacencies = wfAssocDao.getAdjacencies(wfId, 1L);
      for(WfAssoc wfAssoc : adjacencies){
        wfEntityLabel = wfAssoc.getToWfLabel();
        break;
      }
    }
    return cherryPickDao.isEPlateCherrySelected(wfEntityLabel);
  }

  public boolean isWfOnHold(Long wfId) {
    Wf wf = wfDao.find(wfId);
    return (wf.getWfStatus().equalsIgnoreCase("H") ? true : false);
  }

  public WfData getHoldNcrValue(Long wfId) {
    return wfDataDao.getValue(543L, wfId);
  }


  public boolean isEPlateCherryPicked(Long wfId) {
    Wf wf = wfDao.find(wfId);
    return cherryPickDao.isEPlateCherryPicked(wf.getWfEntityLabel());
  }

  private static final String getCurrentYear() {
    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.YEAR, 0);
    return (cal.get(Calendar.YEAR) % 100) + "";
  }

  private static final String getCurrentMonth() {
    Calendar cal = Calendar.getInstance();
    return new SimpleDateFormat("MMM").format(cal.getTime());
  }

  private static final int getCurrentDay() {
    Calendar cal = Calendar.getInstance();
    return cal.get(Calendar.DATE);
  }

  @WfDelegateMethod(wfStepConfigId = 1)
  public JsonResponse post1(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = null;
    try {
      for (Map<String, String> postData : jsonPost.getRows()) {
        //extract wfId to associate data
        Long wfId = Long.parseLong(postData.get("wfId"));
        Wf wf = wfDao.find(wfId);
        if (isEPlateCherrySelected(wfId)) {
          // since plate is a cherry picked plate, it has been NCRd here and hence should not move as a regular e palte.
          // just inactivate this wf id and update status in cherry pick table.
          //wfStepDao.completeCurrentStep(wfId,userId);
          wfDao.updateWf(wfId,userId);

          cherryPickDao.verifySamplesFromEPlate(wf.getWfEntityLabel());

        } else {
          //store wf data for force grouping(only for gl plate creation)
          //update status of each block saved to next Bee status
          //plate remain in the same queue and never move out of this queue by user action - i.e. no default next_wf_step_config_id

          wfService.savePostData(jsonPost);
          String pcrStatus = wfDataDao.getVarchar2ForWfId(wfId, 158L);
          if(null == pcrStatus || pcrStatus.isEmpty()){
            //wfDataDao.save(wfId, 158L, "1 Inventory Loaded");

          }else if (pcrStatus.equals("PCR_EXT_STATUS_RE_EXTRACT_CONFIRMED")) {
            wfDataDao.save(wfId, 158L, "1 Inventory Loaded");
          }else if(pcrStatus.equals("1 Inventory Loaded")){
            wfDataDao.save(wfId, 158L, "2 Quantification Job Grouping");
          }else if(pcrStatus.equals("2 Quantification Job Complete")){
            wfDataDao.save(wfId, 158L, "3 Normalization Grouping");
          }else if(pcrStatus.equals("3 Normalization Complete")){
            wfDataDao.save(wfId, 158L, "4 Library Plate Creation Grouping");
          }


          //TODO : to be moved to a new NCR
          /*//SMBT - 1139 : Add a new column, "Transfer Type"
          // wfDataDao.save(wfId, 143L, "E block");

          wfService.savePostData(jsonPost);
          //SVANT: Create a new wf entry with step config id as "Library Plate Creation" as a new entity type of "D quandrant".
          *//* wfService.passAllWf(jsonPost, null);*//*
          //Since above method has been updated (which instead we can follow wfService.passAllWf(jsonPost, null);) , copying that same method as _1
          long combinedWfId = wfService.completeThisStep_1(1L, userId, wfId, 10l, wf.getWfEntityLabel(), 10199l);
          wfDataDao.save(combinedWfId, 10564L, wf.getWfEntityLabel()) ;

          //wfDataDao.copyDataWithDifferentWfId(wfId,combinedWfId);*/
        }
        //SVANT: TODO : We need to create a wf_grid_data entry for all samples being associated to this D quadrant...
        //(or) do we need this, since its not a real physical entity...

      }
    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;
  }

  public Boolean isEPlateCherryMergeReady(Long wfId) {

    boolean isEPlateCherryMergeReady = false;

    Wf wf = wfDao.find(wfId);
    try {
      List<String> cherryPlates = cherryPickDao.getCherryPlateName(wf.getWfEntityLabel());
      for (String cherryPlate : cherryPlates) {
        List<ProjectResult> projectResultList = projectResultDao.findByBlockBarcodeNbr(cherryPlate);

        //If the CP plate has analyzedE plate associated to it
        if (null != projectResultList && !projectResultList.isEmpty() &&
                null != projectResultList.get(0)) {
          isEPlateCherryMergeReady = true;
        } else {
          isEPlateCherryMergeReady = false;
          break;
        }
      }

    } catch (Exception e) {
      e.printStackTrace();

    }

    return isEPlateCherryMergeReady;
  }

  @WfDelegateMethod(wfStepConfigId = 19)
  public JsonResponse post19(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {
    JsonResponse jsonResponse = null;
    try {
      for (Map<String, String> postData : jsonPost.getRows()) {
        //extract wfId to associate data
        Long wfId = Long.parseLong(postData.get("wfId"));

        saveProtonDilutionData(wfId);

        wfService.savePostData(jsonPost);
        wfService.passAllWf(jsonPost, null);
      }
    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;
  }

  private void saveProtonDilutionData(Long wfId) throws ScriptException {

    BigDecimal qpcr = null;
    if (null != wfDataDao.getValue(29L, wfId)) {
      qpcr = wfDataDao.getValue(29L, wfId).getWfDataNumber();
    }

    if (null != qpcr && !qpcr.toString().isEmpty()) {
      BigDecimal protonDilution = wfService.findByWfConfigIdAndKey(1L,
              "Proton-15 Dilution (pMoles)").getValueNumber();
      BigDecimal dnaDilution = wfService.findByWfConfigIdAndKey(1L,
              "Proton-15 DNA uL").getValueNumber();
      BigDecimal protonPool = wfService.findByWfConfigIdAndKey(1L,
              "Proton-15 Total Volume uL").getValueNumber();

      String dilutionFormula = wfService.findByWfConfigIdAndKey(1L,
              "DILUTION FORMULA").getValueVarchar2();
      String h2oFormula = wfService.findByWfConfigIdAndKey(1L,
              "H2O FORMULA").getValueVarchar2();

      String[] args = new String[2];
      args[0] = qpcr.toString();
      args[1] = protonDilution.toString();
      BigDecimal dilutionAmount = UtilService.evaluateExpression(args, dilutionFormula);

      args[0] = dnaDilution.toString();
      args[1] = dilutionAmount.toString();
      BigDecimal h20Amount = UtilService.evaluateExpression(args, h2oFormula);

      wfDataDao.save(wfId, 85L, dilutionAmount.setScale(0, BigDecimal.ROUND_HALF_UP));
      wfDataDao.save(wfId, 84L, dnaDilution);
      wfDataDao.save(wfId, 31L, h20Amount.setScale(0, BigDecimal.ROUND_HALF_UP));
      wfDataDao.save(wfId, 86L, protonPool);
    }
  }

  public void getProjectExport(Integer projectStatusId, String limsId, PrintWriter pw) {

    Set<String> limsIdList = new TreeSet<String>();

    List<ProjectResult> projectResults = getProjectResults(projectStatusId, limsId, limsIdList);
    StringBuilder str = new StringBuilder();

    str.append("LIMS Project,E Plate,NCR Name,Project Type,Submission Group,Rank,Sequencing Container,Combined Tube,BarCode Set,Clean Tube,L Plate, GL Plate,Scheduled Sample Count,Control Info," +
            "Gems Dropped Sample Count,Found Sample Count,Missing Sample Count (0 markers),Low Quality Sample Count (1-649 markers)," +
            "High Quality Sample Count (>650 markers),Upload Quality Sample Count (>500 markers),Generation,% Het,Raw Read Count,Average PO,Date Due,Include In Project \n");

    for (ProjectResult projectResult : projectResults) {

      Integer scheduledSampleCount = projectResult.getActiveSampleCount() + projectResult.getDropSampleCount() - projectResult.getControlSampleCount();
      Integer expectedSampleCount = scheduledSampleCount - projectResult.getDropSampleCount();
      String controlInfo = "";
      if (null != projectResult.getControlSampleCount() && null != projectResult.getControlMarkerCount() && null != projectResult.getTorrentAnalysisId()) {
        controlInfo = projectResult.getControlSampleCount() + " (" + projectResult.getControlMarkerCount() + " - " + projectResult.getPercentControlMarkersFound() * 100 + "%)";
      }
      Double highPctIndicator = 0D;
      if (null != projectResult.getValidSampleCount() && null != projectResult.getLowMarkerSampleCountQc()) {
        highPctIndicator = (new Double(projectResult.getValidSampleCount() - projectResult.getLowMarkerSampleCountQc()) / expectedSampleCount) * 100;
      } else if (null != projectResult.getValidSampleCount()) {
        highPctIndicator = (new Double(projectResult.getValidSampleCount()) / expectedSampleCount) * 100;
      }
      Double uploadPctIndicator = 0D;
      if (null != projectResult.getValidSampleCount() && null != projectResult.getLowMarkerSampleCountUpload()) {
        uploadPctIndicator = (new Double(projectResult.getValidSampleCount() - projectResult.getLowMarkerSampleCountUpload()) / expectedSampleCount) * 100;
      } else if (null != projectResult.getValidSampleCount()) {
        uploadPctIndicator = (new Double(projectResult.getValidSampleCount()) / expectedSampleCount) * 100;
      }
      String appliedNCRs = "";
      if (null != projectResult.getAppliedNcrName()) {
        for (String ncrName : projectResult.getAppliedNcrName()) {
          appliedNCRs = appliedNCRs + ncrName + " - ";
        }
      }
      String percentHet = "";
      if (null != projectResult.getTorrentAnalysisId() && null != projectResult.getPercentHet() && null != projectResult.getSampleCount3stddev()) {
        percentHet = projectResult.getPercentHet() * 100 + "% / " + projectResult.getSampleCount3stddev();
      } else if (null != projectResult.getPercentHet()) {
        percentHet = projectResult.getPercentHet() * 100 + "%";
      }

      String projectType = "";
      String submissionGroup = "";
      String rank = "";
      if (null != projectResult.getSnapshotData()) {
        for (WfData wfData : projectResult.getSnapshotData()) {
          if (wfData.getWfDataConfigId() == 494) {
            projectType = wfData.getWfDataVarchar2();
          }
          if (wfData.getWfDataConfigId() == 489) {
            submissionGroup = wfData.getWfDataVarchar2();
          }
          if (wfData.getWfDataConfigId() == 490) {
            rank = wfData.getWfDataVarchar2();
          }
        }
      }

      str.append(
              (null != projectResult.getLimsId() ? projectResult.getLimsId() : "") + "," +
                      (null != projectResult.getBlockBarcodeNbr() ? projectResult.getBlockBarcodeNbr() : "") + "," +
                      appliedNCRs + "," +
                      projectType + "," +
                      submissionGroup + "," +
                      rank + "," +
                      (null != projectResult.getSequencingContainer() ? projectResult.getSequencingContainer().toString() : "") + "," +
                      (null != projectResult.getCombinedTubeId() ? projectResult.getCombinedTubeId().toString() : "") + "," +
                      (null != projectResult.getBarcodeIndexPlate() ? projectResult.getBarcodeIndexPlate() : "") + "," +
                      (null != projectResult.getCleanTubeId() ? projectResult.getCleanTubeId().toString() : "") + "," +
                      (null != projectResult.getLplateId() ? projectResult.getLplateId() : "") + "," +
                      (null != projectResult.getGlPlate() ? projectResult.getGlPlate() : "") + "," +
                      scheduledSampleCount.toString() + "," +
                      controlInfo + "," +
                      (null != projectResult.getDropSampleCount() ? projectResult.getDropSampleCount() : "") + "," +
                      (null != projectResult.getValidSampleCount() ? (projectResult.getValidSampleCount() + " / " + expectedSampleCount) : "") + "," +
                      (null != projectResult.getMissingBarcodeSampleCount() ? projectResult.getMissingBarcodeSampleCount() : "") + "," +
                      (null != projectResult.getLowMarkerSampleCountQc() ? projectResult.getLowMarkerSampleCountQc() : "") + "," +
                      (null != projectResult.getValidSampleCount() && null != projectResult.getLowMarkerSampleCountQc() ? (projectResult.getValidSampleCount() - projectResult.getLowMarkerSampleCountQc()) + " / " + expectedSampleCount + " (" + highPctIndicator + "%)" : "") + "," +
                      (null != projectResult.getValidSampleCount() && null != projectResult.getLowMarkerSampleCountUpload() ? (projectResult.getValidSampleCount() - projectResult.getLowMarkerSampleCountUpload()) + " / " + expectedSampleCount + " (" + uploadPctIndicator + "%)" : "") + "," +
                      (null != projectResult.getGenerationInfo() ? projectResult.getPrimaryGenerationName() + " = " + projectResult.getPrimaryGenerationPercent() * 100 + "%" : "") + "," +
                      percentHet + "," +
                      (null != projectResult.getRawReadCount() ? projectResult.getRawReadCount() : "") + "," +
                      (null != projectResult.getPoStatus() ? projectResult.getPoStatus().substring(projectResult.getPoStatus().indexOf("PO=") + 3) : "") + "," +
                      (null != projectResult.getDataDueDate() ? projectResult.getDataDueDate() : "") + "," +
                      (null != projectResult.getIncludeInProject() && projectResult.getIncludeInProject() ? "Y" : "") + "\n"
      );
    }

    pw.write(str.toString());
  }

  @WfDelegateMethod(wfStepConfigId = 24)
  public JsonResponse post24(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = null;
    try {
      for (Map<String, String> postData : jsonPost.getRows()) {
        //extract wfId to associate data
        Long wfId = Long.parseLong(postData.get("wfId"));
        wfDataDao.updateProjectReviewSnapshotForE(wfId);
        wfService.savePostData(jsonPost);
        wfService.passAllWf(jsonPost, null);
      }
    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;
  }


  @WfDelegateMethod(wfStepConfigId = 32)
  public JsonResponse post32(
          @WfParam( WfParamValue.USER_ID ) String userId,
          @WfParam( WfParamValue.JSON_POST) JsonPost jsonPost) {


    return saveDataForConfig22And32(userId, jsonPost);
  }

  @WfDelegateMethod(wfStepConfigId = 22)
  public JsonResponse post22(
          @WfParam( WfParamValue.USER_ID ) String userId,
          @WfParam( WfParamValue.JSON_POST) JsonPost jsonPost) {
    return saveDataForConfig22And32(userId, jsonPost);
  }


  private JsonResponse saveDataForConfig22And32(
          @WfParam( WfParamValue.USER_ID ) String userId,
          @WfParam( WfParamValue.JSON_POST) JsonPost jsonPost) {
    JsonResponse jsonResponse = null;
    //everything is the same as postData, plus save the current timestamp as one of the data config parameters.
    //extract and map all data types for efficiency
    wfService.savePostData(jsonPost);
    //save the current time stamp
    for (Map<String,String> postData: jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));
      wfDataDao.save(wfId, 1223L, new Timestamp(System.currentTimeMillis()));
    }
    wfService.passAllWf(jsonPost, null);
    return jsonResponse;
  }

  public WfGraph getGraphData(String userRequestedBarcode) throws Exception {

    List<WfGraphAdjacency> wfGraphAdjacencies = new ArrayList<WfGraphAdjacency>();

    try {
      List<Long> temp = getWfIds(userRequestedBarcode);

      List<WfAssoc> baseAssocs = wfAssocDao.getWfFromIds(temp);

      for (WfAssoc baseAssoc : baseAssocs) {

        List<WfAssoc> innerAssocs = wfAssocDao.getAdjacencies(baseAssoc.getFromWfId());
        List<WfGraphNode> wfGraphNodes = new ArrayList<WfGraphNode>();

        if (baseAssoc.getEntityTypeIdentifier() == wfEntityTypeDao.WF_ENTITY_TYPE_ID_E_PLATE) {
          // Add the start of the graph (LIMs Project) - since it's not in the the assoc relationship
          WfData wfData = wfDataDao.getValue(8, baseAssoc.getFromWfId());
          if (null == wfData) {
            wfData = wfDataDao.getValue(59, baseAssoc.getFromWfId());
          }
          wfGraphAdjacencies.add(getGraphAdjacency(wfData.getWfDataVarchar2(), baseAssoc.getFromWfLabel(),
                  userRequestedBarcode, baseAssoc.getFromWfId(), wfEntityTypeDao.WF_ENTITY_TYPE_ID_PROJECT, wfService.GRAPH_ASSOC_LEFT));
        }

        for (WfAssoc innerAssoc : innerAssocs) {
          wfGraphNodes.add(new WfGraphNode(innerAssoc.getFromWfLabel(), innerAssoc.getToWfLabel(), new WfGraphNodeData("#FFFFFF")));

          if (innerAssoc.getEntityTypeIdentifier() == wfEntityTypeDao.WF_ENTITY_TYPE_ID_CLEAN_TUBE) {
            // add the seq dilution block - since it's only in the "to" assoc relationship
            wfGraphAdjacencies.add(getGraphAdjacency(innerAssoc.getToWfLabel(), wfService.getStringValue(39, innerAssoc.getToWfId()), userRequestedBarcode,
                    innerAssoc.getToWfId(), wfEntityTypeDao.WF_ENTITY_TYPE_ID_SEQ_BLOCK, wfService.GRAPH_ASSOC_LEFT));

            // add the chip - since it's not in the assoc relationship
            wfGraphAdjacencies.add(getGraphAdjacency(innerAssoc.getToWfLabel(), wfService.getStringValue(39, innerAssoc.getToWfId()), userRequestedBarcode,
                    innerAssoc.getToWfId(), wfEntityTypeDao.WF_ENTITY_TYPE_ID_CHIP, wfService.GRAPH_ASSOC_RIGHT));
          }

        }
        wfGraphAdjacencies.add(new WfGraphAdjacency(baseAssoc.getFromWfLabel(), baseAssoc.getFromWfLabel(), wfGraphNodes,
                getDataAttributes(baseAssoc.getFromWfLabel(), userRequestedBarcode, baseAssoc.getFromWfId(), baseAssoc.getEntityTypeIdentifier(), baseAssoc.getToWfLabel())));
      }
    }catch(Exception e){
      e.printStackTrace();
    }

    WfGraph wfGraph = new WfGraph("Container Relationships", wfGraphAdjacencies, new ArrayList<WfGraphLegendEntry>(), true, "Enter barcode:");
    wfGraph.setWfGraphAdjacencies(wfGraphAdjacencies);

    if (wfGraph.getWfGraphAdjacencies().size() == 0) {
      // No data - show enpty node
      wfGraphAdjacencies.add(getGraphAdjacency("No Data:" + userRequestedBarcode,
              "No Data:" + userRequestedBarcode, userRequestedBarcode, 0, wfEntityTypeDao.WF_ENTITY_TYPE_ID_PROJECT, wfService.GRAPH_ASSOC_RIGHT));
      wfGraph.setWfGraphAdjacencies(wfGraphAdjacencies);
    }

    return wfGraph;

  }

  public WfGraphAdjacencyData getDataAttributes(String relatedBarcode, String requestedBarcode, long relatedWfId, long wfEntityTypeId, String currentBarcode) throws
          Exception {

    WfGraphAdjacencyData data = new WfGraphAdjacencyData();
    WfEntityTypeDao wfEntityTypeDao = new WfEntityTypeDao();

    data.set$dim(6);

    List<WfGraphToolTip> wfGraphToolTips = new ArrayList<WfGraphToolTip>();

    data.setGraphToolTipsList(getToolTips(relatedBarcode, relatedWfId, wfEntityTypeId));

    if (relatedBarcode.equals(requestedBarcode) || (null !=currentBarcode && currentBarcode.equals(requestedBarcode))) { // Requested from UI
      data.set$color("#00FF00");
      data.set$type("star");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_PROJECT) {
      data.set$color("#FFFFFF");
      data.set$type("square");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_E_PLATE) {
      data.set$color("#557EAA");
      data.set$type("square");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_L_PLATE) {
      data.set$color("#909291");
      data.set$type("square");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_GL_PLATE) {
      data.set$color("#C74243");
      data.set$type("square");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_DIL_BLOCK) {
      data.set$color("#83548B");
      data.set$type("square");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_SEQ_BLOCK) {
      data.set$color("#70A35E");
      data.set$type("square");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_CLEAN_TUBE) {
      data.set$color("#EBB056");
      data.set$type("circle");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_CHIP) {
      data.set$color("#99CCFF");
      data.set$type("square");
    } else if (wfEntityTypeId == wfEntityTypeDao.WF_ENTITY_TYPE_ID_F_BLOCK) {
      data.set$color("#654321");
      data.set$type("square");
    }

    return data;
  }

  public List<WfGraphToolTip> getToolTips(String barcode, long wfId, long entityType) throws Exception {

    List<WfGraphToolTip> wfGraphToolTipslist = new ArrayList<WfGraphToolTip>();
//      WfEntityTypeDao wfEntityTypeDao = new WfEntityTypeDao();

    if (entityType == wfEntityTypeDao.WF_ENTITY_TYPE_ID_E_PLATE) {
      double percentHet = wfDataDao.getPercentHet(barcode);
      if (percentHet > 0) {
        wfGraphToolTipslist.add(new WfGraphToolTip("% het:", String.format("%.4f", percentHet), 4));
      } else {
        wfGraphToolTipslist.add(new WfGraphToolTip("% het:", "N/A", 0));
      }

      String pico = wfService.getNumberValue(16, wfId);
      if(null != pico && !pico.equals("N//A")){
        wfGraphToolTipslist.add((new WfGraphToolTip("pico:", String.format("%.4f", pico), 4)));
      }else{
        wfGraphToolTipslist.add((new WfGraphToolTip("pico:", pico, 4)));
      }
      wfGraphToolTipslist.add((new WfGraphToolTip("samples:", wfService.getNumberValue(3, wfId), 0)));
    } else if (entityType == wfEntityTypeDao.WF_ENTITY_TYPE_ID_L_PLATE) {
      wfGraphToolTipslist.add((new WfGraphToolTip("clean tube:", String.valueOf(wfService.getStringValue(26, wfId)), 0)));
    } else if (entityType == wfEntityTypeDao.WF_ENTITY_TYPE_ID_CLEAN_TUBE) {
      wfGraphToolTipslist.add((new WfGraphToolTip("qpcr:", String.valueOf(wfService.getNumberValue(29, wfId)), 4)));
    }

    return wfGraphToolTipslist;
  }

  public WfGraphAdjacency getGraphAdjacency(String fromLabel, String toLabel, String userRequestedBarcode, long wfId, int entityType, int assocDirection) throws Exception {

    List<WfGraphNode> wfGraphNodes = new ArrayList<WfGraphNode>();
    wfGraphNodes.add(new WfGraphNode(fromLabel, toLabel, new WfGraphNodeData("#FFFFFF")));

    WfGraphAdjacency wfga = new WfGraphAdjacency();

    if (assocDirection == wfService.GRAPH_ASSOC_LEFT) {
      wfga = new WfGraphAdjacency(fromLabel, fromLabel, wfGraphNodes, getDataAttributes(toLabel, userRequestedBarcode, wfId, entityType, fromLabel));
    } else if (assocDirection == wfService.GRAPH_ASSOC_RIGHT) {
      wfga = new WfGraphAdjacency(toLabel, toLabel, wfGraphNodes, getDataAttributes(toLabel, userRequestedBarcode, wfId, entityType, fromLabel));
    }

    return wfga;
  }

  public List<Long> getWfIds(String barcode) {

    List<WfData> wfDataList = new ArrayList<WfData>();
    List<Long> wfIds = new ArrayList<Long>();
    Long wfDataConfigId = wfDataDao.getWfDataConfigId(barcode);

    if (wfDataConfigId == 8) { //project not in assoc - so query for E Plates
      wfDataList = wfDataDao.getRelatedWfIds(barcode, 8, 1);
      wfIds = wfService.transFormWfIds(wfDataList);
    } else if (wfDataConfigId == 39) { //chip not in assoc so query for Seq Dil Blocks
      wfDataList = wfDataDao.getRelatedWfIds(barcode, 39, 32);
      wfIds = wfService.transFormWfIds(wfDataList);
    } else { //everything else in assoc

      wfIds.addAll(wfDao.getWfId(WF_CONFIG_ID,barcode));
    }

    return wfIds;

  }

  public List<WfData> getRelatedWfs(String entityBarcode, long thisLevelWfDataConfigId, long searchLevelWfDataConfigId) {

    return wfDataDao.getRelatedWfIds(entityBarcode, thisLevelWfDataConfigId, searchLevelWfDataConfigId);
  }

  public List<String> findLimsIdByProjectStatusId(String[] projectStatus,String Year) {
    return projectResultDao.findLimsIdByProjectStatusId(projectStatus, Year);
  }


  public List<Map<String,Object>> findGostIdbyMbIds(List<String> mbIdsList) {
    return wfDataDao.findGostIdbyMbIds(mbIdsList);
  }



  public List<String> findYears(String[] projectStatus) {
    return projectResultDao.findYears(projectStatus);
  }

  public List<String> getBlockBarcodeList(String projectStatus, String limsId) {
    return projectResultDao.findBlockBarcodeNbrByLimsId(limsId, projectStatus);
  }

  public void saveProjectSummaryNote(long wfId, Integer noteOption, String userId, String noteComment) {

    String noteSummary = "";
    if(null != userId){
      noteSummary += userId;
    }
    if(null != noteOption && noteOption != 0){
      WfConfigProperty wfConfigProperty = wfConfigPropertyDao.find(Long.valueOf(noteOption));
      noteSummary += "-" +wfConfigProperty.getKey();
    }
    wfDataDao.save(wfId, 541L , noteSummary);

    wfDataDao.save(wfId, 542L , noteComment);
  }

  @WfDelegateMethod(wfStepConfigId = 27)
  public JsonResponse post27(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse =  new JsonResponse();

    Map<String, Set<Long>> combinedTubeIdMap = new HashMap<String, Set<Long>>();
    String combinedTubeId = null;
    for (Map<String, String> postData : jsonPost.getRows()) {
      //extract wfId to associate data
      Long wfId = Long.parseLong(postData.get("wfId"));
      //loop through entries for wfdcId fields
      for (String key : postData.keySet()) {
        if (key.equals("wfdc39")) {
          combinedTubeId = postData.get(key);
          Set<Long> wfToIdSet = combinedTubeIdMap.get(combinedTubeId);
          if (wfToIdSet == null) {
            wfToIdSet = new LinkedHashSet<Long>();
          }

          wfToIdSet.add(wfId);
          combinedTubeIdMap.put(combinedTubeId, wfToIdSet);
          break;
        }
      }
    }

    List<WfData> wfDataList = wfDataDao.getWfDataByDataConfigIdAndData(39L, combinedTubeId);
    if (wfDataList.size() > 0) {
      jsonResponse.addError("The Pooled Tube ID has already been used!");
    }

   /* if (wfDataList.size() == 10) {
      jsonResponse.addError("The Combined Tube ID has already been used!");
    } else if (combinedTubeIdMap.get(combinedTubeId).size() > (10 - wfDataList.size())) {
      jsonResponse.addError("The Combined Tube ID has already been used!");
    }*/

    //Restricted to save only 1 pooled tube at a time.
    //check for multiple combined tube scans
    if (combinedTubeIdMap.size() > 1) {
      jsonResponse.addError("The Pooled Tube ID must match across for all Clean Tubes to combine!");
    } else  if (combinedTubeIdMap.size() > 0) {
      //pull the combined tube id and check all barcode indexes about to be combined
      Set<Integer> barcodeIndexPlateSet = new HashSet<Integer>();
      Set<String> cropSet = new HashSet<String>();
      Iterator combinedTubeIterator = combinedTubeIdMap.keySet().iterator();

      while(combinedTubeIterator.hasNext()) {
        combinedTubeId = (String)combinedTubeIterator.next();
        for (Long wfId : combinedTubeIdMap.get(combinedTubeId)) {
          BigDecimal wfDataNumber = wfDataDao.getValue(23L, wfId).getWfDataNumber();
          if (wfDataNumber != null) {
            barcodeIndexPlateSet.add(wfDataNumber.intValue());
          }
          //here, also load the set for Crops: this should always be of size 1...since tubes from different crops are not allowed on single combined tube
          String oligo = wfDataDao.getValue(7L, wfId).getWfDataVarchar2();
          if (wfDataNumber != null) {
            cropSet.add(oligo);
          }
        }
        if (cropSet.size() != 1) {
          jsonResponse.addError("More than one crop type is being pooled together!");
        }
        if (barcodeIndexPlateSet.size() != combinedTubeIdMap.get(combinedTubeId).size()) {
          jsonResponse.addError("Duplicate barcode index plates were found across the Clean Tubes to combine!");
        }
      }
    }

    //if there are any validation errors, return the response
    if (jsonResponse.getErrorCnt() != 0) {
      return jsonResponse;
    }

    //now that we have the map of clean tubes to map to the combined tube id
    //converge them into a new workflow
    for (String combinedTube : combinedTubeIdMap.keySet()) {
      Map<Long, String> fromWfIdMap = new TreeMap<Long, String>();
      for (Long fromWfId : combinedTubeIdMap.get(combinedTube)) {
        fromWfIdMap.put(fromWfId, wfDataDao.getValue(26, fromWfId).getWfDataVarchar2());
      }

        //here, we want to save the Combined Tube (final chipId as the combined tube without associations)
        // Save the data submitted by the form.
        wfService.savePostData(jsonPost);

        for (Map<String, String> postData : jsonPost.getRows()) {

          //extract wfId to associate data
          Long wfId = Long.parseLong(postData.get("wfId"));
          Wf wf = wfDao.find(wfId);

          try {
            saveProtonDilutionDataForIonChef(wfId);
            wfService.passSingleWf(wfId, userId, null);
          }
          catch(Exception e) {
            jsonResponse.addError("There was an error while saving clean tube "+wf.getWfEntityLabel()+ ". Please contact IT.");
          }
        }


    }
    return jsonResponse;
  }

  private void saveProtonDilutionDataForIonChef(Long wfId) throws Exception {

    BigDecimal qpcr = wfDataDao.getValue(29L , wfId).getWfDataNumber();

    if(null != qpcr && !qpcr.toString().isEmpty()) {
      BigDecimal ion50Dilution = (BigDecimal) wfService.findByWfConfigIdAndKey(1L, "Ion Chef-50 Dilution (pMoles)").getValueNumber();
      BigDecimal ion100Dilution = (BigDecimal) wfService.findByWfConfigIdAndKey( 1L,
              "Ion Chef-100 Dilution (pMoles)").getValueNumber();

      BigDecimal ion50DNADilution = (BigDecimal) wfService.findByWfConfigIdAndKey( 1L,
              "Ion Chef-50 DNA uL").getValueNumber();
      BigDecimal ion100DNADilution = (BigDecimal) wfService.findByWfConfigIdAndKey( 1L,
              "Ion Chef-50 DNA uL").getValueNumber();

      BigDecimal ion50Pool = (BigDecimal) wfService.findByWfConfigIdAndKey( 1L,
              "Ion Chef-50 Total Volume uL").getValueNumber();
      BigDecimal ion100Pool = (BigDecimal) wfService.findByWfConfigIdAndKey( 1L,
              "Ion Chef-100 Total Volume uL").getValueNumber();

      String dilutionFormula = wfService.findByWfConfigIdAndKey( 1L,
              "DILUTION FORMULA").getValueVarchar2();
      String h2oFormula = wfService.findByWfConfigIdAndKey( 1L,
              "H2O FORMULA").getValueVarchar2();;
      String nucleaseFreeH20Formula = wfService.findByWfConfigIdAndKey( 1L,
              "NUCLEASE FREE H2O FORMULA").getValueVarchar2();;
      String protonPoolFormula = wfService.findByWfConfigIdAndKey( 1L,
              "PROTON POOL FORMULA").getValueVarchar2();;

      boolean isIon50Run = isCleanTubeIon50Eligible(wfId);

      String[] args = new String[2];
      args[0] = qpcr.toString();

      if (isIon50Run) {

        args[1] = ion50Dilution.toString();
        BigDecimal dilutionAmount = evaluateExpression(args, dilutionFormula);

        args[0] = ion50DNADilution.toString();
        args[1] = dilutionAmount.toString();
        BigDecimal h20Amount = evaluateExpression(args, h2oFormula);

        args[0] = h20Amount.toString();
        BigDecimal nucleaseFreeDNAAmount = evaluateExpression(args, nucleaseFreeH20Formula);

        args[0] = qpcr.toString();
        BigDecimal protonPoolAmount = evaluateExpression(args, protonPoolFormula);

        wfDataDao.save(wfId, 91L, dilutionAmount.setScale(0,BigDecimal.ROUND_HALF_UP));
        wfDataDao.save(wfId, 88L, ion50DNADilution.setScale(0,BigDecimal.ROUND_HALF_UP));
        wfDataDao.save(wfId, 31L, h20Amount.setScale(0,BigDecimal.ROUND_HALF_UP));
        wfDataDao.save(wfId, 89L, nucleaseFreeDNAAmount.setScale(0,BigDecimal.ROUND_HALF_UP));
        wfDataDao.save(wfId, 90L, protonPoolAmount.setScale(0,BigDecimal.ROUND_HALF_UP));
      } else {

        args[1] = ion100Dilution.toString();
        BigDecimal dilutionAmount = evaluateExpression(args, dilutionFormula);

        args[0] = ion100DNADilution.toString();
        args[1] = dilutionAmount.toString();
        BigDecimal h20Amount = evaluateExpression(args, h2oFormula);

        args[0] = h20Amount.toString();
        BigDecimal nucleaseFreeDNAAmount = evaluateExpression(args, nucleaseFreeH20Formula);

        args[0] = qpcr.toString();
        BigDecimal protonPoolAmount = evaluateExpression(args, protonPoolFormula);

        wfDataDao.save(wfId, 87L, dilutionAmount.setScale(0,BigDecimal.ROUND_HALF_UP));
        wfDataDao.save(wfId, 88L, ion100DNADilution.setScale(0,BigDecimal.ROUND_HALF_UP));
        wfDataDao.save(wfId, 31L, h20Amount.setScale(0,BigDecimal.ROUND_HALF_UP));
        wfDataDao.save(wfId, 89L, nucleaseFreeDNAAmount.setScale(0,BigDecimal.ROUND_HALF_UP));
        wfDataDao.save(wfId, 90L, protonPoolAmount.setScale(0,BigDecimal.ROUND_HALF_UP));
      }
    }
  }

  private boolean isCleanTubeIon50Eligible(Long wfId) {

    final String SQL = "select count(*) from ATLAS.WF_ASSOC wa INNER JOIN ATLAS.WF_ASSOC wa1 ON wa1.FROM_WF_ID = wa.FROM_WF_ID " +
            "INNER JOIN ATLAS.WF_DATA wd ON wd.WF_ID = wa1.TO_WF_ID where wa.TO_WF_ID = ? and wd.WF_DATA_CONFIG_ID = 29 and wd.WF_DATA_NUMBER < 100";

    boolean isEligible = false;

    Long count = jdbcTemplate.queryForObject(SQL, Long.class, wfId);

    if (null != count && count > 0) {
      isEligible = true;
    }

    return isEligible;
  }

  public static BigDecimal evaluateExpression(String[] args, String expression) throws ScriptException {

    for(int i = 0 ; i < args.length ; i++){
      if(expression.indexOf("arg"+i) > -1) {
        expression = expression.replace("[arg" + i + "]", args[i]);
      }
    }
    ScriptEngineManager factory = new ScriptEngineManager();
    ScriptEngine engine = factory.getEngineByName("JavaScript");
    Object result = engine.eval(expression);

    return new BigDecimal(result.toString());
  }

  public String forceGroupingCherrySamples(String cropType) {

    try{
      cherryPickDao.forceGroupingCherrySamples(cropType);
      return "Sucess";
    }catch(Exception e){
      return "Error";
    }
  }

  public JsonResponse getSampleData(JsonPost jsonPost) {
    JsonResponse jsonResponse = new JsonResponse();
    List<WfData> wfDataList = new ArrayList<>();
    List<WfGrid> gridList = new ArrayList<WfGrid>();
    List<WfGridAssoc> gridAssocList = new ArrayList<WfGridAssoc>();
    List<WfGridData> gridDataList = new ArrayList<WfGridData>();

    for (Map<String, String> postData : jsonPost.getRows()) {
      Long wfId = Long.parseLong(postData.get("wfId"));

      String ncrCode = postData.get("ncrCode");
      //long wfNcrConfigId = Long.parseLong(ncrCode);
      Long wfNcrReasonId = null;
      //validate Ncr when selected
      if (null != ncrCode && !ncrCode.isEmpty() && StringUtils.isNumeric(ncrCode)  && Long.valueOf(ncrCode) == 76) {

        WfData plate = wfDataDao.getValue(64l, wfId);
        List<WfGridAssoc> wfGridAssocList = wfGridAssocDao.findAll(wfId);

        if(null == wfGridAssocList || wfGridAssocList.isEmpty()){
          addSampleData(jsonResponse, wfDataList, gridList, gridAssocList, gridDataList, wfId,jsonPost.getUserId());
        }
      }
    }
    wfDataDao.batchSaveWfData(wfDataList);
    wfService.saveSampleData(gridList, gridAssocList, gridDataList);

    return jsonResponse;
  }

  /**
   * Group projects into a mix vessel run based on user selection
   *
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 9007)
  public JsonResponse post9007(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = null;
    try {

      BigDecimal groupId = BigDecimal.valueOf(System.currentTimeMillis());

      for (Map<String, String> postData : jsonPost.getRows()) {
        // flag user assignment as a group for agent to pickup
        Long projectWfId = Long.parseLong(postData.get("wfId"));
        wfDataDao.save(projectWfId, 2071L, groupId);
        wfDataDao.save(projectWfId, 2072L, "Y");
      }
    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;
  }


  @WfDelegateMethod(wfStepConfigId = 16)
  public JsonResponse post16(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = null;
    String pcrPlateName = printPCRLCPlateIds();

    Map<Long, String> fromWfIdMap = new HashMap<Long, String>();;
    Map<Long, String> glWfIdMap = new HashMap<Long, String>();;
    Map<Long, List<Long>> dilGlWfIdMap = new HashMap<Long, List<Long>>();

    ServiceCommon serviceCommon = new ServiceCommon(
            wfService.findByWfConfigIdAndKey(1L, "URL_ACCESS_TOKEN").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "CLIENT_ID").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "CLIENT_SECRET").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "GRANT_TYPE").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "HTTPS_PROTOCOL_VALUE").getPropertyValue(),
            wfService.findByWfConfigIdAndKey(1L, "URL_AUTO_TOOL_SYNC").getPropertyValue());

    try {
      for (Map<String, String> postData : jsonPost.getRows()) {
        //extract wfId to associate data
        Long wfId = Long.parseLong(postData.get("wfId"));
        String dilBlockName = postData.get("wfEntityLabel");
        fromWfIdMap.put(wfId, dilBlockName);

        String glPlateBase = dilBlockName.substring(0,dilBlockName.indexOf("-"));
        List<Long> glWfIds = jdbcTemplate.queryForList(" SELECT WF_ID FROM ATLAS.WF WHERE WF_ENTITY_TYPE_ID = 3 AND WF_ENTITY_LABEL LIKE ? " ,  Long.class, glPlateBase+"%");

        for (Long glWfId: glWfIds) {
          glWfIdMap.put(glWfId, null);
        }

        //create another map with dilWfId and the list of individual Gl wfIds.
        dilGlWfIdMap.put(wfId, glWfIds);
      }

      //This will create wf_assoc entries for GL-->PCR plate and creates the new wf for PCR plate.
      wfDao.combineTo(1L, pcrPlateName, glWfIdMap, 90L, userId, 12L);

      //iterate the fromWfIdMap and set the status to 'I'
      Iterator it = fromWfIdMap.entrySet().iterator();
      while (it.hasNext()) {
        Map.Entry pair = (Map.Entry) it.next();
        long wfId = (Long)pair.getKey();
        wfDao.updateWfStatus(wfId,"I",userId);
      }

      Iterator glIterator = glWfIdMap.entrySet().iterator();
      while (glIterator.hasNext()) {
        Map.Entry pair = (Map.Entry) glIterator.next();
        long wfId = (Long) pair.getKey();

        wfDataDao.save(wfId, 108L, pcrPlateName);
        wfDataDao.save(wfId, 115L, "2 Assay Setup AT Pending");//default status
      }

    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }

    //TODO: Here, we need to create an AutoToolJob and display it on step config 16, along with the status
    // 3 types of transfer tasks...
    // Standard/Control DNA-24 standards wells/position transfers
    // Sample DNA-352 mix transfers
    // Master Mix-Changes upon the samples filled-max 376 transfers

    //job prefix will be LCPCR_ (robot_job_name) and (robot_job_type) will be LCPCR
    try {
      int controlDnaVolume = wfConfigPropertyDao.findByWfConfigIdAndKey(1L, "QPCR_LC_CONTROL_VOL").getValueNumber().intValue();
      int masterMixVol =  wfConfigPropertyDao.findByWfConfigIdAndKey(1L, "QPCR_LC_MASTER_MIX_VOL").getValueNumber().intValue();
      String sourceWellName ;
      String destWellName ;

      //Autotool job
      Long robotJobId = xRobotJobDao.createAutotoolJob(pcrPlateName + "_", "LCPCR", serviceCommon);
      createDNATransferTasks (fromWfIdMap, dilGlWfIdMap, robotJobId, pcrPlateName, serviceCommon);

      //This is for control transfer
      List<WfPlateMap> wfPlateMapList = wfPlateMapDao.getCtrlPlateSourceDest("CTLPlate_PCR_LC_384");
      //************Autotool Sync****************************************
      XRobotTransferTskWrapper xRobotTransferTskWrapper = new XRobotTransferTskWrapper();
      List<XRobotTransferTsk> xRobotTransferTsks = new ArrayList<XRobotTransferTsk>();
      for (WfPlateMap list : wfPlateMapList) {

        sourceWellName = list.getSourceWellName();
        destWellName = list.getDestWellName();
        // add control to specified positions in the table: iterate through wfplatemap table to get list of source and destination well names
        xRobotTransferTskDao.createAutotoolTransferTask(robotJobId, "Control DNA", "Control 96 Plate", "CTLPlate_PCR_LC_384",sourceWellName , "PCR 384 Plate", pcrPlateName,destWellName , "N",controlDnaVolume, "GBS", 1, 0);
        xRobotTransferTsks.add(xRobotTransferTskDao.restCreateAutotoolTransferTask(robotJobId, "Control DNA", "Control 96 Plate", "CTLPlate_PCR_LC_384",sourceWellName , "PCR 384 Plate", pcrPlateName,destWellName , "N",controlDnaVolume, "GBS", 1, 0));

        //add master mix to every control
        xRobotTransferTskDao.createAutotoolTransferTask(robotJobId, "MSTR_MIX", "MMTROUGH", "LC_MM_Trough","A1" , "PCR 384 Plate", pcrPlateName, destWellName , "N",masterMixVol, "GBS", 1, 0);
        xRobotTransferTsks.add(xRobotTransferTskDao.restCreateAutotoolTransferTask(robotJobId, "MSTR_MIX", "MMTROUGH", "LC_MM_Trough","A1" , "PCR 384 Plate", pcrPlateName, destWellName , "N",masterMixVol, "GBS", 1, 0));

      }

      xRobotTransferTskWrapper.setTaskList(xRobotTransferTsks);
      //This Job is carried out by AutoToolStatusSyncAgent in atlas-agent-gbs
      //AutoToolDbSyncUtil.syncAutotoolTransferTask(xRobotTransferTskWrapper, serviceCommon);

      for (Map<String, String> postData : jsonPost.getRows()) {
        //extract wfId to associate data
        Long wf_Id = Long.parseLong(postData.get("wfId"));
        //For each dilution block, need to add a wf_data with AutoTool job name - That gets displayed as part of step config id 15
        wfDataDao.save(wf_Id, 108L, pcrPlateName);
        wfDataDao.save(wf_Id, 115L, "2 Assay Setup AT Pending");
        wfDataDao.save(wf_Id, 116L, pcrPlateName+"_"+robotJobId);
      }
    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);
      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;

  }

  void createDNATransferTasks(Map<Long, String> tubeMap, Map<Long, List<Long>> dilGlWfIdMap, Long robotJobId, String pcrPlateName, ServiceCommon serviceCommon) throws Exception {

    int colPosition = 3;
    int endAlphaCount = 80;

    int sampleDnaVolume =  wfConfigPropertyDao.findByWfConfigIdAndKey(1L, "QPCR_LC_SAMPLE_VOL").getValueNumber().intValue();
    int masterMixVol =  wfConfigPropertyDao.findByWfConfigIdAndKey(1L, "QPCR_LC_MASTER_MIX_VOL").getValueNumber().intValue();
    String sourceWellName ;
    String destWellName ;

    String robotTransferTypeId = "Sample DNA";
    String sourcePlateTypeId = "96 DILUTION BLOCK";
    List<WfAssoc> activeLeftEs = null;

    boolean isLP = false;
    for (Long tubeWfId : tubeMap.keySet()) {

      if(isLP) {
        colPosition = colPosition + 2;
      }

      int sourceWell = 0;
      int startAlphaCount = 64;
      List<Long> glWfIds1 = dilGlWfIdMap.get(tubeWfId);
      activeLeftEs = new ArrayList<WfAssoc>();
      for (Long glWfId : glWfIds1) {
        activeLeftEs.addAll(wfAssocDao.getActiveLeft(glWfId));
      }

      for (WfAssoc wf: activeLeftEs) {
        //************Autotool Sync****************************************
        XRobotTransferTskWrapper xRobotTransferTskWrapper = new XRobotTransferTskWrapper();
        List<XRobotTransferTsk> xRobotTransferTsks = new ArrayList<XRobotTransferTsk>();

        sourceWell = sourceWell + 1;
        if (sourceWell > 8) {
          isLP = true;
        } else {
          isLP = false;
        }
        sourceWellName = wfPlateMapDao.get96SourceWellFor384Plate(sourceWell);
        int alpha = startAlphaCount + 1;

        for (int alphaCount = alpha; alphaCount < alpha + 2 && alphaCount <= endAlphaCount; alphaCount++) {
          int position = colPosition;

          if (alphaCount == endAlphaCount){
            startAlphaCount = 64;
            colPosition = colPosition + 2;
          } else {
            startAlphaCount = alphaCount;
          }

          for (int i = position; i < position + 2; i++) {
            destWellName = String.valueOf((char) alphaCount) + i;
            LOG.debug("sourceWellName : " + sourceWellName + "    ---   destWellName : " + destWellName);
            xRobotTransferTskDao.createAutotoolTransferTask(robotJobId, robotTransferTypeId, sourcePlateTypeId, tubeMap.get(tubeWfId), sourceWellName, "PCR 384 Plate", pcrPlateName, destWellName, "N", sampleDnaVolume, "GBS", 1, 0);
            xRobotTransferTsks.add(xRobotTransferTskDao.restCreateAutotoolTransferTask(robotJobId, robotTransferTypeId, sourcePlateTypeId, tubeMap.get(tubeWfId), sourceWellName, "PCR 384 Plate", pcrPlateName, destWellName, "N", sampleDnaVolume, "GBS", 1, 0));
            xRobotTransferTskDao.createAutotoolTransferTask(robotJobId, "MSTR_MIX", "MMTROUGH", "LC_MM_Trough", "A1", "PCR 384 Plate", pcrPlateName, destWellName, "N", masterMixVol, "GBS", 1, 0);
            xRobotTransferTsks.add(xRobotTransferTskDao.restCreateAutotoolTransferTask(robotJobId, "MSTR_MIX", "MMTROUGH", "LC_MM_Trough", "A1", "PCR 384 Plate", pcrPlateName, destWellName, "N", masterMixVol, "GBS", 1, 0));
          }
        }

        xRobotTransferTskWrapper.setTaskList(xRobotTransferTsks);
        //This Job is carried out by AutoToolStatusSyncAgent in atlas-agent-gbs
        //AutoToolDbSyncUtil.syncAutotoolTransferTask(xRobotTransferTskWrapper, serviceCommon);
      }
    }
  }

  public String printPCRLCPlateIds() {
    //gbs_pcrlcplate_id_seq
    final String ID_SQL = "select nextval('ATLAS.gbs_dilution_block_id_seq') ";
    Long id = jdbcTemplate.queryForObject(ID_SQL, Long.class);
    String idFormatted = "qPCR" + getCurrentYear() + "LC" + String.format("%04d", id);

    Long printerId = wfStepConfigDao.getWfPrinterId(16L);
    wfService.printBarcode(printerId, idFormatted);
    /*
    final String PRINT_SQL = "insert into ATLAS.wf_printer_queue (wf_prn_file,queue_enter_ts,printer_id) " +
            "(select " +
            " ?," +
            " now()," +
            " (select wf_printer_id from ATLAS.wf_step_config where wf_step_config_id=10) " +
            "from dual)";
    jdbcTemplate.update(PRINT_SQL, idFormatted);*/

    return idFormatted;
  }

  public TorrentAnalysis createTorrentRecords() {

    TorrentRun torrentRun = new TorrentRun();
    TorrentAnalysis mergeTorrentAnalysis = new TorrentAnalysis();

    long nextTorrentRunId = wfDao.getNextSeqId("torrent_run_id_seq");


    long nextTorrentAnalysisId = wfDao.getNextSeqId("torrent_analysis_id_seq");

    LOG.info("Torrent : "+nextTorrentRunId +" , "+ nextTorrentAnalysisId);
    //create the torrent run
    torrentRun.setTorrentRunId(nextTorrentRunId);
    torrentRun.setTorrentRunName("Atlas_Merge_Run_"+torrentRun.getTorrentRunId());
    torrentRun.setTorrentRunHost("na1000app-gbs");
    torrentRun.setTorrentRunStatus("Merging bam files");
    torrentRunDao.save(torrentRun);

    LOG.info("Saved Torrent Run Record");

    //create the torrent analysis run
    mergeTorrentAnalysis.setTorrentAnalysisId(nextTorrentAnalysisId);
    mergeTorrentAnalysis.setTorrentRunId(torrentRun.getTorrentRunId());
    mergeTorrentAnalysis.setCreateUser("ATLAS_MERGE");
    mergeTorrentAnalysis.setAnalysisStatus("Queued");
    torrentAnalysisDao.save(mergeTorrentAnalysis);

    LOG.info("Saved Torrent Analysis Record");

    Wf wf  = new Wf();
    wf.setCreateUser("ATLAS_MERGE");
    wf.setWfStatus("C");
    wf.setWfConfigId(1L);
    wf.setWfEntityLabel(""+torrentRun.getTorrentRunId());
    wf.setWfEntityTypeId(6L);
    wf.setWfStepConfigId(39L);
    wfDao.save(wf);
    return mergeTorrentAnalysis;
  }

  public void startStepFunctionsExecution(TorrentAnalysis torrentAnalysis) {

    WfConfigProperty host = wfService.findByWfConfigIdAndKey( 1, "URL_TORRENT_STEP_FUNCTIONS_API_HOST");
    WfConfigProperty path = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_PATH");
    WfConfigProperty accessKey = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_ACCESS_KEY");
    WfConfigProperty secretKey = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_SECRET");
    WfConfigProperty region = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_ACCESS_REGION");
    WfConfigProperty serviceName = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_SERVICE");
    WfConfigProperty stepFuncArn = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_ARN_MERGE");

    String jsonRequest = writeJsonMonoService(String.valueOf(torrentAnalysis.getTorrentRunId()), stepFuncArn.getValueVarchar2());

    postRequest(host.getValueVarchar2(), path.getValueVarchar2(), accessKey.getValueVarchar2(), secretKey.getValueVarchar2(),
            region.getValueVarchar2(), serviceName.getValueVarchar2(), jsonRequest);

  }

  public void startManualStepFunctionsExecution(TorrentAnalysis torrentAnalysis) {

    WfConfigProperty host = wfService.findByWfConfigIdAndKey( 1, "URL_TORRENT_STEP_FUNCTIONS_API_HOST");
    WfConfigProperty path = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_PATH_MANUAL");
    WfConfigProperty accessKey = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_ACCESS_KEY");
    WfConfigProperty secretKey = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_SECRET");
    WfConfigProperty region = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_ACCESS_REGION");
    WfConfigProperty serviceName = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_API_SERVICE");
    WfConfigProperty stepFuncArn = wfService.findByWfConfigIdAndKey(1, "URL_TORRENT_STEP_FUNCTIONS_ARN_MANUAL");

    String jsonRequest = writeManualJsonMonoService(String.valueOf(torrentAnalysis.getTorrentAnalysisId ()), stepFuncArn.getValueVarchar2());

    postRequest(host.getValueVarchar2(), path.getValueVarchar2(), accessKey.getValueVarchar2(), secretKey.getValueVarchar2(),
            region.getValueVarchar2(), serviceName.getValueVarchar2(), jsonRequest);

  }

  public void postRequest(String host, String path, String accessKey, String secretKey, String region, String serviceName, String jsonRequest) {

    TreeMap<String, String> awsHeaders = new TreeMap<String, String>();
    awsHeaders.put("host", host);
    awsHeaders.put("content-type", MediaType.APPLICATION_JSON);
    awsHeaders.put("content-length", String.valueOf(jsonRequest.length()));

    AWSV4Auth aWSV4Auth = new AWSV4Auth.Builder(accessKey, secretKey)
            .regionName(region)
            .serviceName(serviceName) // es - elastic search. use your service name
            .httpMethodName("POST") //GET, PUT, POST, DELETE, etc...
            .canonicalURI(path) //end point
            .queryParametes(null) //query parameters if any
            .awsHeaders(awsHeaders) //aws header parameters
            .payload(jsonRequest) // payload if any
            .debug() // turn on the debug mode
            .build();

    AuthenticationUtil.postAwsAuthRequest(aWSV4Auth, host, path, MediaType.APPLICATION_JSON, jsonRequest);
  }

  public String writeJsonMonoService(String chipBarCode, String stepFuncArn) {
    StringBuilder sb = new StringBuilder();
    sb.append("{\"name\":\"").append("GbsTorrentMergeRun_"+chipBarCode+(new Date().getTime())).append("\",");
    sb.append("\"stateMachineArn\":\"").append(stepFuncArn).append("\",");

    sb.append("\"input\":[");
    appendMethodParam(sb,"PreMergeSetup", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"SubmitMergeDSubJob", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"WaitAndReSubmitFailedMergeAnalysis", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"TorrentAnalysisAgent", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"HapChipTorrentAnalysisAgent", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"RawSampleMergeAgent", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"SummarizeMarkerAgent", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"ResummarizationAgent", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"PoAgent", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"AncestryCheckAgent", chipBarCode);
    sb.append(",");

    appendMethodParam(sb,"TorrentAnalysisReviewAgent", chipBarCode);

    sb.append("]");

    sb.append("}");

    return sb.toString();
  }

  private void appendMethodParam(StringBuilder sb, String methodName, String chipName) {

    sb.append("{\"requestAgent\": \"").append(methodName).append("\",").append("\"requestParams\": {\"chipBarcode\": \"").append(chipName).append("\"}}");

  }

  public String writeManualJsonMonoService(String torrentAnalysisId, String stepFuncArn) {
    StringBuilder sb = new StringBuilder();
    sb.append("{\"name\":\"").append("torrentAnalysisId"+ torrentAnalysisId +(new Date().getTime())).append("\",");
    sb.append("\"stateMachineArn\":\"").append(stepFuncArn).append("\",");

    sb.append("\"input\":[");
    appendManualMethodParam(sb,"ManualTorrentRunInitialState", torrentAnalysisId);
    sb.append(",");

    appendManualMethodParam(sb,"ManualPreTASetup", torrentAnalysisId);
    sb.append(",");

    appendManualMethodParam(sb,"ManualSubmitDsubJobs", torrentAnalysisId);
    sb.append(",");

    appendManualMethodParam(sb,"ManualWaitAndReSubmitFailedAnalysis", torrentAnalysisId);
    sb.append(",");

    appendManualMethodParam(sb,"ManualTorrentAnalysisAgent", torrentAnalysisId);

    sb.append("]");

    sb.append("}");

    return sb.toString();
  }

  private void appendManualMethodParam(StringBuilder sb, String methodName, String torrentAnalysisId) {


    sb.append("{\"requestAgent\": \"").append(methodName).append("\",").append("\"requestParams\": {\"torrentAnalysisId\": \"").append(torrentAnalysisId).append("\"}}");

  }

  public List<WfAssoc> getRightAssociations(String selectedPlate) {
    List<WfAssoc> wfAssocList = wfAssocDao.getActiveRightAdjacencies(selectedPlate);
    return wfAssocList;
  }

  public List<WfAssoc> getActiveLeftWithDataNumber(Long toWfId, Long wfDataConfigId) {
    List<WfAssoc> activeLeftWithDataNumber =  wfAssocDao.getActiveLeftWithDataNumber(toWfId, wfDataConfigId, 1L);
    return activeLeftWithDataNumber;
  }

  public List<List<HashMap<String,Object>>>  getGridDataAndMapToCherryObject(Long wfId, String wfGridDataConfigId) {

    List<List<HashMap<String,Object>>>  wfGridsObjectList = new ArrayList<>();
    try {
      wfGridsObjectList = wfService.callStoredProcForPivotGridData(wfId, wfGridDataConfigId);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return wfGridsObjectList;
  }

    public Long getWfIdForEPlate(String blockBarcodeNbr) {
        return projectResultDao.getWfIdForEPlate(blockBarcodeNbr);
    }

  /**
   *  If the e block in the AnalyzedDQuadrant is a Chip or Hap-Chip project this will return true, otherwise false
   */

  public boolean isChipPlate(String ePlateId) throws Exception {

    boolean isChip = false;
    String[] ePlates = ePlateId.split(",");
    for (int i = 0; i < ePlates.length; i++) {
      Long eWfId = wfDao.getWfId(ePlates[i].trim(), 1);
      if(null != eWfId){
        String projectType = wfDataDao.getVarchar2ForWfId( eWfId, 528L);
        if (projectType.equals("Chip") || projectType.equals("Hap-Chip")) {
          isChip = true;
          break;
        } else {
          isChip = false;
        }
      }
    }
    return isChip;
  }

}
