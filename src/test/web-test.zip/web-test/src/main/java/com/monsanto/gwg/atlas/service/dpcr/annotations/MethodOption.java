package com.monsanto.gwg.atlas.service.dpcr.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by PGROS1 on 1/3/2015.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface MethodOption {
    public String value();
    public String text();
    public boolean isDefault();
}