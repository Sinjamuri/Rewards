package com.monsanto.gwg.atlas.model.core;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class WfDetail implements Serializable {

	private static final long serialVersionUID = -7141152536267712055L;

  private Long wfId;
	private Long wfDataId;
	private Long wfDataAssocId;
	private Long wfDataConfigId;
	private String wfDataConfigLabel;
	private String wfDataType;
	private String wfDataVarchar2;
	private BigDecimal wfDataNumber;
	private Timestamp wfDataTimestamp;

    public Long getWfId() {
        return wfId;
    }

    public void setWfId(Long wfId) {
        this.wfId = wfId;
    }

    public Long getWfDataId() {
		return wfDataId;
	}

	public void setWfDataId(Long wfDataId) {
		this.wfDataId = wfDataId;
	}

	public Long getWfDataAssocId() {
		return wfDataAssocId;
	}

	public void setWfDataAssocId(Long wfDataAssocId) {
		this.wfDataAssocId = wfDataAssocId;
	}

	public Long getWfDataConfigId() {
		return wfDataConfigId;
	}

	public void setWfDataConfigId(Long wfDataConfigId) {
		this.wfDataConfigId = wfDataConfigId;
	}

	public String getWfDataConfigLabel() {
		return wfDataConfigLabel;
	}

	public void setWfDataConfigLabel(String wfDataConfigLabel) {
		this.wfDataConfigLabel = wfDataConfigLabel;
	}

	public String getWfDataType() {
		return wfDataType;
	}

	public void setWfDataType(String wfDataType) {
		this.wfDataType = wfDataType;
	}

	public String getWfDataVarchar2() {
		return wfDataVarchar2;
	}

	public void setWfDataVarchar2(String wfDataVarchar2) {
		this.wfDataVarchar2 = wfDataVarchar2;
	}

	public BigDecimal getWfDataNumber() {
		return wfDataNumber;
	}

	public void setWfDataNumber(BigDecimal wfDataNumber) {
		this.wfDataNumber = wfDataNumber;
	}

	public Timestamp getWfDataTimestamp() {
		return wfDataTimestamp;
	}

	public void setWfDataTimestamp(Timestamp wfDataTimestamp) {
		this.wfDataTimestamp = wfDataTimestamp;
	}
}
