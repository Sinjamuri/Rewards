package com.monsanto.gwg.atlas.dao.core;

import com.monsanto.gwg.atlas.dao.BaseWfTableDao;
import com.monsanto.gwg.atlas.model.core.Wf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class WfDao extends BaseWfTableDao<Wf> {

  public final int ENTITY_TYPE_F_BLOCK=9;
  public final int ENTITY_TYPE_E_BLOCK=1;
  public final int ENTITY_TYPE_DIL_BLOCK=3;
  public final int ENTITY_TYPE_CLEAN_TUBE=4;
  public final int ENTITY_TYPE_SEQUENCING_CONTAINER=6;
  public final int ENTITY_TYPE_ANALYZED_E=8;

  @Override
  protected String getTableName() {
    return "wf";
  }

  @Override
  protected String getAllFields() {
    return "wf_id," +
        "wf_config_id," +
        "wf_status," +
        "wf_step_config_id," +
        "wf_entity_type_id," +
        "wf_entity_label," +
        "queue_sort_order," +
        "create_user," +
        "create_ts," +
        "update_user," +
        "update_ts";
  }

  @Override
  protected RowMapper<Wf> getRowMapper() {
    return new RowMapperImpl();
  }

  @Override
  protected Logger getLogger() {
    return LoggerFactory.getLogger(this.getClass());
  }

  @Override
  protected String getDefaultOrderBy() {
    return "queue_sort_order";
  }

    @Override
    protected String getPrimaryKey() {
        return "wf_id";
    }

  /**
   * JdbcTemplate RowMapper used for all object loading.
   */
  private static final class RowMapperImpl implements RowMapper<Wf> {
    public Wf mapRow(ResultSet rs, int rowNum) throws SQLException {
      Wf wf = new Wf();

      wf.setWfId(rs.getLong("wf_id"));
      wf.setWfConfigId(rs.getLong("wf_config_id"));
      wf.setWfStatus(rs.getString("wf_status"));
      wf.setWfStepConfigId(rs.getLong("wf_step_config_id"));
      wf.setWfEntityTypeId(rs.getLong("wf_entity_type_id"));
      wf.setWfEntityLabel(rs.getString("wf_entity_label"));
      wf.setCreateUser(rs.getString("create_user"));
      wf.setCreateTs(rs.getTimestamp("create_ts"));
      wf.setUpdateUser(rs.getString("update_user"));
      wf.setUpdateTs(rs.getTimestamp("update_ts"));

      return wf;
    }
  }

  public long getNextSeqId(String seqName) {
    return getNextId(seqName);
  }

  public List<Wf> findAll(String wfEntityLabel) {
    return findAll("wf_entity_label=?", wfEntityLabel);
  }

  public List<Wf> findAllWf(Long wfStepConfigId) {
      return findAll("wf_step_config_id=? and wf_status IN ('I','H')", wfStepConfigId);

//    final String SQL = "select " + getAllFields() + " from " + getDefaultSchema() + "." + getTableName() +
//        " where wf_step_config_id=? and wf_status='I'" + (getDefaultOrderBy() == null ? "" : " order by " + getDefaultOrderBy());
//
//    if (getLogger().isTraceEnabled()) {
//      getLogger().debug(buildLogMessage(SQL, new Object[] {wfStepConfigId}));
//    }
//
//    return jdbcTemplate.query(SQL, getRowMapper(), wfStepConfigId);
  }

    public List<Wf> findLast10WfAdded(Long wfStepConfigId ) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder
                .append( "SELECT * FROM ( ")
                .append( "  SELECT WF.* ")
                .append( "  FROM " + getFullyQualifiedTableName() )
                .append( "  JOIN ATLAS.WF_STEP WFS ")
                .append( "  ON WF.WF_ID = wfs.wf_id ")
                .append( "  AND wf.wf_step_config_id = wfs.wf_step_config_id ")
                .append( "  WHERE WF.WF_STEP_CONFIG_ID = ? ")
                .append( "  AND WF.WF_STATUS = 'I'")
                .append( "  AND WFS.ACTION_FLG = 'I'")
                .append( "  ORDER BY WFS.CREATE_TS")
                .append( ") ")
                .append( "WHERE limit 10 ");
        return jdbcTemplate.query( sqlBuilder.toString(), getRowMapper(), wfStepConfigId );
    }

  public Wf findWfForStep(int entityTypeId, String entityLabel, Long wfStepConfigId) {

        String sql = " select wf.* from ATLAS.WF wf where wf.WF_ENTITY_TYPE_ID = "+entityTypeId+" AND wf.WF_ENTITY_LABEL = '"+entityLabel+"' " +
            "AND wf.WF_STEP_CONFIG_ID = "+wfStepConfigId;

        return jdbcTemplate.queryForObject(sql, getRowMapper());
      }

  public List<Long> findWfIdsForEntity(int entityTypeId, String entityLabel) {

        String sql = " select wf.* from ATLAS.WF wf where wf.WF_ENTITY_TYPE_ID = "+entityTypeId+" AND wf.WF_ENTITY_LABEL = '"+entityLabel+"'";

        return jdbcTemplate.queryForList(sql, Long.class);
      }

      public List<Wf> findWfForEntity(int entityTypeId, String entityLabel) {

        String sql = " select wf.* from ATLAS.WF wf where wf.WF_ENTITY_TYPE_ID = "+entityTypeId+" AND wf.WF_ENTITY_LABEL = '"+entityLabel+"' and wf_status != 'D'";

        if (entityTypeId==1) {
          if (entityLabel.startsWith("CP")) {
            sql += " and wf_step_config_id IN (10, 30)";
          }
          else if (entityLabel.contains("_")) {
            sql += " and wf_step_config_id IN (1, 10, 30)";
          }
        }

        return jdbcTemplate.query(sql, getRowMapper());
      }

      public List<String> findEntitiesLike(int wfEntityTypeId, String whereClauseAppend) {

         String sql = "select distinct wf_entity_label \n" +
             "from ATLAS.wf\n" +
             "where wf_entity_type_id="+ wfEntityTypeId +  "\n" +
             whereClauseAppend + "\n" +
             "order by wf_entity_label";

         return jdbcTemplate.queryForList(sql, String.class);
       }

    public List<String> findEntitiesLike( String whereClauseAppend) {

        String sql = "select distinct wf_entity_label \n" +
                "from ATLAS.wf\n" +
                "where \n" +
                whereClauseAppend + "\n" +
                "order by wf_entity_label";

        return jdbcTemplate.queryForList(sql, String.class);
    }

    public List<Long> findWfIdForEntitiesLike(int wfEntityTypeId, String whereClauseAppend) {
        String sql = "select distinct wf_id \n" +
                "from ATLAS.wf\n" +
                "where wf_entity_type_id="+ wfEntityTypeId +  "\n" +
                whereClauseAppend ;
        return jdbcTemplate.queryForList(sql, Long.class);
    }

  public long combineTo(Long combinedWfId, Long wfConfigId, String toWfLabel, Map<Long,String> fromWfIdMap, Long wfStepConfigId, String userId, Long toWfEntityTypeId) {
    //insert association records
    final String ASSOC_SQL = "insert into " + getDefaultSchema() + ".wf_assoc (from_wf_id,to_wf_id,sort_key,active,match_key) values (?,?,?,'Y',?)";
    int sortKey = 1;
    for (Long fromWfId: fromWfIdMap.keySet()) {
      String matchKey = fromWfIdMap.get(fromWfId);

        logQuery( ASSOC_SQL, fromWfId, combinedWfId, sortKey, matchKey);
//      if (getLogger().isTraceEnabled()) {
//        getLogger().debug(buildLogMessage(ASSOC_SQL, new Object[] {fromWfId, combinedWfId, sortKey++, matchKey}));
//      }
      jdbcTemplate.update(ASSOC_SQL, fromWfId, combinedWfId, sortKey++, matchKey);
    }

    //mark old wf records as 'M'=merged
    final String MERGE_UPDATE_SQL = "update " + getDefaultSchema() + "." + getTableName() + " set wf_status='M',update_user=?,update_ts=now() where wf_id=?";
    for (Long fromWfId: fromWfIdMap.keySet()) {
        logQuery( MERGE_UPDATE_SQL, fromWfId );

//      if (getLogger().isTraceEnabled()) {
//        getLogger().debug(buildLogMessage(ASSOC_SQL, new Object[] {fromWfId}));
//      }
      jdbcTemplate.update(MERGE_UPDATE_SQL, userId, fromWfId);
    }

    return combinedWfId;
  }

  public long combineTo(Long wfConfigId, String toWfLabel, Set<Long> fromWfIdSet, Long wfStepConfigId, String userId, Long toWfEntityTypeId) {
    Map<Long, String> fromWfIdMap = new HashMap<Long, String>();
    for (Long fromWfId: fromWfIdSet) {
      fromWfIdMap.put(fromWfId, null);
    }
    return combineTo(wfConfigId, toWfLabel, fromWfIdMap, wfStepConfigId, userId, toWfEntityTypeId);
  }

  public long combineTo(Long wfConfigId, String toWfLabel, Map<Long, String> fromWfIdMap, Long wfStepConfigId, String userId, Long toWfEntityTypeId) {
    //get next wfId to combine to
      long combinedWfId = getNextId( "wf_id_seq" );
    //long combinedWfId = jdbcTemplate.queryForObject("select " + SCHEMA + ".wf_id_seq.nextval from dual", Long.class);

    save(wfConfigId, toWfLabel, wfStepConfigId, userId, toWfEntityTypeId, combinedWfId);


    //insert new step record
      //SVANT: Should not have any updates to wf_step table
   /* final String COMBINED_WF_STEP_SQL = "insert into " + getDefaultSchema() + ".wf_step (wf_step_config_id,wf_id,action_flg,create_user) values (?,?,?,?)";
    logQuery( COMBINED_WF_STEP_SQL, wfStepConfigId, combinedWfId, "I", userId);
//      if (getLogger().isTraceEnabled()) {
//      getLogger().debug(buildLogMessage(COMBINED_WF_STEP_SQL, new Object[] {wfStepConfigId, combinedWfId, "I", userId}));
//    }
    jdbcTemplate.update(COMBINED_WF_STEP_SQL, wfStepConfigId, combinedWfId, "I", userId);
*/
    //create association records
    return combineTo(combinedWfId, wfConfigId, toWfLabel, fromWfIdMap, wfStepConfigId, userId, toWfEntityTypeId);
  }

    public void UpdateWfStepConfig(Long orgignalWfId, Long wfStepConfigId, String userId) {
        //insert new step record
        //final String COMBINED_WF_STEP_SQL = "insert into " + getDefaultSchema() + ".wf_step (wf_step_config_id,wf_id,action_flg,create_user) values (?,?,?,?)";
        //update wf with new step config id
        final String COMBINED_WF_UPDATE_SQL = "update " + getDefaultSchema() + "." + getTableName() + " set wf_step_config_id=?,wf_status=?,update_user=?,update_ts=now()  where wf_id=?";

        //logQuery( COMBINED_WF_STEP_SQL, wfStepConfigId, orgignalWfId, "I", userId);

        //jdbcTemplate.update(COMBINED_WF_STEP_SQL, wfStepConfigId, orgignalWfId, "I", userId);

        logQuery(COMBINED_WF_UPDATE_SQL,  wfStepConfigId,"I",userId,orgignalWfId);

        jdbcTemplate.update(COMBINED_WF_UPDATE_SQL, wfStepConfigId,"I",userId,orgignalWfId);
    }

  public void save(Long wfConfigId, String toWfLabel, Long wfStepConfigId, String userId, Long toWfEntityTypeId, long combinedWfId) {
    //insert new workflow record
    final String COMBINED_WF_SQL = "insert into " + getDefaultSchema() + "." + getTableName() + " (wf_id,wf_config_id,wf_step_config_id,wf_status,wf_entity_type_id,wf_entity_label,create_user) values (?,?,?,'I',?,?,?)";
    logQuery( COMBINED_WF_SQL, combinedWfId, wfConfigId, wfStepConfigId, toWfEntityTypeId, toWfLabel, userId);
//    if (getLogger().isTraceEnabled()) {
//      getLogger().debug(buildLogMessage(COMBINED_WF_SQL, new Object[] {combinedWfId, wfConfigId, wfStepConfigId, toWfEntityTypeId, toWfLabel, userId}));
//    }
    jdbcTemplate.update(COMBINED_WF_SQL, combinedWfId, wfConfigId, wfStepConfigId, toWfEntityTypeId, toWfLabel, userId);
  }

  public long getNextId() {
        final String SQL = "SELECT nextval('" + getDefaultSchema() + ".WF_ID_SEQ') DUAL";
        logQuery( SQL );
        return jdbcTemplate.queryForObject( SQL, Long.class );
    }

    public Wf save(Wf wf ) {
        StringBuilder SQLQueryBuilder = new StringBuilder();
        StringBuilder SQLValuesBuilder = new StringBuilder();
        ArrayList<Object> values = new ArrayList<Object>();

        SQLQueryBuilder.append( "INSERT INTO ").append( getFullyQualifiedTableName() ).append(" ( ");
        SQLValuesBuilder.append(" VALUES ( ");

        SQLQueryBuilder.append( "wf_config_id");
        SQLValuesBuilder.append("?");
        values.add(wf.getWfConfigId());

        Long wfId = wf.getWfId();
        SQLQueryBuilder.append( ", wf_id" );
        SQLValuesBuilder.append(", ?");

        if( wfId != null && wfId > 0L ) {
            values.add(wf.getWfId());
        } else {
            wfId = getNextId();
            values.add( wfId );
        }

        if( wf.getWfStatus() != null && !wf.getWfStatus().isEmpty() ) {
            SQLQueryBuilder.append( ", wf_status");
            SQLValuesBuilder.append(", ? ");
            values.add( wf.getWfStatus() );
        }

        SQLQueryBuilder.append( ", wf_step_config_id");
        SQLValuesBuilder.append(", ?");
        values.add( wf.getWfStepConfigId() );

        SQLQueryBuilder.append( ", create_user");
        SQLValuesBuilder.append(", ?");
        values.add( wf.getCreateUser() );

        if( wf.getCreateTs() != null ) {
            SQLQueryBuilder.append( ", create_ts");
            SQLValuesBuilder.append(", ?");
            values.add(wf.getCreateTs() );
        }

        if( wf.getUpdateUser() != null && !wf.getUpdateUser().isEmpty() ) {
            SQLQueryBuilder.append( ", update_user");
            SQLValuesBuilder.append(", ?");
            values.add( wf.getUpdateUser() );
        }

        if( wf.getUpdateTs() != null ) {
            SQLQueryBuilder.append( ", update_ts");
            SQLValuesBuilder.append(", ?");
            values.add(wf.getUpdateTs() );
        }

        if( wf.getWfEntityTypeId() != null && wf.getWfEntityTypeId() > 0L ) {
            SQLQueryBuilder.append( ", wf_entity_type_id" );
            SQLValuesBuilder.append(", ?");
            values.add(wf.getWfEntityTypeId());
        }

        if( wf.getWfEntityLabel() != null && !wf.getWfEntityLabel().isEmpty() ) {
            SQLQueryBuilder.append( ", wf_entity_label");
            SQLValuesBuilder.append(", ?");
            values.add( wf.getWfEntityLabel() );
        }

        SQLQueryBuilder.append( ")" );
        SQLValuesBuilder.append( ")" );

        final String SQL = SQLQueryBuilder.append( SQLValuesBuilder.toString() ).toString();
        logQuery( SQL, values.toArray() );
        jdbcTemplate.update( SQL, values.toArray() );

        wf.setWfId( wfId );
        return wf;
    }

  public List<Long> getWfId(Long wfConfigId, String barcode) {

    String sql = "select distinct(wf_id) from ATLAS.wf where wf_entity_label='" + barcode + "' and WF_CONFIG_ID = "+wfConfigId+"";
    logQuery(sql);

    return jdbcTemplate.queryForList(sql, Long.class);

  }

  public List<Wf> findAllWfInWfConfig(Long wfConfigId, Long wfEntityTypeId) {
    return findAllWfInWfConfig(wfConfigId, wfEntityTypeId, true);
  }
    public List<Wf> findAllWfInWfConfig(Long wfConfigId, String wfEntityLabel) {
        return findAll(" WF_CONFIG_ID = ? AND WF_ENTITY_LABEL = ?", wfConfigId, wfEntityLabel);
    }

    public List<Wf> findAllWfsInWfConfig(Long wfConfigId, String wfEntityLabel, List<Long> toWfIds) {
      List<Wf> allPlatesList=new ArrayList<>();

            StringBuilder sb = new StringBuilder();
            for(Long str:toWfIds){
                if(sb.length() != 0){
                    sb.append(",");
                }
                sb.append(str);
            }

            String whereClause = " WF_CONFIG_ID = ? AND WF_ENTITY_LABEL LIKE '%"+wfEntityLabel+"%'";
            String whereClauseCP = " WF_CONFIG_ID = ? AND WF_ENTITY_LABEL LIKE '%CP%' and WF_ID IN ("+sb+")";

            List<Wf> allPlates= findAllOrdered(whereClause, "WF_ENTITY_LABEL", wfConfigId);

            List<Wf> cherrypickPlates=findAllOrdered(whereClauseCP, "WF_ENTITY_LABEL", wfConfigId);
        allPlatesList.addAll(allPlates);
        allPlatesList.addAll(cherrypickPlates);
            return  allPlatesList;

    }
    public List<Wf> findAllWfsInWfConfig(Long wfConfigId, String wfEntityLabel) {

            String whereClause = " WF_CONFIG_ID = ? AND WF_ENTITY_LABEL LIKE '%"+wfEntityLabel+"%'";
            return findAllOrdered(whereClause, "WF_ENTITY_LABEL", wfConfigId);
    }

  public Long getWfId(String wfEntityLabel, int wfEntityTypeId) {

      String sql = "select distinct(wf_id) from ATLAS.wf where wf_entity_label='" + wfEntityLabel + "' and wf_entity_type_id=" + wfEntityTypeId;
      logQuery(sql);

      return jdbcTemplate.queryForObject(sql, Long.class);

  }

    public List<Wf> findAllWfInWfConfig(Long wfConfigId, Long wfEntityTypeId, boolean onlyInProgress ) {
        String whereClause = " WF_CONFIG_ID = ? AND WF_ENTITY_TYPE_ID = ? " +
                ( onlyInProgress ? "AND WF_STATUS = 'I' " : "" );

        return findAllOrdered(whereClause, "WF_ENTITY_LABEL", wfConfigId, wfEntityTypeId);
    }

    public List<Wf> findAllWfInWfConfigStep(Long wfConfigId, Long wfStepConfigId, boolean onlyInProgress ) {
    String whereClause = " WF_CONFIG_ID = ? AND WF_STEP_CONFIG_ID = ? " +
        ( onlyInProgress ? "AND WF_STATUS = 'I' " : "" );

    return findAllOrdered(whereClause, "WF_ENTITY_LABEL", wfConfigId, wfStepConfigId);
  }

    public Long findActiveWfInWfConfig( Long wfConfigId, Long wfEntityTypeId, String barcode, Long wfStepConfigId ) {
      String activeWf = " select wf.WF_ID from ATLAS.WF wf INNER JOIN ATLAS.WF_ASSOC wa ON wa.TO_WF_ID = wf.WF_ID " +
              " INNER JOIN ATLAS.WF ePlate ON wa.FROM_WF_ID =ePlate.WF_ID  AND ePlate.WF_ENTITY_TYPE_ID = 1 " +
          "where wf.WF_CONFIG_ID = "+wfConfigId+" AND wf.WF_ENTITY_TYPE_ID = "+wfEntityTypeId+" AND " +
          "wf.WF_ENTITY_LABEL = '"+barcode+"' \n" +
          "AND wf.WF_STEP_CONFIG_ID = "+wfStepConfigId+" and wa.ACTIVE = 'Y' ";

      return jdbcTemplate.queryForObject(activeWf, Long.class);
    }

  public Long findActiveWfInWfConfig( Long wfConfigId, Long wfEntityTypeId, String barcode ) {
    String activeWf = " select distinct wf.WF_ID from ATLAS.WF wf INNER JOIN ATLAS.WF_ASSOC wa ON wa.FROM_WF_ID = wf.WF_ID " +
        "where wf.WF_CONFIG_ID = "+wfConfigId+" AND wf.WF_ENTITY_TYPE_ID = "+wfEntityTypeId+" AND " +
        "wf.WF_ENTITY_LABEL = '"+barcode+"' \n" +
        "and wa.ACTIVE = 'Y' AND WF_STATUS != 'D'  ";

    return jdbcTemplate.queryForObject(activeWf, Long.class);
  }

    public List<Long> findActiveWfInStep(Long wfConfigId, Long wfEntityTypeId, String barcode, Long wfStepConfigId, Long toWfEntityTypeId ) {
        String activeWf = " select wa.TO_WF_ID from ATLAS.WF wf INNER JOIN ATLAS.WF_ASSOC wa ON wa.FROM_WF_ID = wf.WF_ID " +
                "INNER JOIN ATLAS.WF wf1 ON wf1.WF_ID=wa.TO_WF_ID " +
                "where wf.WF_CONFIG_ID = ? AND wf.WF_ENTITY_TYPE_ID = ? AND " +
                "wf.WF_ENTITY_LABEL = ? " +
                "AND wf.WF_STEP_CONFIG_ID = ? and wa.ACTIVE = 'Y' AND wf.WF_STATUS != 'D' and wf1.WF_STATUS != 'D' AND wf1.WF_ENTITY_TYPE_ID= ?";

        return jdbcTemplate.queryForList(activeWf, Long.class, wfConfigId, wfEntityTypeId, barcode, wfStepConfigId, toWfEntityTypeId);
    }

    public Long findWfInWfConfig(Long wfConfigId, Long entityTypeId, String ePlate, Long wfStepConfigId) {

      String activeWf = " select wf.WF_ID from ATLAS.WF wf where wf.WF_CONFIG_ID = "+wfConfigId+
          " AND wf.WF_ENTITY_TYPE_ID = "+entityTypeId+" AND wf.WF_ENTITY_LABEL = '"+ePlate+"' " +
          "AND wf.WF_STEP_CONFIG_ID = "+wfStepConfigId+" AND wf.WF_STATUS='I'";

        try {
            return jdbcTemplate.queryForObject(activeWf, Long.class);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    public List findAllWfWithStatus(Long wfStepConfigId) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT count(*) as count,WF_STATUS as status FROM ATLAS.WF ");
        sql.append("WHERE wf_step_config_id="+wfStepConfigId);
        sql.append(" GROUP BY WF_STATUS");

        logQuery(sql.toString());

        List resultMap = new ArrayList();
        try{
            resultMap = jdbcTemplate.queryForList(sql.toString());
        }catch(Exception e){

        }

        return resultMap;
    }

  public void updateWf(Long fromWfId,String userId){

    updateWfStatus(fromWfId,"M",userId);
  }


  public boolean updateWfStatus(Long fromWfId, String wfStatus,String userId){

      final String MERGE_UPDATE_SQL = "update " + getDefaultSchema() + "." + getTableName() + " set wf_status=?,update_user=?,update_ts=now() where wf_id=?";

      return (jdbcTemplate.update(MERGE_UPDATE_SQL, wfStatus,userId, fromWfId) > 0 ? true: false);
  }

  public boolean updateWfEntityTypeId(Long fromWfId, Long wfEntityTypeId){

    final String MERGE_UPDATE_SQL = "update " + getDefaultSchema() + "." + getTableName() + " set wf_entity_type_id=? where wf_id=?";

    return (jdbcTemplate.update(MERGE_UPDATE_SQL, wfEntityTypeId, fromWfId) > 0 ? true: false);
  }

  public Long findWfWithStatus(Long wfConfigId, String wfEntityLabel, String wfStatus){

      final String SQL = "SELECT WF_ID FROM ATLAS.WF WHERE WF_CONFIG_ID =" + wfConfigId + " AND WF_ENTITY_LABEL = '"+ wfEntityLabel +"'"+ " AND WF_STATUS = '"+ wfStatus +"'";

      try {
          return jdbcTemplate.queryForObject(SQL, Long.class);
      } catch (EmptyResultDataAccessException e) {
          return null;
      }
  }

  public Integer getProjectsCount(String project){
      StringBuilder sql = new StringBuilder();
      sql.append("select count(*) in_progress from ");
      sql.append(" (select wdProject.wf_data_varchar2 project ");
      sql.append(" from ATLAS.wf wfD ");
      sql.append(" inner join ATLAS.wf_data wdProject on wdProject.wf_id=wfD.wf_id ");
      sql.append(" where wfD.wf_status='I' ");
      sql.append("   and wfD.wf_step_config_id in (9000, 9001, 9010)  ");
      sql.append("   and wdProject.wf_data_config_id=2036 ");
      sql.append(" union  ");
      sql.append(" select wf.wf_entity_label project ");
      sql.append("   from ATLAS.wf ");
      sql.append("   where wf_status='I' ");
      sql.append("   and wf_step_config_id=9007) ");
      sql.append("   where project= '"+project+"'");
      logQuery(sql.toString());
        try{
            return jdbcTemplate.queryForObject(sql.toString(),Integer.class);
        }
        catch (EmptyResultDataAccessException e) {
            return null;
        }
  }

    public Long getWfId(String wfEntityLabel, int wfEntityTypeId, Long wfConfigId) {

        String sql = "select distinct(wf_id) from ATLAS.wf where wf_entity_label='" + wfEntityLabel + "' and wf_entity_type_id=" + wfEntityTypeId + "and wf_config_id = "+ wfConfigId+" and wf_status != 'D'";
        logQuery(sql);

        return jdbcTemplate.queryForObject(sql, Long.class);
    }

    public String getWfEntityLabel(Long wfDataConfigId, String wfDataVarchar2, Long wfEntityType) {
      String SQL = "select w.wf_entity_label from atlas.wf_data wd join atlas.wf w on w.wf_id=wd.wf_id where wf_data_config_id=" + wfDataConfigId + " and wd.wf_data_varchar2='" + wfDataVarchar2 + "' AND W.WF_ENTITY_TYPE_ID=" + wfEntityType;
      logQuery(SQL, wfDataConfigId, wfDataVarchar2, wfEntityType);

      return jdbcTemplate.queryForObject(SQL, String.class );
    }

    public Integer pPlateIsRedoEligible(String pPlate){
        StringBuilder sql = new StringBuilder();
        sql.append("select count(*) cnt from ATLAS.wf ");
        sql.append(" where wf_entity_type_id=95 and wf_status='I' ");
        sql.append(" and wf_step_config_id=9011 ");
        sql.append(" and wf_entity_label= ");
        sql.append(" (select wdProj.wf_data_varchar2 ");
                sql.append(" from ATLAS.wf wfP ");
                        sql.append(" inner join ATLAS.wf_data wdProj on wdProj.wf_id=wfP.wf_id ");
                                sql.append(" where  wdProj.wf_data_config_id=2036 ");
        sql.append(" and wfP.wf_entity_type_id=100 and wf_status != 'D' ");
        sql.append(" and wfP.wf_entity_label='"+pPlate+"') ");
        logQuery(sql.toString());
        try{
            return jdbcTemplate.queryForObject(sql.toString(),Integer.class);
        }
        catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    public List<Wf> findAllWf(Long wfStepConfigId, Long wfEntityTypeId) {
        return findAll("wf_step_config_id=? and wf_status ='I' and wf_entity_type_id=?", wfStepConfigId, wfEntityTypeId);

    }

}
