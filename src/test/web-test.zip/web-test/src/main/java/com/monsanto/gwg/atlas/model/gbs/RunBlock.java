package com.monsanto.gwg.atlas.model.gbs;

import java.io.Serializable;
import java.sql.Timestamp;

public class RunBlock implements Serializable {

  private long wfId;
  private String torrentRunName;
  private long torrentAnalysisId;
  private long torrentRunId;
  private String blockBarcodeNbr;
  private long snapshotWfId;
  private Timestamp analysisCompleteTs;

  public long getWfId() {
    return wfId;
  }

  public void setWfId(long wfId) {
    this.wfId = wfId;
  }

  public String getTorrentRunName() {
    return torrentRunName;
  }

  public void setTorrentRunName(String torrentRunName) {
    this.torrentRunName = torrentRunName;
  }

  public long getTorrentAnalysisId() {
    return torrentAnalysisId;
  }

  public void setTorrentAnalysisId(long torrentAnalysisId) {
    this.torrentAnalysisId = torrentAnalysisId;
  }

  public long getTorrentRunId() {
    return torrentRunId;
  }

  public void setTorrentRunId(long torrentRunId) {
    this.torrentRunId = torrentRunId;
  }

  public String getBlockBarcodeNbr() {
    return blockBarcodeNbr;
  }

  public void setBlockBarcodeNbr(String blockBarcodeNbr) {
    this.blockBarcodeNbr = blockBarcodeNbr;
  }

  public long getSnapshotWfId() {
    return snapshotWfId;
  }

  public void setSnapshotWfId(long snapshotWfId) {
    this.snapshotWfId = snapshotWfId;
  }

  public Timestamp getAnalysisCompleteTs() {
    return analysisCompleteTs;
  }

  public void setAnalysisCompleteTs(Timestamp analysisCompleteTs) {
    this.analysisCompleteTs = analysisCompleteTs;
  }
}
