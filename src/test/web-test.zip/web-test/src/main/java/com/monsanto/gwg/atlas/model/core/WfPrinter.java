package com.monsanto.gwg.atlas.model.core;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */
public class WfPrinter {
  private Long printerId;
  private String commandsPrefix;
  private String commandsSuffix;
  private String printerName;
  private Long completedRequests;
  private String ipAddress;
  private String location;
  private boolean active;
  private Long wfConfigId;


  public Long getPrinterId() {
    return printerId;
  }

  public void setPrinterId(Long printerId) {
    this.printerId = printerId;
  }

  public String getIpAddress(){return ipAddress;}

  public void setIpAddress(String ipAddress){this.ipAddress = ipAddress;}

  public String getCommandsPrefix() {
    return commandsPrefix;
  }

  public void setCommandsPrefix(String commandsPrefix) {
    this.commandsPrefix = commandsPrefix;
  }

  public String getCommandsSuffix() {
    return commandsSuffix;
  }

  public void setCommandsSuffix(String commandsSuffix) {
    this.commandsSuffix = commandsSuffix;
  }

  public String getPrinterName() {
    return printerName;
  }

  public void setPrinterName(String printerName) {
    this.printerName = printerName;
  }

  public Long getCompletedRequests() {
    return completedRequests;
  }

  public void setCompletedRequests(Long completedRequests) {
    this.completedRequests = completedRequests;
  }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }
}