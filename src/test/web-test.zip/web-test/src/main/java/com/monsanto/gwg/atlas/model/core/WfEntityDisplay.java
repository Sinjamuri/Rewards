package com.monsanto.gwg.atlas.model.core;

public class WfEntityDisplay {

  private String label;
  private String display;
  private Long wfId;

  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public String getDisplay() {
    return display;
  }

  public void setDisplay(String display) {
    this.display = display;
  }

  public Long getWfId() {
    return wfId;
  }

  public void setWfId(Long wfId) {
    this.wfId = wfId;
  }
}
