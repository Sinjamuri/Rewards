package com.monsanto.gwg.atlas.service.tossQueue;

import com.monsanto.gwg.atlas.constants.WfStepConfigConstants;
import com.monsanto.gwg.atlas.constants.WfStepDataConfigConstants;
import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.dao.tossQueue.TossQueueDao;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.model.containerlocation.ContainerLocation;
import com.monsanto.gwg.atlas.model.core.WfStepDataConfigVw;
import com.monsanto.gwg.atlas.service.UtilService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class TossQueueService {

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfStepDataConfigVwDao wfStepDataConfigVwDao;

    @Autowired
    private WfStepConfigDao wfStepConfigDao;

    @Autowired
    private WfDao wfDao;

    @Autowired
    private WfAssocDao wfAssocDao;


    @Autowired
    private TossQueueDao tossQueueDao;

    @Autowired
    private UtilService utilService;

    private static final Logger LOG = LoggerFactory.getLogger(TossQueueService.class);

    /**
     *
     * @return
     */
    public List<ContainerLocation> getFPlateStorageLocationsToToss() {
        List<ContainerLocation> containerLocsList = new ArrayList<ContainerLocation>();

        // Fetch "READY_FOR_CLEAN_UP" WF_STEP_CONFIG_ID
        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.READY_FOR_CLEAN_UP);

        // Fetch F Plate Storage locations stored at "READY FOR CLEAN UP" QUEUE
        containerLocsList = tossQueueDao.getFPlateStorageLocationsToToss(WfStepDataConfigConstants.F_PLATE,
                wfStepConfigId,
                WfStepDataConfigConstants.F_LOCATION_1_DISPLAY);

        return containerLocsList;
    }

    /**
     *
     * @return
     */
    public List<WfStepDataConfigVw> getFPlateStorageDataConfigs() {
        List<WfStepDataConfigVw> wfStepDataConfigList = new ArrayList<WfStepDataConfigVw>();

        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.READY_FOR_CLEAN_UP);

        wfStepDataConfigList.addAll(wfStepDataConfigVwDao.findWfStepDataConfig(wfStepConfigId,
                WfStepDataConfigConstants.F_LOCATION_1_DISPLAY,
                WfStepDataConfigConstants.F_LOCATION_2_DISPLAY));

        return wfStepDataConfigList;
    }

    /**
     *
     * @return
     */
    public List<ContainerLocation> getGLPlateStorageLocationsToToss(){
        List<ContainerLocation> containerLocsList = new ArrayList<ContainerLocation>();

        // Fetch "Gencell LC - Plate CrTEP_CONFIG_ID
       // Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.ANALYSIS_SNP_GENOTYPING);

        // GL Plate Storage Locations are stored at "Gencell LC - Plate Creation" queue.
        containerLocsList = tossQueueDao.getGLPlateStorageLocationsToToss(WfStepDataConfigConstants.GL_PLATE,
                WfStepDataConfigConstants.GL_LOCATION_1_DISPLAY,
                WfStepDataConfigConstants.GL_LOCATION_2_DISPLAY);
        return containerLocsList;
    }

    /**
     *
     * @return
     */
    public List<WfStepDataConfigVw> getGLPlateStorageDataConfigs() {
        List<WfStepDataConfigVw> wfStepDataConfigList = new ArrayList<WfStepDataConfigVw>();

        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.GENCELL_LC_RECEIVED);

        wfStepDataConfigList.addAll(wfStepDataConfigVwDao.findWfStepDataConfig(wfStepConfigId,
                WfStepDataConfigConstants.GL_PLATE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.GL_PLATE_LOCATION_2_LABEL));

        return wfStepDataConfigList;
    }

    /**
     *
     * @return
     */
    public List<ContainerLocation> getCTPlateStorageLocationsToToss(){
        List<ContainerLocation> containerLocsList = new ArrayList<ContainerLocation>();

        // Fetch "Sequencing Group Pooling" WF_STEP_CONFIG_ID
        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.SEQUENCING_GRP_POOLING);

        // Fetch CLEAN TUBE storage locations from "Sequencing Grp Pooling" QUEUE.
        containerLocsList.addAll(tossQueueDao.getCTStorageLocationsToToss(WfStepDataConfigConstants.CLEAN_TUBE,
                wfStepConfigId,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_2_LABEL));

        // Fetch "Ion Chef - Run Ready" WF_STEP_CONFIG_ID
        //wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.ION_CHEF_RUN_READY);

        // Fetch CLEAN TUBE storage locations from "ION CHEF - RUN READY" QUEUE.
       /* containerLocsList.addAll(tossQueueDao.getCTStorageLocationsToToss(WfStepDataConfigConstants.CLEAN_TUBE,
                wfStepConfigId,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_2_LABEL));*/

        return containerLocsList;
    }

    /**
     *
     * @return
     */
    public List<WfStepDataConfigVw> getCTStorageDataConfigs() {
        List<WfStepDataConfigVw> wfStepDataConfigList = new ArrayList<WfStepDataConfigVw>();

        // Fetch "Sequencing Group Pooling" WF_STEP_CONFIG_ID
        Long wfStepConfigId = wfStepConfigDao.getWfStepConfig(WfStepConfigConstants.SEQUENCING_GRP_POOLING);

        wfStepDataConfigList.addAll(wfStepDataConfigVwDao.findWfStepDataConfig(wfStepConfigId,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_1_LABEL,
                WfStepDataConfigConstants.SEQUENCING_TUBE_LOCATION_2_LABEL));

        return wfStepDataConfigList;
    }

    public JsonResponse savePostData(JsonPost jsonPost) {
        JsonResponse jsonResponse = null;
        try{
            for (Map<String,String> postData: jsonPost.getRows()) {
                Long wfId = Long.parseLong(postData.get("wfId"));
                wfDataDao.save(wfId, 1221L , jsonPost.getUserId());
                wfDataDao.save(wfId, 1222L, new Timestamp(System.currentTimeMillis()));
                //Also, set the status of the wf to "T"rash.
                tossQueueDao.updateWfStatusToToss(wfId);
            }
        }catch (Exception ex) {
            LOG.error("Method invocation error", ex);

            //send exception to the UI to be logged by console
            jsonResponse = new JsonResponse();
            jsonResponse.setException(utilService.getStackTrace(ex));
        }
        return jsonResponse;
    }

}
