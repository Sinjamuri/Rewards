package com.monsanto.gwg.atlas.service.core;

import com.monsanto.gwg.atlas.dao.core.WfDataConfigDao;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.model.core.WfDataConfig;
import com.monsanto.gwg.atlas.model.core.WfStepDataConfigVw;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by ASHAR7 on 1/5/2015.
 */
@Service
public class WriteWfExcel {

    @Autowired
    private WfDataConfigDao wfDataConfigDao;

    public final static String ANALYSIS__EXCEL_TEMPLATE = "/excelTemplates/ExportFilteredRows.xlsx";
    public final static String DATE_FORMAT = "mm/dd/yyyy";

    /**
     * Writes the workbook to the passed output stream which will allow the excel sheet to be downloaded on the user's computer.
     *
     * @param stepInfo
     * @param scannedMap
     * @param out
     * @return Plate Name
     */
    public void createExcel(List<WfStepDataConfigVw> stepInfo, Map<String, List<WfData>> scannedMap, OutputStream out){

        try {
            InputStream fileIn = getClass().getResourceAsStream(ANALYSIS__EXCEL_TEMPLATE);

            XSSFWorkbook workbook = new XSSFWorkbook(fileIn);
            XSSFSheet worksheet = workbook.getSheetAt(0);

            CreationHelper createHelper = workbook.getCreationHelper();

            CellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(DATE_FORMAT));

            Iterator mapItr = scannedMap.keySet().iterator();

            int i = 0;

            Row row = worksheet.createRow((short) i);

            for(WfStepDataConfigVw wfStepDataConfig : stepInfo) {
                WfDataConfig wfDataConfig = wfDataConfigDao.find(wfStepDataConfig.getWfDataConfigId());
                setCellValueString(row, wfStepDataConfig.getSortKey(), wfDataConfig.getWfDataConfigLabel());
            }

            while(mapItr.hasNext()){
                String wfId = (String) mapItr.next();
                i++;
                // index from 0,0... cell A1 is cell(0,0)
                row = worksheet.createRow((short) i);

                for(WfData wfData : scannedMap.get(wfId) ) {

                    for(WfStepDataConfigVw wfStepDataConfig : stepInfo){
                        if(null != wfData.getWfDataVarchar2() && wfStepDataConfig.getWfDataConfigId().longValue() == wfData.getWfDataConfigId().longValue()){
                            setCellValueString(row, wfStepDataConfig.getSortKey(), wfData.getWfDataVarchar2());
                        }else  if(null != wfData.getWfDataNumber() && wfStepDataConfig.getWfDataConfigId().longValue() == wfData.getWfDataConfigId().longValue()){
                            setCellValueString(row, wfStepDataConfig.getSortKey(), wfData.getWfDataNumber().toPlainString());
                        }else  if(null != wfData.getWfDataTimestamp() && wfStepDataConfig.getWfDataConfigId().longValue() == wfData.getWfDataConfigId().longValue()){
                            Cell cellf1 = row.createCell(wfStepDataConfig.getSortKey());
                            cellf1.setCellStyle(cellStyle);
                            cellf1.setCellValue(wfData.getWfDataTimestamp());
                        }else  if(null != wfData.getWfDataBlob() && wfStepDataConfig.getWfDataConfigId().longValue() == wfData.getWfDataConfigId().longValue()){
                            setCellValueString(row, wfStepDataConfig.getSortKey(), new String(wfData.getWfDataBlob()));
                        }
                    }
                }
            }

            workbook.write(out);

            fileIn.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * sets the cell value in the given row
     * @param row
     * @param index
     * @param value
     */
    private static void setCellValueString(Row row, int index, String value) {
        Cell cell = row.createCell(index);
        cell.setCellValue(value);
    }

}
