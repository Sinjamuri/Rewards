package com.monsanto.gwg.atlas.model.torrent;

import java.sql.Timestamp;

public class TorrentReference {
  private long torrentReferenceId;
  private String referenceName;
  private String referencePath;
  private long cropId;
  private String environment;
  private String indelName;
  private String indelPath;
  private String notes;
  private Timestamp createTs;
  private int sortKey;
  private boolean enabled;

  public long getTorrentReferenceId() {
    return torrentReferenceId;
  }

  public void setTorrentReferenceId(long torrentReferenceId) {
    this.torrentReferenceId = torrentReferenceId;
  }

  public String getReferenceName() {
    return referenceName;
  }

  public void setReferenceName(String referenceName) {
    this.referenceName = referenceName;
  }

  public String getReferencePath() {
    return referencePath;
  }

  public void setReferencePath(String referencePath) {
    this.referencePath = referencePath;
  }

  public long getCropId() {
    return cropId;
  }

  public void setCropId(long cropId) {
    this.cropId = cropId;
  }

  public String getEnvironment() {
    return environment;
  }

  public void setEnvironment(String environment) {
    this.environment = environment;
  }

  public String getIndelName() {
    return indelName;
  }

  public void setIndelName(String indelName) {
    this.indelName = indelName;
  }

  public String getIndelPath() {
    return indelPath;
  }

  public void setIndelPath(String indelPath) {
    this.indelPath = indelPath;
  }

  public String getNotes() {
    return notes;
  }

  public void setNotes(String notes) {
    this.notes = notes;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public int getSortKey() {
    return sortKey;
  }

  public void setSortKey(int sortKey) {
    this.sortKey = sortKey;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }
}
