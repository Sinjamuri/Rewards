package com.monsanto.gwg.atlas.json.core;

public class JsonSecureCheckpoint {
  private boolean allowed;
  private String error;
  private String checkPoint;
  private String userId;

  public boolean getAllowed() {
    return allowed;
  }

  public void setAllowed(boolean allowed) {
    this.allowed = allowed;
  }

  public String getError() {
    return error;
  }

  public void setError(String error) {
    this.error = error;
  }

  public String getCheckPoint() {
    return checkPoint;
  }

  public void setCheckPoint(String checkPoint) {
    this.checkPoint = checkPoint;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }
}
