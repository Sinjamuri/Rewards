package com.monsanto.gwg.atlas.model;

import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author ATPINZ
 * @version $Revision$
 */
public class Reagent implements Serializable {

  private long reagentId;
  private String reagentName;
  private String workflowStepName;
  private String lotNumber;
  private long cost;
  private long workflowStepConfigId;
  private String userId;

  public long getWorkflowStepConfigId() {
    return workflowStepConfigId;
  }

  public void setWorkflowStepConfigId(long workflowStepConfigId) {
    this.workflowStepConfigId = workflowStepConfigId;
  }

  public long getReagentId() {
    return reagentId;
  }

  public void setReagentId(long reagentId) {
    this.reagentId = reagentId;
  }

  public String getReagentName() {
    return reagentName;
  }

  public void setReagentName(String reagentName) {
    this.reagentName = reagentName;
  }

  public String getWorkflowStepName() {
    return workflowStepName;
  }

  public void setWorkflowStepName(String workflowStepName) {
    this.workflowStepName = workflowStepName;
  }

  public String getLotNumber() {
    return lotNumber;
  }

  public void setLotNumber(String lotNumber) {
    this.lotNumber = lotNumber;
  }

  public long getCost() {
    return cost;
  }

  public void setCost(long cost) {
    this.cost = cost;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

}