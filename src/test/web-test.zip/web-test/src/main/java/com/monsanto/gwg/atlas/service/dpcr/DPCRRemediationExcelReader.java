package com.monsanto.gwg.atlas.service.dpcr;

import com.monsanto.gwg.atlas.dao.core.WfConfigPropertyDao;
import com.monsanto.gwg.atlas.dao.core.WfDao;
import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.model.core.Wf;
import com.monsanto.gwg.atlas.model.core.WfConfigProperty;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by SINJA on 05/08/2017.
 */
@Service
public class DPCRRemediationExcelReader implements DPcrConstants {


    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfDao wfDao;

    @Autowired
    private WfConfigPropertyDao wfConfigPropertyDao;


    @Autowired
    private DataSourceTransactionManager txManager;

    String createUser = "";
    int numberOfColumns = 0;
    String fileName ="";

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public int getNumberOfColumns() {
        return numberOfColumns;
    }

    public void setNumberOfColumns(int numberOfColumns) {
        this.numberOfColumns = numberOfColumns;
    }

    public void setFileName(String fileName) {this.fileName = fileName;}

    public String getFileName() {
        return fileName;
    }

    /**
     * reads row by row starting with second row and populates the Object
     * returns the grid list.
     * @param rowsList List of rows frm the excel
     */
    public List<String> processRows(List<Row> rowsList) throws  Exception{

        List<Object[]> rowArrayList = new ArrayList<Object[]>();

        List<String> errorLogs = new ArrayList<String>();

        //Iterate through each rows from first sheet
        for(int i = 0 ; i < rowsList.size() ; i++){
            Row row = rowsList.get(i);
            if(null != row && 0 < row.getPhysicalNumberOfCells()){
                Object[] rowArray = readRowIntoCustomObject(createUser,
                        row, numberOfColumns, errorLogs, i);
                if(null != rowArray ){
                    rowArrayList.add(rowArray);
                }
            }
        }

        if(errorLogs.isEmpty()){
            saveData(rowArrayList);
        }

        return errorLogs;
    }

    private void saveData(final List<Object[]> rowArrayList) {

        TransactionCallback transactionCallback = new TransactionCallback() {
            @Override
            public Object doInTransaction(TransactionStatus transactionStatus) {
                updateStatuses(rowArrayList);
                return null;
            }
        };

        TransactionTemplate tt = new TransactionTemplate();
        tt.setTransactionManager(txManager);
        tt.execute(transactionCallback);
    }


    private void updateStatuses(final List<Object[]> rowArrayList) {
        for(Object[] rowArray : rowArrayList){
            Wf wf = (Wf) rowArray[0];
            wfDataDao.save(wf.getWfId(), 2093L, DPcrConstants.CONFIG_KEY_DPCR_P_PLATE_STATUS_REDO_PENDING);
            // Get value for the key from wf_config_properties
            WfConfigProperty wfConfigProperty= wfConfigPropertyDao.findByWfConfigIdAndKey(9L, DPcrConstants.CONFIG_KEY_DPCR_P_PLATE_STATUS_REDO_PENDING );
            wfDataDao.save(wf.getWfId(), 2092L, wfConfigProperty.getValueVarchar2());
            // Store upload file name
            wfDataDao.save(wf.getWfId(),2109L,this.getFileName());
            //Store File Uploaded By
            wfDataDao.save(wf.getWfId(),2110L,this.getCreateUser());
            // SMBT-1118  Store Reason Code
            wfDataDao.save(wf.getWfId(),2117L,(String)rowArray[1]);
            // SMBT-1118  Store Marker Tube BarCode
            if(!StringUtils.isEmpty((String)rowArray[2])){
                wfDataDao.save(wf.getWfId(),2116L,(String)rowArray[2]);
            }
        }

    }


    /**
     * reads a single row at a time
     * create a plate if not already present
     * save the sample entity
     * return the grid assoc to be added to the list
     * @param createUser user name
     * @param row excel row
     * @param numberOfColumns number of columns expected in a row
     * @param errorLogs
     * @param rowNum
     * @return Data object for the row
     * @throws Exception may result due to bad data in the row.
     */
    private Object[] readRowIntoCustomObject(String createUser,
                     Row row, int numberOfColumns, List<String> errorLogs, int rowNum)
            throws Exception{

        Object[] rowDataArray = new Object[3];

        String pPlate = "";
        String reasonCode = "";
        String markerTubeBarCode = "";
        String errorLog = "";
        for(int i = 0 ; i < numberOfColumns; i++) {
            Cell cell = row.getCell(i, Row.RETURN_BLANK_AS_NULL);
            if (null != cell) {

                switch (i) {
                    case 0:
                        pPlate = cell.getStringCellValue().trim();
                        break;
                    case 1:
                        reasonCode = cell.getStringCellValue().trim();
                        break;
                    case 2:
                        markerTubeBarCode = cell.getStringCellValue().trim();
                        break;
                }
            }
        }
            errorLogs = validateData(pPlate, reasonCode, markerTubeBarCode,rowNum,errorLogs);
                if (errorLogs.isEmpty()) {
                    //get the  WF
                    Wf wf = new Wf();
                    wf.setWfConfigId(9L);
                    wf.setWfEntityTypeId(100L);
                    wf.setWfEntityLabel(pPlate);
                    wf.setCreateUser(createUser);
                    // Get WF_ID for the P Plate
                    wf.setWfId(wfDao.getWfId(pPlate,100, 9L));
                    rowDataArray[0] = wf;
                    rowDataArray[1]=reasonCode;
                    rowDataArray[2]=markerTubeBarCode;

                }

        return rowDataArray;
    }



    /**
     * validate data for business rules
     * @param pPlate PPlate must exist in the system and have status of DPCR_P_PLATE_STATUS_UPLOAD_PENDING for wf_data_config_id=2093
     * @param reasonCode Reason Code must exist in WF_CONFIG_PROPERTIES
     * @param rowNum
     * @return
     */
    private List<String>  validateData(String pPlate, String reasonCode,String markerTubeBarCode,
                                int rowNum,List<String> errorLogs) {

        String errorLog = "";
        if (StringUtils.isNotEmpty(pPlate)) {
            errorLog = "Row " + (rowNum + 2) + ": P Plate is required. ";
        } else {
            if (!isValidPPlate(pPlate)) {
                // Get value for the key from wf_config_properties
                WfConfigProperty wfConfigProperty = wfConfigPropertyDao.findByWfConfigIdAndKey(9L, DPcrConstants.CONFIG_KEY_DPCR_P_PLATE_STATUS_UPLOAD_PENDING);
                if (!StringUtils.isEmpty(errorLog)) {
                    errorLog = errorLog + "P Plate  " + pPlate + " is not eligible for Remediation.  It does not have " + wfConfigProperty.getValueVarchar2() + " status. ";
                } else {
                    errorLog = errorLog + "Row " + (rowNum + 2) + ": P Plate  " + pPlate + " is not eligible for Remediation.  It does not have " + wfConfigProperty.getValueVarchar2() + " status. ";
                }
            }
            //SMBT-1144 As ATLAS dPCR remediation, I need to further validate the P plates in the score results.
            else{

                try {
                    Long pPlateWfId = wfDao.getWfId(pPlate,100, 9L);
                    //If the related project for the P plate is in Pending Marker Validation, Validation Issues, or Ready to Design raise an error and do not process the file.
                    String project = wfDataDao.getVarchar2ForWfId(pPlateWfId, 2036L);
                    Integer projectCount = wfDao.getProjectsCount(project);
                    if (projectCount != null & projectCount.intValue() > 0){
                        if (!StringUtils.isEmpty(errorLog)) {
                            errorLog = errorLog + "Project for " + pPlate + " is currently in remediation. ";
                        } else {
                            errorLog = errorLog + "Row " + (rowNum + 2) + ": Project for " + pPlate + " is currently in remediation. ";
                        }
                    }
                }
                catch ( Exception ex){
                }
                // SMBT-1146 Validate P Plate
                try{
                    Integer statusCount = wfDao.pPlateIsRedoEligible(pPlate);
                    if(statusCount == null || statusCount.intValue() == 0){
                        if (!StringUtils.isEmpty(errorLog)) {
                            errorLog = errorLog + "Project for " + pPlate + " must be in Ready for Import to remediate. ";
                        } else {
                            errorLog = errorLog + "Row " + (rowNum + 2) + ": Project for " + pPlate + " must be in Ready for Import to remediate. ";
                        }
                    }
                }
                catch(Exception ex){
                }
            }
        }

        if (StringUtils.isEmpty(reasonCode)) {
            if (!StringUtils.isEmpty(errorLog)) {
                if (StringUtils.isEmpty(pPlate)) {
                    errorLog = errorLog + "Reason Code is required. ";
                } else {
                    errorLog = errorLog + "P Plate " + pPlate + " Reason Code is required. ";
                }

            } else {

                if (StringUtils.isEmpty(pPlate)) {
                    errorLog = errorLog + "Reason Code is required. ";
                } else {
                    errorLog = errorLog + "Row " + (rowNum + 2) + ": P Plate " + pPlate + " Reason Code is required. ";
                }

            }
        } else {
            if (!isValidReasonCode(reasonCode)) {
                if (!StringUtils.isEmpty(errorLog)) {

                    if (StringUtils.isEmpty(pPlate)) {
                        errorLog = errorLog + "Invalid Reason Code " + reasonCode + ". ";
                    } else {
                        errorLog = errorLog + "P Plate " + pPlate + " has invalid Reason Code " + reasonCode + ". ";
                    }

                } else {
                    if (StringUtils.isEmpty(pPlate)) {
                        errorLog = errorLog + "Row " + (rowNum + 2) + ": Invalid Reason Code " + reasonCode + ". ";
                    } else {
                        errorLog = errorLog + "Row " + (rowNum + 2) + ": P Plate " + pPlate + " has invalid Reason Code " + reasonCode + ". ";
                    }
                }
            }
        }
        //MBTSUPPORT-404 Validation for R02 Reason Code
        if(reasonCode.equals("R02")){
            if(StringUtils.isEmpty(markerTubeBarCode)){
                if (!StringUtils.isEmpty(errorLog)) {

                    if (StringUtils.isEmpty(pPlate)) {
                        errorLog = errorLog + "Marker Tube Barcode is required when Reason Code is R02. ";
                    } else {
                        errorLog = errorLog + "P Plate " + pPlate + " requires valid Marker Tube Barcode when Reason Code is R02. ";
                    }

                } else {
                    if (StringUtils.isEmpty(pPlate)) {
                        errorLog = errorLog + "Row " + (rowNum + 2) + ": Marker Tube Barcode is required when Reason Code is R02. ";
                    } else {
                        errorLog = errorLog + "Row " + (rowNum + 2) + ": P Plate " + pPlate + " requires valid Marker Tube Barcode when Reason Code is R02. ";
                    }
                }
            }
        }
        // The Marker Tube Barcode in the system should match to the upload file data, if present
        if (!StringUtils.isEmpty(markerTubeBarCode)) {
            try {
                long wfId = wfDao.getWfId(pPlate, 100, 9L);
                String value = wfDataDao.getVarchar2ForWfId(wfId, 2108L);
                if (StringUtils.isEmpty(value)) {
                    if (!StringUtils.isEmpty(errorLog)) {
                        if (StringUtils.isEmpty(pPlate)) {
                            errorLog = errorLog + "Marker Tube Bar Code does not exists in the system. ";
                        } else {
                            errorLog = errorLog + "P Plate " + pPlate + " Marker Tube Bar Code does not exists in the system. ";
                        }

                    } else {
                        if (StringUtils.isEmpty(pPlate)) {
                            errorLog = "Row " + (rowNum + 2) + ": Marker Tube Bar Code does not exists in the system. ";
                        } else {
                            errorLog = "Row " + (rowNum + 2) + ": P Plate " + pPlate + " Marker Tube Bar Code does not exists in the system. ";
                        }

                    }
                } else if (!value.equals(markerTubeBarCode)) {
                    if (!StringUtils.isEmpty(errorLog)) {
                        if (StringUtils.isEmpty(pPlate)) {
                            errorLog = errorLog + " Marker Tube Bar Code " + markerTubeBarCode + " does not match " + value + " in the system. ";
                        } else {
                            errorLog = errorLog + "P Plate " + pPlate + " Marker Tube Bar Code " + markerTubeBarCode + " does not match " + value + " in the system. ";
                        }

                    } else {
                        if (StringUtils.isEmpty(pPlate)) {
                            errorLog = "Row " + (rowNum + 2) + ": Marker Tube Bar Code " + markerTubeBarCode + " does not match " + value + " in the system. ";
                        } else {
                            errorLog = "Row " + (rowNum + 2) + ": P Plate " + pPlate + " Marker Tube Bar Code " + markerTubeBarCode + " does not match " + value + " in the system. ";
                        }
                    }
                }
            } catch (Exception e) {
                if (!StringUtils.isEmpty(errorLog)) {
                    if (StringUtils.isEmpty(pPlate)) {
                        errorLog = errorLog + "Marker Tube Bar Code does not exists in the system. ";
                    } else {
                        errorLog = errorLog + "P Plate " + pPlate + " Marker Tube Bar Code does not exists in the system. ";
                    }
                } else {
                    if (StringUtils.isEmpty(pPlate)) {
                        errorLog = "Row " + (rowNum + 2) + ": Marker Tube Bar Code does not exists in the system. ";
                    } else {
                        errorLog = "Row " + (rowNum + 2) + ": P Plate " + pPlate + " Marker Tube Bar Code does not exists in the system. ";
                    }
                }
            }
        }

        if(!StringUtils.isEmpty(errorLog)){
            errorLogs.add(errorLog);
        }
        return errorLogs;
    }

    private boolean isValidPPlate(String pPlate) {
        boolean isValid = true;
        String status = wfDataDao.getVarchar2ForEntity(2093L, pPlate,100L,9L);
        if (DPcrConstants.CONFIG_KEY_DPCR_P_PLATE_STATUS_UPLOAD_PENDING. equals(status)) {
            return isValid;
        }
        else {
            isValid = false;
        }
        return  isValid;
    }

    private boolean isValidReasonCode(String reasonCode) {
        boolean isValid = true;
        WfConfigProperty wfConfigProperty = wfConfigPropertyDao.findByWfConfigIdAndKey(9L, reasonCode);
        if (wfConfigProperty == null) {
            isValid = false;
        }
        return isValid;
    }

}
