package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

/**
 * Created by PNARL on 10/17/2016.
 */
public class WfPlateMap {
    @DbColumn(field="type")
    private String type;
    @DbColumn(field="source_quadrant")
    private int sourceQuadrant;
    @DbColumn(field="source_row")
    private int sourceRow;
    @DbColumn(field="source_col")
    private int sourceCol;
    @DbColumn(field="source_well_name")
    private String sourceWellName;
    @DbColumn(field="dest_quadrant")
    private int destQuadrant;
    @DbColumn(field="dest_row")
    private int destRow;
    @DbColumn(field="dest_col")
    private int destCol;
    @DbColumn(field="dest_well_name")
    private String destWellName;
    @DbColumn(field="is_control")
    private boolean isControl;

    public String getSourceRowCol() {
        return getSourceRow()+ "" +getSourceCol();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSourceQuadrant() {
        return sourceQuadrant;
    }

    public void setSourceQuadrant(int sourceQuadrant) {
        this.sourceQuadrant = sourceQuadrant;
    }

    public int getSourceRow() {
        return sourceRow;
    }

    public void setSourceRow(int sourceRow) {
        this.sourceRow = sourceRow;
    }

    public int getSourceCol() {
        return sourceCol;
    }

    public void setSourceCol(int sourceCol) {
        this.sourceCol = sourceCol;
    }

    public String getSourceWellName() {
        return sourceWellName;
    }

    public void setSourceWellName(String sourceWellName) {
        this.sourceWellName = sourceWellName;
    }

    public int getDestQuadrant() {
        return destQuadrant;
    }

    public void setDestQuadrant(int destQuadrant) {
        this.destQuadrant = destQuadrant;
    }

    public int getDestRow() {
        return destRow;
    }

    public void setDestRow(int destRow) {
        this.destRow = destRow;
    }

    public int getDestCol() {
        return destCol;
    }

    public void setDestCol(int destCol) {
        this.destCol = destCol;
    }

    public String getDestWellName() {
        return destWellName;
    }

    public void setDestWellName(String destWellName) {
        this.destWellName = destWellName;
    }

    public boolean isControl() {
        return isControl;
    }

    public void setControl(boolean control) {
        isControl = control;
    }
}

