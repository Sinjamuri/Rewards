package com.monsanto.gwg.atlas.model.core;

/**
 * Created by PGROS1 on 6/24/14.
 */
public interface WfAsyncStatusUpdater {
    public void commitStatusUpdate( WfAsyncStatus asyncProcessStatus );
}
