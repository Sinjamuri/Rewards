package com.monsanto.gwg.atlas.service.extract;

import com.monsanto.gwg.atlas.dao.extract.ExtractBpoGbsDao;
import com.monsanto.gwg.atlas.model.extract.ExtractBpoGBS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by ASHAR7 on 1/13/2015.
 */
@Service
public class ExtractBpoGbsService {

    @Autowired
    private ExtractBpoGbsDao extractBpoGbsDao;

    protected Logger getLogger() {
        return LoggerFactory.getLogger(this.getClass());
    }

    public List<ExtractBpoGBS> getAllByBpo(String plateId){

        return extractBpoGbsDao.getAllByBpo(plateId );
    }

    public List<ExtractBpoGBS> getAllByGbs(String blockBarcodeNbr){

        return extractBpoGbsDao.getAllByGbs(blockBarcodeNbr );
    }

    public List<ExtractBpoGBS> getAllByBpoAndGbs(String plateId, String blockBarcodeNbr){

        return extractBpoGbsDao.getAllByBpoAndGbs(plateId , blockBarcodeNbr);
    }

    public List<ExtractBpoGBS> getAllByPlateAndMbId(String plateId, String mbId){

        return extractBpoGbsDao.getAllByBpoAndGbs(plateId , mbId);
    }

    public int deleteAllByBpo(String plateId){

        return extractBpoGbsDao.deleteAllByBpo(plateId);
    }

    public int deleteAllByGbs(String blockBarcodeNbr){

        return extractBpoGbsDao.deleteAllByGbs(blockBarcodeNbr);
    }

    public int deleteAllByBpoAndGbs(String plateId, String blockBarcodeNbr){

        return extractBpoGbsDao.deleteAllByBpoAndGbs(plateId, blockBarcodeNbr);
    }

    public int save(String plateId, String blockBarcodeNbr) {

        int numberOfRows = 0;

        try {
            numberOfRows = extractBpoGbsDao.save(plateId, blockBarcodeNbr);
        } catch(DataAccessException e){
        }
        return numberOfRows;
    }

    public ExtractBpoGbsDao getExtractBpoGbsDao() {
        return extractBpoGbsDao;
    }

    public void setExtractBpoGbsDao(ExtractBpoGbsDao extractBpoGbsDao) {
        this.extractBpoGbsDao = extractBpoGbsDao;
    }
}
