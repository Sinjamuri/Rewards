package com.monsanto.gwg.atlas.model.gbs;

import java.sql.Timestamp;

public class CherryPickSample {
  private String blockBarcodeNbr;
  private Integer sampleId;
  private String pedigreeOrigin;
  private String generation;
  private Double po;
  private Double het;
  private boolean control;
  private boolean dropped;
  private String wellAddress;
  private Integer markerCount;
  private String limsId;
  private Integer round;
  private String status;
  private String destBlock;
  private String destWell;
  private Integer destPosition;
  private Timestamp selectedTs;
  private Timestamp verifiedTs;
  private Timestamp reArrayTs;
  private Timestamp completeTs;
  private Timestamp acceptedTs;
  private Timestamp rejectedTs;
  private Long gbsCherryPickId;
  private Timestamp dueDate;
  private String glPlateId;
  private Integer glPlateQuad;
  private String userId;
  private Long torrentAnalysisId;
  private Integer barcodeAdapter;
  private Integer blockSampleTotal;
  private Integer blockSamplesPassed;
  private Double blockSamplesPassedPercent;

  public String getSampleOverrideEligible() {
    return sampleOverrideEligible;
  }

  public void setSampleOverrideEligible(String sampleOverrideEligible) {
    this.sampleOverrideEligible = sampleOverrideEligible;
  }

  private String sampleOverrideEligible;

  public String getBlockBarcodeNbr() {
    return blockBarcodeNbr;
  }

  public void setBlockBarcodeNbr(String blockBarcodeNbr) {
    this.blockBarcodeNbr = blockBarcodeNbr;
  }

  public Integer getSampleId() {
    return sampleId;
  }

  public void setSampleId(Integer sampleId) {
    this.sampleId = sampleId;
  }

  public String getPedigreeOrigin() {
    return pedigreeOrigin;
  }

  public void setPedigreeOrigin(String pedigreeOrigin) {
    this.pedigreeOrigin = pedigreeOrigin;
  }

  public String getGeneration() {
    return generation;
  }

  public void setGeneration(String generation) {
    this.generation = generation;
  }

  public Double getPo() {
    return po;
  }

  public void setPo(Double po) {
    this.po = po;
  }

  public Double getHet() {
    return het;
  }

  public void setHet(Double het) {
    this.het = het;
  }

  public boolean isControl() {
    return control;
  }

  public void setControl(boolean control) {
    this.control = control;
  }

  public boolean isDropped() {
    return dropped;
  }

  public void setDropped(boolean dropped) {
    this.dropped = dropped;
  }

  public String getWellAddress() {
    return wellAddress;
  }

  public void setWellAddress(String wellAddress) {
    this.wellAddress = wellAddress;
  }

  public Integer getMarkerCount() {
    return markerCount;
  }

  public void setMarkerCount(Integer markerCount) {
    this.markerCount = markerCount;
  }

  public String getLimsId() {
    return limsId;
  }

  public void setLimsId(String limsId) {
    this.limsId = limsId;
  }

  public Integer getRound() {
    return round;
  }

  public void setRound(Integer round) {
    this.round = round;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getDestBlock() {
    return destBlock;
  }

  public void setDestBlock(String destBlock) {
    this.destBlock = destBlock;
  }

  public String getDestWell() {
    return destWell;
  }

  public void setDestWell(String destWell) {
    this.destWell = destWell;
  }

  public Integer getDestPosition() {
    return destPosition;
  }

  public void setDestPosition(Integer destPosition) {
    this.destPosition = destPosition;
  }

  public Timestamp getSelectedTs() {
    return selectedTs;
  }

  public void setSelectedTs(Timestamp selectedTs) {
    this.selectedTs = selectedTs;
  }

  public Timestamp getVerifiedTs() {
    return verifiedTs;
  }

  public void setVerifiedTs(Timestamp verifiedTs) {
    this.verifiedTs = verifiedTs;
  }

  public Timestamp getReArrayTs() {
    return reArrayTs;
  }

  public void setReArrayTs(Timestamp reArrayTs) {
    this.reArrayTs = reArrayTs;
  }

  public Timestamp getCompleteTs() {
    return completeTs;
  }

  public void setCompleteTs(Timestamp completeTs) {
    this.completeTs = completeTs;
  }

  public Timestamp getAcceptedTs() {
    return acceptedTs;
  }

  public void setAcceptedTs(Timestamp acceptedTs) {
    this.acceptedTs = acceptedTs;
  }

  public Timestamp getRejectedTs() {
    return rejectedTs;
  }

  public void setRejectedTs(Timestamp rejectedTs) {
    this.rejectedTs = rejectedTs;
  }

  public Long getGbsCherryPickId() {
    return gbsCherryPickId;
  }

  public void setGbsCherryPickId(Long gbsCherryPickId) {
    this.gbsCherryPickId = gbsCherryPickId;
  }

  public Timestamp getDueDate() {
    return dueDate;
  }

  public void setDueDate(Timestamp dueDate) {
    this.dueDate = dueDate;
  }

  public String getGlPlateId() {
    return glPlateId;
  }

  public void setGlPlateId(String glPlateId) {
    this.glPlateId = glPlateId;
  }

  public Integer getGlPlateQuad() {
    return glPlateQuad;
  }

  public void setGlPlateQuad(Integer glPlateQuad) {
    this.glPlateQuad = glPlateQuad;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public Long getTorrentAnalysisId() {
    return torrentAnalysisId;
  }

  public void setTorrentAnalysisId(Long torrentAnalysisId) {
    this.torrentAnalysisId = torrentAnalysisId;
  }

  public Integer getBarcodeAdapter() {
    return barcodeAdapter;
  }

  public void setBarcodeAdapter(Integer barcodeAdapter) {
    this.barcodeAdapter = barcodeAdapter;
  }

  public Integer getBlockSampleTotal() {
    return blockSampleTotal;
  }

  public void setBlockSampleTotal(Integer blockSampleTotal) {
    this.blockSampleTotal = blockSampleTotal;
  }

  public Integer getBlockSamplesPassed() {
    return blockSamplesPassed;
  }

  public void setBlockSamplesPassed(Integer blockSamplesPassed) {
    this.blockSamplesPassed = blockSamplesPassed;
  }

  public Double getBlockSamplesPassedPercent() {
    return blockSamplesPassedPercent;
  }

  public void setBlockSamplesPassedPercent(Double blockSamplesPassedPercent) {
    this.blockSamplesPassedPercent = blockSamplesPassedPercent;
  }
}
