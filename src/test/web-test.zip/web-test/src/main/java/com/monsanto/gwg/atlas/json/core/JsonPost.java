package com.monsanto.gwg.atlas.json.core;

import java.util.List;
import java.util.Map;

/**
 * Row based container.
 * 
 * List<Map<String,String>> rows is a list of Map objects.  The Map<String,String>
 * is flexible and supports as many key/value pairs as needed for marshaling.
 * 
 * Row - id:4
 *       barcode1:E1234SDF234
 *       barcode2:E1234SDF235
 *		 reagent:342
 *
 * Row - id:5
 *       barcode1:E1234SDF236
 *       barcode2:E1234SDF237
 *		 reagent:342
 *
 * Row... to support as many rows as needed
 */

public class JsonPost {
	private List<Map<String,String>> rows;
  private String userId;

	public List<Map<String,String>> getRows() {
		return rows;
	}

	public void setRows(List<Map<String,String>> rows) {
		this.rows = rows;
	}

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }
}
