package com.monsanto.gwg.atlas.model.gbs;

import java.io.Serializable;
import java.sql.Timestamp;

public class WfNcr implements Serializable {

  private long wfId;
  private String EntityLabel;
  private String ncrName;
  private String wfStepName;
  private String createUser;
  private Timestamp createTs;
  private String comments;
  private int entityTypeId;
  private String display;


  public long getWfId() {
    return wfId;
  }

  public void setWfId(long wfId) {
    this.wfId = wfId;
  }


  public String getEntityLabel() {
    return EntityLabel;
  }

  public void setEntityLabel(String entityLabel) {
    EntityLabel = entityLabel;
  }

  public String getNcrName() {
    return ncrName;
  }

  public void setNcrName(String ncrName) {
    this.ncrName = ncrName;
  }

  public String getWfStepName() {
    return wfStepName;
  }

  public void setWfStepName(String wfStepName) {
    this.wfStepName = wfStepName;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public String getComments() {
    return comments;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public int getEntityTypeId() {
    return entityTypeId;
  }

  public void setEntityTypeId(int entityTypeId) {
    this.entityTypeId = entityTypeId;
  }

  public String getDisplay() {
    return display;
  }

  public void setDisplay(String display) {
    this.display = display;
  }
}
