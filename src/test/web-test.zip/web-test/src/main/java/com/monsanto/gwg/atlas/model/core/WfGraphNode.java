package com.monsanto.gwg.atlas.model.core;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */
public class WfGraphNode {

  private String nodeFrom;
  private String nodeTo;
  private WfGraphNodeData data;

  public WfGraphNode(String nodeFrom, String nodeTo, WfGraphNodeData data) {
    this.nodeFrom = nodeFrom;
    this.nodeTo = nodeTo;
    this.data = data;
  }

  public WfGraphNode() {
  }

  public String getNodeFrom() {
    return nodeFrom;
  }

  public void setNodeFrom(String nodeFrom) {
    this.nodeFrom = nodeFrom;
  }

  public String getNodeTo() {
    return nodeTo;
  }

  public void setNodeTo(String nodeTo) {
    this.nodeTo = nodeTo;
  }

  public WfGraphNodeData getData() {
    return data;
  }

  public void setData(WfGraphNodeData data) {
    this.data = data;
  }

}