package com.monsanto.gwg.atlas.json.sandwichshop;

/**
 * Created by REGAMA on 8/18/14.
 */
public class JsonSandwich {
    private String breadType;
    private String meatType;
    private String comments;
    private Integer cheeseSlices;
    private String toasted;

    public String getBreadType() {
        return breadType;
    }

    public void setBreadType(String breadType) {
        this.breadType = breadType;
    }

    public String getMeatType() {
        return meatType;
    }

    public void setMeatType(String meatType) {
        this.meatType = meatType;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Integer getCheeseSlices() {
        return cheeseSlices;
    }

    public void setCheeseSlices(Integer cheeseSlices) {
        this.cheeseSlices = cheeseSlices;
    }

    public String getToasted() {
        return toasted;
    }

    public void setToasted(String toasted) {
        this.toasted = toasted;
    }
}
