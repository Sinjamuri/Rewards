package com.monsanto.gwg.atlas.model.core;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */
public class WfGraphNodeData {

  private String $color;

  public WfGraphNodeData(String color) {
    this.$color = color;
  }

  public WfGraphNodeData() {
    }

  public String get$color() {
    return $color;
  }

  public void set$color(String $color) {
    this.$color = $color;
  }

}