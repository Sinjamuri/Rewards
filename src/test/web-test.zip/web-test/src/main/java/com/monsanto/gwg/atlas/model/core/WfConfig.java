package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;
import org.apache.commons.lang.StringUtils;

import java.sql.Timestamp;
import java.util.Set;
import java.util.TreeSet;

public class WfConfig {
  @DbColumn(field="wf_config_id")
  private Long wfConfigId;
  @DbColumn(field="wf_config_domain")
  private String wfConfigDomain;
  @DbColumn(field="wf_config_name")
  private String wfConfigName;
  @DbColumn(field="wf_config_admins")
  private Set<String> wfConfigAdmins;
  @DbColumn(field="create_user")
  private String createUser;
  @DbColumn(field="create_ts")
  private Timestamp createTs;

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getWfConfigDomain() {
    return wfConfigDomain;
  }

  public void setWfConfigDomain(String wfConfigDomain) {
    this.wfConfigDomain = wfConfigDomain;
  }

  public String getWfConfigName() {
    return wfConfigName;
  }

  public void setWfConfigName(String wfConfigName) {
    this.wfConfigName = wfConfigName;
  }

  public Set<String> getWfConfigAdmins() {
    return wfConfigAdmins;
  }

  public void setWfConfigAdmins(String wfConfigAdmins) {
    this.wfConfigAdmins = new TreeSet<String>();

    String[] vals = wfConfigAdmins.split(",");
    for (String val : vals) {
      if (val!=null && val.trim().length()>0) {
        this.wfConfigAdmins.add(val.trim().toUpperCase());
      }
    }
  }

  public String getWfConfigAdminsString() {
      return StringUtils.join(getWfConfigAdmins(), ",");
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }
}
