package com.monsanto.gwg.atlas.service.torrent;

import au.com.bytecode.opencsv.CSVWriter;
import com.amazonaws.util.IOUtils;
import com.monsanto.gwg.atlas.agent.common.AWSAuthUtil;
import com.monsanto.gwg.atlas.dao.core.WfConfigPropertyDao;
import com.monsanto.gwg.atlas.dao.core.WfDao;
import com.monsanto.gwg.atlas.dao.core.WfDao;
import com.monsanto.gwg.atlas.dao.torrent.*;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.model.core.WfConfigProperty;
import com.monsanto.gwg.atlas.model.torrent.TorrentAnalysis;
import com.monsanto.gwg.atlas.model.torrent.TorrentAnalysisVw;
import com.monsanto.gwg.atlas.model.torrent.TorrentReference;
import com.monsanto.gwg.atlas.model.torrent.TorrentRun;
import com.monsanto.gwg.atlas.service.annotations.WfDelegateMethod;
import com.monsanto.gwg.atlas.service.annotations.WfParam;
import com.monsanto.gwg.atlas.service.annotations.WfParamValue;
import com.monsanto.gwg.atlas.service.gbs.GbsService;
import com.monsanto.gwg.atlas.service.gbs.GbsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.List;
import java.util.Map;

@Service
public class TorrentService {

  private static final Logger LOG = LoggerFactory.getLogger(TorrentService.class);

  public static final long WF_CONFIG_ID = 4L;

  @Autowired
  private TorrentRunDao torrentRunDao;

  @Autowired
  private TorrentAnalysisDao torrentAnalysisDao;

  @Autowired
  private TorrentAnalysisVwDao torrentAnalysisVwDao;

  @Autowired
  private TorrentReferenceDao torrentReferenceDao;

  @Autowired
  private WfConfigPropertyDao wfConfigPropertyDao;

  @Autowired
  private GbsService gbsService;

  @Autowired
  private WfDao wfDao;


  public List<TorrentRun> findIndexes(String searchTerm) {
    //adjust for empty query
    if (searchTerm == null) {
      searchTerm = "";
    }
    return torrentRunDao.findIndexes(searchTerm);
  }

  public List<TorrentAnalysisVw> findAnalysis(String searchTerm) {
    //adjust for empty query
    if (searchTerm == null) {
      searchTerm = "";
    }
    return torrentAnalysisVwDao.findAnalysis(searchTerm);
  }

  @WfDelegateMethod(wfStepConfigId = 100)
  public JsonResponse post100(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    //validate all parameters and throw error back if any single submission fails
    for (Map<String, String> row : jsonPost.getRows()) {
      if (!(row.containsKey("wfdc100")) ||
              !(row.containsKey("wfdc101")) ||
              !(row.containsKey("wfdc102"))) {
        JsonResponse jsonResponse = new JsonResponse();
        jsonResponse.addError("You must select options for Marker Reference, QC Threshold & Barcode Index Plate to submit an analysis run!");
        return jsonResponse;
      }
    }

    //insert into torrent analysis table for agent to process
    for (Map<String, String> row : jsonPost.getRows()) {
      String wfId = row.get("wfId");
      Long nextTorrentAnalysisId = wfDao.getNextSeqId("torrent_analysis_id_seq");

      torrentAnalysisDao.createAnalysisRun(
              Long.parseLong(row.get("wfId")),
              row.get("wfdc100"),
              row.get("wfdc101"),
              Integer.parseInt(row.get("wfdc102")),
              userId,
              row.get("wfdc103"),
              row.get("wfdc104"),nextTorrentAnalysisId
      );
      wfDao.save (1L, nextTorrentAnalysisId.toString (), 40L, userId, 13L, wfDao.getNextId ());
      TorrentAnalysis torrentAnalysis = new TorrentAnalysis ();
      torrentAnalysis.setTorrentRunId (Long.parseLong (wfId));
      torrentAnalysis.setTorrentAnalysisId  (nextTorrentAnalysisId);
      gbsService.startManualStepFunctionsExecution (torrentAnalysis);
    }

    JsonResponse jsonResponse = new JsonResponse();
    jsonResponse.addMessage("Analysis runs have been submitted to the queue");
    return jsonResponse;
  }

  public String getReportZip(long torrentAnalysisId, OutputStream os) throws Exception {
    //write content to byte array stream
    os.write(torrentAnalysisDao.getReportZip(torrentAnalysisId));
    os.flush();

    //return torrent run name
    TorrentAnalysisVw torrentAnalysisVw = torrentAnalysisVwDao.find(torrentAnalysisId);
    return torrentAnalysisVw.getTorrentRunName();
  }

  public byte[] getReportFromS3(long torrentAnalysisId) throws Exception {

    WfConfigProperty bucketConfigProperty = wfConfigPropertyDao.findByWfConfigIdAndKey(1L, "S3_BUCKET_NAME_CF");
    String bucketName = bucketConfigProperty!=null ? bucketConfigProperty.getPropertyValue(): null;
    WfConfigProperty locationConfigProperty = wfConfigPropertyDao.findByWfConfigIdAndKey(1L, "S3_TORRENT_ANALYSIS_PATH");
    String location = locationConfigProperty !=null ? locationConfigProperty.getPropertyValue() : null;
    String fileName = torrentAnalysisId+".csv";
    try{
      if(bucketName!=null && fileName!=null){
        AWSAuthUtil util = new AWSAuthUtil();
        return util.getObject(bucketName,location + "/" + fileName);
      }else{
        LOG.warn("Bukcet name or File name is received as null for torrent id" +torrentAnalysisId);
      }
    }catch(Exception e){
      LOG.error("Error occurred while fetching data from s3 for torrent_analysis_id=" + torrentAnalysisId);
    }
    return null;
  }

  public String getAnalysisParameterFile(long torrentAnalysisId, OutputStream os) throws Exception {
    //write content to byte array stream
    os.write(torrentAnalysisDao.getAnalysisParameterFile(torrentAnalysisId).getBytes());
    os.flush();

    //return torrent run name
    TorrentAnalysisVw torrentAnalysisVw = torrentAnalysisVwDao.find(torrentAnalysisId);
    return torrentAnalysisVw.getTorrentRunName();
  }

  public List<TorrentReference> getTorrentReferences() {
    return torrentReferenceDao.findEnabledReferences();
  }

  public void updateAnalysisParameterFile(long torrentAnalysisId, String analysisParameterFile) {
    torrentAnalysisDao.updateAnalysisParameterFile(torrentAnalysisId, analysisParameterFile);
  }
}
