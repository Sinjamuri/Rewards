package com.monsanto.gwg.atlas.model.core;

/**
 * Created by PGROS1 on 6/24/14.
 */
public abstract class AbstractWfAsyncProcess implements WfAsyncProcess {
    public abstract void startProcess();
    public abstract void handleCancelProcess();

    private WfAsyncStatus status;
    private WfAsyncStatusUpdater statusUpdater;

    public void setWfAsyncStatus( WfAsyncStatus asyncProcessStatus ) {
        status = asyncProcessStatus;
    }
    public WfAsyncStatus getWfAsyncStatus() {
        return status;
    }

    public void setStatusUpdater( WfAsyncStatusUpdater wfAsyncStatusUpdater) {
        this.statusUpdater = wfAsyncStatusUpdater;
    }

    protected WfAsyncStatusUpdater getStatusUpdater() {
        return statusUpdater;
    }

    protected void updateStatus( boolean isDone ) {
        updateStatus( status.getMessage(), status.getProgressValue(), isDone );
    }

    protected void updateStatus( long newProgressValue ) {
        updateStatus( status.getMessage(), newProgressValue, status.getIsDone() );
    }

    protected void updateStatus( String message ) {
        updateStatus( message, status.getProgressValue(), status.getIsDone() );
    }

    protected void updateStatus( String message, boolean incrementProgress ) {
        updateStatus(message, status.getProgressValue() + 1, status.getIsDone());
    }

    protected void updateStatus( String message, long newProgressValue ) {
        updateStatus( message, newProgressValue, status.getIsDone() );
    }

    protected void updateStatus( String message, long newProgressValue, boolean isDone ) {
        status.setMessage( message );
        status.setProgressValue( newProgressValue );
        status.setIsDone( isDone );

        getStatusUpdater().commitStatusUpdate( status );
    }
}
