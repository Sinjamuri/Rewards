package com.monsanto.gwg.atlas.model.gbs;

public class MergeSourceRuns {
  private Long torrentAnalysisId1;
  private Long torrentAnalysisId2;

  public Long getTorrentAnalysisId1() {
    return torrentAnalysisId1;
  }

  public void setTorrentAnalysisId1(Long torrentAnalysisId1) {
    this.torrentAnalysisId1 = torrentAnalysisId1;
  }

  public Long getTorrentAnalysisId2() {
    return torrentAnalysisId2;
  }

  public void setTorrentAnalysisId2(Long torrentAnalysisId2) {
    this.torrentAnalysisId2 = torrentAnalysisId2;
  }
}
