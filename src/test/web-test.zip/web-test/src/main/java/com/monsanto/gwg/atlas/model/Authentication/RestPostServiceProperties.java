/*
 Copyright:  Copyright � 2016 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.gwg.atlas.model.Authentication;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author ATPINZ
 * @version $Revision$
 */
public class RestPostServiceProperties {

  private Object requestObj;
  private Class<?> requestClass;
  private Class<?> responseClass;
  private String serviceUrl;
  private String token;

  public RestPostServiceProperties(Object requestObj, Class<?> requestClass, Class<?> responseClass, String serviceUrl, String token) {
    this.requestObj = requestObj;
    this.requestClass = requestClass;
    this.responseClass = responseClass;
    this.serviceUrl = serviceUrl;
    this.token = token;
  }

  public Object getRequestObj() {
    return requestObj;
  }

  public void setRequestObj(Object requestObj) {
    this.requestObj = requestObj;
  }

  public Class<?> getRequestClass() {
    return requestClass;
  }

  public void setRequestClass(Class<?> requestClass) {
    this.requestClass = requestClass;
  }

  public Class<?> getResponseClass() {
    return responseClass;
  }

  public void setResponseClass(Class<?> responseClass) {
    this.responseClass = responseClass;
  }

  public String getServiceUrl() {
    return serviceUrl;
  }

  public void setServiceUrl(String serviceUrl) {
    this.serviceUrl = serviceUrl;
  }

  public String getToken() {
    return token;
  }

  public void setToken(String token) {
    this.token = token;
  }
}