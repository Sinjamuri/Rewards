package com.monsanto.gwg.atlas.json.admin;

/**
 * Created by regama on 6/5/14.
 */
public class JsonWfDataConfig {
    private Long wfDataConfigId;
    private Long wfConfigId;
    private String wfDataLabel;
    private String wfDataConfigType;
    private String wfDataConfigSearchable;
    private String createUser;

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public String getWfDataLabel() {
        return wfDataLabel;
    }

    public void setWfDataLabel(String wfDataLabel) {
        this.wfDataLabel = wfDataLabel;
    }

    public String getWfDataConfigType() {
        return wfDataConfigType;
    }

    public void setWfDataConfigType(String wfDataConfigType) {
        this.wfDataConfigType = wfDataConfigType;
    }

    public String getWfDataConfigSearchable() { return wfDataConfigSearchable; }

    public void setWfDataConfigSearchable(String wfDataConfigSearchable) {
        this.wfDataConfigSearchable = wfDataConfigSearchable;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Long getWfDataConfigId() {
        return wfDataConfigId;
    }

    public void setWfDataConfigId(Long wfDataConfigId) {
        this.wfDataConfigId = wfDataConfigId;
    }
}
