package com.monsanto.gwg.atlas.service.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ASHAR7 on 12/23/2014.
 */
@Service
public class ExcelFactory {

    @Autowired
    private XssfReader xssfReader;

    @Autowired
    private HssfReader hssfReader;

    public List<String> excelReader(String fileName, String createUser,
                                    InputStream resultsFileInputStream, String sheetName, int numberOfColumns, String fileSource){

        List<String> errorLogs = new ArrayList<String>();

        if(fileName.endsWith(".xlsx")){
            errorLogs = xssfReader.startReaderProcessing(fileName, createUser, resultsFileInputStream, sheetName, numberOfColumns, fileSource);


        } else if(fileName.endsWith(".xls")){
            errorLogs = hssfReader.startReaderProcessing(fileName, createUser, resultsFileInputStream, sheetName, numberOfColumns, fileSource);
        }

        return errorLogs;
    }
}
