package com.monsanto.gwg.atlas.service.dpcr;

import com.monsanto.gwg.atlas.service.dpcr.annotations.MethodOption;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by PGROS1 on 1/3/2015.
 *
 * This is a level of indirection from the AutoThresholder class which is adapted from ImageJ.
 * The indirection is necessary to limit the thresholding options we present, and to separate
 * that presentation layer from the actual thresholding implementations.
 */
public class PositiveThresholdAlgorithms {

    public static AutoThresholder thresholder = new AutoThresholder();

    @MethodOption( value = "li", text = "Li", isDefault = true)
    public static int li( int[] histogram ) {
        return thresholder.Li( histogram );
    }

    @MethodOption( value = "otsu", text = "Otsu", isDefault = false)
    public static int otsu( int[] histogram ) {
        return thresholder.Otsu( histogram );
    }

    @MethodOption(value = "manualThresholds", text = "Manual Thresholds", isDefault = false)
    public static Map<String, Float> manualThresholds( Map<String, String> fixedThresholds) {
        Map<String, Float> manualThresholdsMap = new HashMap<String, Float>();
        for( Map.Entry<String, String> fixedThreshold : fixedThresholds.entrySet() ) {
            manualThresholdsMap.put( fixedThreshold.getKey(), new Float( fixedThreshold.getValue() ));
        }

        return manualThresholdsMap;
    }
}
