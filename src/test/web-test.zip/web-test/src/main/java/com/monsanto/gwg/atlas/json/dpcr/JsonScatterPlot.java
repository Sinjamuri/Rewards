package com.monsanto.gwg.atlas.json.dpcr;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by pgros1 on 9/16/14.
 */
public class JsonScatterPlot {
    private String xAxisName;
    private String yAxisName;
    private String title;

    private Collection<ArrayList<String>> scatterPlotPoints;

    public String getxAxisName() {
        return xAxisName;
    }

    public void setxAxisName(String xAxisName) {
        this.xAxisName = xAxisName;
    }

    public String getyAxisName() {
        return yAxisName;
    }

    public void setyAxisName(String yAxisName) {
        this.yAxisName = yAxisName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Collection<ArrayList<String>> getScatterPlotPoints() {
        return scatterPlotPoints;
    }

    public void setScatterPlotPoints(Collection<ArrayList<String>> scatterPlotPoints) {
        this.scatterPlotPoints = scatterPlotPoints;
    }
}
