package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

/**
 * Created by regama on 9/25/14.
 */
public class WfGridAssocVw {
    @DbColumn(field = "wf_config_id")
    private Long wfConfigId;
    @DbColumn(field = "wf_id")
    private Long wfContainerId;
    @DbColumn(field = "container_entity_type_id")
    private Long containerEntityTypeId;
    @DbColumn(field = "container_entity_type_label")
    private String containerEntityTypeLabel;
    @DbColumn(field = "container_label")
    private String containerLabel;
    @DbColumn(field = "grid_col")
    private Integer gridCol;
    @DbColumn(field = "grid_row")
    private Integer gridRow;
    @DbColumn(field = "grid_pos_label")
    private String gridPosLabel;
    @DbColumn(field = "grid_pos_status")
    private String gridPosStatus;
    @DbColumn(field = "wf_entity_id")
    private Long wfEntityId;
    @DbColumn(field = "entity_type_id")
    private Long entityTypeId;
    @DbColumn(field = "entity_type_label")
    private String entityTypeLabel;
    @DbColumn(field = "entity_label")
    private String entityLabel;

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public Long getWfContainerId() {
        return wfContainerId;
    }

    public void setWfContainerId(Long wfContainerId) {
        this.wfContainerId = wfContainerId;
    }

    public Long getContainerEntityTypeId() {
        return containerEntityTypeId;
    }

    public void setContainerEntityTypeId(Long containerEntityTypeId) {
        this.containerEntityTypeId = containerEntityTypeId;
    }

    public String getContainerLabel() {
        return containerLabel;
    }

    public void setContainerLabel(String containerLabel) {
        this.containerLabel = containerLabel;
    }

    public Integer getGridCol() {
        return gridCol;
    }

    public void setGridCol(Integer gridCol) {
        this.gridCol = gridCol;
    }

    public Integer getGridRow() {
        return gridRow;
    }

    public void setGridRow(Integer gridRow) {
        this.gridRow = gridRow;
    }

    public String getGridPosLabel() {
        return gridPosLabel;
    }

    public void setGridPosLabel(String gridPosLabel) {
        this.gridPosLabel = gridPosLabel;
    }

    public String getGridPosStatus() {
        return gridPosStatus;
    }

    public void setGridPosStatus(String gridPosStatus) {
        this.gridPosStatus = gridPosStatus;
    }

    public Long getWfEntityId() {
        return wfEntityId;
    }

    public void setWfEntityId(Long wfEntityId) {
        this.wfEntityId = wfEntityId;
    }

    public Long getEntityTypeId() {
        return entityTypeId;
    }

    public void setEntityTypeId(Long entityTypeId) {
        this.entityTypeId = entityTypeId;
    }

    public String getEntityLabel() {
        return entityLabel;
    }

    public void setEntityLabel(String entityLabel) {
        this.entityLabel = entityLabel;
    }

    public String getContainerEntityTypeLabel() {
        return containerEntityTypeLabel;
    }

    public void setContainerEntityTypeLabel(String containerEntityTypeLabel) {
        this.containerEntityTypeLabel = containerEntityTypeLabel;
    }

    public String getEntityTypeLabel() {
        return entityTypeLabel;
    }

    public void setEntityTypeLabel(String entityTypeLabel) {
        this.entityTypeLabel = entityTypeLabel;
    }
}
