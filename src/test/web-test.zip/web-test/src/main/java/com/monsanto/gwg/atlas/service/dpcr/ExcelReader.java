package com.monsanto.gwg.atlas.service.dpcr;

import com.monsanto.gwg.atlas.dao.core.WfDao;
import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.dao.core.WfGridAssocDao;
import com.monsanto.gwg.atlas.dao.core.WfRefConfigDao;
import com.monsanto.gwg.atlas.dao.dpcr.DPcrPlateDao;
import com.monsanto.gwg.atlas.model.core.Wf;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.model.core.WfGridAssoc;
import com.monsanto.gwg.atlas.model.dpcr.DPcrPlate;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.util.UtilityMethodsImpl;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.Timestamp;
import java.util.*;

/**
 * Created by ASHAR7 on 12/23/2014.
 */
public class ExcelReader implements DPcrConstants {

    @Autowired
    private DPcrPlateDao dPcrPlateDao;

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfDao wfDao;

    @Autowired
    private WfGridAssocDao wfGridAssocDao;

    @Autowired
    private WfRefConfigDao wfRefConfigDao;

    @Autowired
    private WfService wfService;

    @Autowired
    private DataSourceTransactionManager txManager;

    String createUser = "";
    int numberOfColumns = 0;

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public int getNumberOfColumns() {
        return numberOfColumns;
    }

    public void setNumberOfColumns(int numberOfColumns) {
        this.numberOfColumns = numberOfColumns;
    }


    /**
     * reads row by row starting with second row and populates the Object
     * returns the grid list.
     * @param rowsList List of rows frm the excel
     */
    protected List<String> processRows(List<Row> rowsList) throws  Exception{

        List<Object[]> rowArrayList = new ArrayList<Object[]>();

        List<String> errorLogs = new ArrayList<String>();

        //Iterate through each rows from first sheet
        //Do not want to read the first line - column names
        for(int i = 0 ; i < rowsList.size() ; i++){
            Row row = rowsList.get(i);
            if(null != row && 0 < row.getPhysicalNumberOfCells()){
                Object[] rowArray = readRowIntoCustomObject(createUser,
                        row, numberOfColumns, errorLogs, i);
                if(!errorLogs.isEmpty()){
                    break;
                }
                if(null != rowArray && null != rowArray[7] && !((String) rowArray[7]).isEmpty()){
                    rowArrayList.add(rowArray);
                }
            }
        }

        if(errorLogs.isEmpty()){
            saveData(rowArrayList);
        }

        return errorLogs;
    }

    private void saveData(final List<Object[]> rowArrayList) {

        TransactionCallback transactionCallback = new TransactionCallback() {
            @Override
            public Object doInTransaction(TransactionStatus transactionStatus) {

                List<WfGridAssoc> gridAssocList = savePlateData(rowArrayList);
                saveGridAssocData(gridAssocList);
                movePlatesToWaitingStep( gridAssocList, createUser );
                return null;
            }
        };

        TransactionTemplate tt = new TransactionTemplate();
        tt.setTransactionManager(txManager);
        tt.execute(transactionCallback);
    }

    private List<WfGridAssoc> savePlateData(List<Object[]> rowArrayList) {

        Map<String,DPcrPlate> wfMap = new HashMap<String,DPcrPlate>();

        List<WfGridAssoc> gridAssocList = new ArrayList<WfGridAssoc>();

        for(Object[] rowArray : rowArrayList){

            String plateName = (String) rowArray[7];
            //get the plate
            DPcrPlate plate;
            if (null != wfMap && !wfMap.containsKey(plateName)) {
                plate = createPlate(plateName, createUser);

                wfMap.put(plateName, plate);
            } else {
                plate = wfMap.get(plateName);
            }

            Wf sample = (Wf) rowArray[0];
            sample = wfDao.save(sample);

            WfData wfData = (WfData) rowArray[1];
            wfDataDao.save(sample.getWfId(),wfData.getWfDataConfigId(),wfData.getWfDataVarchar2());

            wfData = (WfData) rowArray[2];
            wfDataDao.save(sample.getWfId(),wfData.getWfDataConfigId(),wfData.getWfDataVarchar2());

            wfData = (WfData) rowArray[3];
            wfDataDao.save(sample.getWfId(),wfData.getWfDataConfigId(),wfData.getWfDataVarchar2());

            wfData = (WfData) rowArray[4];
            wfDataDao.save(sample.getWfId(),wfData.getWfDataConfigId(),wfData.getWfDataVarchar2());

            wfData = (WfData) rowArray[5];
            wfDataDao.save(sample.getWfId(),wfData.getWfDataConfigId(),wfData.getWfDataTimestamp());

            //get the grid assoc and save it as a batch
            WfGridAssoc wfGridAssoc = (WfGridAssoc) rowArray[6];
            wfGridAssoc.setWfId(plate.getWfId());

            gridAssocList.add(wfGridAssoc);
        }

        return gridAssocList;
    }

    protected void movePlatesToWaitingStep( List<WfGridAssoc> wfGridAssocs, String createUser ) {
        Set<Long> plateWfIds = new HashSet<Long>();
        for( WfGridAssoc wfGridAssoc : wfGridAssocs ) {
            plateWfIds.add( wfGridAssoc.getWfId() );
        }

        moveWfsToWaitingStep( new LinkedList( plateWfIds ), createUser);
    }

    protected void moveWfsToWaitingStep( List<Long> wfIds, String createUser ) {
        for(Long wfId : wfIds ) {
            wfService.passSingleWf( wfId, createUser, DPCR_WAIT_FOR_DATA_WF_STEP_CONFIG_ID );
        }
    }

    /**
     * reads a single row at a time
     * create a plate if not already present
     * save the sample entity
     * return the grid assoc to be added to the list
     * @param createUser user name
     * @param row excel row
     * @param numberOfColumns number of columns expected in a row
     * @param errorLogs
     * @param rowNum
     * @return WfGridAssoc grid data object for the row
     * @throws Exception may result due to bad data in the row.
     */
    private Object[] readRowIntoCustomObject(String createUser,
                     Row row, int numberOfColumns, List<String> errorLogs, int rowNum)
            throws Exception{

        Object[] rowDataArray = new Object[8];

        String plateName = "";
        String cropType = "";
        String tissueType = "";
        String marker = "";
        String sampleName = "";
        String comment = "";
        Date date = new Date();
        String sampleWell = "";

        for(int i = 0 ; i < numberOfColumns; i++) {
            Cell cell = row.getCell(i, Row.RETURN_BLANK_AS_NULL);
            if (null != cell) {

                switch (i) {
                    case 0:
                        plateName = cell.getStringCellValue().trim();
                        break;
                    case 1:
                        cropType = cell.getStringCellValue().trim();
                        break;
                    case 2:
                        tissueType = cell.getStringCellValue().trim();
                        break;
                    case 3:
                        marker = cell.getStringCellValue().trim();
                        break;
                    case 4:
                        sampleWell = cell.getStringCellValue().trim();
                        break;
                    case 5:
                        sampleName = cell.getStringCellValue().trim();
                        break;
                    case 6:
                        comment = cell.getStringCellValue().trim();
                        break;
                    case 7:
                        if (DateUtil.isCellDateFormatted(cell)) {
                            date = cell.getDateCellValue();
                        }
                        break;
                }
            }
        }

        String errorLog = "";

        if(!plateName.isEmpty()) {
            errorLog = validateData(plateName, cropType, tissueType, rowNum);

            if (errorLog.isEmpty()) {

                //get the  sample
                Wf sample = new Wf();
                sample.setWfConfigId(DPCR_WF_CONFIG_ID);
                sample.setWfEntityTypeId(DPCR_SAMPLE_WF_ENTITY_TYPE_ID);
                sample.setWfEntityLabel(sampleName);
                sample.setWfStepConfigId(DPCR_SAMPLE_ASSOC_WF_STEP_CONFIG_ID);
                sample.setCreateUser(createUser);
                rowDataArray[0] = sample;

                WfData cropTypeWfData = new WfData();
                cropTypeWfData.setWfDataConfigId(DPCR_CROP_TYPE_WF_DATA_CONFIG_ID);
                cropTypeWfData.setWfDataVarchar2(cropType);
                rowDataArray[1] = cropTypeWfData;

                WfData tissueTypeWfData = new WfData();
                tissueTypeWfData.setWfDataConfigId(DPCR_TISSUE_TYPE_WF_DATA_CONFIG_ID);
                tissueTypeWfData.setWfDataVarchar2(tissueType);
                rowDataArray[2] = tissueTypeWfData;

                WfData markerWfData = new WfData();
                markerWfData.setWfDataConfigId(DPCR_MARKER_WF_DATA_CONFIG_ID);
                markerWfData.setWfDataVarchar2(marker);
                rowDataArray[3] = markerWfData;

                WfData commentData = new WfData();
                commentData.setWfDataConfigId(DPCR_COMMENT_WF_DATA_CONFIG_ID);
                commentData.setWfDataVarchar2(comment);
                rowDataArray[4] = commentData;

                WfData createsTsWfData = new WfData();
                createsTsWfData.setWfDataConfigId(DPCR_CREATE_DATE_WF_DATA_CONFIG_ID);
                createsTsWfData.setWfDataTimestamp(new Timestamp(date.getTime()));
                rowDataArray[5] = createsTsWfData;

                WfGridAssoc wfGridAssoc = new WfGridAssoc();
                String rowAndColumnArray[] = UtilityMethodsImpl.splitAndGetNumericPosition(sampleWell);
                wfGridAssoc.setGridRow(Integer.valueOf(rowAndColumnArray[0]));
                wfGridAssoc.setGridCol(Integer.valueOf(rowAndColumnArray[1]));
                wfGridAssoc.setLabel(sampleWell);
                wfGridAssoc.setWfConfigId(DPCR_WF_CONFIG_ID);
                rowDataArray[6] = wfGridAssoc;

                rowDataArray[7] = plateName;

            } else {
                errorLogs.add(errorLog);
            }
        }
        return rowDataArray;
    }

    /**
     * creates a plate workflow for plate entity id in WF table
     * then stores the plate specific metadata to WF_DATA table
     * @param plateName plate name column from the excel
     * @param uploadUser user name
     * @return DPcrPlate
     */
    private DPcrPlate createPlate(String plateName, String uploadUser) {

        DPcrPlate plate = new DPcrPlate();
        plate.setWfConfigId( DPCR_WF_CONFIG_ID );
        plate.setWfEntityTypeId(DPCR_PLATE_WF_ENTITY_TYPE_ID);
        plate.setPlateImagingId(plateName);
        plate.setWfStepConfigId( DPCR_SAMPLE_WF_STEP_CONFIG_ID );
        plate.setCreateUser( uploadUser );

        plate = dPcrPlateDao.save(plate);

        wfDataDao.save( plate.getWfId(), DPCR_PLATE_NAME_WF_DATA_CONFIG_ID, plateName );

        return plate;
    }

    /**
     * saves the grid assoc list to database as a batch
     * @param recordsList list of assoc records
     */
    private void saveGridAssocData(List<WfGridAssoc> recordsList) {

        wfGridAssocDao.batchSaveGridAssoc(recordsList);
    }

    /**
     * validate data for business rules
     * @param plateName plate name should be unique in database
     * @param cropType crop type should confirm to ref config in database
     * @param tissueType tissue type should confirm to ref config in database
     * @param rowNum
     * @return
     */
    private String validateData(String plateName, String cropType, String tissueType,
                                int rowNum) {

        boolean isValid = true;
        String errorLog = "";

        isValid = isPlateNameValid(plateName);

        if(isValid){
            isValid = isRefTypeValid(cropType, WF_REF_CONFIG_KEY_CROP, DPCR_WF_CONFIG_ID);
        }else{
            errorLog = "Row "+ rowNum +" - Plate Name Already Exists - "+plateName;
            return errorLog;
        }

        if(isValid){
            isValid = isRefTypeValid(tissueType, WF_REF_CONFIG_KEY_TISSUE, DPCR_WF_CONFIG_ID);
        }else{
            errorLog = "Row "+ rowNum +" - Invalid Crop Type - "+cropType;
            return errorLog;
        }

        if(!isValid){
            errorLog = "Row "+ rowNum +" - Invalid Tissue Type - "+tissueType;
            return errorLog;
        }

        return errorLog;
    }

    private boolean isPlateNameValid(String plateName) {
        boolean isValid = true;

        long numberOfPlates = dPcrPlateDao.countPlateNames(plateName,DPCR_WF_CONFIG_ID, DPCR_PLATE_WF_ENTITY_TYPE_ID);

        if(0 < numberOfPlates){
            isValid = false;
        }
        return isValid;
    }

    private boolean isRefTypeValid(String childType, String ref_key, long wfConfigId) {

        boolean isValid = true;

        List<String> refList = wfRefConfigDao.getWfRefChildConfigForWfConfig(wfConfigId, ref_key);

        if((null != refList && !refList.isEmpty()) && !refList.contains(childType.trim())){
            isValid = false;
        }
        return isValid;
    }
}
