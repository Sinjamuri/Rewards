package com.monsanto.gwg.atlas.service.stltaqmanService;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.monsanto.gwg.atlas.agent.common.AWSAuthUtil;
import com.monsanto.gwg.atlas.agent.common.utils.UtilCommon;
import com.monsanto.gwg.atlas.agent.common.utils.WfUtilCommon;
import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.model.admin.WfGraphLink;
import com.monsanto.gwg.atlas.model.admin.WfGraphNodeFactory;
import com.monsanto.gwg.atlas.model.core.*;
import com.monsanto.gwg.atlas.model.gbs.CherryPickSample;
import com.monsanto.gwg.atlas.service.DetailServiceResponse;
import com.monsanto.gwg.atlas.service.UtilService;
import com.monsanto.gwg.atlas.service.WellSample;
import com.monsanto.gwg.atlas.service.admin.AdminService;
import com.monsanto.gwg.atlas.service.annotations.WfDelegateMethod;
import com.monsanto.gwg.atlas.service.annotations.WfParam;
import com.monsanto.gwg.atlas.service.annotations.WfParamValue;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.pcrExt.PcrExtService;
import com.monsanto.gwg.atlas.service.util.AWSV4Auth;
import com.monsanto.gwg.atlas.service.util.AuthenticationUtil;
import com.monsanto.gwg.atlas.service.util.UtilityMethodsImpl;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;
import java.io.*;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.jdbc.core.JdbcTemplate;


/**
 * Created by ashar7 on 8/27/15.
 */
@Service
public class StltaqmanService implements StltaqmanConstants {

  private static final Logger LOG = LoggerFactory.getLogger(StltaqmanService.class);

  @Autowired
  private WfDao wfDao;

  @Autowired
  private WfDataDao wfDataDao;

  @Autowired
  private WfGridDataDao wfGridDataDao;

  @Autowired
  private WfPlateMapDao wfPlateMapDao;

  @Autowired
  private WfService wfService;

  @Autowired
  private UtilService utilService;

  @Autowired
  private AdminService adminService;

  @Autowired
  private WfAssocDao wfAssocDao;

  @Autowired
  private WfEntityTypeDao wfEntityTypeDao;

  @Autowired
  private WfNcrConfigDao wfNcrConfigDao;

  @Autowired
  private WfGridAssocDao wfGridAssocDao;

  @Autowired
  private XRobotJobDao xRobotJobDao;

  @Autowired
  private XRobotTransferTskDao xRobotTransferTskDao;

  @Autowired
  private JdbcTemplate jdbcTemplate;

  @Autowired
  private WfStepConfigDao wfStepConfigDao;

  @WfDelegateMethod(wfStepConfigId = 3000)
  public JsonResponse post3000(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = null;

    try {

      wfService.savePostData(jsonPost);
      wfService.passAllWf(jsonPost, null);

    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;
  }

  @WfDelegateMethod(wfStepConfigId = 3005)
  public JsonResponse post3005(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = null;

    try {
      wfService.savePostData(jsonPost);
      wfService.passAllWf(jsonPost, null);
    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);

      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }
    return jsonResponse;
  }

  @WfDelegateMethod(wfStepConfigId = 3010)
  public JsonResponse post3010(
      @WfParam(WfParamValue.USER_ID) String userId,
      @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    try {
      wfService.savePostData(jsonPost);
      wfService.passAllWf(jsonPost, null);

    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);
      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }

    return jsonResponse;
  }


    @WfDelegateMethod(wfStepConfigId = 3015)
    public JsonResponse post3015(
            @WfParam(WfParamValue.USER_ID) String userId,
            @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

        JsonResponse jsonResponse = new JsonResponse();
        Map<String, Map<Integer, Long>> ePlateMap = new HashMap<String, Map<Integer, Long>>();
        Map<Integer, Long> posWithWfIdMap = null;


        try {
            List<WfPlateMap> wfPlateMapList = wfPlateMapDao.getWfPlateMap(1L, "BIOCELL_96_TO_384");
            Map<Integer, List<WfPlateMap>> wfPlateMap = wfPlateMapList.stream().collect(Collectors.groupingBy(WfPlateMap::getSourceQuadrant));

            for (Map<String, String> postData : jsonPost.getRows()) {
                //extract wfId to associate data
                Long wfId = Long.parseLong(postData.get("wfId"));
                String ePlateBarcode = postData.get("wfdc3066");
                String biomekDeckPosition = postData.get("wfdc43");
                int pos = 0;
                if ((biomekDeckPosition.equals("PRECIP1")) || (biomekDeckPosition.equals("PRECIP5"))) {
                    pos = 1;
                } else if ((biomekDeckPosition.equals("PRECIP2")) || (biomekDeckPosition.equals("PRECIP6"))) {
                    pos = 2;
                } else if ((biomekDeckPosition.equals("PRECIP3")) || (biomekDeckPosition.equals("PRECIP7"))) {
                    pos = 3;
                } else if ((biomekDeckPosition.equals("PRECIP4")) || (biomekDeckPosition.equals("PRECIP8"))) {
                    pos = 4;
                }

                if (ePlateMap.containsKey(ePlateBarcode)) {
                    ePlateMap.get(ePlateBarcode).putIfAbsent(pos, wfId);
                } else {
                    posWithWfIdMap = new HashMap<>();
                    posWithWfIdMap.put(pos, wfId);
                    ePlateMap.put(ePlateBarcode, posWithWfIdMap);
                }
            }

            for (String ePlateBarcode : ePlateMap.keySet()) {
                Long ePlateWfId = null;
                posWithWfIdMap = ePlateMap.get(ePlateBarcode);
                for (Integer quad : posWithWfIdMap.keySet()) {

                    if (ePlateWfId == null) {
                        Map<Long, String> fromWfIdMap = new HashMap<Long, String>();
                        for (Long fromWfId : posWithWfIdMap.values()) {
                            fromWfIdMap.put(fromWfId, ePlateBarcode);

                        }
                        ePlateWfId = wfDao.combineTo(WF_CONFIG_ID, ePlateBarcode, fromWfIdMap, EXTRACTION_COMPLETE_STEP_CONFIG_ID, userId, EPLATE_ENTITY_ID);
                        wfDataDao.save(ePlateWfId, PCR_PLATE_DATA_CONFIG_ID, ePlateBarcode);
                        wfDataDao.save(ePlateWfId, RUN_TYPE_DATA_CONFIG_ID, "BIOMEK");
                        String requestId = ePlateBarcode.substring(2, ePlateBarcode.indexOf('-'));
                        long requestWfId = wfDao.getWfId(requestId, REQUEST_ENTITY_TYPE_ID);
                        wfDataDao.copyDataWithDifferentWfId(requestWfId, ePlateWfId);
                        Integer numberOfAssays= wfDataDao.getCountByWfDataConfigId(requestWfId,MARKER_REFERENCE_ID_DATA_CONFIG_ID);
                        wfDataDao.save(ePlateWfId,ASSAYS_COUNT_DATA_CONFIG_ID,numberOfAssays);
                        int elutionFactor = Math.toIntExact((numberOfAssays/8) + 1);
                        wfDataDao.save(ePlateWfId,ELUTION_FACTOR_DATA_CONFIG_ID,elutionFactor);
                        copyRedoDataToEPlate(fromWfIdMap,ePlateWfId);
                    }

                    List<WfPlateMap> wfPlateMapByQuadList = wfPlateMap.get(quad);
                    Map<String, WfPlateMap> wfPlateMapByQuad = wfPlateMapByQuadList.stream().collect(Collectors.toMap(WfPlateMap::getSourceRowCol, Function.identity()));
                    List<WfGridAssoc> wfGridAssocList = wfGridAssocDao.findAll(posWithWfIdMap.get(quad));
                    List<WfGridAssoc> destWfGridAssocList = new ArrayList<>();
                    List<WfGridData> gridDataList = new ArrayList<>();
                    for (WfGridAssoc sourceGridAssoc : wfGridAssocList) {
                        WfPlateMap destWfPlateMap = wfPlateMapByQuad.get(sourceGridAssoc.getGridRow() + "" + sourceGridAssoc.getGridCol());
                        WfGridAssoc destGrid = new WfGridAssoc();
                        destGrid.setWfConfigId(WF_CONFIG_ID);
                        destGrid.setWfId(ePlateWfId);
                        destGrid.setStatus(sourceGridAssoc.getStatus());
                        destGrid.setWfGridId(sourceGridAssoc.getWfGridId());
                        destGrid.setGridCol(destWfPlateMap.getDestCol());
                        destGrid.setGridRow(destWfPlateMap.getDestRow());
                        destGrid.setLabel(destWfPlateMap.getDestWellName());
                        destWfGridAssocList.add(destGrid);

                        WfGridData gridData = new WfGridData();
                        gridData.setWfId(ePlateWfId);
                        gridData.setWfGridId(sourceGridAssoc.getWfGridId());
                        gridData.setValueVarchar2(ePlateBarcode);
                        gridData.setWfGridDataConfigId(E_PLATEBARCODE_GRID_DATA_TYPE);
                        gridDataList.add(gridData);
                    }
                    wfGridAssocDao.batchSaveGridAssoc(destWfGridAssocList);
                    wfGridDataDao.batchSaveGridData(gridDataList);
                }

            }
        } catch (Exception ex) {
            LOG.error("Method invocation error", ex);
            //send exception to the UI to be logged by console
            jsonResponse = new JsonResponse();
            jsonResponse.setException(utilService.getStackTrace(ex));
        }
        return jsonResponse;
    }

  @WfDelegateMethod(wfStepConfigId = 3018)
  public JsonResponse post3018(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    try {
      //Change Wf_status to 'H' so that, PcrPlate Agent picks up and creates PCR Plates
      for(Map<String,String> jsonPostData : jsonPost.getRows()) {
        long ePlateWfId =  Long.parseLong(jsonPostData.get("wfId"));
        wfDao.updateWfStatus(ePlateWfId, STATUS_HOLD,jsonPost.getUserId());
      }

    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);
      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }

    return jsonResponse;
  }

  @WfDelegateMethod(wfStepConfigId = 3030)
  public JsonResponse post3030(
          @WfParam(WfParamValue.USER_ID) String userId,
          @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    try {
      wfService.savePostData(jsonPost);
      wfService.passAllWf(jsonPost, null);

    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);
      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }

    return jsonResponse;
  }

  /**
   * Delegate method triggered when users save PCR plates in Pre-PCR Assembly.
   * Check to make sure there are a proper number of assay plates (<24)
   * Creates Autotool job and transfer tasks
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 3020)
  public JsonResponse post3020(
    @WfParam(WfParamValue.USER_ID) String userId,
    @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost
  ) {
    JsonResponse jsonResponse = new JsonResponse();
    Map<String, List<Long>> plateListMapByJobType = new HashMap<String, List<Long>>();
    List<Long> raptorPlates = new ArrayList<Long>();
    List<Long> offlinePlates = new ArrayList<Long>();
    String raptorJobType = null;

    // Get info for each pcr plate and add it to a job list (either Raptor or Offline)
    for(Map<String,String> jsonPostData : jsonPost.getRows()) {
      Long pcrPlateWfId = Long.parseLong(jsonPostData.get("wfId"));

      try {
        // Job type can be Raptor1, Raptor2, or Offline
        String jobType = jsonPostData.get("wfdc3077");
        if(jobType.contains("Raptor")) {
          raptorPlates.add(pcrPlateWfId);
          raptorJobType = jobType;
        } else if(jsonPostData.get("wfdc3077").equals("Offline")) {
          offlinePlates.add(pcrPlateWfId);
        }
      } catch (Exception ex) {
        LOG.error("Method invocation error", ex);
        jsonResponse.setException(utilService.getStackTrace(ex));
      }
    }

    if(raptorPlates.size() > 0) {
      plateListMapByJobType.put("RAPTOR", raptorPlates);
    }

    if(offlinePlates.size() > 0) {
      plateListMapByJobType.put("OFFLINE", offlinePlates);
    }

    // Create Autotool jobs for raptor and offline
    String finalRaptorJobType = raptorJobType;
    plateListMapByJobType.forEach((jobType, plateList) -> {
      try {
        String prefix = userId;
        Date date = new Date();
        String formattedDate = new SimpleDateFormat("MMddYY", Locale.ENGLISH).format(date);
        prefix = prefix + formattedDate;

        List<Long> robotJobIds = xRobotJobDao.findRobotJobIdsByNameLike(prefix);
        int incrementor =robotJobIds.size();

        prefix = prefix + "_" + String.format("%03d", incrementor + 1);
        String robotJobName = prefix;

        Long robotJobId = xRobotJobDao.createAutotoolJobTaqman(robotJobName, jobType, "MBQC", "US_MO_CV");

        for( Long wfId : plateList ) {
          try {
            if(jobType.contains("RAPTOR")) {
              wfDataDao.save(wfId, StltaqmanConstants.RAPTOR_JOB_ID, robotJobId.intValue());
              if(finalRaptorJobType.equals("Raptor1")) {
                wfDataDao.save(wfId, StltaqmanConstants.NUMBER_OF_TEMPESTS_DATA_CONFIG_ID, 1);
              } else {
                wfDataDao.save(wfId, StltaqmanConstants.NUMBER_OF_TEMPESTS_DATA_CONFIG_ID, 2);
              }
            } else {
              wfDataDao.save(wfId, StltaqmanConstants.OFFLINE_JOB_ID_DATA_CONFIG_ID, robotJobId.intValue());
            }
            wfDataDao.save(wfId, StltaqmanConstants.AUTOTOOL_JOB_NAME_DATA_CONFIG_ID, robotJobName);
            wfDataDao.save(wfId, StltaqmanConstants.PCR_EXT_STATUS_DATA_CONFIG_ID, "Transfer Tasks pending...");
          } catch (Exception ex) {
            LOG.error("Method invocation error", ex);
            jsonResponse.setException(utilService.getStackTrace(ex));
          }
        }
      } catch (Exception ex) {
        LOG.error("Method invocation error", ex);
        jsonResponse.setException(utilService.getStackTrace(ex));
      }
    });

    // If everything checks out, post the sample group list to S3 to be processed by the CherryPickPlateAssemblyAgent
    /*try {
      WfConfigProperty accessKey = wfService.findByWfConfigIdAndKey(30, "ACCESS_KEY_ID");
      WfConfigProperty accessSecret = wfService.findByWfConfigIdAndKey(30, "SECRET_ACCESS_KEY");
      WfConfigProperty region = wfService.findByWfConfigIdAndKey(30, "URL_CP_SAMPLE_GROUPS_SUBMISSION_S3_ACCESS_REGION");
      WfConfigProperty bucketName = wfService.findByWfConfigIdAndKey(30, "URL_CP_SAMPLE_GROUPS_SUBMISSION_S3_BUCKET_NAME");
      WfConfigProperty objPrefix = wfService.findByWfConfigIdAndKey(30, "URL_CP_SAMPLE_GROUPS_SUBMISSION_S3_OBJ_KEY_PREFIX");

      BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKey.getValueVarchar2(), accessSecret.getValueVarchar2());
      AWSLambda lambdaClient = AmazonLa.standard()
        .withRegion(region.getValueVarchar2())
        .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
        .build();

      String streamString = "{ \"sampleGroup\": " + wfIds.toString() + "}";
      InputStream stream = new ByteArrayInputStream(streamString.getBytes());
      PutObjectRequest s3upload = new PutObjectRequest(bucketName.getValueVarchar2(), objPrefix.getValueVarchar2() + new SimpleDateFormat("MM.dd.yyyy_HH:mm:ss").format(new Date()) + ".json", stream, null);
      s3Client.putObject(s3upload);

      for (Long wfId : wfIds) {
        wfDataDao.save(wfId, STATUS_DATA_CONFIG_ID, "Adding samples to cherry pick plate(s)...");
      }
    } catch (Exception e) {
      jsonResponse.addError(e.toString());
    } */

    return jsonResponse;
  }

  /**
   * Delegate method triggered when users want to advance Raptor job manually.
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 3025)
  public JsonResponse post3025(
    @WfParam(WfParamValue.USER_ID) String userId,
    @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost
  ) {
    JsonResponse jsonResponse = new JsonResponse();

    for(Map<String,String> jsonPostData : jsonPost.getRows()) {
      Long jobGroupWfId = Long.parseLong(jsonPostData.get("wfId"));
      WfData raptorJobIdData = wfDataDao.getValue(RAPTOR_JOB_ID, jobGroupWfId);
      xRobotJobDao.completeRobotJob(raptorJobIdData.getWfDataNumber().longValue());
      wfDataDao.save(jobGroupWfId, PCR_EXT_STATUS_DATA_CONFIG_ID, "Complete");
      jsonResponse.addMessage("Job" + raptorJobIdData.getWfDataNumber() + " was updated to complete");
    }

    return jsonResponse;
  }

  /**
   * Delegate method triggered when users want to advance Offline job manually.
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 3026)
  public JsonResponse post3026(
    @WfParam(WfParamValue.USER_ID) String userId,
    @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost
  ) {
    JsonResponse jsonResponse = new JsonResponse();

    for(Map<String,String> jsonPostData : jsonPost.getRows()) {
      Long jobGroupWfId = Long.parseLong(jsonPostData.get("wfId"));
      WfData offlineJobIdData = wfDataDao.getValue(OFFLINE_JOB_ID_DATA_CONFIG_ID, jobGroupWfId);
      xRobotJobDao.completeRobotJob(offlineJobIdData.getWfDataNumber().longValue());
      wfDataDao.save(jobGroupWfId, PCR_EXT_STATUS_DATA_CONFIG_ID, "Complete");
      jsonResponse.addMessage("Job" + offlineJobIdData.getWfDataNumber() + " was updated to complete");
    }

    return jsonResponse;
  }

  /**
   * Delegate method triggered when users want to manually move jobs from Control/Mix to Raptor or Offline job queue.
   * This is necessary if the lab wants to manually prepare control or mix plates instead of having Tecan handle it.
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 3024)
  public JsonResponse post3024(
    @WfParam(WfParamValue.USER_ID) String userId,
    @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost
  ) {
    JsonResponse jsonResponse = new JsonResponse();
    // Get info for each pcr plate and add it to a job list (either Raptor or Offline)
    for(Map<String,String> jsonPostData : jsonPost.getRows()) {
      Long jobGroupWfId = Long.parseLong(jsonPostData.get("wfId"));
      try {
        String raptorJobName = wfDataDao.getVarchar2ForWfId(jobGroupWfId, RAPTOR_JOB_NAME_DATA_CONFIG_ID);
        String offlineJobName = wfDataDao.getVarchar2ForWfId(jobGroupWfId, OFFLINE_JOB_NAME_DATA_CONFIG_ID);

        if(raptorJobName != null && raptorJobName != "") {
          wfDao.UpdateWfStepConfig(jobGroupWfId, 3025L, userId);
        } else if (offlineJobName != null && offlineJobName != "") {
          wfDao.UpdateWfStepConfig(jobGroupWfId, 3026L, userId);
        } else {
          jsonResponse.addError("ERROR: Could not determine job type. (Raptor or Offline job name not found)");
        }
      } catch (Exception ex) {
        ex.printStackTrace();
        jsonResponse.addError(ex.toString());
      }
    }
    return jsonResponse;
  }

  /**
   * cherry pick plate assembly queue
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 3033)
  public JsonResponse post3033(
    @WfParam(WfParamValue.USER_ID) String userId,
    @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost
  ) {
    // Initialize variables
    JsonResponse jsonResponse = new JsonResponse();
    HashMap<String, List<WfGridData>> mappedGridData = new HashMap<String, List<WfGridData>>();
    String assayType = null;
    String request = null;
    String redoReason = "";
    String cyclingCondition = null;
    String crop = null;
    HashSet<String> requestIds = new HashSet<>();
    HashSet<String> cyclingConditions = new HashSet<>();
    HashSet<String> crops = new HashSet<>();
    Timestamp closestDueDate = Timestamp.valueOf(jsonPost.getRows().get(0).get("dueTs"));
    List<Long> wfIds = new ArrayList<>();

    // For each cherry pick sample group, activate status to allow them to be picked up by plate managing agent
    for(Map<String,String> jsonPostData : jsonPost.getRows()) {
      String wfEntitylabel = null;
      Long sampleGroupWfId = Long.parseLong(jsonPostData.get("wfId"));
      wfIds.add(sampleGroupWfId);
      Timestamp dueDate = Timestamp.valueOf(jsonPostData.get("dueTs"));

      if(dueDate.before(closestDueDate)) {
        closestDueDate = dueDate;
      }

      // Fill in data variables
      try {
        assayType = wfDataDao.getVarchar2ForWfId(sampleGroupWfId, LAN_NAME_DATA_CONFIG_ID);
        request = wfDataDao.getVarchar2ForWfId(sampleGroupWfId, REQUEST_DATA_CONFIG_ID);
        cyclingCondition = wfDataDao.getVarchar2ForWfId(sampleGroupWfId, CYCLING_CONDITIONS_DATA_CONFIG_ID);
        crop = wfDataDao.getVarchar2ForWfId(sampleGroupWfId, CROP_DATA_CONFIG_ID);
        redoReason = wfDataDao.getVarchar2ForWfId(sampleGroupWfId, REDO_REASON_DATA_CONFIG_ID);
        requestIds.add(request);
        cyclingConditions.add(cyclingCondition);
        crops.add(crop);
      } catch (Exception e) {
        jsonResponse.addError("Error: Could not retrieve data for plate wf id " + sampleGroupWfId);
      }

      // If the redo reason is R05, we need to make sure an extraction plate exists for the sample group before going further
      String[] redoTokenArray = redoReason.split(",");
      if (Arrays.asList(redoTokenArray).contains("R05")) {
        // Get the PCR plates associated with the sample group
        List<WfAssoc> wfAssocList = wfAssocDao.getActiveLeftAdjacencies(sampleGroupWfId);
        for ( WfAssoc wfAssoc : wfAssocList ) {
          // From the PCR plates, get the E plates from the sample group
          Long pcrPlateWfId = wfAssoc.getFromWfId();
          List<WfAssoc> ePlateAssocs = wfAssocDao.getAllLeftAdjacenciesByEntityType(pcrPlateWfId, EPLATE_ENTITY_ID);

          // From the E plates, get the F plates associated with the sample group
          List<WfAssoc> tPlatesAssocs = wfAssocDao.getAllLeftAdjacenciesByEntityType(ePlateAssocs.get(0).getFromWfId(), new Long(PLATE_ENTITY_ID));

          for( WfAssoc assoc : tPlatesAssocs) {
            Long tWfId = assoc.getFromWfId();
            try {
              // Make sure the E plate has the right redo reason and that the E plate is active
              List<WfAssoc> ePlateAssoc = wfAssocDao.getActiveRight(tWfId, EPLATE_ENTITY_ID);
              String tPlateRedoReason = wfDataDao.getVarchar2ForWfId(tWfId, REDO_REASON_DATA_CONFIG_ID);
              String[] tPlateRedoTokenArray = tPlateRedoReason.split(",");
              if(!(Arrays.asList(tPlateRedoTokenArray).contains("R05")) || ePlateAssoc.size() < 1) {
                jsonResponse.addError("Error: Re-extraction has not taken place and is required for group " + sampleGroupWfId);
              }
            } catch (Exception e) {
              jsonResponse.addError("Error: Could not determine whether re-extraction has taken place. It is required for group " + sampleGroupWfId);
            }
          }
        }
      }
    }

    if(jsonResponse.getErrors().size() > 0) {
      return jsonResponse;
    }

    // If everything checks out, post the sample group list to S3 to be processed by the CherryPickPlateAssemblyAgent
    try {
      WfConfigProperty accessKey = wfService.findByWfConfigIdAndKey(30, "ACCESS_KEY_ID");
      WfConfigProperty accessSecret = wfService.findByWfConfigIdAndKey(30, "SECRET_ACCESS_KEY");
      WfConfigProperty region = wfService.findByWfConfigIdAndKey(30, "URL_CP_SAMPLE_GROUPS_SUBMISSION_S3_ACCESS_REGION");
      WfConfigProperty bucketName = wfService.findByWfConfigIdAndKey(30, "URL_CP_SAMPLE_GROUPS_SUBMISSION_S3_BUCKET_NAME");
      WfConfigProperty objPrefix = wfService.findByWfConfigIdAndKey(30, "URL_CP_SAMPLE_GROUPS_SUBMISSION_S3_OBJ_KEY_PREFIX");

      BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKey.getValueVarchar2(), accessSecret.getValueVarchar2());
      AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
        .withRegion(region.getValueVarchar2())
        .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
        .build();

      String streamString = "{ \"sampleGroup\": " + wfIds.toString() + "}";
      InputStream stream = new ByteArrayInputStream(streamString.getBytes());
      PutObjectRequest s3upload = new PutObjectRequest(bucketName.getValueVarchar2(), objPrefix.getValueVarchar2() + new SimpleDateFormat("MM.dd.yyyy_HH:mm:ss").format(new Date()) + ".json", stream, null);
      s3Client.putObject(s3upload);

      for (Long wfId : wfIds) {
        wfDataDao.save(wfId, STATUS_DATA_CONFIG_ID, "Adding samples to cherry pick plate(s)...");
      }

    } catch(AmazonServiceException e) {
      jsonResponse.addError(e.toString());
    }
      catch(SdkClientException e) {
      jsonResponse.addError(e.toString());
    }

    return jsonResponse;
  }

  /**
   * Delegate method triggered when users save PCR plates in Pre-PCR Assembly.
   * Check to make sure there are a proper number of assay plates (<24)
   * Creates Autotool job and transfer tasks
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 3034)
  public JsonResponse post3034(
    @WfParam(WfParamValue.USER_ID) String userId,
    @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost
  ) {
    JsonResponse jsonResponse = new JsonResponse();
    String prefix = userId;

    Date date = new Date();
    String formattedDate = new SimpleDateFormat("MMddYY", Locale.ENGLISH).format(date);
    prefix = prefix + formattedDate;

    Long robotJobId = null;
    String robotJobName = null;
    try {
      List<Long> robotJobIds = xRobotJobDao.findRobotJobIdsByNameLike(prefix);
      int incrementor = robotJobIds.size();
      prefix = prefix + "_" + String.format("%03d", incrementor + 1);
      robotJobName = prefix;
      robotJobId = xRobotJobDao.createAutotoolJobTaqman(robotJobName, "OFFLINE", "MBQC", "US_MO_CV");
    } catch (Exception e) {
      System.out.println(e);
    }

    // Get info for each pcr plate and add it to a job list (either Raptor or Offline)
    for (Map<String, String> jsonPostData : jsonPost.getRows()) {
      Long pcrPlateWfId = Long.parseLong(jsonPostData.get("wfId"));
      try {
        wfDataDao.save(pcrPlateWfId, StltaqmanConstants.OFFLINE_JOB_ID_DATA_CONFIG_ID, robotJobId.intValue());
        wfDataDao.save(pcrPlateWfId, StltaqmanConstants.AUTOTOOL_JOB_NAME_DATA_CONFIG_ID, robotJobName);
        wfDataDao.save(pcrPlateWfId, StltaqmanConstants.PCR_EXT_STATUS_DATA_CONFIG_ID, "Transfer Tasks pending...");
      } catch (Exception ex) {
        LOG.error("Method invocation error", ex);
        jsonResponse.setException(utilService.getStackTrace(ex));
      }
    }

    return jsonResponse;
  }

  /**
   * Delegate method triggered when users save requests in the Ready for Import queue.
   * @param userId
   * @param jsonPost
   * @return
   */
  @WfDelegateMethod(wfStepConfigId = 3043)
  public JsonResponse post3043(
    @WfParam(WfParamValue.USER_ID) String userId,
    @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost
  ) {
    JsonResponse jsonResponse = new JsonResponse();

    for(Map<String,String> jsonPostData : jsonPost.getRows()) {
      Long wfId = Long.parseLong(jsonPostData.get("wfId"));
      wfDao.updateWfStatus(wfId, "M", userId);
      jsonResponse.addMessage("Wf id " + wfId + " was updated to complete");
    }

    return jsonResponse;
  }

  /**
   * create grid data list and drop out samples
   *
   * @param postData
   */
 /* public List<WfGridData> dropSamples(Map<String, String> postData) {

    //extract wfId to associate data
    Long wfId = Long.parseLong(postData.get("wfId"));

    List<WfGridData> wfGridDataList = wfGridDataDao.findAll(wfId, PEDIGREE_GRID_TYPE_ID);
    List<WfGridData> gridDataList = new ArrayList<WfGridData>();

    if (postData.keySet().contains("selectedCells")) {
      for (String key : postData.keySet()) {
        if (key.equals("selectedCells")) {
          String selectedCells = postData.get("selectedCells");
          List<String> selectedCellsList = Arrays.asList(selectedCells.split(","));

          for (WfGridData wfGridData : wfGridDataList) {
            if (selectedCellsList.contains(UtilityMethodsImpl.getAlphaNumericString(wfGridData.getGridRow(), wfGridData.getGridCol()))) {
              wfGridData.setWfId(wfId);
              wfGridData.setValueVarchar2(CHAR_YES);
              wfGridData.setWfGridDataTypeId(SAMPLE_DROPPED_GRID_TYPE_ID);
              gridDataList.add(wfGridData);
            }
          }
        }
      }
    }

    return gridDataList;
  }
*/
  /**
   * Disable samples in Grid Assoc, coming from Sample Verification page
   * @param postData
   */
  public void disableSamples(Map<String, String> postData) {
    //extract wfId to associate data
    String wfEntityLabel = postData.get("wfEntityLabel");
    Wf wf = wfDao.findWfForStep(301,wfEntityLabel,SAMPLE_VERIFICATION_STEP_CONFIG_ID);
    // Reset already dropped Samples to active state before updating with new drop samples
    wfGridAssocDao.resetGridAssoc(wf.getWfId());
    List<WfGridData> gridDataList = new ArrayList<WfGridData>();
    if (postData.keySet().contains("selectedCells")) {
      for (String key : postData.keySet()) {
        if (key.equals("selectedCells")) {
          String selectedCells = postData.get("selectedCells");
          List<String> selectedCellsList = Arrays.asList(selectedCells.split(","));
          for (String cell:selectedCellsList) {
            wfGridAssocDao.updateGridAssoc(wf.getWfId(),cell);
            List<WfGridAssoc> wfGridAssocList=wfGridAssocDao.findAll(wf.getWfId());
            List<WfGridAssoc> filterWfGridAssoc=wfGridAssocList.stream().filter(wfGridAssoc1 -> wfGridAssoc1.getLabel().equals(cell)).collect(Collectors.toList());
            if(filterWfGridAssoc.size() > 0) {
              WfGridData wfGridData = new WfGridData();
              wfGridData.setWfId(wf.getWfId());
              wfGridData.setWfGridId(filterWfGridAssoc.get(0).getWfGridId());
              wfGridData.setValueVarchar2("Y");
              wfGridData.setWfGridDataConfigId(SAMPLE_DROPPED_GRID_TYPE_ID);
              gridDataList.add(wfGridData);
            }
          }
          wfGridDataDao.batchSaveGridData(gridDataList);
        }
      }
    }
  }

  /**
   * only for manual request submission
   * @param fileAddress
   * @return
   * @throws FileNotFoundException
   */
  public String getJsonResponse(String fileAddress) throws FileNotFoundException {
    JsonParser parser = new JsonParser();
    JsonArray jsonArray = new JsonArray();

    Object obj = parser.parse(new FileReader(fileAddress));
    jsonArray = (JsonArray) obj;

    return jsonArray.toString();
  }

  /**
   * only for manual request submission
   * @param output
   * @return
   * @throws Exception
   */
  public List<DetailServiceResponse> parseResponse(String output) throws Exception {

    Type collectionType = new TypeToken<List<DetailServiceResponse>>() {
    }.getType();

    List<DetailServiceResponse> detailServiceResponseList = (List<DetailServiceResponse>) new Gson().fromJson(output, collectionType);

    return detailServiceResponseList;
  }

  /**
   * overridden for each workflow
   * to produce relationships chart between existing entities - applicable only for this workflow
   * @param userRequestedBarcode
   * @return
   * @throws Exception
   */
  public WfGraph getGraphData(String userRequestedBarcode) throws Exception {

    List<Long> temp = wfDao.getWfId(WF_CONFIG_ID,userRequestedBarcode);

    List<WfAssoc> baseAssocs = wfAssocDao.getWfFromIds(temp);
    List<WfGraphAdjacency> wfGraphAdjacencies = new ArrayList<WfGraphAdjacency>();

    for (WfAssoc baseAssoc : baseAssocs) {

      List<WfAssoc> innerAssocs = wfAssocDao.getAdjacencies(baseAssoc.getFromWfId());
      List<WfGraphNode> wfGraphNodes = new ArrayList<WfGraphNode>();

      if (baseAssoc.getEntityTypeIdentifier() == REQUEST_ENTITY_ID) {
        // Add the start of the graph (LIMs Project) - since it's not in the the assoc relationship
        wfGraphAdjacencies.add(getGraphAdjacency("Request", baseAssoc.getFromWfLabel(),
            userRequestedBarcode, baseAssoc.getFromWfId(), (int) REQUEST_ENTITY_ID, wfService.GRAPH_ASSOC_LEFT));
      }

      for (WfAssoc innerAssoc : innerAssocs) {
        wfGraphNodes.add(new WfGraphNode(innerAssoc.getFromWfLabel(), innerAssoc.getToWfLabel(), new WfGraphNodeData("#FFFFFF")));

        /*if (innerAssoc.getEntityTypeIdentifier() == wfEntityTypeDao.WF_ENTITY_TYPE_ID_CLEAN_TUBE) {
          // add the seq dilution block - since it's only in the "to" assoc relationship
          wfGraphAdjacencies.add(wfService.getGraphAdjacency(innerAssoc.getToWfLabel(), wfService.getStringValue(39, innerAssoc.getToWfId()), userRequestedBarcode,
              innerAssoc.getToWfId(), wfEntityTypeDao.WF_ENTITY_TYPE_ID_SEQ_BLOCK, wfService.GRAPH_ASSOC_LEFT));

          // add the chip - since it's not in the assoc relationship
          wfGraphAdjacencies.add(wfService.getGraphAdjacency(innerAssoc.getToWfLabel(), wfService.getStringValue(39, innerAssoc.getToWfId()), userRequestedBarcode,
              innerAssoc.getToWfId(), wfEntityTypeDao.WF_ENTITY_TYPE_ID_CHIP, wfService.GRAPH_ASSOC_RIGHT));
        }*/

      }
      wfGraphAdjacencies.add(new WfGraphAdjacency(baseAssoc.getFromWfLabel(), baseAssoc.getFromWfLabel(), wfGraphNodes,
          getDataAttributes(baseAssoc.getFromWfLabel(), userRequestedBarcode, baseAssoc.getFromWfId(), baseAssoc.getEntityTypeIdentifier())));
    }

    WfGraph wfGraph = new WfGraph("Container Relationships", wfGraphAdjacencies, new ArrayList<WfGraphLegendEntry>(), true, "Enter barcode:");
    wfGraph.setWfGraphAdjacencies(wfGraphAdjacencies);

    if (wfGraph.getWfGraphAdjacencies().size() == 0) {
      // No data - show enpty node
      wfGraphAdjacencies.add(getGraphAdjacency("No Data:" + userRequestedBarcode,
          "No Data:" + userRequestedBarcode, userRequestedBarcode, 0, (int) REQUEST_ENTITY_ID, wfService.GRAPH_ASSOC_RIGHT));
      wfGraph.setWfGraphAdjacencies(wfGraphAdjacencies);
    }
    return wfGraph;
  }


  /**
   * overridden for each workflow
   * @param relatedBarcode
   * @param requestedBarcode
   * @param relatedWfId
   * @param wfEntityTypeId
   * @return
   * @throws Exception
   */
  public WfGraphAdjacencyData getDataAttributes(String relatedBarcode, String requestedBarcode, long relatedWfId, long wfEntityTypeId) throws
      Exception {

    WfGraphAdjacencyData data = new WfGraphAdjacencyData();

    data.set$dim(6);
    data.setGraphToolTipsList(getToolTips(relatedBarcode, relatedWfId, wfEntityTypeId));

    if (relatedBarcode.equals(requestedBarcode)) { // Requested from UI
      data.set$color("#00FF00");
      data.set$type("star");
    } else if (wfEntityTypeId == REQUEST_ENTITY_ID) {
      data.set$color("#FFFFFF");
      data.set$type("square");
    }else if (wfEntityTypeId == PLATE_96_WELL_ENTITY_ID) {
      data.set$color("#557EAA");
      data.set$type("square");
    } else if (wfEntityTypeId == PLATE_384_WELL_ENTITY_ID) {
      data.set$color("#909291");
      data.set$type("square");
    }

    return data;
  }

  /**
   * overridden for each workflow
   * @param barcode
   * @param wfId
   * @param entityType
   * @return
   * @throws Exception
   */
  public List<WfGraphToolTip> getToolTips(String barcode, long wfId, long entityType) throws Exception {

    List<WfGraphToolTip> wfGraphToolTipslist = new ArrayList<WfGraphToolTip>();
//      WfEntityTypeDao wfEntityTypeDao = new WfEntityTypeDao();

    if (entityType == PLATE_96_WELL_ENTITY_ID) {
      wfGraphToolTipslist.add((new WfGraphToolTip("samples:",  "0", 0)));
    } else if (entityType == wfEntityTypeDao.WF_ENTITY_TYPE_ID_L_PLATE) {
      wfGraphToolTipslist.add((new WfGraphToolTip("clean tube:", String.valueOf( wfService.getStringValue(26, wfId)), 0)));
    } else if (entityType == wfEntityTypeDao.WF_ENTITY_TYPE_ID_CLEAN_TUBE) {
      wfGraphToolTipslist.add((new WfGraphToolTip("qpcr:", String.valueOf( wfService.getNumberValue(29, wfId)), 4)));
    }

    return wfGraphToolTipslist;
  }

  /**
   * overridden for each workflow
   * @param fromLabel
   * @param toLabel
   * @param userRequestedBarcode
   * @param wfId
   * @param entityType
   * @param assocDirection
   * @return
   * @throws Exception
   */
  public WfGraphAdjacency getGraphAdjacency(String fromLabel, String toLabel, String userRequestedBarcode, long wfId, int entityType, int assocDirection) throws Exception {

    List<WfGraphNode> wfGraphNodes = new ArrayList<WfGraphNode>();
    wfGraphNodes.add(new WfGraphNode(fromLabel, toLabel, new WfGraphNodeData("#FFFFFF")));

    WfGraphAdjacency wfga = new WfGraphAdjacency();

    if (assocDirection == wfService.GRAPH_ASSOC_LEFT) {
      wfga = new WfGraphAdjacency(fromLabel, fromLabel, wfGraphNodes, getDataAttributes(toLabel, userRequestedBarcode, wfId, entityType));
    } else if (assocDirection == wfService.GRAPH_ASSOC_RIGHT) {
      wfga = new WfGraphAdjacency(toLabel, toLabel, wfGraphNodes, getDataAttributes(toLabel, userRequestedBarcode, wfId, entityType));
    }

    return wfga;
  }

  /**
   * overridden for each workflow
   * @param entityLabel
   * @return
   */
  public List<com.monsanto.gwg.atlas.model.admin.WfGraphNode> getWfGraphNodes( String entityLabel ) {

    //find entity label in wf,get wf_data where wf_data_config_id = 3014/3012, get wf_id with that label
    List<Wf> allWf = new ArrayList<Wf>();
    Wf originalWf = new Wf();
    if(null != entityLabel && !entityLabel.isEmpty()){
      allWf = wfService.findAllWf(30, entityLabel);
      if(null != allWf && !allWf.isEmpty()){
        Wf wf = allWf.get(0);
        WfData wfData = wfDataDao.getValue(REQUEST_ID_DATA_CONFIG_ID, wf.getWfId());
        originalWf = wfService.findAllWf(30, wfData.getWfDataVarchar2()).get(0);
      }
    }

    WfGraphNodeFactory wfGraphNodeFactory = new WfGraphNodeFactory();

    //get source project node
    com.monsanto.gwg.atlas.model.admin.WfGraphNode startNode = wfGraphNodeFactory.getGraphNode("STEP", originalWf.getWfId());
    if( startNode.getNodeDescription() == null ) {
      startNode.setNodeDescription(originalWf.getWfEntityLabel());
    }
    if( startNode.getGraphNodeId() == null) {
      startNode.setGraphNodeId(adminService.getWfGraphNodeId( startNode ));
    }

    setAssocs(originalWf.getWfId(), startNode, wfGraphNodeFactory);

    return wfGraphNodeFactory.getOrderedGraphNodes();
  }

  /**
   * recursive loop to get all relationships
   * @param wfId
   * @param startNode
   * @param wfGraphNodeFactory
   */
  private void setAssocs(Long wfId, com.monsanto.gwg.atlas.model.admin.WfGraphNode startNode, WfGraphNodeFactory wfGraphNodeFactory) {

    //get children
    List<WfAssoc> adjacencies = wfAssocDao.getAdjacencies(wfId);

    //get NCRs for the parent wf id
    addNcrNodes(startNode, wfGraphNodeFactory, wfId);

    for(WfAssoc wfAssoc : adjacencies){

      com.monsanto.gwg.atlas.model.admin.WfGraphNode nodeAdded = addNextNode(startNode, wfGraphNodeFactory, "STEP",
          wfAssoc.getToWfId(), wfAssoc.getToWfLabel(), wfAssoc.isActive());
      setAssocs(wfAssoc.getToWfId(), nodeAdded, wfGraphNodeFactory);
    }
  }

  /**
   * add all NCRs for an entity
   * @param startNode
   * @param wfGraphNodeFactory
   * @param wfId
   */
  private void addNcrNodes(com.monsanto.gwg.atlas.model.admin.WfGraphNode startNode,
                           WfGraphNodeFactory wfGraphNodeFactory, Long wfId) {

    List<WfNcrConfig> ncrInfo = wfNcrConfigDao.getNcrInfo(wfId);

    for(WfNcrConfig ncr  : ncrInfo){
      com.monsanto.gwg.atlas.model.admin.WfGraphNode ncrNode = addNextNode(startNode, wfGraphNodeFactory, "NCR", ncr.getWfNcrId(), ncr.getNcrName(), false);

      WfGraphLink wfGraphLink = new WfGraphLink();
      //wfGraphLink.setWfStepAssocId(wfStepAssoc.getWfStepAssocId());
      wfGraphLink.setWfSourceGraphNodeId( ncrNode.getGraphNodeId() );
      wfGraphLink.setWfTargetGraphNodeId( "STEP_"+ncr.getToWfId() );
      wfGraphLink.setStatus( "N" );

      if(!startNode.hasGraphLink(wfGraphLink)){
        startNode.addChildNode( wfGraphLink, ncrNode );
      }
    }
  }

  /**
   * create noew and links between entities
   * @param startNode
   * @param wfGraphNodeFactory
   * @param nodeType
   * @param nodeId
   * @param wfLabel
   * @param isActive
   * @return
   */
  private com.monsanto.gwg.atlas.model.admin.WfGraphNode addNextNode(
      com.monsanto.gwg.atlas.model.admin.WfGraphNode startNode, WfGraphNodeFactory wfGraphNodeFactory,
      String nodeType, Long nodeId, String wfLabel, boolean isActive) {

    com.monsanto.gwg.atlas.model.admin.WfGraphNode nextNode = wfGraphNodeFactory.getGraphNode( nodeType, nodeId );

    if( nextNode.getNodeDescription() == null ) {
      nextNode.setNodeDescription( wfLabel );
    }
    if( nextNode.getGraphNodeId() == null ) {
      nextNode.setGraphNodeId( adminService.getWfGraphNodeId( nextNode ));
    }

    if( nextNode != null ) {
      WfGraphLink wfGraphLink = new WfGraphLink();
      //wfGraphLink.setWfStepAssocId(wfStepAssoc.getWfStepAssocId());
      wfGraphLink.setWfSourceGraphNodeId( startNode.getGraphNodeId() );
      wfGraphLink.setWfTargetGraphNodeId( nextNode.getGraphNodeId() );
      wfGraphLink.setStatus( isActive ? "Y":"N" );

      if(!startNode.hasGraphLink(wfGraphLink)) {
        startNode.addChildNode(wfGraphLink, nextNode);
      }
    }

    return nextNode;
  }

  public void saveTaqmanNote(long wfId, String userId, String noteComment) throws Exception {

    String noteAuthor = "";
    if(null != userId){
      noteAuthor = userId;
    }
    //get existing comments
    String existingNotes = wfDataDao.getVarchar2ForWfId(wfId,StltaqmanConstants.NOTES_DATA_CONFIG_ID);
    noteComment = existingNotes+noteAuthor+" : "+ noteComment+ "<br>";
    wfDataDao.save(wfId, StltaqmanConstants.NOTES_DATA_CONFIG_ID , noteComment);
  }

  public PrintWriter  getPrintData(Long wfId, HttpServletResponse response) throws Exception{

    //set content headers
    response.setHeader("Content-type", "application/text");
    PrintWriter pw = response.getWriter();
    StringBuilder str = new StringBuilder();
    str.append("Barcode\thr-bc\tDate\tAssay\tCycle\t");
    Wf pcrJob = wfDao.find(wfId);
    List<WfAssoc> pcrPlates = wfAssocDao.getActiveLeftAdjacencies(pcrJob.getWfId());
    String fileName = null;
    for (WfAssoc pcrPlate : pcrPlates) {
      if (pcrPlate.getEntityTypeIdentifier() == PCR_PLATE_ENTITY_TYPE_ID) {
        //Get PCR Plate Wf_Data
        String plateName = wfDataDao.getVarchar2ForWfId(pcrPlate.getFromWfId(), PCR_PLATE_DATA_CONFIG_ID);
        if (null == fileName) {
          fileName = StringUtils.substringBefore(plateName, "-");
        }
        String cyclingCondition = wfDataDao.getVarchar2ForWfId(pcrPlate.getFromWfId(), CYCLING_CONDITIONS_DATA_CONFIG_ID);
        String assay = wfDataDao.getVarchar2ForWfId(pcrPlate.getFromWfId(), ASSAY_SUBSTANCE_DATA_CONFIG_ID);
        String ePlate = wfDataDao.getVarchar2ForWfId(pcrPlate.getFromWfId(), EXTRACTION_PLATE_DATA_CONFIG_ID);
        Timestamp ts = wfDataDao.getValue(DUE_DATE_DATA_CONFIG_ID, pcrPlate.getFromWfId()).getWfDataTimestamp();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String dueDate = dateFormat.format(ts);
        String isCherryPickPlate = wfDataDao.getVarchar2ForWfId(pcrPlate.getFromWfId(), IS_CHERRY_PICK_PLATE_DATA_CONFIG_ID);
        if("Y".equals(isCherryPickPlate)){
          str.append("\r\n" + plateName + "\t" + plateName + "\t" + cyclingCondition + "\t" + dueDate + "\t" + plateName);
        } else{
          str.append("\r\n" + plateName + "\t" + plateName + "\t" + cyclingCondition + "\t" + assay + "\t" + ePlate + "\t" + dueDate);
        }

      }
    }
        response.setHeader("Content-disposition", "attachment; filename=\"" + fileName + ".txt\"");
    pw.write(str.toString());
    return pw;
  }

    // DSA-5476
    private void copyRedoDataToEPlate(Map<Long, String> fromWfIdMap, long ePlateWfId) throws Exception{
        for (Long fromWfId: fromWfIdMap.keySet()) {
            String reasonCode = wfDataDao.getVarchar2ForWfId(fromWfId,REDO_REASON_DATA_CONFIG_ID);
            String assay = wfDataDao.getVarchar2ForWfId(fromWfId,R01_REDO_ASSAY_NAME_DATA_CONFIG_ID);
            if(REASON_CODE_R01.equals(reasonCode)){
                wfDataDao.save(ePlateWfId,REDO_REASON_DATA_CONFIG_ID,REASON_CODE_R01);
                wfDataDao.save(ePlateWfId,R01_REDO_ASSAY_NAME_DATA_CONFIG_ID,assay);
            }
        }
    }
    //DSA-5873
    public String printEPlateBarcode(String request) {
        String barCodes = null;
        int tBlocksCount =0;
        int ePlatesCount = 0;
        int startNumber;
        final String TBLOCKS_COUNT_SQL = "select count(*) count from atlas.wf where wf_status='"+STATUS_IN_PROGRESS+"' and wf_step_config_id="+READY_FOR_CLEANUP_STEP_CONFIG_ID+" and wf_entity_label like '%"+request+"%'";
        final String BARCODE_SQL = "select wf_entity_label from atlas.wf where wf_entity_label like 'RE"+request+"-%'  order by wf_entity_label desc";
        tBlocksCount = jdbcTemplate.queryForObject(TBLOCKS_COUNT_SQL,Integer.class);
        if( tBlocksCount != 0){
            int mod = 0;
            ePlatesCount = tBlocksCount/4;
            mod = tBlocksCount%4;
            if(mod > 0){
                ePlatesCount++;
            }
        }
        List<String> ePlatesList = jdbcTemplate.queryForList(BARCODE_SQL, String.class);
        if((ePlatesList.size() == 0) || (null == ePlatesList)){
            startNumber =0;
        }
        else{
            String lastPlateId = ePlatesList.get(0);
            int lastPlateNumber  = Integer.parseInt(lastPlateId.substring(lastPlateId.lastIndexOf("-")+1));
            startNumber = lastPlateNumber;
        }
        try {
            Long printerId = wfStepConfigDao.getWfPrinterId(READY_FOR_CLEANUP_STEP_CONFIG_ID);
            String ePlateId=null;
            if(ePlatesCount > 0){
                for (int i = 0; i < ePlatesCount; i++) {
                    ePlateId = "RE"+request+"-"+ String.format("%03d", startNumber+1);
                    startNumber++;
                    System.out.println("Sending  "+ePlateId+ " to Printer");
                    wfService.printBarcode(printerId, ePlateId);
                    if(null == barCodes){
                        barCodes=ePlateId;
                    }
                    else{
                        barCodes = barCodes+", "+ePlateId;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return barCodes;
    }


}
