package com.monsanto.gwg.atlas.json.core;

import java.util.List;
import java.util.Map;

/**
 * Created by regama on 8/7/14.
 */
public class JsonGridAssocData {
    private String createUser;
    private Long wfId;
    private Long wfConfigId;
    private List<Map<String,String>> gridItems;

    public List<Map<String, String>> getGridItems() {
        return gridItems;
    }

    public void setGridItems(List<Map<String, String>> gridItems) {
        this.gridItems = gridItems;
    }

    public Long getWfId() {
        return wfId;
    }

    public void setWfId(Long wfId) {
        this.wfId = wfId;
    }



    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }
}
