package com.monsanto.gwg.atlas.json.admin;

/**
 * Created by regama on 7/30/14.
 */
public class JsonWfGridDataType {
    private Long wfGridDataTypeId;
    private Long wfConfigId;
    private String wfGridDataType;
    private String dataType;
    private Integer sortKey;
    private String numberFormat;
    private String timestampFormat;
    private String iconPng;
    private String enabled;

    public Long getWfGridDataTypeId() {
        return wfGridDataTypeId;
    }

    public void setWfGridDataTypeId(Long wfGridDataTypeId) {
        this.wfGridDataTypeId = wfGridDataTypeId;
    }

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public String getWfGridDataType() {
        return wfGridDataType;
    }

    public void setWfGridDataType(String wfGridDataType) {
        this.wfGridDataType = wfGridDataType;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public Integer getSortKey() {
        return sortKey;
    }

    public void setSortKey(Integer sortKey) {
        this.sortKey = sortKey;
    }

    public String getNumberFormat() {
        return numberFormat;
    }

    public void setNumberFormat(String numberFormat) {
        this.numberFormat = numberFormat;
    }

    public String getTimestampFormat() {
        return timestampFormat;
    }

    public void setTimestampFormat(String timestampFormat) {
        this.timestampFormat = timestampFormat;
    }

    public String getIconPng() {
        return iconPng;
    }

    public void setIconPng(String iconPng) {
        this.iconPng = iconPng;
    }

    public String getEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }
}
