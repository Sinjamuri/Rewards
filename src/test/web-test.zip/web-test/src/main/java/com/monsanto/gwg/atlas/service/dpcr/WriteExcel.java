package com.monsanto.gwg.atlas.service.dpcr;

import com.monsanto.gwg.atlas.dao.core.WfDao;
import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.dao.core.WfGridAssocDao;
import com.monsanto.gwg.atlas.dao.dpcr.SampleDao;
import com.monsanto.gwg.atlas.model.core.Wf;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.model.core.WfGridAssoc;
import com.monsanto.gwg.atlas.model.dpcr.Sample;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ASHAR7 on 1/5/2015.
 */
@Service
public class WriteExcel implements DPcrConstants{

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfDao wfDao;

    @Autowired
    private WfGridAssocDao wfGridAssocDao;

    @Autowired
    private SampleDao sampleDao;

    /**
     * Writes the workbook to the passed output stream which will allow the excel sheet to be downloaded on the user's computer.
     * @param plateWfId
     * @param copyEstimates
     * @param zygosityCalls
     * @param algorithm
     * @return Plate Name
     */
    public byte[] createExcel(Long plateWfId, Map<String, Integer[][]> copyEstimates, String[][] zygosityCalls, String algorithm){

        String plateName = "";
        byte excelByteArray[] = null;

        try {
            InputStream fileIn = getClass().getResourceAsStream(ANALYSIS__EXCEL_TEMPLATE);

            XSSFWorkbook workbook = new XSSFWorkbook(fileIn);
            XSSFSheet worksheet = workbook.getSheetAt(0);

            CreationHelper createHelper = workbook.getCreationHelper();

            CellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(DATE_FORMAT));

            // get the plate name from the request
            // plate name = WF.WF_ENTITY_LABEL - get the WF_ID
            // get the record from WF_GRID_ASSOC where WF.WF_ID=WF_GRID_ASSOC.WF_CONTAINER_ID
            // get the Sample Name where WF.WF_ID = WF_GRID_ASSOC.WF_ENTITY_ID
            // get the other data from WF_DATA where WF_DATA.WF_ID = WF.WF_ID

            //Below line is required only if we have to fetch by palte name
            //Wf wf = wfDao.find("wf_entity_label=?","dPCR-001D");

            Wf wf = wfDao.find(plateWfId);
            plateName = wf.getWfEntityLabel();

            List<WfGridAssoc> wfGridAssocList = wfGridAssocDao.findAll(plateWfId);

            Map<Long, WfGridAssoc> gridAssocMap = new HashMap<Long, WfGridAssoc>();
            for( WfGridAssoc wfGridAssoc : wfGridAssocList ) {
                gridAssocMap.put( wfGridAssoc.getWfId(), wfGridAssoc);
            }

            List<WfData> wfDataList = (List<WfData>) wfDataDao.findAll("WF_ID=?", wf.getWfId());

            List<Sample> samples = sampleDao.getSamples( plateWfId );

            int i = 0;

            Integer[][] famEstimatesArray = null;
            Integer[][] vicEstimatesArray = null;

            if(null != copyEstimates && null != copyEstimates.get("FAM")){
                famEstimatesArray = copyEstimates.get("FAM");
            }

            if(null != copyEstimates && null != copyEstimates.get("VIC")){
                vicEstimatesArray = copyEstimates.get("VIC");
            }

            for( Sample sample : samples ) {
                WfGridAssoc wfGridAssoc = gridAssocMap.get( sample.getWfId() );

//            for(WfGridAssoc wfGridAssoc : wfGridAssocList){

                i++;
                // index from 0,0... cell A1 is cell(0,0)
                Row row = worksheet.createRow((short) i);

//                Wf wfSample = wfDao.find(wfGridAssoc.getWfEntityId());

                setCellValueString(row, 0, plateName);
                setCellValueString(row, 1, sample.getCropType());
                setCellValueString(row, 2, sample.getTissueType() );
                setCellValueString(row, 3, sample.getMarker());

                String wellLabel = wfGridAssoc.getLabel();
                setCellValueString(row, 4, wellLabel );

                setCellValueString(row, 5, sample.getName() );
                setCellValueString(row, 6, sample.getComment() );

                Cell cellH1 = row.createCell((short) 7);
                cellH1.setCellStyle(cellStyle);
                cellH1.setCellValue(sample.getCreateDate());

                setCellValueBlob(
                        row,
                        (short)8,
                        wfGridAssoc.getGridRow() - 1 ,
                        wfGridAssoc.getGridCol() - 1,
                        famEstimatesArray,
                        vicEstimatesArray,
                        zygosityCalls,
                        algorithm
                );
          /*
                for(WfData wfData : wfDataList){

                    switch (wfData.getWfDataConfigId().intValue()) {
                        case 1120:
                            setCellValueString(row, 1, wfData.getWfDataVarchar2() );
                            break;
                        case 1121:
                            setCellValueString(row, (short) 2, wfData.getWfDataVarchar2());
                            break;
                        case 1122:
                            setCellValueString(row, (short) 3, wfData.getWfDataVarchar2());
                            break;
                        case 1123:
                            cellH1.setCellValue(wfData.getWfDataTimestamp());
                            break;
                        case 1124:
                            setCellValueString(row, (short) 6, wfData.getWfDataVarchar2());
                            break;
                    }
                }

                setCellValueString(row, (short) 4, wfGridAssoc.getLabel());
                setCellValueString(row, (short) 5, wfSample.getWfEntityLabel());

                //decrease row and column number by 1 as arrays start from 0 and the row numbers here start from 1
                setCellValueBlob(row, (short) 8, wfGridAssoc.getGridRow() - 1 , wfGridAssoc.getGridCol() - 1, famEstimatesArray,vicEstimatesArray, zygosityCalls, algorithm);
                */
            }

            ByteArrayOutputStream fileOut = new ByteArrayOutputStream();

            fileIn.close();
            workbook.write(fileOut);

            excelByteArray = fileOut.toByteArray();

            fileOut.flush();
            fileOut.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return excelByteArray;

    }

    private void setCellValueBlob(Row row, short index, Integer gridRow, Integer gridCol, Integer[][] famEstimatesArray,
                                  Integer[][] vicEstimatesArray, String[][] zygosityCalls, String algorithm) {

        Cell cell8 = row.createCell(index);
        try{
            cell8.setCellValue(famEstimatesArray[gridRow][gridCol]);
        }catch(IndexOutOfBoundsException e){
            //e.printStackTrace();
        }catch (Exception e){
            //e.printStackTrace();
        }

        Cell cell9 = row.createCell(++index);
        try{
            cell9.setCellValue(vicEstimatesArray[gridRow][gridCol]);
        }catch(IndexOutOfBoundsException e){
            //e.printStackTrace();
        }catch (Exception e){
            //e.printStackTrace();
        }

        Cell cell10 = row.createCell(++index);
        try{
            cell10.setCellValue(zygosityCalls[gridRow][gridCol]);
        }catch(IndexOutOfBoundsException e){
            //e.printStackTrace();
        }catch (Exception e){
            //e.printStackTrace();
        }

        Cell cell11 = row.createCell(++index);
        cell11.setCellValue(algorithm);

    }

    /**
     * sets the cell value in the given row
     * @param row
     * @param index
     * @param value
     */
    private static void setCellValueString(Row row, int index, String value) {
        Cell cell = row.createCell(index);
        cell.setCellValue(value);
    }

}
