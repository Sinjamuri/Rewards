package com.monsanto.gwg.atlas.model.gbs;

import java.sql.Timestamp;

public class MergedSample {
  private long gbsMergedSampleId;
  private long gbsMergedSampleGroupId;
  private String blockBarcodeNbr;
  private int sampleId;
  private Long torrentAnalysisId1;
  private Integer barcodeAdapter1;
  private Long torrentAnalysisId2;
  private Integer barcodeAdapter2;
  private Timestamp createTs;
  private Long mergeTorrentRunId;
  private Integer mergeBarcodeAdapter;
  private int mergeStatus; //Draft=1, Pending=2, Merged=3, Genotyped=4
  private Long mergeTorrentAnalysisId;
  private String userId;

  private boolean control;
  private boolean dropped;

  private Integer rawReads1;
  private Integer rawReads2;
  private boolean bam1Exists;
  private boolean bam2Exists;

  public Long getGridId() {
    return gridId;
  }

  public void setGridId(Long gridId) {
    this.gridId = gridId;
  }

  private Long gridId;

  public long getGbsMergedSampleId() {
    return gbsMergedSampleId;
  }

  public void setGbsMergedSampleId(long gbsMergedSampleId) {
    this.gbsMergedSampleId = gbsMergedSampleId;
  }

  public long getGbsMergedSampleGroupId() {
    return gbsMergedSampleGroupId;
  }

  public void setGbsMergedSampleGroupId(long gbsMergedSampleGroupId) {
    this.gbsMergedSampleGroupId = gbsMergedSampleGroupId;
  }

  public String getBlockBarcodeNbr() {
    return blockBarcodeNbr;
  }

  public void setBlockBarcodeNbr(String blockBarcodeNbr) {
    this.blockBarcodeNbr = blockBarcodeNbr;
  }

  public int getSampleId() {
    return sampleId;
  }

  public void setSampleId(int sampleId) {
    this.sampleId = sampleId;
  }

  public Long getTorrentAnalysisId1() {
    return torrentAnalysisId1;
  }

  public void setTorrentAnalysisId1(Long torrentAnalysisId1) {
    this.torrentAnalysisId1 = torrentAnalysisId1;
  }

  public Integer getBarcodeAdapter1() {
    return barcodeAdapter1;
  }

  public void setBarcodeAdapter1(Integer barcodeAdapter1) {
    this.barcodeAdapter1 = barcodeAdapter1;
  }

  public Long getTorrentAnalysisId2() {
    return torrentAnalysisId2;
  }

  public void setTorrentAnalysisId2(Long torrentAnalysisId2) {
    this.torrentAnalysisId2 = torrentAnalysisId2;
  }

  public Integer getBarcodeAdapter2() {
    return barcodeAdapter2;
  }

  public void setBarcodeAdapter2(Integer barcodeAdapter2) {
    this.barcodeAdapter2 = barcodeAdapter2;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public Long getMergeTorrentRunId() {
    return mergeTorrentRunId;
  }

  public void setMergeTorrentRunId(Long mergeTorrentRunId) {
    this.mergeTorrentRunId = mergeTorrentRunId;
  }

  public Integer getMergeBarcodeAdapter() {
    return mergeBarcodeAdapter;
  }

  public void setMergeBarcodeAdapter(Integer mergeBarcodeAdapter) {
    this.mergeBarcodeAdapter = mergeBarcodeAdapter;
  }

  public int getMergeStatus() {
    return mergeStatus;
  }

  public void setMergeStatus(int mergeStatus) {
    this.mergeStatus = mergeStatus;
  }

  public Long getMergeTorrentAnalysisId() {
    return mergeTorrentAnalysisId;
  }

  public void setMergeTorrentAnalysisId(Long mergeTorrentAnalysisId) {
    this.mergeTorrentAnalysisId = mergeTorrentAnalysisId;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public boolean isControl() {
    return control;
  }

  public void setControl(boolean control) {
    this.control = control;
  }

  public boolean isDropped() {
    return dropped;
  }

  public void setDropped(boolean dropped) {
    this.dropped = dropped;
  }

  public Integer getRawReads1() {
    return rawReads1;
  }

  public void setRawReads1(Integer rawReads1) {
    this.rawReads1 = rawReads1;
  }

  public Integer getRawReads2() {
    return rawReads2;
  }

  public void setRawReads2(Integer rawReads2) {
    this.rawReads2 = rawReads2;
  }

  public boolean isBam1Exists() {
    return bam1Exists;
  }

  public void setBam1Exists(boolean bam1Exists) {
    this.bam1Exists = bam1Exists;
  }

  public boolean isBam2Exists() {
    return bam2Exists;
  }

  public void setBam2Exists(boolean bam2Exists) {
    this.bam2Exists = bam2Exists;
  }
}
