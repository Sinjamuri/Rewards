package com.monsanto.gwg.atlas.json.core;

/**
 * Created by PGROS1 on 6/23/14.
 */
public class JsonCancelAsyncProcessResponse {
    private boolean wasCancelSuccessful;
    private String message;

    public boolean getWasCancelSuccessful() {
        return wasCancelSuccessful;
    }

    public void setWasCancelSuccessful(boolean wasCancelSuccessful) {
        this.wasCancelSuccessful = wasCancelSuccessful;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
