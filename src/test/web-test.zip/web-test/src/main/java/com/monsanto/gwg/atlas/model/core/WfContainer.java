package com.monsanto.gwg.atlas.model.core;

import java.util.List;

/**
 * Created by regama on 9/26/14.
 */
public class WfContainer {
    private Long wfId;
    private Long wfConfigId;
    private String label;
    private String entityTypeLabel;
    private Integer rowSize;
    private Integer colSize;
    private List<WfData> wfDataList;
    private List<WfGridAssocVw> wfGridAssocVwList;

    public Long getWfId() {
        return wfId;
    }

    public void setWfId(Long wfId) {
        this.wfId = wfId;
    }

    public Integer getRowSize() {
        return rowSize;
    }

    public void setRowSize(Integer rowSize) {
        this.rowSize = rowSize;
    }

    public Integer getColSize() {
        return colSize;
    }

    public void setColSize(Integer colSize) {
        this.colSize = colSize;
    }

    public List<WfData> getWfDataList() {
        return wfDataList;
    }

    public void setWfDataList(List<WfData> wfDataList) {
        this.wfDataList = wfDataList;
    }

    public List<WfGridAssocVw> getWfGridAssocVwList() {
        return wfGridAssocVwList;
    }

    public void setWfGridAssocVwList(List<WfGridAssocVw> wfGridAssocVwList) {
        this.wfGridAssocVwList = wfGridAssocVwList;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getEntityTypeLabel() {
        return entityTypeLabel;
    }

    public void setEntityTypeLabel(String entityTypeLabel) {
        this.entityTypeLabel = entityTypeLabel;
    }

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }
}
