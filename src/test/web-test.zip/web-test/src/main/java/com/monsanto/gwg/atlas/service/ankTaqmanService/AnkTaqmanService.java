package com.monsanto.gwg.atlas.service.ankTaqmanService;

import com.monsanto.gwg.atlas.dao.core.WfAssocDao;
import com.monsanto.gwg.atlas.dao.core.WfDao;
import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.service.UtilService;
import com.monsanto.gwg.atlas.service.annotations.WfDelegateMethod;
import com.monsanto.gwg.atlas.service.annotations.WfParam;
import com.monsanto.gwg.atlas.service.annotations.WfParamValue;
import com.monsanto.gwg.atlas.service.core.WfService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;

import static com.monsanto.gwg.atlas.service.ankTaqmanService.AnkTaqmanConstants.*;

@Service
public class AnkTaqmanService {

  private static final Logger LOG = LoggerFactory.getLogger(AnkTaqmanService.class);

  @Autowired
  WfDao wfDao;

  @Autowired
  WfDataDao wfDataDao;

  @Autowired
  WfAssocDao wfAssocDao;

  @Autowired
  WfService wfService;

  @Autowired
  UtilService utilService;

  @WfDelegateMethod(wfStepConfigId = 5035)
  public JsonResponse post5035(
    @WfParam(WfParamValue.USER_ID) String userId,
    @WfParam(WfParamValue.JSON_POST) JsonPost jsonPost) {

    JsonResponse jsonResponse = new JsonResponse();

    try {
      wfService.savePostData(jsonPost);

      for (Map<String, String> postData : jsonPost.getRows()) {
        //extract wfId to associate data
        Long wfId = Long.parseLong(postData.get("wfId"));
        wfDataDao.save(wfId, AnkTaqmanConstants.BATCH_STATUS_WF_DATA_CONFIG_ID, "Approved");
      }
      //wfService.passAllWf(jsonPost, null);

    } catch (Exception ex) {
      LOG.error("Method invocation error", ex);
      //send exception to the UI to be logged by console
      jsonResponse = new JsonResponse();
      jsonResponse.setException(utilService.getStackTrace(ex));
    }

    return jsonResponse;
  }

}
