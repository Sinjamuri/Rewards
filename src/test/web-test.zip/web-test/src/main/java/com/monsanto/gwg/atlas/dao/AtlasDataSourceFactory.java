package com.monsanto.gwg.atlas.dao;

import com.monsanto.labos.config.atlas.DbConfig;
import org.apache.commons.dbcp.BasicDataSource;

import javax.sql.DataSource;

public class AtlasDataSourceFactory {

    public DataSource createGbsDataSource() {
        BasicDataSource newDataSource = new BasicDataSource();
        DbConfig dbConfig = new DbConfig();

        String dbUrl = dbConfig.getUrl();
        newDataSource.setDriverClassName(dbConfig.getDriverClassName());
        newDataSource.setUrl(dbUrl);
        newDataSource.setUsername(dbConfig.getUsername());
        newDataSource.setPassword(dbConfig.getPassword());
        newDataSource.setConnectionProperties("ssl=true;sslfactory=org.postgresql.ssl.NonValidatingFactory");
        //newDataSource.setDefaultAutoCommit(false);
        return newDataSource;
    }
}
