package com.monsanto.gwg.atlas.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.monsanto.gwg.atlas.dao.*;
import com.monsanto.gwg.atlas.dao.DashboardIndicator;

@Service
public class DashboardService {

	private static final Logger LOG = LoggerFactory.getLogger(DashboardService.class);

  @Autowired
	UtilService utilService;

	@Autowired
	DashboardDao dashboardDao;

	public void getDashboard(Model model) {
		
		//merge dashboard data into model
		model.addAttribute("WIDGET_INACTIVE_BY_STEP", dashboardDao.getInactiveByStep());
		model.addAttribute("WIDGET_COUNT_BY_STEP", dashboardDao.getCountByStep());

    //merge indicator count variables into model
		mergeIndicatorSummaries(model);
	}

	private void mergeIndicatorSummaries(Model model) {
		Map<String, Object> modelMap = model.asMap(); 
		Map<String, Object> mergeMap = new HashMap<String, Object>();
		
		for (String k: modelMap.keySet()) {
			int alertCount = 0;
			
			if (k.startsWith("WIDGET_")) {
				@SuppressWarnings("unchecked")
				List<DashboardIndicator> dashboardIndicators = (List<DashboardIndicator>) modelMap.get(k);
				for (DashboardIndicator dashboardIndicator: dashboardIndicators) {
					if (dashboardIndicator.hasAlerts()) {
						alertCount++;
					}
				}
				
				LOG.debug(k + " - calculated widget alert count=" + alertCount);
				mergeMap.put(k+"_ALERT_COUNT", alertCount);
			}
		}
		
		model.mergeAttributes(mergeMap);
	}
}
