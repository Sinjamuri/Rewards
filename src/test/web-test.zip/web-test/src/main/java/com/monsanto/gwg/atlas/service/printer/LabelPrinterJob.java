package com.monsanto.gwg.atlas.service.printer;

import com.google.gson.Gson;
import com.monsanto.gwg.atlas.json.labelprinting.JsonPrintRequest;
import com.monsanto.gwg.atlas.model.core.WfPrinter;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.util.AuthenticationUtil;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by syroth on 5/26/2017.
 */
@Service
public class LabelPrinterJob {
    private static final Logger LOG = LoggerFactory.getLogger(LabelPrinterJob.class);

    @Autowired
    WfService wfService;

    //creates print template string from pre-defined prefix/suffix specific to label type/printer and user message
    public String createPrintTemplateString(WfPrinter wfprinter, String message){
        return wfprinter.getCommandsPrefix() + message + wfprinter.getCommandsSuffix();
    }

    //attach JSON object to request and get response
    public String getPrintResponse(WebResource webresource, JsonPrintRequest jsonPrintRequest,
                                   String url_access_token, String client_id_print, String client_secret_print, String grant_type, String https_protocol_value){
        ClientResponse response = null;
        Gson gson = new Gson();
        String postJsonData = gson.toJson(jsonPrintRequest);

        LOG.info("Post JSON: " + postJsonData);


        String accessToken = AuthenticationUtil.getAccessToken(url_access_token,client_id_print,client_secret_print,grant_type, https_protocol_value);

        System.out.println(accessToken);
        LOG.info("AccessToken generated: " + accessToken);

        try {

            response = webresource.accept("application/json")
                    .type("application/json").header("Authorization", accessToken).post(ClientResponse.class, postJsonData);
            LOG.info("Accessing Response:" + response);

            if (response.getStatus() != 200) {
                if ("Y".equalsIgnoreCase(wfService.findByWfConfigIdAndKey(1L, "USE_PING_AUTH").getPropertyValue())) {
                    accessToken = AuthenticationUtil.getPingAccessToken(
                            wfService.findByWfConfigIdAndKey(1L, "URL_ACCESS_TOKEN").getPropertyValue(),
                            wfService.findByWfConfigIdAndKey(1L, "CLIENT_ID").getPropertyValue(),
                            wfService.findByWfConfigIdAndKey(1L, "CLIENT_SECRET").getPropertyValue(),
                            wfService.findByWfConfigIdAndKey(1L, "GRANT_TYPE").getPropertyValue(),
                            wfService.findByWfConfigIdAndKey(1L, "HTTPS_PROTOCOL_VALUE").getPropertyValue());

                    response = webresource.accept("application/json")
                            .type("application/json").header("Authorization", accessToken).post(ClientResponse.class, postJsonData);

                    if (response.getStatus() != 200) {
                        throw new RuntimeException("Failed : HTTP error code : "
                                + response.getStatus());
                    }
                }
            }
        }catch(ClientHandlerException se){
            return "Error: "+se.getMessage();
        }catch(Exception e){
            return "Error: "+e.getMessage();
        }

        return response.getEntity(String.class);
    }

    public WebResource getPrintWebResource(String cab_np_print_service_url){
        LOG.info("Accessing Print Service at: " + cab_np_print_service_url);
        Client client = Client.create();
        return client.resource(cab_np_print_service_url);
    }

}
