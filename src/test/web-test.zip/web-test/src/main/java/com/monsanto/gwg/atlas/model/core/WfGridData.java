package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class WfGridData {
    @DbColumn(field="wf_grid_data_id")
  private Long wfGridDataId;
    @DbColumn(field="wf_grid_data_config_id")
  private Long wfGridDataConfigId;
    @DbColumn(field="wf_id")
  private Long wfId;
    @DbColumn(field="grid_row")
  private Integer gridRow;
    @DbColumn(field="grid_col")
  private Integer gridCol;
    @DbColumn(field="value_varchar2")
  private String valueVarchar2;
    @DbColumn(field="value_timestamp")
  private Timestamp valueTimestamp;
    @DbColumn(field="value_number")
  private Double valueNumber;
    @DbColumn(field="wf_grid_id")
  private Long wfGridId;
  @DbColumn(field="aggregate_group_id")
  private Long aggregateGroupId;
  @DbColumn(field="sort_key")
  private Long sortKey;
    @DbColumn(field="create_ts")
  private Timestamp createTs;

  public Long getWfGridDataId() {
    return wfGridDataId;
  }

  public void setWfGridDataId(Long wfGridDataId) {
    this.wfGridDataId = wfGridDataId;
  }

  public Long getWfGridDataConfigId() {
    return wfGridDataConfigId;
  }

  public void setWfGridDataConfigId(Long wfGridDataConfigId) {
    this.wfGridDataConfigId = wfGridDataConfigId;
  }

  public Long getWfId() {
    return wfId;
  }

  public void setWfId(Long wfId) {
    this.wfId = wfId;
  }

  public Integer getGridRow() {
    return gridRow;
  }

  public void setGridRow(Integer gridRow) {
    this.gridRow = gridRow;
  }

  public Integer getGridCol() {
    return gridCol;
  }

  public void setGridCol(Integer gridCol) {
    this.gridCol = gridCol;
  }

  public String getValueVarchar2() {
    return valueVarchar2;
  }

  public void setValueVarchar2(String valueVarchar2) {
    this.valueVarchar2 = valueVarchar2;
  }

  public Timestamp getValueTimestamp() {
    return valueTimestamp;
  }

  public void setValueTimestamp(Timestamp valueTimestamp) {
    this.valueTimestamp = valueTimestamp;
  }

  public Double getValueNumber() {
    return valueNumber;
  }

  public void setValueNumber(Double valueNumber) {
    this.valueNumber = valueNumber;
  }

  public Long getWfGridId() {
    return wfGridId;
  }

  public void setWfGridId(Long wfGridId) {
    this.wfGridId = wfGridId;
  }

  public Long getAggregateGroupId() {
    return aggregateGroupId;
  }

  public void setAggregateGroupId(Long aggregateGroupId) {
    this.aggregateGroupId = aggregateGroupId;
  }

  public Long getSortKey() {
    return sortKey;
  }

  public void setSortKey(Long sortKey) {
    this.sortKey = sortKey;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }
}
