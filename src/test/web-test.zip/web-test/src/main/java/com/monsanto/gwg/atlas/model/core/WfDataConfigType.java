package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;

/**
 * Created by regama on 6/5/14.
 */

public class WfDataConfigType {
    @DbColumn(field="wf_data_config_type_id")
    private Long wfDataConfigTypeId;
    @DbColumn(field="wf_data_type_name")
    private String wfDataTypeName;
    @DbColumn(field="wf_data_type_description")
    private String wfDataTypeDescription;
    @DbColumn(field="wf_data_type_column")
    private String wfDataTypeColumn;
    @DbColumn(field="create_user")
    private String createUser;
    @DbColumn(field="create_ts")
    private Timestamp createTs;

    public Long getWfDataConfigTypeId() {
        return wfDataConfigTypeId;
    }

    public void setWfDataConfigTypeId(Long wfDataConfigTypeId) {
        this.wfDataConfigTypeId = wfDataConfigTypeId;
    }

    public String getWfDataTypeName() {
        return wfDataTypeName;
    }

    public void setWfDataTypeName(String wfDataTypeName) {
        this.wfDataTypeName = wfDataTypeName;
    }

    public String getWfDataTypeDescription() {
        return wfDataTypeDescription;
    }

    public void setWfDataTypeDescription(String wfDataTypeDescription) {
        this.wfDataTypeDescription = wfDataTypeDescription;
    }

    public String getWfDataTypeColumn() {
        return wfDataTypeColumn;
    }

    public void setWfDataTypeColumn(String wfDataTypeColumn) {
        this.wfDataTypeColumn = wfDataTypeColumn;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Timestamp createTs) {
        this.createTs = createTs;
    }
}
