package com.monsanto.gwg.atlas.service.core;

import com.monsanto.gwg.atlas.dao.core.WfAsyncStatusDao;
import com.monsanto.gwg.atlas.model.core.AbstractWfAsyncProcess;
import com.monsanto.gwg.atlas.model.core.WfAsyncStatus;
import com.monsanto.gwg.atlas.model.core.WfAsyncStatusUpdater;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Created by PGROS1 on 6/24/14.
 */
@Service
public class WfAsyncProcessService {

    @Autowired
    private WfAsyncStatusDao wfAsyncStatusDao;

    @Autowired
    private WfAsyncProcessStarter wfAsyncProcessStarter;

    @Autowired
    private DataSourceTransactionManager txManager;

    public WfAsyncStatus startWfAsyncProcess( long wfConfigId, String processCreateUser, AbstractWfAsyncProcess wfAsyncProcess ) {
        WfAsyncStatus asyncProcessStatus = new WfAsyncStatus();
        asyncProcessStatus.setWfConfigId(wfConfigId);
        asyncProcessStatus.setCreateUser(processCreateUser);

        asyncProcessStatus = wfAsyncStatusDao.save( asyncProcessStatus );
        wfAsyncProcess.setWfAsyncStatus(asyncProcessStatus);
        wfAsyncProcess.setStatusUpdater(new WfAsyncStatusUpdaterImpl());

        txManager.setNestedTransactionAllowed( true );
        wfAsyncProcessStarter.start( wfAsyncProcess );

        return asyncProcessStatus;
    }

    public WfAsyncStatus getWfAsyncStatus( long wfAsyncStatusId ) {
        return wfAsyncStatusDao.find( wfAsyncStatusId );
    }

    public boolean cancelWfAsyncProcessService( long wfAsyncStatusId ) {
        wfAsyncStatusDao.updateStatusToCancelled( wfAsyncStatusId );
        WfAsyncStatus asyncProcessStatus = wfAsyncStatusDao.find( wfAsyncStatusId );
        return asyncProcessStatus.getIsCancelled();
    }

    class WfAsyncStatusUpdaterImpl implements WfAsyncStatusUpdater {
        private void checkIfCancelled( long wfAsyncStatusId ) {
            WfAsyncStatus isCancelledStatus = wfAsyncStatusDao.find( wfAsyncStatusId );
            if( isCancelledStatus.getIsCancelled() ) {
                throw new WfAsyncProcessCancelledException();
            }
        }

        public void commitStatusUpdate( final WfAsyncStatus wfAsyncStatus) {
            checkIfCancelled(wfAsyncStatus.getWfAsyncStatusId());

            TransactionTemplate tt = new TransactionTemplate();
            tt.setTransactionManager(txManager);
            tt.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);

            tt.execute( new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus transactionStatus) {
                    wfAsyncStatusDao.updateStatus( wfAsyncStatus );
                }
            });
        }
    }
}
