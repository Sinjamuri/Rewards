package com.monsanto.gwg.atlas.model.core;

import java.sql.Timestamp;

public class WfAgent {
  private Long wfAgentId;
  private String agentClassPath;
  private boolean agentEnabled;
  private String agentArgs;
  private Timestamp registeredTs;
  private Timestamp startTs;
  private Timestamp activeTs;
  private Timestamp restartTs;
  private String agentStatus;
  private Long wfConfigId;

  public Long getWfAgentId() {
    return wfAgentId;
  }

  public void setWfAgentId(Long wfAgentId) {
    this.wfAgentId = wfAgentId;
  }

  public String getAgentClassPath() {
    return agentClassPath;
  }

  public void setAgentClassPath(String agentClassPath) {
    this.agentClassPath = agentClassPath;
  }

  public boolean isAgentEnabled() {
    return agentEnabled;
  }

  public void setAgentEnabled(boolean agentEnabled) {
    this.agentEnabled = agentEnabled;
  }

  public String getAgentArgs() {
    return agentArgs;
  }

  public void setAgentArgs(String agentArgs) {
    this.agentArgs = agentArgs;
  }

  public Timestamp getRegisteredTs() {
    return registeredTs;
  }

  public void setRegisteredTs(Timestamp registeredTs) {
    this.registeredTs = registeredTs;
  }

  public Timestamp getStartTs() {
    return startTs;
  }

  public void setStartTs(Timestamp startTs) {
    this.startTs = startTs;
  }

  public Timestamp getActiveTs() {
    return activeTs;
  }

  public void setActiveTs(Timestamp activeTs) {
    this.activeTs = activeTs;
  }

  public Timestamp getRestartTs() {
    return restartTs;
  }

  public void setRestartTs(Timestamp restartTs) {
    this.restartTs = restartTs;
  }

  public String getAgentStatus() {
    return agentStatus;
  }

  public void setAgentStatus(String agentStatus) {
    this.agentStatus = agentStatus;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }
}
