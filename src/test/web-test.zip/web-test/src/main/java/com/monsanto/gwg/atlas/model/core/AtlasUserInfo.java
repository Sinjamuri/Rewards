package com.monsanto.gwg.atlas.model.core;

import java.sql.Timestamp;

/**
 * Created by ashar7 on 11/3/2016.
 */
public class AtlasUserInfo {

  private Long userConfigId;
  private String userId;
  private String userName;
  private String createUser;
  private Timestamp createTs;

  private String userIdGenerated;
  private String badgeComment;
  private String userVersionStatus;

  private Long wfConfigId;
  private String wfConfigStatus;

  public Long getUserConfigId() {
    return userConfigId;
  }

  public void setUserConfigId(Long userConfigId) {
    this.userConfigId = userConfigId;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public String getUserIdGenerated() {
    return userIdGenerated;
  }

  public void setUserIdGenerated(String userIdGenerated) {
    this.userIdGenerated = userIdGenerated;
  }

  public String getBadgeComment() {
    return badgeComment;
  }

  public void setBadgeComment(String badgeComment) {
    this.badgeComment = badgeComment;
  }

  public String getUserVersionStatus() {
    return userVersionStatus;
  }

  public void setUserVersionStatus(String userVersionStatus) {
    this.userVersionStatus = userVersionStatus;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getWfConfigStatus() {
    return wfConfigStatus;
  }

  public void setWfConfigStatus(String wfConfigStatus) {
    this.wfConfigStatus = wfConfigStatus;
  }
}
