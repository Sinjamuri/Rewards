package com.monsanto.gwg.atlas.json.core;

public class JsonBlockId extends JsonResponse {
  private String id;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }
}
