package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;

/**
 * Created by pgros1 on 7/22/14.
 */
public class WfStepDataConfig {
    @DbColumn(field="wf_step_config_id")
    private Long wfStepConfigId;
    @DbColumn(field="wf_data_config_id")
    private Long wfDataConfigId;
    @DbColumn(field="sort_key")
    private Integer sortKey;
    @DbColumn(field="wf_data_config_label_override")
    private String wfDataConfigLabelOverride;
    @DbColumn(field="scan_line_key")
    private boolean scanLineKey;
    @DbColumn(field="barcode_capture")
    private boolean barcodeCapture;
    @DbColumn(field="display_only")
    private boolean displayOnly;
    @DbColumn(field="required")
    private boolean required;
    @DbColumn(field="max_length")
    private Integer maxLength;
    @DbColumn(field="wf_data_config_id_group")
    private Long wfDataConfigIdGroup;
    @DbColumn(field="wf_data_config_id_match")
    private Long wfDataConfigIdMatch;
    @DbColumn(field="wf_ref_config_id")
    private Long wfRefConfigId;
    @DbColumn(field="number_format")
    private String numberFormat;
    @DbColumn(field="date_format")
    private String dateFormat;
    @DbColumn(field="css_classes")
    private String cssClasses;
    @DbColumn(field="regex_match")
    private String regexMatch;
    @DbColumn(field="create_user")
    private String createUser;
    @DbColumn(field="create_ts")
    private Timestamp createTs;

    public Long getWfStepConfigId() {
        return wfStepConfigId;
    }

    public void setWfStepConfigId(Long wfStepConfigId) {
        this.wfStepConfigId = wfStepConfigId;
    }

    public Long getWfDataConfigId() {
        return wfDataConfigId;
    }

    public void setWfDataConfigId(Long wfDataConfigId) {
        this.wfDataConfigId = wfDataConfigId;
    }

    public Integer getSortKey() {
        return sortKey;
    }

    public void setSortKey(Integer sortKey) {
        this.sortKey = sortKey;
    }


    public boolean isScanLineKey() {
        return scanLineKey;
    }

    public void setScanLineKey(boolean scanLineKey) {
        this.scanLineKey = scanLineKey;
    }

    public boolean isBarcodeCapture() {
        return barcodeCapture;
    }

    public void setBarcodeCapture(boolean barcodeCapture) {
        this.barcodeCapture = barcodeCapture;
    }

    public boolean isDisplayOnly() {
        return displayOnly;
    }

    public void setDisplayOnly(boolean displayOnly) {
        this.displayOnly = displayOnly;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public Integer getMaxLength() {
        return maxLength;
    }

    public void setMaxLength(Integer maxLength) {
        this.maxLength = maxLength;
    }

    public Long getWfDataConfigIdGroup() {
        return wfDataConfigIdGroup;
    }

    public void setWfDataConfigIdGroup(Long wfDataConfigIdGroup) {
        this.wfDataConfigIdGroup = wfDataConfigIdGroup;
    }

    public Long getWfDataConfigIdMatch() {
        return wfDataConfigIdMatch;
    }

    public void setWfDataConfigIdMatch(Long wfDataConfigIdMatch) {
        this.wfDataConfigIdMatch = wfDataConfigIdMatch;
    }

    public Long getWfRefConfigId() {
        return wfRefConfigId;
    }

    public void setWfRefConfigId(Long wfRefConfigId) {
        this.wfRefConfigId = wfRefConfigId;
    }

    public String getNumberFormat() {
        return numberFormat;
    }

    public void setNumberFormat(String numberFormat) {
        this.numberFormat = numberFormat;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getCssClasses() {
        return cssClasses;
    }

    public void setCssClasses(String cssClasses) {
        this.cssClasses = cssClasses;
    }

    public String getRegexMatch() {
        return regexMatch;
    }

    public void setRegexMatch(String regexMatch) {
        this.regexMatch = regexMatch;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Timestamp createTs) {
        this.createTs = createTs;
    }

    public String getWfDataConfigLabelOverride() {
        return wfDataConfigLabelOverride;
    }

    public void setWfDataConfigLabelOverride(String wfDataConfigLabelOverride) {
        this.wfDataConfigLabelOverride = wfDataConfigLabelOverride;
    }
}
