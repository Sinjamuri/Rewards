package com.monsanto.gwg.atlas.json.sandwichshop;

import java.util.List;

/**
 * Created by REGAMA on 8/18/14.
 */
public class JsonOrder {
    private String pickUpName;
    private List<JsonSandwich> sandwiches;

    public String getPickUpName() {
        return pickUpName;
    }

    public void setPickUpName(String pickUpName) {
        this.pickUpName = pickUpName;
    }

    public List<JsonSandwich> getSandwiches() {
        return sandwiches;
    }

    public void setSandwiches(List<JsonSandwich> sandwiches) {
        this.sandwiches = sandwiches;
    }
}
