package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class WfStepConfig {
    @DbColumn(field="wf_step_config_id")
  private Long wfStepConfigId;
    @DbColumn(field="wf_config_id")
  private Long wfConfigId;
    @DbColumn(field="wf_step_name")
  private String wfStepName;
    @DbColumn(field="wf_step_number")
  private Integer wfStepNumber;
    @DbColumn(field="wf_step_privileges")
  private Set<String> wfStepPrivileges;
    @DbColumn(field="ui_agent_only")
  private boolean uiAgentOnly;
    @DbColumn(field="ui_custom_view")
  private String uiCustomView;
    @DbColumn(field="ui_queue_comparator")
  private String uiQueueComparator;
    @DbColumn(field="ui_force_row_scan")
  private boolean uiForceRowScan;
    @DbColumn(field="html_btn_bar")
  private String htmlBtnBar;
    @DbColumn(field="create_user")
  private String createUser;
    @DbColumn(field="create_ts")
  private Timestamp createTs;
    @DbColumn(field="wf_entity_type_id")
  private Long wfEntityTypeId;
    @DbColumn(field="active")
  private boolean active;
    @DbColumn(field="bulk_ncr_active")
  private boolean bulkNcrActive;
    @DbColumn(field="next_wf_step_config_id")
  private Long nextWfStepConfigId;
    @DbColumn(field="is_ncr_reason_mandatory")
  private boolean isNcrReasonMandatory;

  public Long getWfStepConfigId() {
    return wfStepConfigId;
  }

  public void setWfStepConfigId(Long wfStepConfigId) {
    this.wfStepConfigId = wfStepConfigId;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getWfStepName() {
    return wfStepName;
  }

  public void setWfStepName(String wfStepName) {
    this.wfStepName = wfStepName;
  }

  public Integer getWfStepNumber() {
    return wfStepNumber;
  }

  public void setWfStepNumber(Integer wfStepNumber) {
    this.wfStepNumber = wfStepNumber;
  }

  public Set<String> getWfStepPrivileges() {
    return wfStepPrivileges;
  }

  public void setWfStepPrivileges(String wfStepPrivileges) {
    this.wfStepPrivileges = new TreeSet<String>();

    //step privileges are by default unrestrictive
    if (wfStepPrivileges!=null && wfStepPrivileges.trim().length()>0) {
      String[] vals = wfStepPrivileges.split(",");
      for (String val : vals) {
        if (val!=null && val.trim().length()>0) {
          this.wfStepPrivileges.add(val.trim().toUpperCase());
        }
      }
    }
  }

  public boolean isUiAgentOnly() {
    return uiAgentOnly;
  }

  public void setUiAgentOnly(boolean uiAgentOnly) {
    this.uiAgentOnly = uiAgentOnly;
  }

  public String getUiCustomView() {
    return uiCustomView;
  }

  public void setUiCustomView(String uiCustomView) {
    this.uiCustomView = uiCustomView;
  }

  public String getUiQueueComparator() {
    return uiQueueComparator;
  }

  public void setUiQueueComparator(String uiQueueComparator) {
    this.uiQueueComparator = uiQueueComparator;
  }

  public boolean isUiForceRowScan() {
    return uiForceRowScan;
  }

  public void setUiForceRowScan(boolean uiForceRowScan) {
    this.uiForceRowScan = uiForceRowScan;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public String getHtmlBtnBar() {
    return htmlBtnBar;
  }

  public void setHtmlBtnBar(String htmlBtnBar) {
    this.htmlBtnBar = htmlBtnBar;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

    public Long getWfEntityTypeId() {
        return wfEntityTypeId;
    }

    public void setWfEntityTypeId(Long wfEntityTypeId) {
        this.wfEntityTypeId = wfEntityTypeId;
    }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }


    public boolean isBulkNcrActive() {
        return bulkNcrActive;
    }

    public void setBulkNcrActive(boolean bulkNcrActive) {
        this.bulkNcrActive = bulkNcrActive;
    }

  public Long isNextWfStepConfigId() {
    return nextWfStepConfigId;
  }

  public void setNextWfStepConfigId(Long nextWfStepConfigId) {
    this.nextWfStepConfigId = nextWfStepConfigId;
  }

  public boolean isNcrReasonMandatory() {
    return isNcrReasonMandatory;
  }

  public void setIsNcrReasonMandatory(boolean isNcrReasonMandatory) {
    this.isNcrReasonMandatory = isNcrReasonMandatory;
  }
}
