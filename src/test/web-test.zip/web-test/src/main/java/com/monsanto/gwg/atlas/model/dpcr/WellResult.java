package com.monsanto.gwg.atlas.model.dpcr;

import com.monsanto.gwg.atlas.model.core.WfGridData;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by pgros1 on 6/10/14.
 */
public class WellResult extends WfGridData {
    private TreeMap<Integer, TreeMap<Integer, TreeMap<String, PartitionResult>>> allPartitionResults;

    private int wellRow, wellColumn;
    private int partitionRowCount;
    private int partitionColumnCount;

    public void setPartitionResult( int partitionRow, int partitionColumn, PartitionResult partitionResult) {
        TreeMap<Integer, TreeMap<String, PartitionResult>> partitionColumnMap = allPartitionResults.get( partitionRow );
        if( partitionColumnMap == null ) {
            partitionColumnMap = new TreeMap<Integer, TreeMap<String, PartitionResult>>();
            allPartitionResults.put(partitionRow, partitionColumnMap);
        }

        TreeMap<String, PartitionResult> currentPartitionResultMap = partitionColumnMap.get( partitionColumn );
        if( currentPartitionResultMap == null ) {
            currentPartitionResultMap = new TreeMap<String, PartitionResult>();
            partitionColumnMap.put( partitionColumn, currentPartitionResultMap );
        }

        currentPartitionResultMap.put( partitionResult.getFilterName(), partitionResult );
    }

    public void setAllPartitionResults( TreeMap<Integer, TreeMap<Integer, TreeMap<String, PartitionResult>>> partitionResults ) {
        if( this.allPartitionResults == null ) {
            this.allPartitionResults = partitionResults;
        } else {
            for( int partitionRow : partitionResults.navigableKeySet() ) {
                TreeMap<Integer, TreeMap<String, PartitionResult>> partitionColumnMap = partitionResults.get( partitionRow );
                for( int partitionColumn : partitionColumnMap.navigableKeySet() ) {
                    for( PartitionResult partitionResult : partitionColumnMap.get( partitionColumn ).values() ) {
                        setPartitionResult( partitionRow, partitionColumn, partitionResult );
                    }
                }
            }
        }
    }

    public PartitionResult getPartitionResult( int partitionRow, int partitionColumn, String filterName) {
        try {
            return allPartitionResults.get( partitionRow ).get( partitionColumn ).get( filterName );
        } catch ( NullPointerException e ) {
            return null;
        }
    }

    public List<PartitionResult> getPartitionResultsList( int partitionRow, int partitionColumn ) {
        try {
            return new ArrayList<PartitionResult>( allPartitionResults.get( partitionRow ).get( partitionColumn ).values() );
        } catch ( NullPointerException e ) {
            return null;
        }
    }

    public TreeMap<Integer, TreeMap<Integer, TreeMap<String, PartitionResult>>> getAllPartitionResults() {
        return allPartitionResults;
    }

    public List<PartitionResult> getAllPartitionResultsList() {
        ArrayList<PartitionResult> partitionResultList = new ArrayList<PartitionResult>();
        for( int partitionRow : allPartitionResults.navigableKeySet() ) {
            TreeMap<Integer, TreeMap<String, PartitionResult>> partitionColumnMap = allPartitionResults.get( partitionRow );
            for( int partitionColumn : partitionColumnMap.navigableKeySet() ) {
                for( PartitionResult partitionResult : partitionColumnMap.get( partitionColumn).values() ) {
                    partitionResultList.add( partitionResult );
                }
            }
        }

        return partitionResultList;
    }

//    public void setPartitionResults( PartitionResult[][] allPartitionResults ) {
//        this.allPartitionResults = allPartitionResults;
//    }

//    public PartitionResult[][] getPartitionResults() {
//        return allPartitionResults;
//    }

    public void setWellRow(int wellRow) {
        setGridRow( wellRow );
    }

    public void setWellColumn(int wellColumn) {
        setGridCol( wellColumn );
    }

    public int getPartitionRowCount() {
        return partitionRowCount;
    }

    public void setPartitionRowCount(int partitionRowCount) {
        this.partitionRowCount = partitionRowCount;
    }

    public int getPartitionColumnCount() {
        return partitionColumnCount;
    }

    public void setPartitionColumnCount(int partitionColumnCount) {
        this.partitionColumnCount = partitionColumnCount;
    }
}
