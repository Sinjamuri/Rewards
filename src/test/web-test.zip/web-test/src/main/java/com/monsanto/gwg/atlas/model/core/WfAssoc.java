package com.monsanto.gwg.atlas.model.core;

public class WfAssoc {
  private Long fromWfId;
  private Long toWfId;
  private String fromWfLabel;
  private String toWfLabel;
  private boolean active;
  private Long entityTypeIdentifier;
  private Long toEntityTypeIdentifier;
  private Long wfDataNumber;

  public Long getEntityTypeIdentifier() {
    return entityTypeIdentifier;
  }

  public void setWfEntityTypeId(Long entityTypeIdentifier) {
    this.entityTypeIdentifier = entityTypeIdentifier;
  }

  public Long getFromWfId() {
    return fromWfId;
  }

  public void setFromWfId(Long fromWfId) {
    this.fromWfId = fromWfId;
  }

  public Long getToWfId() {
    return toWfId;
  }

  public void setToWfId(Long toWfId) {
    this.toWfId = toWfId;
  }

  public String getFromWfLabel() {
    return fromWfLabel;
  }

  public void setFromWfLabel(String fromWfLabel) {
    this.fromWfLabel = fromWfLabel;
  }

  public String getToWfLabel() {
    return toWfLabel;
  }

  public void setToWfLabel(String toWfLabel) {
    this.toWfLabel = toWfLabel;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public void setEntityTypeIdentifier(Long entityTypeIdentifier) {
    this.entityTypeIdentifier = entityTypeIdentifier;
  }

  public Long getToEntityTypeIdentifier() {
    return toEntityTypeIdentifier;
  }

  public void setToEntityTypeIdentifier(Long toEntityTypeIdentifier) {
    this.toEntityTypeIdentifier = toEntityTypeIdentifier;
  }

  public Long getWfDataNumber() {
    return wfDataNumber;
  }

  public void setWfDataNumber(Long wfDataNumber) {
    this.wfDataNumber = wfDataNumber;
  }
}
