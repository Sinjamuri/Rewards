package com.monsanto.gwg.atlas.json.torrent;

public class JsonTorrentRun {
  private long id;
  private String host;
  private String runName;
  private String indexTs;
  private String status;
  private String archivedPath;

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getHost() {
    return host;
  }

  public void setHost(String host) {
    this.host = host;
  }

  public String getRunName() {
    return runName;
  }

  public void setRunName(String runName) {
    this.runName = runName;
  }

  public String getIndexTs() {
    return indexTs;
  }

  public void setIndexTs(String indexTs) {
    this.indexTs = indexTs;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getArchivedPath() {
    return archivedPath;
  }

  public void setArchivedPath(String archivedPath) {
    this.archivedPath = archivedPath;
  }
}
