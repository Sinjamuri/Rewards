package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.gbs.WfNcr;
import com.monsanto.gwg.atlas.model.gbs.WfRelationships;

import java.util.List;

public class WfEntityHistory {

  // holds the active relationship
  private List<WfRelationships> wfRelationships;

  // holds list of runs at e block level (Wf entities will only be partially populated for what page needs to display)
  private List<WfRelationships> wfEblockRuns;

  // holds list of NCRs
  private List<WfNcr> wfNcrs;

  public List<WfRelationships> getWfRelationships() {
    return wfRelationships;
  }

  public void setWfRelationships(List<WfRelationships> wfRelationships) {
    this.wfRelationships = wfRelationships;
  }

  public List<WfRelationships> getWfEblockRuns() {
    return wfEblockRuns;
  }

  public void setWfEblockRuns(List<WfRelationships> wfEblockRuns) {
    this.wfEblockRuns = wfEblockRuns;
  }

  public List<WfNcr> getWfNcrDetails() {
    return wfNcrs;
  }

  public void setWfNcrDetails(List<WfNcr> wfNcrDetails) {
    this.wfNcrs = wfNcrDetails;
  }
}
