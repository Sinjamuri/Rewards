package com.monsanto.gwg.atlas.json.dpcr;

import org.codehaus.jackson.annotate.JsonIgnore;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by pgros1 on 9/3/14.
 */
public class JsonHistogram {
    private String filterName;

    public String getFilterName() {
        return filterName;
    }

    public void setFilterName(String filterName) {
        this.filterName = filterName;
    }

    private int[] histogramArray;
    private Map<String, Integer> thresholds;

    @JsonIgnore
    public int[] getHistogramArray() {
        return histogramArray;
    }

    public List<String> getFlotHistogram() {
        ArrayList<String> flotHistogram = new ArrayList<String>();
        Map<Integer, Integer> histogramMap = new TreeMap<Integer, Integer>();
        for( int i = 0; i < histogramArray.length; i++ ) {
            String flotPoint = i + "," + histogramArray[i];
            flotHistogram.add( flotPoint );

//            histogramMap.put( i, histogramArray[i] );
        }

        return flotHistogram;
    }

    public void setHistogramArray(int[] histogram) {
        this.histogramArray = histogram;
    }

    public Map<String, Integer> getThresholds() {
        return thresholds;
    }

    public void setThresholds(Map<String, Integer> thresholds) {
        this.thresholds = thresholds;
    }
}
