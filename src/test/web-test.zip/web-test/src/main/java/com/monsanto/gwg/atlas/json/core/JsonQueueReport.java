package com.monsanto.gwg.atlas.json.core;

import java.util.Map;

public class JsonQueueReport {
  private Long reportSqlId;
  private String userId;
  private Boolean queueable;
  private Map<String,String> params;
  private Long reportSqlQueueId;
  private String status;

  public Long getReportSqlId() {
    return reportSqlId;
  }

  public void setReportSqlId(Long reportSqlId) {
    this.reportSqlId = reportSqlId;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public Map<String, String> getParams() {
    return params;
  }

  public void setParams(Map<String, String> params) {
    this.params = params;
  }

  public Boolean getQueueable() {
    return queueable;
  }

  public void setQueueable(Boolean queueable) {
    this.queueable = queueable;
  }

  public Long getReportSqlQueueId() {
    return reportSqlQueueId;
  }

  public void setReportSqlQueueId(Long reportSqlQueueId) {
    this.reportSqlQueueId = reportSqlQueueId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }
}
