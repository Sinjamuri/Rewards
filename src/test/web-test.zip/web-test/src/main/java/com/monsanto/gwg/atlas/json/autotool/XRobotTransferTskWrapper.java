package com.monsanto.gwg.atlas.json.autotool;





import com.monsanto.gwg.atlas.model.core.XRobotTransferTsk;

import java.util.List;

/**
 * Created by syroth on 6/14/2017.
 */
public class XRobotTransferTskWrapper {

    //@JsonProperty("xRobotTransferTsks")
    private List<XRobotTransferTsk> xRobotTransferTsks;

    public List<XRobotTransferTsk> getTaskList(){return this.xRobotTransferTsks;}
    public void setTaskList(List<XRobotTransferTsk> xRobotTransferTsks){this.xRobotTransferTsks = xRobotTransferTsks;}

    @Override
    public String toString(){
        return String.format("Num tasks: %d", xRobotTransferTsks.size());
    }
}
