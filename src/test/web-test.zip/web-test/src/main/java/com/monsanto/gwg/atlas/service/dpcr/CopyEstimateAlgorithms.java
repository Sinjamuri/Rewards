package com.monsanto.gwg.atlas.service.dpcr;

import com.monsanto.gwg.atlas.service.dpcr.annotations.MethodOption;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by PGROS1 on 1/3/2015.
 */
public class CopyEstimateAlgorithms {

    // ln( 1 - ( 1 / 496 ) ), assuming 496 partitions in a well
    private static final int NUM_PARTITIONS_IN_WELL = 496;
    private static final Float LN_RATIO_DENOMINATOR =
            new Float( Math.log(1 - 1 / (new Float( NUM_PARTITIONS_IN_WELL )).doubleValue()));

    @MethodOption( text = "Log Ratio Test", value="lnRatio", isDefault = true )
    public static Map<String, Integer[][]> lnRatio( Integer[][] referencePositiveCounts, Map<String, Integer[][]> filterPositiveCounts ) {
        LinkedHashMap<String, Integer[][]> filterToEstimatesMap = new LinkedHashMap<String, Integer[][]>();

        for( String filterName : filterPositiveCounts.keySet() ) {
            Integer[][] filterEstimates = new Integer[referencePositiveCounts.length][referencePositiveCounts[0].length];
            filterToEstimatesMap.put( filterName, filterEstimates );
        }

        for( int wellRow = 0; wellRow < referencePositiveCounts.length; wellRow++ ) {
            for( int wellColumn = 0; wellColumn < referencePositiveCounts[wellRow].length; wellColumn++ ) {

                // Handling the "empty" reference well case
                if( referencePositiveCounts[wellRow][wellColumn] == null ) {
                    continue;
                }

                for( Map.Entry<String, Integer[][]> filterPositiveCountsEntry : filterPositiveCounts.entrySet() ) {
                    // Handling the "empty" well case
                    if( filterPositiveCountsEntry.getValue()[wellRow][wellColumn] == null ) {
                        continue;
                    }

                    filterToEstimatesMap.get( filterPositiveCountsEntry.getKey() )[wellRow][wellColumn] =
                            getLnRatioValue(
                                    referencePositiveCounts[wellRow][wellColumn],
                                    filterPositiveCountsEntry.getValue()[wellRow][wellColumn]
                            );
                }
            }
        }

        return filterToEstimatesMap;
    }

    private static Integer getLnRatioValue( int referenceFilterCount, int filterCount ) {
      Float refFilterCountBD = new Float( referenceFilterCount );
      Float filterCountBD = new Float( filterCount );

        if( refFilterCountBD.equals( 0f) ) {
            return null;
        }

      Float temp = (float) (Math
          .floor((Math.log(1 - (double) filterCountBD / refFilterCountBD) * -496.0)));

      double logOfFilterRatio =
                Math.log(
                    1 - Double.valueOf(filterCountBD / refFilterCountBD));

        // Handling the above possible estimates case, or "over" case
        if( Double.isInfinite( logOfFilterRatio ) || Double.isNaN( logOfFilterRatio )) {
            return null;
        }

        return temp.intValue();
    }
}
