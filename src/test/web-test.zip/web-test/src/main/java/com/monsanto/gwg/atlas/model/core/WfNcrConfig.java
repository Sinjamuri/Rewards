package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.util.Set;
import java.util.TreeSet;

public class WfNcrConfig {
    @DbColumn(field="wf_ncr_config_id")
  private long wfNcrConfigId;
    @DbColumn(field="ncr_name")
  private String ncrName;
    @DbColumn(field="ncr_description")
  private String ncrDescription;
    @DbColumn(field="allowed_users")
  private Set<String> allowedUserSet;

  private long fromWfId;
  private long toWfId;
  private long wfNcrId;

  public long getWfNcrConfigId() {
    return wfNcrConfigId;
  }

  public void setWfNcrConfigId(long wfNcrConfigId) {
    this.wfNcrConfigId = wfNcrConfigId;
  }

  public String getNcrName() {
    return ncrName;
  }

  public void setNcrName(String ncrName) {
    this.ncrName = ncrName;
  }

  public String getNcrDescription() {
    return ncrDescription;
  }

  public void setNcrDescription(String ncrDescription) {
    this.ncrDescription = ncrDescription;
  }

  public void setAllowedUsers(String allowedUsers) {
    allowedUserSet = new TreeSet<String>();

    if (allowedUsers!=null) {
      String[] users = allowedUsers.toUpperCase().split(",");
      for (String user:users) {
        allowedUserSet.add(user.trim());
      }
    }
  }

  public String getAllowedUsers() {
    //return null to allow permissions when restrictive user ids are not defined
    if (allowedUserSet==null || allowedUserSet.size()==0) {
      return null;
    } else {
      StringBuilder sb = new StringBuilder();
      for (String allowedUser:allowedUserSet) {
        sb.append(allowedUser).append(" ");
      }
      return sb.toString().trim();
    }
  }

  public boolean isUserAllowed(String userId) {
    return allowedUserSet==null || allowedUserSet.size()==0 || allowedUserSet.contains(userId.toUpperCase().trim());
  }

  public long getFromWfId() {
    return fromWfId;
  }

  public void setFromWfId(long fromWfId) {
    this.fromWfId = fromWfId;
  }

  public long getToWfId() {
    return toWfId;
  }

  public void setToWfId(long toWfId) {
    this.toWfId = toWfId;
  }

  public long getWfNcrId() {
    return wfNcrId;
  }

  public void setWfNcrId(long wfNcrId) {
    this.wfNcrId = wfNcrId;
  }
}
