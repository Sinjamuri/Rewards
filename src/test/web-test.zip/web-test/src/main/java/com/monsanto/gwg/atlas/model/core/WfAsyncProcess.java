package com.monsanto.gwg.atlas.model.core;

/**
 * Created by PGROS1 on 6/24/14.
 */
public interface WfAsyncProcess {
    public void startProcess();
    public void handleCancelProcess();

    public void setWfAsyncStatus( WfAsyncStatus wfAsyncStatus );
    public WfAsyncStatus getWfAsyncStatus( );
    public void setStatusUpdater( WfAsyncStatusUpdater wfAsyncStatusUpdater);
}
