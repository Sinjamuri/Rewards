package com.monsanto.gwg.atlas.service.util;

import com.monsanto.gwg.atlas.service.dpcr.DPCRExcelReader;
import com.monsanto.gwg.atlas.service.dpcr.DPCRRemediationExcelReader;
import com.monsanto.gwg.atlas.service.pcrExt.QPCRExcelReader;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by ASHAR7 on 12/23/2014.
 */
@Service
public class HssfReader {

    @Autowired
    private QPCRExcelReader qpcrExcelReader ;

    @Autowired
    private DPCRExcelReader dpcrExcelReader ;

    @Autowired
    private DPCRRemediationExcelReader dpcrRemediationExcelReader;

    public List<String> startReaderProcessing(String fileName, String createUser, InputStream resultsFileInputStream,
                                              String sheetName, int numberOfColumns, String fileSource) {


        List<String> errorLogs = new ArrayList<String>();

        try {
            HSSFSheet sheet = getSheet(resultsFileInputStream, sheetName);

            if (null != sheet && sheet.getPhysicalNumberOfRows() > -1) {
                List<Row> rowsList = getRows(sheet);
            if("DPCR".equalsIgnoreCase(fileSource)) {
                dpcrExcelReader.setCreateUser(createUser);
                dpcrExcelReader.setNumberOfColumns(numberOfColumns);
                errorLogs = dpcrExcelReader.processRows(rowsList);
            } else if("QPCR".equalsIgnoreCase(fileSource)) {

                qpcrExcelReader.setCreateUser(createUser);
                qpcrExcelReader.setNumberOfColumns(numberOfColumns);
                errorLogs = qpcrExcelReader.processRows(fileName, rowsList);
            } else if("DPCR_REMEDIATION".equalsIgnoreCase(fileSource)) {
                dpcrRemediationExcelReader.setCreateUser(createUser);
                dpcrRemediationExcelReader.setNumberOfColumns(numberOfColumns);
                dpcrRemediationExcelReader.setFileName(fileName);
                errorLogs = dpcrRemediationExcelReader.processRows(rowsList);
            }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch(Exception e){
            e.printStackTrace();
        }
        return errorLogs;
    }


    /**
     * read only XLXS format file and get the sheet
     * looks for sheet name passed, if not present - reads the first file.
     * (extracted into a separate method to create the plate only if the sheet is actually present)
     * @param resultsFileInputStream
     * @param sheetName
     * @return XSSFSheet Framework specific sheet
     */
    private HSSFSheet getSheet(InputStream resultsFileInputStream, String sheetName) throws Exception {

        //Get the workbook instance for XLS file
        HSSFWorkbook workbook = new HSSFWorkbook(resultsFileInputStream);

        //Get first sheet from the workbook
        HSSFSheet sheet = workbook.getSheet(sheetName);
        if(null == sheet){
            sheet = workbook.getSheetAt(0);
        }

        return sheet;
    }

    /**
     * read only XLXS format file and get the rows
     * return the not null list of rows
     * @param sheet
     * @return gridList from Excel
     * @throws Exception handles exception thrown while reading a particular row and
     *                    throws any other exception
     */
    private List<Row> getRows(HSSFSheet sheet) throws Exception {

        List<Row> rowsList = new ArrayList<Row>();

        //Iterate through each rows from first sheet
        Iterator<Row> rowIterator = sheet.iterator();
        //Do not want to read the first line - column names
        rowIterator.next();
        while(rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (null != row && 0 < row.getPhysicalNumberOfCells()) {
                rowsList.add(row);
            }
        }
        return rowsList;
    }
}
