package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;

public class WfDataConfig {
    @DbColumn(field="wf_data_config_id")
  private Long wfDataConfigId;
    @DbColumn(field="wf_config_id")
  private Long wfConfigId;
    @DbColumn(field="wf_data_config_type")
  private String wfDataConfigType;
    @DbColumn(field="wf_data_config_label")
  private String wfDataConfigLabel;
    @DbColumn(field="wf_data_config_searchable")
  private String wfDataConfigSearchable;
    @DbColumn(field="wf_create_user")
  private String createUser;
    @DbColumn(field="wf_create_ts")
  private Timestamp createTs;

  public Long getWfDataConfigId() {
    return wfDataConfigId;
  }

  public void setWfDataConfigId(Long wfDataConfigId) {
    this.wfDataConfigId = wfDataConfigId;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getWfDataConfigType() {
    return wfDataConfigType;
  }

  public void setWfDataConfigType(String wfDataConfigType) {
    this.wfDataConfigType = wfDataConfigType;
  }

  public String getWfDataConfigLabel() {
    return wfDataConfigLabel;
  }

  public void setWfDataConfigLabel(String wfDataConfigLabel) {
    this.wfDataConfigLabel = wfDataConfigLabel;
  }

  public String getWfDataConfigSearchable() {
    return wfDataConfigSearchable;
  }

  public void setWfDataConfigSearchable(String wfDataConfigSearchable) {
    this.wfDataConfigSearchable = wfDataConfigSearchable;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }
}
