package com.monsanto.gwg.atlas.model.sandwichshop;

/**
 * Created by REGAMA on 8/18/14.
 */
public class SandwichShopSandwich {
    private String sandwichId;
    private String sandwichWrapperId;
    private String step;
    private String meatType;
    private String breadType;
    private String toasted;
    private String comments;
    private Integer cheeseSlices;
    private Long parentOrderId;

    public String getSandwichId() {
        return sandwichId;
    }

    public void setSandwichId(String sandwichId) {
        this.sandwichId = sandwichId;
    }

    public String getSandwichWrapperId() {
        return sandwichWrapperId;
    }

    public void setSandwichWrapperId(String sandwichWrapperId) {
        this.sandwichWrapperId = sandwichWrapperId;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getMeatType() {
        return meatType;
    }

    public void setMeatType(String meatType) {
        this.meatType = meatType;
    }

    public String getBreadType() {
        return breadType;
    }

    public void setBreadType(String breadType) {
        this.breadType = breadType;
    }

    public String getToasted() {
        return toasted;
    }

    public void setToasted(String toasted) {
        this.toasted = toasted;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Integer getCheeseSlices() {
        return cheeseSlices;
    }

    public void setCheeseSlices(Integer cheeseSlices) {
        this.cheeseSlices = cheeseSlices;
    }

    public Long getParentOrderId() {
        return parentOrderId;
    }

    public void setParentOrderId(Long parentOrderId) {
        this.parentOrderId = parentOrderId;
    }
}
