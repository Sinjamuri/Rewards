package com.monsanto.gwg.atlas.model.admin;

import com.monsanto.gwg.atlas.model.core.WfStepAssocVw;
import org.codehaus.jackson.annotate.JsonIgnore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
* Created by pgros1 on 5/22/14.
*/
public class WfGraphNode {
    private List<WfGraphNode> children = new ArrayList<WfGraphNode>();
    private List<WfGraphLink> childLinks = new ArrayList<WfGraphLink>();
    private long nodeInternalId;
    private String nodeDescription;
    private String nodeInternalType;

    private String graphNodeId;

    public void setNodeInternalId( long nodeInternalId ) {
        this.nodeInternalId = nodeInternalId;
    }

    public void setNodeDescription( String nodeDescription ) {
        this.nodeDescription = nodeDescription;
    }

    public void setGraphNodeId( String graphNodeId ) { this.graphNodeId = graphNodeId; }

    @JsonIgnore
    public List<WfGraphNode> getChildNodes() {
        return children;
    }

    public List<String> getChildren() {
        List<String> childIds = new ArrayList<String>();
        for( WfGraphNode childNode : children ) {
            childIds.add( childNode.getGraphNodeId() );
        }
        return childIds;
    }

    public List<WfGraphLink> getChildLinks() {
        return childLinks;
    }

    public void addChildNode( WfGraphLink wfGraphLink, WfGraphNode childNode ) {
        children.add( childNode );
        childLinks.add( wfGraphLink );
    }

  public boolean hasGraphLink(WfGraphLink wfGraphLink){

    boolean exists = false;
    for(WfGraphLink link  : childLinks){
      if(link.getWfSourceGraphNodeId().equals(wfGraphLink.getWfSourceGraphNodeId()) &&
          link.getWfTargetGraphNodeId().equals(wfGraphLink.getWfTargetGraphNodeId())){
        exists = true;
        break;
      }
    }
    return exists;
  }

    public String getGraphNodeId() {
        return graphNodeId;
//        return getNodeInternalType() + "_" + getNodeInternalId();
    }

    public long getNodeInternalId() {
        return nodeInternalId;
    }

    public String getNodeDescription() {
        return nodeDescription;
    }

    public String getNodeInternalType() {
        return nodeInternalType;
    }

    public void setNodeInternalType( String nodeInternalType ) {
        this.nodeInternalType = nodeInternalType;
    }
}

