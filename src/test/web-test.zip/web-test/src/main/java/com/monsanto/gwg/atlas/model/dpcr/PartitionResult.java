package com.monsanto.gwg.atlas.model.dpcr;

import com.monsanto.gwg.atlas.dao.core.WfGridDataDao;
import com.monsanto.gwg.atlas.model.core.WfGridData;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by pgros1 on 6/10/14.
 */
public class PartitionResult extends WfGridData {
    private int partitionRow;
    private int partitionColumn;

    private String filterName;
    private Float intensityValue;
    private boolean isPartitionEmpty;

//    private Map<String, PartitionData> filterToPartitionDataMap = new TreeMap<String, PartitionData>();

//    public void addPartitionData( PartitionData partitionData) {
//        filterToPartitionDataMap.put( partitionData.getFilterName(), partitionData);
//    }
//
//    public PartitionData getPartitionDataForFilter( String filterId ) {
//        return filterToPartitionDataMap.get( filterId );
//    }
//
//    public List<String> getFilters() {
//        return new ArrayList<String>( filterToPartitionDataMap.keySet() );
//    }

    public String getFilterName() {
        return filterName;
    }

    public void setFilterName(String filterName) {
        this.filterName = filterName;
    }

    public Float getIntensityValue() {
        return new Float( getValueNumber() );
    }

    public void setIntensityValue(Float intensityValue) {
        setValueNumber( intensityValue.doubleValue() );
    }

    public boolean getIsPartitionEmpty() {
        return isPartitionEmpty;
    }

    public void setIsPartitionEmpty(boolean isPartitionEmpty) {

        this.isPartitionEmpty = isPartitionEmpty;
    }

    public int getPartitionRow() {
        return getGridRow();
    }

    public void setPartitionRow(int partitionRow) {
        setGridRow( partitionRow );
    }

    public int getPartitionColumn() {
        return getGridCol() ;
    }

    public void setPartitionColumn(int partitionColumn) {
        setGridCol( partitionColumn );
    }


}
