package com.monsanto.gwg.atlas.service;

import com.monsanto.gwg.atlas.dao.ReagentDao;
import com.monsanto.gwg.atlas.model.Reagent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReagentService {

  private static final Logger LOG = LoggerFactory.getLogger(ReagentService.class);

  @Autowired
  private ReagentDao reagentDao;


  public List<Reagent> findAll() {
    return reagentDao.findAll();
  }

  public List<Reagent> findByStep(long workflowStepNumber) {
    return reagentDao.findByStep(workflowStepNumber);
  }

  public Reagent findById(long reagentId) {
    return reagentDao.findById(reagentId);
  }

  public void update(long reagentId, String lotNumber, long cost, String userId) {
    reagentDao.update(reagentId, lotNumber, cost, userId);
  }

  public void insert(long workflowStepConfigId, String reagentName, String lotNumber, long cost, String userId) {
    reagentDao.insert(workflowStepConfigId, reagentName, lotNumber, cost, userId);
  }

  public void delete(long reagentId, String userId) {
    reagentDao.delete(reagentId, userId);
  }


  public void addEmpty(List<Reagent> reagents) {
    Reagent r = new Reagent();
    r.setReagentId(-1);
    reagents.add(0, r);
  }

}
