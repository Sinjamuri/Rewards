package com.monsanto.gwg.atlas.controller;


import com.monsanto.gwg.atlas.json.admin.*;
import com.monsanto.gwg.atlas.json.core.JsonOption;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.model.admin.WfGraphNode;
import com.monsanto.gwg.atlas.model.core.*;
import com.monsanto.gwg.atlas.service.UtilService;
import com.monsanto.gwg.atlas.service.admin.AdminService;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.util.ExcelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Controller
public class AdminController {

  private static final Logger LOG = LoggerFactory.getLogger(AdminController.class);

  @Autowired
  private AdminService adminService;

  @Autowired
  private UtilService utilService;

  @Autowired
  private WfService wfService;

    @Autowired
    private ExcelFactory excelFactory;

  @RequestMapping(value = "/admin/diagnostics/", method = RequestMethod.GET)
  public String diagnostics(Model model) {

    LOG.debug("diagnostics() of WorkflowController called");

    return "admin/diagnostics";
  }

  @RequestMapping(value = "/admin/", method = RequestMethod.GET)
  public String adminHome(Model model) {
    return "admin/home";
  }

  @RequestMapping(value = "/admin/sql/", method = RequestMethod.GET)
  public String adminSql() {
    return "/admin/sql";
  }

  @RequestMapping(value = "/admin/userbarcode/", method = RequestMethod.GET)
  public String getUserBarcode(Model model) throws Exception {

    model.addAttribute("WF_CONFIGS", wfService.findAllWfConfig());

    return "/admin/userbarcode";
  }

  @RequestMapping(value = "/admin/usercookie/", method = RequestMethod.GET)
  public String getUserCookie(Model model, HttpServletRequest request) {
    String val = utilService.getCookieValue(request.getCookies(), "ATLAS_UID");
    if (val!=null) {
      model.addAttribute("uid", val);
    }

    return "/admin/usercookie";
  }

  @RequestMapping(value = "/admin/sql/", method = RequestMethod.POST)
  public String adminSql(Model model, @RequestParam String sql) {

    if (sql==null || sql.trim().length()==0) {

      //nothing available to execute
      model.addAttribute("sqlException", "Last SQL statement was empty!");
      model.addAttribute("sql", "&nbsp;");
      model.addAttribute("recordsAffected", 0);

    } else {
      //remove trailing semi-colon if there is one
      sql = sql.replaceAll("\\s+;\\s+$","");

      //remove trailing forward-slash if there is one
      sql = sql.replaceAll("\\s+/\\s+$","");

      LOG.info("Executing: " + sql);

      //return records affected
      int recordsAffected = 0;
      try {
        recordsAffected = adminService.executeSqlUpdate(sql);
      } catch (Throwable t) {
        //add stack trace to show any execution errors
        model.addAttribute("sqlException", utilService.getStackTrace(t));
      }

      //show what was executed
      model.addAttribute("sql", sql);
      model.addAttribute("recordsAffected", recordsAffected);
    }

    return "admin/sql";
  }

    @RequestMapping( value = "/admin/wfmanager/", method = RequestMethod.GET )
    public String getWorkflowManager( Model model ) {
        model.addAttribute("WF_CONFIGS", wfService.findAllWfConfig());
        return "admin/manager/wfConfig";
    }

    @RequestMapping( value = "/admin/wfmanager/", method = RequestMethod.POST )
    public @ResponseBody
    JsonResponse postNewWorkflow(@RequestBody JsonWfConfig jsonWfConfig ) {
        JsonResponse jsonResponse = new JsonResponse();

        if( adminService.isValidNewWfConfig( jsonWfConfig, jsonResponse ) ){
            adminService.addNewWfConfig(jsonWfConfig, jsonResponse);
        }

        return jsonResponse;
    }

    @RequestMapping( value = "/admin/wfmanager/data/{wfConfigId}", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse postNewDataConfig(
            @PathVariable("wfConfigId") Long wfConfigId,
            @RequestBody JsonWfDataConfig jsonWfDataConfig,
            Model model
    ){
        JsonResponse response = new JsonResponse();
        try {
            jsonWfDataConfig.setWfConfigId(wfConfigId);
            adminService.addNewWfDataConfig(jsonWfDataConfig);
            response.addMessage("Success!");
        }catch(Exception ex){
            response.addError(ex.getMessage());
        }
        return response;
    }

    @RequestMapping( value = "/admin/wfmanager/property/{wfConfigId}", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse postNewConfigProperty(
            @PathVariable("wfConfigId") Long wfConfigId,
            @RequestBody JsonWfConfigProperty jsonWfConfigProperty,
            Model model
    ){
        JsonResponse response = new JsonResponse();
        try {
            jsonWfConfigProperty.setWfConfigId(wfConfigId);
            adminService.addNewWfConfigProperty(jsonWfConfigProperty);
            response.addMessage("Success!");
        }catch(Exception ex){
            response.addError(ex.getMessage());
        }
        return response;
    }

    @RequestMapping( value = "/admin/wfmanager/entity/{wfConfigId}", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse postNewEntityType(
            @PathVariable("wfConfigId") Long wfConfigId,
            @RequestBody JsonWfEntityType jsonWfEntityType,
            Model model
    ){
        JsonResponse response = new JsonResponse();
        try {
            jsonWfEntityType.setWfConfigId(wfConfigId);
            adminService.addNewWfEntityType(jsonWfEntityType);
            response.addMessage("Success!");
        }catch(Exception ex){
            response.addError(ex.getMessage());
        }
        return response;
    }


    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}", method = RequestMethod.GET )
    public String getWorkflowSteps(
            @PathVariable("wfConfigId") Long wfConfigId,
            Model model
    ) {
        model.addAttribute( "WF_CONFIG_ID", wfConfigId );
        return "admin/manager/wfStepGraphEditor";
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/step/", method = RequestMethod.POST )
    public @ResponseBody
    JsonResponse SaveWorkflowStep(
            @PathVariable("wfConfigId") Long wfConfigId,
            @RequestBody JsonWfStepAndStepDataConfig wfStepAndStepDataConfig
    ) {
        JsonResponse response = new JsonResponse();
        WfStepConfig wfStepConfig = wfStepAndStepDataConfig.getWfStepConfig();
        if( wfStepConfig.getWfConfigId() == null ) {
            wfStepConfig.setWfConfigId( wfConfigId );
        }

        boolean isNewStep = wfStepConfig.getWfStepConfigId() == null;

        try {
            wfStepConfig = adminService.saveWfStepConfigAndDataConfigs( wfStepConfig, wfStepAndStepDataConfig.getWfStepDataConfigs(), wfStepAndStepDataConfig.getCreateUser());
            if( wfStepAndStepDataConfig.getWfStepDataConfigsToRemove() != null ) {
                for (WfStepDataConfig wfStepDataConfig : wfStepAndStepDataConfig.getWfStepDataConfigsToRemove() ) {
                    adminService.deleteWfStepDataConfig( wfStepDataConfig );
                }
            }

            WfGraphNode wfGraphNode = new WfGraphNode();
            wfGraphNode.setNodeInternalType( "STEP" );
            wfGraphNode.setNodeDescription(wfStepConfig.getWfStepName());
            wfGraphNode.setNodeInternalId(wfStepConfig.getWfStepConfigId());
            response.addData(wfGraphNode);

            if( isNewStep ) {
                response.addMessage( "Successfully added step " + wfStepConfig.getWfStepName());
            } else {
                response.addMessage( "Successfully changed step " + wfStepConfig.getWfStepName() );
            }
        } catch (Exception e) {
            response.setException(e.toString());
        }

        return response;
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/step/{wfStepId}/data/select", method = RequestMethod.GET, produces = {"application/json"} )
    public @ResponseBody List<WfStepDataConfig> getWfStepDataConfigs(
            @PathVariable("wfStepId") Long wfStepId
    ) {
        return adminService.getWfStepDataConfigsForStep( wfStepId );
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/step/{wfStepConfigId}/data/{wfDataConfigId}/", method = RequestMethod.DELETE )
    public @ResponseBody
    JsonResponse deleteWfStepDataConfig(
            @PathVariable("wfStepConfigId") Long wfStepConfigId,
            @PathVariable("wfDataConfigId") Long wfDataConfigId,
            @RequestParam("required = true") boolean displayOnly
    ) {
        JsonResponse jsonResponse = new JsonResponse();

        WfStepDataConfig wfStepDataConfig = new WfStepDataConfig();
        wfStepDataConfig.setWfStepConfigId( wfStepConfigId );
        wfStepDataConfig.setWfDataConfigId( wfDataConfigId );
        wfStepDataConfig.setDisplayOnly( displayOnly );

        try {
            adminService.deleteWfStepDataConfig(wfStepDataConfig);
            jsonResponse.addMessage("Successfully removed data for step.");
        } catch (Exception e) {
            jsonResponse.setException( e.toString() );
        }

        return jsonResponse;
    }

    @RequestMapping( value = "/admin/wfmanager/wfgraphnodes/{wfConfigId}/", method = RequestMethod.GET)
    public @ResponseBody List<WfGraphNode> getWorkflowStepNodes (
                @PathVariable( "wfConfigId" ) Long wfConfigId ){

        return adminService.getWfGraphNodes(wfConfigId);
    }

    @RequestMapping( value = "/admin/wfmanager/wfgraphlinks/{wfConfigId}", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse postWfStepAssocUpdates(
            @PathVariable("wfConfigId") Long wfConfigId,
            @RequestBody JsonWfGraphLinks jsonWfGraphLinks
    ) {
        JsonResponse response = new JsonResponse();
        try {
            adminService.updateWfStepAssocs(jsonWfGraphLinks.getWfGraphLinks(), wfConfigId, jsonWfGraphLinks.getCreateUser());
            response.addMessage( "Workflow changes saved successfully!");
        } catch ( Exception e ) {
            response.setException( "ERROR: " + e.getMessage() );
        }

        return response;
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/step/", method = RequestMethod.GET)
    public String getWorkflowSteps(
            Model model,
            @PathVariable("wfConfigId") Long wfConfigId ) {

        model.addAttribute( "WF_CONFIG", wfService.findWfConfig( wfConfigId ) );
        model.addAttribute( "WF_STEP_CONFIG_LIST", wfService.findAllWfStepConfig(wfConfigId));



        return "admin/manager/step/all";
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/step/{wfStepId}/", method = RequestMethod.GET)
    public String getWorkflowStepDetails(
            @PathVariable("wfConfigId") Long wfConfigId,
            @PathVariable("wfStepId") Long wfStepId,
            Model model,
            HttpServletRequest request
    ) {
        model.addAttribute( "WF_CONFIG", wfService.findWfConfig( wfConfigId ) );
        model.addAttribute( "WF_VIEWS", adminService.getWfViews(wfConfigId, request.getSession()));

        return "admin/manager/step/all";
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/step/{wfStepId}/", method = RequestMethod.GET, produces = {"application/json"})
    public @ResponseBody
    WfStepConfig getWorkflowStepJSON(
            @PathVariable("wfConfigId") Long wfConfigId,
            @PathVariable("wfStepId") Long wfStepId,
            Model model,
            HttpServletRequest request
    ) {
        WfStepConfig wfStepConfig = wfService.findWfStepConfig( wfStepId );
        return wfStepConfig;
    }

    @RequestMapping( value = "/admin/wfmanager/data/{wfConfigId}/", method = RequestMethod.GET )
     public String getWorkflowDataConfig( Model model, @PathVariable("wfConfigId") Long wfConfigId ) {
        model.addAttribute("WF_DATA_CONFIGS", wfService.findWfDataConfig(wfConfigId));

        model.addAttribute("WF_DATA_CONFIG_TYPES", wfService.findAllWfDataConfigType());
        model.addAttribute("WF_CONFIG", wfService.findWfConfig(wfConfigId));
        model.addAttribute("WF_CONFIG_ID", wfConfigId);
        return "admin/manager/wfDataConfigs";

    }

    @RequestMapping( value = "/admin/wfmanager/property/{wfConfigId}/", method = RequestMethod.GET )
    public String getWorkflowConfigProperties( Model model, @PathVariable("wfConfigId") Long wfConfigId ) {

        List<WfConfigProperty> wfConfigPropertyTree = wfService.getWfConfigPropertyTree(wfConfigId);

        List<WfConfigProperty> wfConfigProperties = wfService.findWfConfigProperty(wfConfigId);

        List<WfDataConfigType> dataTypes = wfService.findAllWfDataConfigType();
        WfDataConfigType dataType = new WfDataConfigType();
        dataType.setWfDataTypeName("REF_ID");
        dataType.setWfDataTypeDescription("Refer a Key");
        dataTypes.add(dataType);

        model.addAttribute("WF_CONFIG_PROPERTIES", wfConfigProperties);
        model.addAttribute("WF_CONFIG_PROPERTY_TYPES", dataTypes);
        model.addAttribute("WF_CONFIG", wfService.findWfConfig(wfConfigId));
        model.addAttribute("WF_CONFIG_ID", wfConfigId);
        model.addAttribute("WF_CONFIG_PROPERTIES_TABLE", wfConfigPropertyTree);

        return "admin/manager/wfConfigProperties";
    }

    /*private Map<String, Map<String,String>> getPrimaryMap(List<WfConfigProperty> wfConfigProperties) {

        Map<String, Map<String,String>> primaryMap = new
                HashMap<String, Map<String, String>>();

        Map<String,String> secondaryMap;

        for(WfConfigProperty wfConfigProperty : wfConfigProperties){
            if(null == wfConfigProperty.getRefKey() || 0 == wfConfigProperty.getRefKey()){
                if(primaryMap.containsKey(wfConfigProperty.getKey())){
                    secondaryMap = primaryMap.get(wfConfigProperty.getKey());
                }else {
                    secondaryMap = new HashMap<String, String>();
                }
                createSecondaryMapForThisRefKey(wfConfigProperty.getPropertyId(), secondaryMap,
                        wfConfigProperties);
                primaryMap.put(wfConfigProperty.getKey(),secondaryMap);
            }
        }

        return primaryMap;
    }

    private void createSecondaryMapForThisRefKey(Long key, Map<String, String> secondaryMap,
                                                 List<WfConfigProperty> wfConfigProperties) {

        for(WfConfigProperty wfConfigProperty : wfConfigProperties){
            if(null != wfConfigProperty.getRefKey() && 0 != wfConfigProperty.getRefKey() &&
                    key == wfConfigProperty.getRefKey()){

                try{
                    secondaryMap.put(wfConfigProperty.getKey(), wfConfigProperty.getPropertyValue());
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    private Map<String,Integer> getSecondaryUniqueValues(List<WfConfigProperty> wfConfigProperties) {

        Map<String,Integer> secondaryKeyMap = new HashMap<String, Integer>();
        int i = 1;

        for(WfConfigProperty wfConfigProperty : wfConfigProperties){
            if(null != wfConfigProperty.getRefKey() && 0 != wfConfigProperty.getRefKey()
                    && !secondaryKeyMap.containsKey(wfConfigProperty.getKey())){
                secondaryKeyMap.put(wfConfigProperty.getKey(),Integer.valueOf(++i));
            }
        }
        return secondaryKeyMap;
    }*/

    @RequestMapping( value = "/admin/wfmanager/entity/{wfConfigId}/", method = RequestMethod.GET )
    public String getWorkflowEntityType( Model model, @PathVariable("wfConfigId") Long wfConfigId ) {
        model.addAttribute("WF_ENTITY_TYPES", adminService.findAllWfEntityType(wfConfigId));
        model.addAttribute("WF_CONFIG", wfService.findWfConfig(wfConfigId));
        model.addAttribute("WF_CONFIG_ID", wfConfigId);
        return "admin/manager/wfEntityType";
    }

    @RequestMapping(value = "/admin/wfmanager/griddatatype/{wfConfigId}/", method = RequestMethod.GET)
    public String getWorkflowGridDataType( Model model, @PathVariable("wfConfigId") Long wfConfigId) {
        model.addAttribute("WF_GRID_DATA_TYPES", adminService.findWfGridDataType(wfConfigId));
        model.addAttribute("WF_CONFIG", wfService.findWfConfig(wfConfigId));
        model.addAttribute("WF_CONFIG_ID", wfConfigId);
        return "admin/manager/wfGridDataType";
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/views/select", method = RequestMethod.GET, produces = {"application/json"} )
    public @ResponseBody List<JsonOption> getWorkflowViewsSelectOptions(@PathVariable("wfConfigId") Long wfConfigId, HttpServletRequest request ) {
        List<String> workflowViews = adminService.getWfViews( wfConfigId, request.getSession() );

        JsonOption defaultOption = new JsonOption();
        defaultOption.setText("None (Use Default View)");
        defaultOption.setAttribute("value", null);
        defaultOption.setAttribute("selected", "selected");

        List<JsonOption> options = new ArrayList<JsonOption>();
        options.add(defaultOption);

        for( String workflowView : workflowViews ) {
            JsonOption option = new JsonOption();
            option.setText(workflowView);
            option.setAttribute( "value", workflowView );
            options.add( option );
        }

        return options;
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/entity/select", method = RequestMethod.GET, produces = {"application/json"} )
    public @ResponseBody List<JsonOption> getEntitiesSelectOptions(@PathVariable("wfConfigId") Long wfConfigId, HttpServletRequest request ) {

        JsonOption defaultOption = new JsonOption();
        defaultOption.setText( "Unknown" );
        defaultOption.setAttribute("value", null);
        defaultOption.setAttribute("selected", "selected");

        List<JsonOption> options = new ArrayList<JsonOption>();
        options.add(defaultOption);

        List<WfEntityType> entityTypes = adminService.findAllWfEntityType(wfConfigId);
        for( WfEntityType entityType: entityTypes ) {
            JsonOption option = new JsonOption();
            option.setText( entityType.getWfEntityType() );
            option.setAttribute( "value", entityType.getWfEntityTypeId() );
            options.add( option );
        }

        return options;
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/data/select", method = RequestMethod.GET, produces = {"application/json"} )
    public @ResponseBody List<JsonOption> getDataConfigSelectOptions(@PathVariable("wfConfigId") Long wfConfigId, HttpServletRequest request ) {
        JsonOption defaultOption = new JsonOption();
        defaultOption.setText( " " );
        defaultOption.setAttribute("value", null);
        defaultOption.setAttribute("selected", "selected");

        List<JsonOption> options = new ArrayList<JsonOption>();
        options.add( defaultOption );

        List<WfDataConfig> dataConfigs = wfService.findWfDataConfig(wfConfigId);
        for( WfDataConfig dataConfig: dataConfigs) {
            JsonOption option = new JsonOption();
            option.setText(dataConfig.getWfDataConfigLabel());
            option.setAttribute( "value", dataConfig.getWfDataConfigId() );
            options.add( option );
        }

        return options;
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/ref/select", method = RequestMethod.GET, produces = {"application/json"} )
    public @ResponseBody List<JsonOption> getRefConfigSelectOptions(@PathVariable("wfConfigId") Long wfConfigId, HttpServletRequest request ) {
        JsonOption defaultOption = new JsonOption();
        defaultOption.setText( "None: Not a list" );
        defaultOption.setAttribute("value", null);
        defaultOption.setAttribute("selected", "selected");

        List<JsonOption> options = new ArrayList<JsonOption>();
        options.add( defaultOption );

        List<WfRefConfig> refParents = wfService.findWfRefConfigParents(wfConfigId);
        for( WfRefConfig refParent : refParents) {
            JsonOption option = new JsonOption();
            option.setText(refParent.getWfRefVarchar2());
            option.setAttribute( "value", refParent.getWfRefConfigId() );
            options.add( option );
        }

        return options;
    }

    @RequestMapping( value = "/admin/wfmanager/{wfConfigId}/step/{wfStepId}/data/", method = RequestMethod.GET, produces = {"application/json"} )
    public @ResponseBody List<WfStepDataConfigVw> getStepDataConfigs(
            @PathVariable("wfStepId") Long wfStepId,
            HttpServletRequest request ) {

        return wfService.findWfStepDataConfig(wfStepId);
    }



    @RequestMapping( value = "/admin/wfmanager/ref/{wfConfigId}/", method = RequestMethod.GET )
    public String getWorkflowRefType( Model model, @PathVariable("wfConfigId") Long wfConfigId ) {
        model.addAttribute("WF_CONFIG", wfService.findWfConfig(wfConfigId));
        model.addAttribute("WF_CONFIG_ID", wfConfigId);
        model.addAttribute("WF_REF_CONFIGS", wfService.findAllWfRefConfig(wfConfigId));
        model.addAttribute("WF_REF_PARENT_CONFIGS", wfService.findWfRefConfigParents(wfConfigId));
        return "admin/manager/wfRefConfig";
    }

    @RequestMapping( value = "/admin/wfmanager/ref/{wfConfigId}", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse postNewRefConfig (
            @PathVariable Long wfConfigId,
            @RequestBody JsonWfRefConfig jsonWfRefConfig,
            Model model){
        JsonResponse response = new JsonResponse();
        try {
            jsonWfRefConfig.setWfConfigId(wfConfigId);
            adminService.addNewWfRefConfig(jsonWfRefConfig);
            response.addMessage("Success!");
        }catch (Exception ex){
            response.addError(ex.getMessage());
        }
        return response;
    }


    @RequestMapping( value = "/admin/wfmanager/griddatatype/{wfConfigId}", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse postNewGridDataType (
            @PathVariable Long wfConfigId,
            @RequestBody JsonWfGridDataType jsonWfGridDataType,
            Model model){
        JsonResponse response = new JsonResponse();
        try {
            jsonWfGridDataType.setWfConfigId(wfConfigId);
            adminService.addNewWfGridDataType(jsonWfGridDataType);
            response.addMessage("Success!");
        }catch (Exception ex){
            response.addError(ex.getMessage());
        }
        return response;
    }


    @RequestMapping ( value = "/admin/wfmanager/ref/{wfConfigId}/", method = RequestMethod.DELETE)
    public @ResponseBody
    JsonResponse deleteRefConfig (@PathVariable Long wfConfigId, @RequestParam Long wfRefConfigId){
        JsonResponse response = new JsonResponse();
        try{
            adminService.deleteWfRefConfig(wfRefConfigId);
            response.addMessage("Success!");
        } catch (Exception ex){
            response.addError(ex.getMessage());
        }
        return response;
    }

    @RequestMapping (value = "/admin/wfmanager/entity/{wfConfigId}/", method = RequestMethod.DELETE)
    public  @ResponseBody
    JsonResponse deleteEntityType(@PathVariable Long wfConfigId, @RequestParam Long wfEntityTypeId){
        JsonResponse response = new JsonResponse();
        try {
            adminService.deleteWfEntityType(wfEntityTypeId);
            response.addMessage("Success!");
        } catch (Exception ex){
            if (ex.getMessage().toLowerCase().contains("child record found")){
                response.addError("Entity ID: " + wfEntityTypeId + " cannot be deleted as there are records linked to it. See log for more details.");
            } else {
            response.addError(ex.getMessage());
            }
        }
        return response;
    }


    @RequestMapping (value = "/admin/wfmanager/data/{wfConfigId}/", method = RequestMethod.DELETE)
    public @ResponseBody
    JsonResponse deleteDataConfig(@PathVariable Long wfConfigId, @RequestParam Long wfDataConfigId){
        JsonResponse response = new JsonResponse();
        try {
            adminService.deleteWfDataConfig(wfDataConfigId);
            response.addMessage("Success!");
        } catch (Exception ex){
            if (ex.getMessage().toLowerCase().contains("child record found")){
                response.addError("Data Config Id: " + wfDataConfigId + " cannot be deleted as there are records linked to it. See log for more details.");
            } else {
            response.addError(ex.getMessage());
            }
        }
        return response;
    }

    @RequestMapping (value = "/admin/wfmanager/property/{wfConfigId}/", method = RequestMethod.DELETE)
    public @ResponseBody
    JsonResponse deleteWfConfigProperty(@PathVariable Long wfConfigId, @RequestParam String propertyId){
        JsonResponse response = new JsonResponse();
        try {
            adminService.deleteWfConfigProperty(Long.valueOf(propertyId));
            response.addMessage("Success!");
        } catch (Exception ex){
            if (ex.getMessage().toLowerCase().contains("child record found")){
                response.addError("Property Id: " + propertyId + " cannot be deleted as there are records linked to it. See log for more details.");
            } else {
                response.addError(ex.getMessage());
            }
        }
        return response;
    }

    @RequestMapping (value="/admin/wfmanager/entity/{wfConfigId}/updateEntityType/", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse updateEntityType(@PathVariable Long wfConfigId, @RequestBody JsonWfEntityType jsonWfEntityType){
        JsonResponse response = new JsonResponse();
        jsonWfEntityType.setWfConfigId(wfConfigId);

        try {
            adminService.updateWfEntityType(jsonWfEntityType);
            response.addMessage("Success!");
        } catch (Exception ex){
            response.addError(ex.getMessage());
        }
        return response;
    }

    @RequestMapping (value="/admin/wfmanager/ref/{wfConfigId}/updateRefConfig/", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse updateRefConfig(@PathVariable Long wfConfigId, @RequestBody JsonWfRefConfig jsonWfRefConfig){
        JsonResponse jsonResponse = new JsonResponse();

        jsonWfRefConfig.setWfConfigId(wfConfigId);

        try {
            adminService.updateWfRefConfig(jsonWfRefConfig);
            jsonResponse.addMessage("Success!");
        } catch (Exception ex){
            jsonResponse.addError(ex.getMessage());
        }

        return jsonResponse;
    }

    @RequestMapping (value="/admin/wfmanager/data/{wfConfigId}/updateDataConfig/", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse updateDataConfig(@PathVariable Long wfConfigId, @RequestBody JsonWfDataConfig jsonWfDataConfig){
        JsonResponse jsonResponse = new JsonResponse();

        try {
            adminService.updateWfDataConfig(jsonWfDataConfig);
            jsonResponse.addMessage("Success!");
        } catch (Exception ex){
            jsonResponse.addError(ex.getMessage());
        }

        return jsonResponse;
    }

    @RequestMapping (value="/admin/wfmanager/property/{wfConfigId}/updateWfConfigProperty/", method = RequestMethod.POST)
    public @ResponseBody
    JsonResponse updateWfConfigProperty(@PathVariable Long wfConfigId, @RequestBody JsonWfConfigProperty jsonWfConfigProperty){
        JsonResponse jsonResponse = new JsonResponse();

        try {
            jsonWfConfigProperty.setWfConfigId(wfConfigId);
            adminService.updateWfConfigProperty(jsonWfConfigProperty);
            jsonResponse.addMessage("Success!");
        } catch (Exception ex){
            jsonResponse.addError(ex.getMessage());
        }

        return jsonResponse;
    }

    @RequestMapping(value = "/admin/id/{numberOfIds}", method = RequestMethod.GET)
    public @ResponseBody
    JsonResponse getSequenceIds(
            @PathVariable("numberOfIds") Long numberOfIds) {

        JsonResponse response = new JsonResponse();
        String sequenceIds = adminService.getSequenceIds(numberOfIds);
        response.addData( sequenceIds );
        return response;
    }




    @RequestMapping(value="/admin/uploadPCRCalibrationFile", method=RequestMethod.GET)
   public String uploadPCRCalibrationFile(Model model) {
        //Get the previously uploaded files
        String key = "PCR_EXT_FILE_";
        model.addAttribute("fileList", adminService.getPreviouslyUploadedFiles(key) );
        return "admin/uploadPCRCalibrationFile";
    }

     @RequestMapping(value="/admin/uploadPCRRemediationFile", method=RequestMethod.GET)
    public String uploadPCRRemediationFile(Model model) {
        return "admin/uploadPCRRemediationFile";
    }

    @RequestMapping(value="/admin/upload", method=RequestMethod.POST)
    public @ResponseBody
    JsonResponse uploadPCRCalibrationFile(Model model,
                                          final MultipartHttpServletRequest multiRequest,
                                          @RequestParam String createUser,
                                          @RequestParam String fileName,
                                          @RequestParam String requestId) {

        JsonResponse response = new JsonResponse();
        Iterator<String> fileNames = multiRequest.getFileNames();
        if( fileNames.hasNext() ) {
            String requestFileName = fileNames.next();
            MultipartFile resultsFile = multiRequest.getFile(requestFileName);
            try {
                InputStream inputStream = resultsFile.getInputStream();
                List<String> errorLogs = excelFactory.excelReader(resultsFile.getOriginalFilename(), createUser, inputStream,
                        "Results", 25, "QPCR");

                if(errorLogs.isEmpty()) {
                    byte[] b = resultsFile.getBytes();
                    String key = "PCR_EXT_FILE_" + resultsFile.getOriginalFilename();
                    adminService.saveBlobData(b, key, 1L);
                    response.addMessage("File uploaded successfully");
                    key = "PCR_EXT_FILE_";
                    model.addAttribute("fileList", adminService.getPreviouslyUploadedFiles(key));
                } else {
                    response.addMessage(errorLogs.get(0));
                }

            } catch (Exception e) {
                response.addMessage("File upload failed");
            }
        }
        return response;
    }


    @RequestMapping(value="/admin/result", method=RequestMethod.GET)
    public void getReportResultCsv(HttpServletResponse response,@RequestParam Long propertyId) throws Exception {
        //set content headers
        response.setHeader("Content-type", "application/octet-stream");
        response.setHeader("Content-disposition", "attachment; filename=download.csv");
        OutputStream os = response.getOutputStream();
        os.write(adminService.getWfConfigBlobData(propertyId));
        os.flush();
    }

    @RequestMapping(value="/admin/uploadRemediationFile", method=RequestMethod.POST)
    public @ResponseBody
    JsonResponse uploadRemediationFile(Model model,
                                       final MultipartHttpServletRequest multiRequest,
                                       @RequestParam String createUser,
                                       @RequestParam String fileName,
                                       @RequestParam String requestId) {

        JsonResponse response = new JsonResponse();
        Iterator<String> fileNames = multiRequest.getFileNames();
         if( fileNames.hasNext() ) {
            String requestFileName = fileNames.next();
            MultipartFile resultsFile = multiRequest.getFile(requestFileName);
            try {
                InputStream inputStream = resultsFile.getInputStream();
                List<String> errorLogs = new ArrayList<String>();
                if(fileName.endsWith(".xlsx")) {
                    errorLogs = excelFactory.excelReader(resultsFile.getOriginalFilename(), createUser, inputStream,
                            "Results", 3, "DPCR_REMEDIATION");
                } else{
                    String errorMsg ="Incorrect File Type. Use xlsx files only.";
                    errorLogs.add(errorMsg);
                }

                if(errorLogs.isEmpty()) {
                    response.addMessage("File uploaded successfully");
                } else {
                    response.setErrors(errorLogs);
                }

            } catch (Exception e) {
                response.addMessage("File upload failed");
            }
        }
        return response;
    }

}
