package com.monsanto.gwg.atlas.service;

import java.util.List;

/**
 * Created by ASHAR7 on 2/13/2015.
 */
public class DetailServiceResponse {

    private String mbId;
    private String fieldPlateBarcode;
    private String sampleType;
    private List<WellSample> wellSamples;
    private String kernelNumber;
    private String plateNumber;
    private String fieldPlateStatus;
    private String dueDate;

    public String getMbId() {
        return mbId;
    }

    public void setMbId(String mbId) {
        this.mbId = mbId;
    }

    public String getFieldPlateBarcode() {
        return fieldPlateBarcode;
    }

    public void setFieldPlateBarcode(String fieldPlateBarcode) {
        this.fieldPlateBarcode = fieldPlateBarcode;
    }

    public String getSampleType() {
        return sampleType;
    }

    public void setSampleType(String sampleType) {
        this.sampleType = sampleType;
    }

    public List<WellSample> getWellSamples() {
        return wellSamples;
    }

    public void setWellSamples(List<WellSample> wellSamples) {
        this.wellSamples = wellSamples;
    }

    public String getKernelNumber() {
        return kernelNumber;
    }

    public void setKernelNumber(String kernelNumber) {
        this.kernelNumber = kernelNumber;
    }

    public String getPlateNumber() {
      return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
      this.plateNumber = plateNumber;
    }

    public String getFieldPlateStatus() {
      return fieldPlateStatus;
    }

    public void setFieldPlateStatus(String fieldPlateStatus) {
      this.fieldPlateStatus = fieldPlateStatus;
    }

    public String getDueDate() {
      return dueDate;
    }

    public void setDueDate(String dueDate) {
      this.dueDate = dueDate;
    }
}
