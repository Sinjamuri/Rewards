package com.monsanto.gwg.atlas.service.sandwichshop;

import com.monsanto.gwg.atlas.dao.core.WfAssocDao;
import com.monsanto.gwg.atlas.dao.core.WfDao;
import com.monsanto.gwg.atlas.dao.core.WfDataDao;
import com.monsanto.gwg.atlas.dao.core.WfStepDao;
import com.monsanto.gwg.atlas.dao.sandwichshop.SandwichShopOrderDao;
import com.monsanto.gwg.atlas.json.core.JsonPost;
import com.monsanto.gwg.atlas.json.core.JsonResponse;
import com.monsanto.gwg.atlas.json.sandwichshop.JsonOrder;
import com.monsanto.gwg.atlas.json.sandwichshop.JsonSandwich;
import com.monsanto.gwg.atlas.model.core.Wf;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.model.sandwichshop.SandwichShopOrder;
import com.monsanto.gwg.atlas.model.sandwichshop.SandwichShopSandwich;
import com.monsanto.gwg.atlas.service.annotations.WfDelegateMethod;
import com.monsanto.gwg.atlas.service.annotations.WfParam;
import com.monsanto.gwg.atlas.service.annotations.WfParamValue;
import com.monsanto.gwg.atlas.service.core.WfService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by pgros1 on 8/16/14.
 */
@Service
public class SandwichShopService {

    private static final long SW_PROTO_WF_CONFIG_ID = 880L;

    private static final long TOASTING_DESIRED_WF_DATA_CONFIG_ID = 806L;
    private static final long TOASTER_SELECTION_WF_STEP_CONFING_ID = 886L;

    private final static long ORDER_ENTITY_TYPE_ID = 311L;
    private final static long SWPROTO_WF_CONFIG_ID = 185L;
    private final static long SANDWICH_ENTITY_TYPE_ID = 312L;
    private final static long SANDWICH_BREAD_SELECT_STEP = 881L;
    private final static long ORDER_REVIEW_STEP = 888L;
    private final static long PICK_UP_NAME_DATA_CONFIG_ID = 820L;
    private final static long BREAD_DATA_CONFIG_ID = 802L;
    private final static long MEAT_DATA_CONFIG_ID = 804L;
    private final static long COMMENTS_DATA_CONFIG_ID = 805L;
    private final static long TOAST_DATA_CONFIG_ID = 806L;
    private final static long CHEESE_SLICES_DATA_CONFIG_ID = 803L;
    private final static long SANDWICH_ID_DATA_CONFIG_ID = 801L;

    private final static long FINISHED_SANDWICHES_STEP_DATA_CONFIG_ID = 882L;

    private final static String ATLAS_USER = "ATLAS";

    private static final Logger LOG = LoggerFactory.getLogger(SandwichShopService.class);

    @Autowired
    private WfDao wfDao;

    @Autowired
    private SandwichShopOrderDao sandwichShopOrderDao;

    @Autowired
    private WfAssocDao wfAssocDao;

    @Autowired
    private WfDataDao wfDataDao;

    @Autowired
    private WfService wfService;

    @Autowired
    private WfStepDao wfStepDao;

    public Wf addOrder (JsonOrder order){
        Wf orderWf = new Wf();
        orderWf.setWfConfigId( SWPROTO_WF_CONFIG_ID );
        orderWf.setWfId(wfDao.getNextId());
        orderWf.setWfEntityLabel("ORDER-" + orderWf.getWfId());
        orderWf.setWfEntityTypeId(ORDER_ENTITY_TYPE_ID);
        orderWf.setWfStepConfigId(ORDER_REVIEW_STEP);
        orderWf.setCreateUser(ATLAS_USER);

        orderWf = wfDao.save( orderWf );
        wfDataDao.save(orderWf.getWfId(), PICK_UP_NAME_DATA_CONFIG_ID, order.getPickUpName() );

        Set<Wf> sandwichWfs = new HashSet<Wf>();
        int sandwichIndex = 1;
        for( JsonSandwich sandwich : order.getSandwiches() ) {
            Wf sandwichWf = new Wf();
            sandwichWf.setWfConfigId( SWPROTO_WF_CONFIG_ID );

            sandwichWf.setWfEntityLabel( orderWf.getWfEntityLabel() + String.format( "-S-%03d", sandwichIndex) );
            sandwichWf.setWfEntityTypeId(SANDWICH_ENTITY_TYPE_ID);
            sandwichWf.setWfStepConfigId( SANDWICH_BREAD_SELECT_STEP );
            sandwichWf.setCreateUser(ATLAS_USER);

            sandwichWf = wfDao.save( sandwichWf );
            sandwichWfs.add( sandwichWf );

            wfDataDao.save(sandwichWf.getWfId(), SANDWICH_ID_DATA_CONFIG_ID, sandwichWf.getWfEntityLabel() );
            wfDataDao.save(sandwichWf.getWfId(), BREAD_DATA_CONFIG_ID, sandwich.getBreadType());
            wfDataDao.save(sandwichWf.getWfId(), MEAT_DATA_CONFIG_ID, sandwich.getMeatType());
            wfDataDao.save(sandwichWf.getWfId(), CHEESE_SLICES_DATA_CONFIG_ID, sandwich.getCheeseSlices());
            wfDataDao.save(sandwichWf.getWfId(), TOAST_DATA_CONFIG_ID, sandwich.getToasted());
            wfDataDao.save(sandwichWf.getWfId(), COMMENTS_DATA_CONFIG_ID, sandwich.getComments());

            sandwichIndex++;
        }

        splitFrom( orderWf, sandwichWfs, SANDWICH_BREAD_SELECT_STEP );

        return orderWf;
    }


    public void splitFrom( Wf fromWf, Set<Wf> toWfs, Long toWfStepConfig ) {
        for( Wf toWf : toWfs ) {
            wfStepDao.initStep( toWfStepConfig, toWf.getWfId(), ATLAS_USER );
            wfAssocDao.save(fromWf, toWf);
        }

        wfStepDao.completeCurrentStep( fromWf.getWfId(), ATLAS_USER );
    }



    public List<SandwichShopOrder> findAllOrders() {
        return sandwichShopOrderDao.getAllOrders();
    }

    public List<SandwichShopSandwich> findAllIncompleteSandwiches(){
        return sandwichShopOrderDao.getIncompleteSandwiches();
    }

    public List<String> findAllBreadTypes(){
        return sandwichShopOrderDao.getBreadTypes();
    }

    public List<String> findAllMeatTypes(){
        return sandwichShopOrderDao.getMeatTypes();
    }


    @WfDelegateMethod( wfStepConfigId = 884 )
    public JsonResponse moveColdSandwich(
            @WfParam( WfParamValue.USER_ID) String user,
            @WfParam( WfParamValue.JSON_POST ) JsonPost post
    ) {

        Set<Long> sandwichWfIds = new HashSet<Long>();
        for (Map<String,String> postData: post.getRows()) {
            //extract wfId to associate data
            Long wfId = Long.parseLong(postData.get("wfId"));
            sandwichWfIds.add(wfId);
        }

        Set<Long> sandwichWfDataConfigs = new HashSet<Long>();
        sandwichWfDataConfigs.add( TOASTING_DESIRED_WF_DATA_CONFIG_ID );

        Map<Long, List<WfData>> sandwichesWfData = wfDataDao.find( sandwichWfIds, sandwichWfDataConfigs );

        for(Map.Entry<Long, List<WfData>> sandwichEntry : sandwichesWfData.entrySet() ) {
            for( WfData dataItem : sandwichEntry.getValue() ) {
                if( dataItem.getWfDataConfigId() == TOASTING_DESIRED_WF_DATA_CONFIG_ID ) {
                    Long nextWfStepConfigId = null;

                    if( "Y".equals( dataItem.getWfDataVarchar2())) {
                        nextWfStepConfigId = TOASTER_SELECTION_WF_STEP_CONFING_ID;
                    }

                    wfService.passSingleWf( sandwichEntry.getKey(), user, nextWfStepConfigId );
                }
            }
        }

        return new JsonResponse();
    }

    public void closeOrder(Long wfId) {
        sandwichShopOrderDao.closeOrder(wfId);
    }
}
