package com.monsanto.gwg.atlas.json.admin;

import com.monsanto.gwg.atlas.model.core.WfStepConfig;
import com.monsanto.gwg.atlas.model.core.WfStepDataConfig;

import java.util.List;

/**
 * Created by pgros1 on 7/21/14.
 */
public class JsonWfStepAndStepDataConfig {
    private String createUser;
    private WfStepConfig wfStepConfig;
    private List<WfStepDataConfig> wfStepDataConfigs;
    private List<WfStepDataConfig> wfStepDataConfigsToRemove;

    public WfStepConfig getWfStepConfig() {
        return wfStepConfig;
    }

    public void setWfStepConfig(WfStepConfig wfStepConfig) {
        this.wfStepConfig = wfStepConfig;
    }

    public List<WfStepDataConfig> getWfStepDataConfigs() {
        return wfStepDataConfigs;
    }

    public void setWfStepDataConfigs(List<WfStepDataConfig> wfStepDataConfigs) {
        this.wfStepDataConfigs = wfStepDataConfigs;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public List<WfStepDataConfig> getWfStepDataConfigsToRemove() {
        return wfStepDataConfigsToRemove;
    }

    public void setWfStepDataConfigsToRemove(List<WfStepDataConfig> wfStepDataConfigsToRemove) {
        this.wfStepDataConfigsToRemove = wfStepDataConfigsToRemove;
    }
}
