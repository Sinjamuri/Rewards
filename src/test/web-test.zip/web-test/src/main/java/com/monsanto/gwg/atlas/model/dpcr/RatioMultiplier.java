package com.monsanto.gwg.atlas.model.dpcr;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by pgros1 on 1/15/2015.
 */
public class RatioMultiplier {
    public RatioMultiplier() {}

    public RatioMultiplier( Map serializedRatioMultiplier ) {
        crop = (String) serializedRatioMultiplier.get( "crop" );
        tissueType = (String) serializedRatioMultiplier.get( "tissueType" );
        multiplier = new Float( (String)serializedRatioMultiplier.get( "multiplier" ) );
    }

    private String crop;
    private String tissueType;
    private Float multiplier;

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getTissueType() {
        return tissueType;
    }

    public void setTissueType(String tissueType) {
        this.tissueType = tissueType;
    }

    public Float getMultiplier() {
        return multiplier;
    }

    public void setMultiplier(Float multiplier) {
        this.multiplier = multiplier;
    }
}
