package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;

/**
 * Created by regama on 3/20/15.
 */
public class XRobotJob {
    @DbColumn(field="robot_job_id")
    private Long robotJobId;
    @DbColumn(field="robot_job_name")
    private String robotJobName;
    @DbColumn(field="lims_create_date")
    private Timestamp limsCreateDate;
    @DbColumn(field="lims_create_user")
    private String limsCreateUser;
    @DbColumn(field="team_name")
    private String teamName;
    @DbColumn(field="team_site")
    private String teamSite;
    @DbColumn(field="robot_job_type")
    private String robotJobType;
    @DbColumn(field="run_date")
    private Timestamp runDate;
    @DbColumn(field="run_machine")
    private String runMachine;
    @DbColumn(field="run_user")
    private String runUser;
    @DbColumn(field="status")
    private String status;

    public Long getRobotJobId() {
        return robotJobId;
    }

    public void setRobotJobId(Long robotJobId) {
        this.robotJobId = robotJobId;
    }

    public String getRobotJobName() {
        return robotJobName;
    }

    public void setRobotJobName(String robotJobName) {
        this.robotJobName = robotJobName;
    }

    public Timestamp getLimsCreateDate() {
        return limsCreateDate;
    }

    public void setLimsCreateDate(Timestamp limsCreateDate) {
        this.limsCreateDate = limsCreateDate;
    }

    public String getLimsCreateUser() {
        return limsCreateUser;
    }

    public void setLimsCreateUser(String limsCreateUser) {
        this.limsCreateUser = limsCreateUser;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getTeamSite() {
        return teamSite;
    }

    public void setTeamSite(String teamSite) {
        this.teamSite = teamSite;
    }

    public String getRobotJobType() {
        return robotJobType;
    }

    public void setRobotJobType(String robotJobType) {
        this.robotJobType = robotJobType;
    }

    public Timestamp getRunDate() {
        return runDate;
    }

    public void setRunDate(Timestamp runDate) {
        this.runDate = runDate;
    }

    public String getRunMachine() {
        return runMachine;
    }

    public void setRunMachine(String runMachine) {
        this.runMachine = runMachine;
    }

    public String getRunUser() {
        return runUser;
    }

    public void setRunUser(String runUser) {
        this.runUser = runUser;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
