package com.monsanto.gwg.atlas.service.ankTaqmanService;

public class AnkTaqmanConstants {

  public final static Long PROJECT_WF_ENTITY_TYPE_ID = 501L;

  public final static Long READY_FOR_DETECTION_WF_STEP_CONFIG_ID = 5030L;

  public final static Long BATCH_STATUS_WF_DATA_CONFIG_ID=5059L;
}
