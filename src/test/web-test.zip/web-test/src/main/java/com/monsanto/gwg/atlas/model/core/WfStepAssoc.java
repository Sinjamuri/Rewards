package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;

/**
 * Created by pgros1 on 7/7/14.
 */
public class WfStepAssoc {
    @DbColumn(field="wf_config_id")
    private Long wfConfigId;
    @DbColumn(field="wf_step_assoc_id")
    private Long wfStepAssocId;
    @DbColumn(field="wf_step_config_id")
    private Long wfStepConfigId;
    @DbColumn(field="next_wf_step_config_id")
    private Long nextWfStepConfigId;
    @DbColumn(field="wf_ncr_config_id")
    private Long wfNcrConfigId;
    @DbColumn(field="next_wf_ncr_config_id")
    private Long nextWfNcrConfigId;
    @DbColumn(field="status")
    private String status;
    @DbColumn(field="last_scan_use_ts")
    private Timestamp lastScanUseTs;
    @DbColumn(field="create_user")
    private String createUser;
    @DbColumn(field="create_ts")
    private Timestamp createTs;

    public Long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(Long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public Long getWfStepAssocId() {
        return wfStepAssocId;
    }

    public void setWfStepAssocId(Long wfStepAssocId) {
        this.wfStepAssocId = wfStepAssocId;
    }

    public Long getWfStepConfigId() {
        return wfStepConfigId;
    }

    public void setWfStepConfigId(Long wfStepConfigId) {
        this.wfStepConfigId = wfStepConfigId;
    }

    public Long getNextWfStepConfigId() {
        return nextWfStepConfigId;
    }

    public void setNextWfStepConfigId(Long nextWfStepConfigId) {
        this.nextWfStepConfigId = nextWfStepConfigId;
    }

    public Long getWfNcrConfigId() {
        return wfNcrConfigId;
    }

    public void setWfNcrConfigId(Long wfNcrConfigId) {
        this.wfNcrConfigId = wfNcrConfigId;
    }

    public Long getNextWfNcrConfigId() {
        return nextWfNcrConfigId;
    }

    public void setNextWfNcrConfigId(Long nextWfNcrConfigId) {
        this.nextWfNcrConfigId = nextWfNcrConfigId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getLastScanUseTs() {
        return lastScanUseTs;
    }

    public void setLastScanUseTs(Timestamp lastScanUseTs) {
        this.lastScanUseTs = lastScanUseTs;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Timestamp createTs) {
        this.createTs = createTs;
    }
}
