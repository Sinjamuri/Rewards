package com.monsanto.gwg.atlas.json.admin;

import com.monsanto.gwg.atlas.model.admin.WfGraphLink;

import java.util.List;

/**
 * Created by pgros1 on 7/7/14.
 */
public class JsonWfGraphLinks {
    private java.util.List<WfGraphLink> wfGraphLinks;
    private String createUser;

    public List<WfGraphLink> getWfGraphLinks() {
        return wfGraphLinks;
    }

    public void setWfGraphLinks(List<WfGraphLink> wfGraphLinks) {
        this.wfGraphLinks = wfGraphLinks;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }
}
