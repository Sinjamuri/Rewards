package com.monsanto.gwg.atlas.service.dpcr;

import com.monsanto.gwg.atlas.model.dpcr.RatioThreshold;
import com.monsanto.gwg.atlas.service.dpcr.annotations.MethodOption;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by PGROS1 on 1/3/2015.
 */
public class RatioThresholdAlgorithms {

    @MethodOption(value = "manualThresholds", text = "Manual Thresholds", isDefault = true)
    public static Map<String, Map<String, RatioThreshold>> manualThresholds( List<RatioThreshold> fixedRatioThresholds) {
        Map<String, Map<String, RatioThreshold>> thresholds = new HashMap<String, Map<String, RatioThreshold>>();

        for( RatioThreshold ratioThreshold : fixedRatioThresholds) {
            Map<String, RatioThreshold> markerThresholds = thresholds.get( ratioThreshold.getMarker() );
            if( markerThresholds == null ) {
                markerThresholds = new HashMap<String, RatioThreshold>();
                thresholds.put( ratioThreshold.getMarker(), markerThresholds );
            }

            markerThresholds.put( ratioThreshold.getTissueType(), ratioThreshold );
        }

        return thresholds;
    }
}
