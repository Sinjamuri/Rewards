package com.monsanto.gwg.atlas.service.dpcr;

import com.monsanto.gwg.atlas.model.dpcr.*;
import org.apache.commons.lang.WordUtils;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.el.MethodNotFoundException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

/**
 * Created by pgros1 on 6/4/14.
 */
/* package-visible */ class ConstellationResultsFileHandler extends DefaultHandler {
    private static final String PLATE_INFO_TAG = "PlateInfo";
    private static final String FILTER_INFO_TAG = "FilterPairInfo";
    private static final String WELL_RESULT_TAG = "WellResult";


    private static final String REFERENCE_FILTER_TAG = "ReferencePlateResultFilterPairId";
    private static final String PARTITION_RESULT_DATA_TAG = "string";

    private static final String PARTITION_INTENSITY_TAG = "AveragePartitionIntensity";
    private static final String PARTITION_EMPTY_TAG = "PartitionIsEmpty";


    private static Map<String, Field> resultsDataTagToPartitionResultFieldMap = new HashMap<String, Field>();

    private ArrayList<DPcrPlate> plates = new ArrayList<DPcrPlate>();
    private Map<String, DPcrPlate> platesMap = new HashMap<String, DPcrPlate>();
    public ArrayList<DPcrPlate> getPlates() { return new ArrayList<DPcrPlate>( platesMap.values() ); }

    private DPcrPlate currentPlate;
    private FilterData currentFilter;
    private WellResult currentWell;
    private String currentDataType;

    private String referenceFilter;

    private Stack<String> elementStack = new Stack<String>();
    private String getCurrentElement() {
        return elementStack.peek();
    }

    private Stack objectStack = new Stack();
    private Object getCurrentObject() {
        try {
            return objectStack.peek();
        } catch ( EmptyStackException e ) {
            return null;
        }
    }

    private int partitionRow = 0;

    public ConstellationResultsFileHandler() throws NoSuchFieldException{
        resultsDataTagToPartitionResultFieldMap.put(PARTITION_INTENSITY_TAG, PartitionResult.class.getDeclaredField("intensityValue"));
        resultsDataTagToPartitionResultFieldMap.put(PARTITION_EMPTY_TAG, PartitionResult.class.getDeclaredField("isPartitionEmpty"));
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if( resultsDataTagToPartitionResultFieldMap.containsKey( qName ) && !qName.equals( currentDataType )) {
            currentDataType = qName;
            partitionRow = 0;
        }

        elementStack.push( qName );

        if( PLATE_INFO_TAG.equals(qName)) {
            currentPlate = new DPcrPlate();
//            plates.add(currentPlate);
            objectStack.push( currentPlate );

        } else if( WELL_RESULT_TAG.equals(qName)) {
            currentWell = new WellResult();
            currentWell.setAllPartitionResults(new TreeMap<Integer, TreeMap<Integer, TreeMap<String, PartitionResult>>>());
            objectStack.push( currentWell );
            partitionRow = 0;

        } else if( FILTER_INFO_TAG.equals(qName)) {
            currentFilter = new FilterData();
            currentFilter.setReferenceFilter( referenceFilter );
            currentPlate.addFilterData(currentFilter);
            objectStack.push( currentFilter );
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if( PLATE_INFO_TAG.equals(qName)) {
            DPcrPlate plate = (DPcrPlate) objectStack.pop();
            if( platesMap.containsKey( plate.getPlateImagingId() )) {
                currentPlate = platesMap.get( plate.getPlateImagingId() );
            } else {
                platesMap.put( plate.getPlateImagingId(), plate );
//                plate.setWellResults( new WellResult[ plate.getWellRowCount()][plate.getWellColumnCount()]);
                plate.setWellResults( new TreeMap<Integer, TreeMap<Integer, WellResult>>() );
            }
        } else if( WELL_RESULT_TAG.equals(qName)) {
            WellResult wellResult = (WellResult) objectStack.pop();
            currentPlate.setWellResult( wellResult.getGridRow() , wellResult.getGridCol() , wellResult);

        } else if( FILTER_INFO_TAG.equals(qName)) {
            objectStack.pop();
        }

        elementStack.pop();
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String value = new String( ch, start, length).trim();
        String currentElement = getCurrentElement();

        if( REFERENCE_FILTER_TAG.equals(currentElement)) {
            referenceFilter = value;

        } else if( PARTITION_RESULT_DATA_TAG.equals( currentElement )) {
            partitionRow++;

            try {
                Field partitionResultField = resultsDataTagToPartitionResultFieldMap.get( currentDataType );
                Method partitionResultFieldSetter = PartitionResult.class.getDeclaredMethod("set" + WordUtils.capitalize(partitionResultField.getName()), partitionResultField.getType());

                String[] values = value.split(";");
                int partitionColumn;
                for( int i = 0; i < values.length; i++ ) {
                    partitionColumn = i + 1;

                    PartitionResult partitionResult = currentWell.getPartitionResult( partitionRow, partitionColumn, currentFilter.getFilterPairId() );
                    if( partitionResult == null ) {
                        partitionResult = new PartitionResult();
                        partitionResult.setPartitionRow(partitionRow);
                        partitionResult.setPartitionColumn(partitionColumn);
                        partitionResult.setFilterName(currentFilter.getFilterPairId());

                        currentWell.setPartitionResult( partitionRow, partitionColumn, partitionResult);
                    }

                    Object fieldValue = values[i];
                    if( partitionResultField.getType().equals( Float.class )) {
                        fieldValue = new Float( values[i] );
                    } else if ( partitionResultField.getType().equals( Boolean.TYPE)) {
                        fieldValue = Boolean.parseBoolean(values[i]);
                    }

                    partitionResultFieldSetter.invoke(partitionResult, fieldValue);
                }
            } catch ( MethodNotFoundException e ) {
                throw new MethodNotFoundException( e );
            } catch (Exception e ) {
                // pass
            }
        } else  {
            try {
                Object currentObject = getCurrentObject();
                if( currentObject != null ) {
                    Field field = currentObject.getClass().getDeclaredField(WordUtils.uncapitalize(getCurrentElement()));
                    Method setterMethod = currentObject.getClass().getMethod( "set" + WordUtils.capitalize(field.getName()), field.getType());

                    Object typedValue = value;

                    if( field.getType().equals( Integer.TYPE) ) {
                        typedValue = Integer.parseInt( value );
                    } else if (field.getType().equals( Float.class )) {
                        typedValue = new Float( value );
                    } else if( field.getType().equals( Boolean.TYPE )) {
                        typedValue = Boolean.parseBoolean( value );
                    }

                    setterMethod.invoke( getCurrentObject(), typedValue);
                }

            } catch (NoSuchFieldException e) {
                // pass, expected
            } catch (NoSuchMethodException e) {
                // pass, expected
            } catch ( Exception e ) {
                // pass
            }
        }
    }
}
