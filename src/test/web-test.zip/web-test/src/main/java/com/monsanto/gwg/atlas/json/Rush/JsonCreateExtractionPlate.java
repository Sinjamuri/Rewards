package com.monsanto.gwg.atlas.json.Rush;

/**
 * Created by HHZHU on 9/26/14.
 */
public class JsonCreateExtractionPlate {
}
