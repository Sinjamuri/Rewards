package com.monsanto.gwg.atlas.service.stltaqmanService;

/**
 * Created by ASHAR7 on 12/22/2014.
 */
public interface StltaqmanConstants {

  public final static long WF_CONFIG_ID = 30L;
  public final static String WF_CONFIG = "stltaqman";
  public static final long REQUEST_ID_DATA_CONFIG_ID = 3014L;
  public static final Long READY_TO_RECEIVE_STEP_CONFIG_ID = 3000L;
  public static final Long ARRIVED_STEP_CONFIG_ID = 3005L;
  public static final Long SAMPLE_VERIFICATION_STEP_CONFIG_ID = 3010L;
  public static final long EXTRACTION_COMPLETE_STEP_CONFIG_ID =3018L;
  public static final Long PRE_PCR_ASSEMBLY_STEP_CONFIG_ID = 3020L;
  public static final Long CHERRY_PICK_PLATE_ASSEMBLY_STEP_CONFIG_ID = 3033L;
  public static final Long CHERRY_PICK_JOB_ASSEMBLY_STEP_CONFIG_ID = 3034L;
  public static final long READY_FOR_CLEANUP_STEP_CONFIG_ID =3015L;
  public static final Long AP_DATA_CONFIG_ID = 3002L;
  public static final Long CROP_DATA_CONFIG_ID = 3005L;
  public static final Long DUE_DATE_DATA_CONFIG_ID = 3010L;
  public static final Long AUTOTOOL_JOB_NAME_DATA_CONFIG_ID = 3017L;
  public static final long CYCLING_CONDITIONS_DATA_CONFIG_ID = 3018L;
  public static final Long PCR_PLATE_DATA_CONFIG_ID = 3037L;
  public static final Long EXTRACTION_PLATE_DATA_CONFIG_ID = 3066L;
  public static final Long ASSAY_SUBSTANCE_DATA_CONFIG_ID = 3035L;
  public static final long ASSAYS_COUNT_DATA_CONFIG_ID = 3070L;
  public static final Long CONTROL_PLATE_CORN_RAPTOR_DATA_CONFIG_ID = 3073L;
  public static final Long PCR_EXT_STATUS_DATA_CONFIG_ID = 3076L;
  public static final Long MIX_JOB_STATUS_DATA_CONFIG_ID = 3078L;
  public static final Long CONTROL_JOB_STATUS_DATA_CONFIG_ID = 3079L;
  public static final Long PCR_PLATES_COUNT_DATA_CONFIG_ID = 3080L;
  public static final Long CONTROL_JOB_ID_DATA_CONFIG_ID = 3081L;
  public static final Long MIX_JOB_ID_DATA_CONFIG_ID = 3082L;
  public static final Long RAPTOR_JOB_ID = 3083L;
  public static final Long RAPTOR_JOB_NAME_DATA_CONFIG_ID = 3086L;
  public static final Long FORECASTED_DATA_STEP_CONFIG_ID = 3045L;
  public static final long LAN_NAME_DATA_CONFIG_ID = 3090L;
  public static final Long OFFLINE_JOB_NAME_DATA_CONFIG_ID=3092L;
  public static final Long OFFLINE_JOB_ID_DATA_CONFIG_ID=3093L;
  public static final Long QUADRANT_1_ASSAY_DATA_CONFIG_ID = 3095L;
  public static final Long QUADRANT_2_ASSAY_DATA_CONFIG_ID = 3096L;
  public static final Long QUADRANT_3_ASSAY_DATA_CONFIG_ID = 3097L;
  public static final Long QUADRANT_4_ASSAY_DATA_CONFIG_ID = 3098L;
  public static final Long NUMBER_OF_TEMPESTS_DATA_CONFIG_ID = 3099L;
  public static final Long STATUS_DATA_CONFIG_ID = 3100L;
  public static final Long REDO_REASON_DATA_CONFIG_ID = 3102L;
  public static final long RUN_TYPE_DATA_CONFIG_ID = 163L;
  public static final long IS_CHERRY_PICK_PLATE_DATA_CONFIG_ID =3101L;
  public static final Long R01_REDO_ASSAY_NAME_DATA_CONFIG_ID = 3103L;

  public static final long REQUEST_ENTITY_ID = 300L;
  public static final long PLATE_96_WELL_ENTITY_ID = 301L;
  public static final int PLATE_ENTITY_ID = 301;
  public static final long PLATE_384_WELL_ENTITY_ID = 302L;
  public static final long CONTROL_PLATE_ENTITY_ID = 304L;
  public static final Long PREMIX_PLATE_ENTITY_ID = 306L;
  public static final long NOTES_DATA_CONFIG_ID = 71L;
  public static final long EPLATE_ENTITY_ID = 303L;


  public static final Long CONTROL_TYPE_GRID_DATA_TYPE = 515L;
  public static final Long ASSAY_SUBSTANCE_GRID_DATA_TYPE = 516L;
  public static final Long VOLUME_GRID_DATA_TYPE = 517L;
  public static final long LAN_NAME_GRID_DATA_TYPE_ID=518L;
  public static final long IS_CHERRY_PICKED_GRID_DATA_TYPE = 521L;
  public static final long NUMBER_OF_CHERRY_PICKS_GRID_DATA_TYPE = 522L;
  public static final long REDO_REASON_GRID_DATA_TYPE = 523L;
  public static final Long SAMPLE_DROPPED_GRID_TYPE_ID = 525L;

  public static final Long TEMPLATE_PREMIX_PLATE_WF_ID = 10096747L;
  public static final Long TEMPLATE_CONTROL_PLATE_WF_ID = 10070820L;
  public static final int CONTROL_DNA_VOLUME = 2;
  public static final Double ASSAY_MIX_TRANSFER_VOLUME = 2.5;
  public static final int CONTROL_DNA_STANDARD_PLATE_VOLUME = 150;


  public static final long REQUEST_DATA_CONFIG_ID = 3001L;
  public static final int REQUEST_ENTITY_TYPE_ID = 300;
  public static final int CONTROL_PLATE_ENTITY_TYPE_ID = 304;
  public static final long PCR_PLATE_ENTITY_TYPE_ID = 305;
  public static final long PCR_JOB_ENTITY_TYPE_ID = 307;

  public static final String STATUS_HOLD= "H";
  public static final String STATUS_IN_PROGRESS = "I";
  public static final long E_PLATEBARCODE_GRID_DATA_TYPE = 520L;
  public static final long MARKER_REFERENCE_ID_DATA_CONFIG_ID = 3032L;
  public static final Long ELUTION_FACTOR_DATA_CONFIG_ID = 3104L;

  public static final String REASON_CODE_R01 = "R01";
  public static final String REASON_CODE_R02 = "R02";
  public static final String REASON_CODE_R03 = "R03";


/*
  public static final long SAMPLE_DROPPED_GRID_TYPE_ID = 304L;
  public static final Long GENERATION_GRID_TYPE_ID = 303L;
  public static final Long PEDIGREE_GRID_TYPE_ID = 501L;
  public static final long ORIGIN_GRID_TYPE_ID = 302L;

  public static final String CHAR_YES = "Y";
  */
}

