package com.monsanto.gwg.atlas.model.rush;


/**
 * Created by HHZHU on 10/22/14.
 */
public class RushSamplePlate {
    private long  wfConfigId ;
    private long wfEntityTypeId;
    private String sampleUploadId;

    private long wfStepConfigId;
    private String CreateUser;

    public RushSamplePlate() {
    }

    public long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public long getWfEntityTypeId() {
        return wfEntityTypeId;
    }

    public void setWfEntityTypeId(long wfEntityTypeId) {
        this.wfEntityTypeId = wfEntityTypeId;
    }

    public String getSampleUploadId() {
        return sampleUploadId;
    }

    public void setSampleUploadId(String sampleUploadId) {
        this.sampleUploadId = sampleUploadId;
    }

    public long getWfStepConfigId() {
        return wfStepConfigId;
    }

    public void setWfStepConfigId(long wfStepConfigId) {
        this.wfStepConfigId = wfStepConfigId;
    }

    public String getCreateUser() {
        return CreateUser;
    }

    public void setCreateUser(String createUser) {
        CreateUser = createUser;
    }




}
