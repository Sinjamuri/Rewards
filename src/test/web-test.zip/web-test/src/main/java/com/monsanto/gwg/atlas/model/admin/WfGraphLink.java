package com.monsanto.gwg.atlas.model.admin;

/**
 * Created by pgros1 on 6/30/14.
 */
public class WfGraphLink {
    private Long wfStepAssocId;
    private String wfSourceGraphNodeId;
    private String wfTargetGraphNodeId;
    private String status;
    private boolean isDirty;

    public Long getWfStepAssocId() {
        return wfStepAssocId;
    }

    public void setWfStepAssocId(Long wfStepAssocId) {
        this.wfStepAssocId = wfStepAssocId;
    }

    public String getWfSourceGraphNodeId() {
        return wfSourceGraphNodeId;
    }

    public void setWfSourceGraphNodeId(String wfSourceGraphNodeId) {
        this.wfSourceGraphNodeId = wfSourceGraphNodeId;
    }

    public String getWfTargetGraphNodeId() {
        return wfTargetGraphNodeId;
    }

    public void setWfTargetGraphNodeId(String wfTargetGraphNodeId) {
        this.wfTargetGraphNodeId = wfTargetGraphNodeId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean getIsDirty() {
        return isDirty;
    }

    public void setIsDirty(boolean isDirty) {
        this.isDirty = isDirty;
    }
}
