package com.monsanto.gwg.atlas.model.core;

import java.sql.Clob;
import java.sql.Timestamp;

public class WfPrintQueue {
  private Long wfPrintQueueId;
  private String wfPrintDestination;
  private String wfPrintFile;
  private Timestamp queueEnterTs;
  private Timestamp agentStartTs;
  private Timestamp agentCompleteTs;
  private Long printerId;
  private String responseMessage;

  public Long getPrinterId() {
    return printerId;
  }

  public void setPrinterId(Long printerId) {
    this.printerId = printerId;
  }

  public Long getWfPrintQueueId() {
    return wfPrintQueueId;
  }

  public void setWfPrintQueueId(Long wfPrintQueueId) {
    this.wfPrintQueueId = wfPrintQueueId;
  }

  public String getWfPrintDestination() {
    return wfPrintDestination;
  }

  public void setWfPrintDestination(String wfPrintDestination) {
    this.wfPrintDestination = wfPrintDestination;
  }

  public String getWfPrintFile() {
    return wfPrintFile;
  }

  public void setWfPrintFile(String wfPrintFile) {
    this.wfPrintFile = wfPrintFile;
  }

  public Timestamp getQueueEnterTs() {
    return queueEnterTs;
  }

  public void setQueueEnterTs(Timestamp queueEnterTs) {
    this.queueEnterTs = queueEnterTs;
  }

  public Timestamp getAgentStartTs() {
    return agentStartTs;
  }

  public void setAgentStartTs(Timestamp agentStartTs) {
    this.agentStartTs = agentStartTs;
  }

  public Timestamp getAgentCompleteTs() {
    return agentCompleteTs;
  }

  public void setAgentCompleteTs(Timestamp agentCompleteTs) {
    this.agentCompleteTs = agentCompleteTs;
  }

  public String getResponseMessage(){return this.responseMessage;}

  public void setResponseMessage(String responseMessage){this.responseMessage = responseMessage;}
}
