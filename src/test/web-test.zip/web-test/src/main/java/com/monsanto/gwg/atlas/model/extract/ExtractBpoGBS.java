package com.monsanto.gwg.atlas.model.extract;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;

/**
 * Created by ASHAR7 on 1/13/2015.
 */
public class ExtractBpoGBS {
        @DbColumn(field="plate_id")
    private String plateId;
        @DbColumn(field="block_barcode_nbr")
    private String blockBarcodeNbr;
        @DbColumn(field="create_ts")
    private Timestamp createTs;
        @DbColumn(field="mb_id")
    private String mbId;

    public String getPlateId() {
        return plateId;
    }

    public void setPlateId(String plateId) {
        this.plateId = plateId;
    }

    public String getBlockBarcodeNbr() {
        return blockBarcodeNbr;
    }

    public void setBlockBarcodeNbr(String blockBarcodeNbr) {
        this.blockBarcodeNbr = blockBarcodeNbr;
    }

    public Timestamp getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Timestamp createTs) {
        this.createTs = createTs;
    }

    public String getMbId() {
        return mbId;
    }

    public void setMbId(String mbId) {
        this.mbId = mbId;
    }
}
