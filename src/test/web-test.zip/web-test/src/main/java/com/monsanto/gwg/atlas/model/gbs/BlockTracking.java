package com.monsanto.gwg.atlas.model.gbs;

import java.sql.Timestamp;

/**
 * Created by ashar7 on 3/16/2016.
 */
public class BlockTracking {

  private String limsId;
  private String blockBarcodeNbr;
  private String entityName;
  private Long wfId;
  private Long wfNcrId;
  private String stepConfigName;
  private String createUser;
  private Timestamp createTs;

  public String getLimsId() {
    return limsId;
  }

  public void setLimsId(String limsId) {
    this.limsId = limsId;
  }

  public String getBlockBarcodeNbr() {
    return blockBarcodeNbr;
  }

  public void setBlockBarcodeNbr(String blockBarcodeNbr) {
    this.blockBarcodeNbr = blockBarcodeNbr;
  }

  public String getEntityName() {
    return entityName;
  }

  public void setEntityName(String entityName) {
    this.entityName = entityName;
  }

  public Long getWfId() {
    return wfId;
  }

  public void setWfId(Long wfId) {
    this.wfId = wfId;
  }

  public Long getWfNcrId() {
    return wfNcrId;
  }

  public void setWfNcrId(Long wfNcrId) {
    this.wfNcrId = wfNcrId;
  }

  public String getStepConfigName() {
    return stepConfigName;
  }

  public void setStepConfigName(String stepConfigName) {
    this.stepConfigName = stepConfigName;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }
}
