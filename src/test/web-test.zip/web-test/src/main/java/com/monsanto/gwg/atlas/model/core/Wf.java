package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Wf {
    @DbColumn(field="wf_id")
  private Long wfId;
    @DbColumn(field="wf_config_id")
  private Long wfConfigId;
    @DbColumn(field="wf_status")
  private String wfStatus;
    @DbColumn(field="wf_step_config_id")
  private Long wfStepConfigId;
    @DbColumn(field="wf_entity_type_id")
  private Long wfEntityTypeId;
    @DbColumn(field="wf_entity_label")
  private String wfEntityLabel;
    @DbColumn(field="create_user")
  private String createUser;
    @DbColumn(field="create_ts")
  private Timestamp createTs;
    @DbColumn(field="update_user")
  private String updateUser;
    @DbColumn(field="update_ts")
  private Timestamp updateTs;

  //workflow data loaded at fetch for display & validation purposes
  //the map key is the workflow data config id and the value is an
  //ordered list of associated workflow data
  Map<Long,List<WfData>> wfDataMap = new HashMap<Long, List<WfData>>();

  //fields loaded by mapped meta data for the workflow active step
  private String scanLineKey;
  private String scanLineSetIndex;
  private String wfStepConfigLabel;
  private String maxWfStepTimestamp;
  private String note;
  private Timestamp dueDateTimestamp;

  public Long getWfId() {
    return wfId;
  }

  public void setWfId(Long wfId) {
    this.wfId = wfId;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }

  public String getWfStatus() {
    return wfStatus;
  }

  public void setWfStatus(String wfStatus) {
    this.wfStatus = wfStatus;
  }

  public Long getWfStepConfigId() {
    return wfStepConfigId;
  }

  public void setWfStepConfigId(Long wfStepConfigId) {
    this.wfStepConfigId = wfStepConfigId;
  }

  public Long getWfEntityTypeId() {
    return wfEntityTypeId;
  }

  public void setWfEntityTypeId(Long wfEntityTypeId) {
    this.wfEntityTypeId = wfEntityTypeId;
  }

  public String getWfEntityLabel() {
    return wfEntityLabel;
  }

  public void setWfEntityLabel(String wfEntityLabel) {
    this.wfEntityLabel = wfEntityLabel;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public Timestamp getCreateTs() {
    return createTs;
  }

  public void setCreateTs(Timestamp createTs) {
    this.createTs = createTs;
  }

  public String getUpdateUser() {
    return updateUser;
  }

  public void setUpdateUser(String updateUser) {
    this.updateUser = updateUser;
  }

  public Timestamp getUpdateTs() {
    return updateTs;
  }

  public void setUpdateTs(Timestamp updateTs) {
    this.updateTs = updateTs;
  }

  public Map<Long, List<WfData>> getWfDataMap() {
    return wfDataMap;
  }

  public String getScanLineKey() {
    return scanLineKey;
  }

  public void setScanLineKey(String scanLineKey) {
    this.scanLineKey = scanLineKey;
  }

  public String getScanLineSetIndex() {
    return scanLineSetIndex;
  }

  public void setScanLineSetIndex(String scanLineSetIndex) {
    this.scanLineSetIndex = scanLineSetIndex;
  }

  public String getWfStepConfigLabel() {
    return wfStepConfigLabel;
  }

  public void setWfStepConfigLabel(String wfStepConfigLabel) {
    this.wfStepConfigLabel = wfStepConfigLabel;
  }

  public String getMaxWfStepTimestamp() {
    return maxWfStepTimestamp;
  }

  public void setMaxWfStepTimestamp(String maxWfStepTimestamp) {
    this.maxWfStepTimestamp = maxWfStepTimestamp;
  }

  public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public Timestamp getDueDateTimestamp() {
    return dueDateTimestamp;
  }

  public void setDueDateTimestamp(Timestamp dueDateTimestamp) {
    this.dueDateTimestamp = dueDateTimestamp;
  }
}
