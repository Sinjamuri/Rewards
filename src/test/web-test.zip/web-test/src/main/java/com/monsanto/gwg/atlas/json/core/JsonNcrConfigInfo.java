package com.monsanto.gwg.atlas.json.core;

public class JsonNcrConfigInfo {
  private String ncrName;
  private String ncrDescription;
  private String allowedUsers;

  public String getNcrName() {
    return ncrName;
  }

  public void setNcrName(String ncrName) {
    this.ncrName = ncrName;
  }

  public String getNcrDescription() {
    return ncrDescription;
  }

  public void setNcrDescription(String ncrDescription) {
    this.ncrDescription = ncrDescription;
  }

  public String getAllowedUsers() {
    return allowedUsers;
  }

  public void setAllowedUsers(String allowedUsers) {
    this.allowedUsers = allowedUsers;
  }
}
