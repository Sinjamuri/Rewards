package com.monsanto.gwg.atlas.json.core;

/**
 * Created by pgros1 on 7/18/14.
 */
public class JsonOption {
    private String text;
    private java.util.Map<String,Object> attr;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setAttribute( String attribute, Object value ) {
        if( attr == null ) {
            attr = new java.util.TreeMap<String, Object>();
        }

        attr.put( attribute, value );
    }

    public java.util.Map<String, Object> getAttr() {
        return attr;
    }
}
