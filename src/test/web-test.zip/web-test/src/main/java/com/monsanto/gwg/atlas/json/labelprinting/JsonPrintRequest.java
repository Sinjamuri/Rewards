package com.monsanto.gwg.atlas.json.labelprinting;

/**
 * Created by syroth on 5/28/2017.
 */
public class JsonPrintRequest {

    private String printInstructions;
    private String printerIP;



    public String getPrintInstructions(){return this.printInstructions;}

    public void setPrintInstructions(String printInstructions){
        this.printInstructions = printInstructions;
    }

    public String getPrinterIP(){
        return this.printerIP;
    }

    public void setPrinterIP(String printerIP){
        this.printerIP = printerIP;
    }



    @Override
    public String toString(){
        return "JsonPrintRequest [printInstructions=" + this.printInstructions + ", printerIP = " + this.printerIP + "]";
    }


}
