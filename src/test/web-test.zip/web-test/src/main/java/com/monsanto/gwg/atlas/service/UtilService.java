package com.monsanto.gwg.atlas.service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.monsanto.gwg.atlas.dao.core.AtlasUserDao;
import com.monsanto.gwg.atlas.dao.core.WfConfigDao;
import com.monsanto.gwg.atlas.model.core.AtlasUserInfo;
import com.monsanto.gwg.atlas.model.core.WfConfig;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.servlet.http.Cookie;
import java.io.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

@Service
@Scope(value = "singleton")
public class UtilService {

  private static final Logger LOG = LoggerFactory.getLogger(UtilService.class);

  @Autowired
  private AtlasUserDao atlasUserDao;

  @Autowired
  private WfConfigDao wfConfigDao;

	private static final DateFormat DATE_TIME_AM_PM = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
	private static final DateFormat DATE_RUBICON_UPLOAD = new SimpleDateFormat("M/d/yyyy");

	/**
	 * Converts a stack trace to String representation.
	 * @param t
	 * @return
	 */
	public String getStackTrace(Throwable t) {
		final Writer sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw);
		t.printStackTrace(pw);
		return sw.toString();
	}

	/**
	 * Iterates through an array of cookies and returns the cookie value matching the name argument.
	 * This function returns null if the cookie was not found.
	 * @param cookies
	 * @param name
	 * @return
	 */
	public String getCookieValue(Cookie[] cookies, String name) {
		if (cookies!=null) {
			for (Cookie cookie: cookies) {
				if (cookie.getName().equals(name)) {
					return cookie.getValue();
				}
			}
		}
		return null;
	}

	/**
	 * Returns the current fiscal year.  The new fiscal year begins on 9/1.
	 * @return
	 */
	public int getFiscalYear() {
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);

		//JANUARY=0 ... SEPTEMBER=8
		//new fiscal year starts on 9/1
		if (calendar.get(Calendar.MONTH)>=8) {
			year++;
		}
		return year;
	}

	public String getFiscalYear2Digit() {
		return String.valueOf(getFiscalYear()).substring(2);
	}

	public String formatDateTimeAmPm(Date date) {
		if (date==null) {
			return "";
		} else {
		  return DATE_TIME_AM_PM.format(date);
		}
	}

  public String formatDateRubiconUpload(Date date) {
    if (date==null) {
      return "";
    } else {
      return DATE_RUBICON_UPLOAD.format(date);
    }
  }

  /**
   *
   * @param data
   * @param outputStream
   * @param size
   * Valid sizes: 41,82,123,164,205
   */
  public void generateQRCode(String data, OutputStream outputStream, int size) {
    //ISO-8859-1 is required character set
    final String QR_ENCODING = "ISO-8859-1";

    Charset charset = Charset.forName(QR_ENCODING);
    CharsetEncoder encoder = charset.newEncoder();
    byte[] b = null;
    try {
      // Convert a string to ISO-8859-1 bytes in a ByteBuffer
      ByteBuffer byteBuffer = encoder.encode(CharBuffer.wrap(data));
      b = byteBuffer.array();
    } catch (CharacterCodingException ex) {
      LOG.error("Exception occurred while converting to ISO-8859-1 character set for QR Code generation", ex);
      return;
    }

    //build hint map
    Map<EncodeHintType, Object> hintMap = new HashMap<EncodeHintType, Object>();
    hintMap.put(EncodeHintType.CHARACTER_SET, QR_ENCODING);
    hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);

    //get a bit matrix for the data
    BitMatrix bitMatrix = null;
    try {
      bitMatrix = new QRCodeWriter().encode(new String(b, QR_ENCODING), BarcodeFormat.QR_CODE, size, size, hintMap);
      MatrixToImageWriter.writeToStream(bitMatrix, "PNG", outputStream);
    } catch (Exception ex) {
      LOG.error("Exception occurred while encoding the QR Code", ex);
      return;
    }
  }

  public void generateBadge(String userId, String data, OutputStream outputStream) throws Exception {
    ByteArrayOutputStream bos1 = new ByteArrayOutputStream();
    ByteArrayOutputStream bos2 = new ByteArrayOutputStream();
    ByteArrayOutputStream bos3 = new ByteArrayOutputStream();

    //build images
    generateQRCode(data, bos1, 123);
    generateQRCode(data, bos2, 82);
    generateQRCode(data, bos3, 41);

    //render pdf
    generateBadge(outputStream, bos1.toByteArray(), bos2.toByteArray(), bos3.toByteArray(), userId);
  }

  public void generateBadge(OutputStream outputStream,
                                   byte[] img1b,
                                   byte[] img2b,
                                   byte[] img3b,
                                   String userId) throws Exception {

    com.itextpdf.text.Font helvetica10 = FontFactory.getFont(FontFactory.HELVETICA, 10);
//    helvetica10.setStyle(com.itextpdf.text.Font.BOLD);

    //create document
    Document document = new Document(PageSize.LETTER);
    document.setMargins(36f, 36f, 36f, 36f);

    PdfWriter.getInstance(document, outputStream);
    document.open();
    document.newPage();
    document.setPageCount(1);

    com.itextpdf.text.Image img1 = com.itextpdf.text.Image.getInstance(img1b);
    com.itextpdf.text.Image img2 = com.itextpdf.text.Image.getInstance(img2b);
    com.itextpdf.text.Image img3 = com.itextpdf.text.Image.getInstance(img3b);

    //two columns, one per badge side
    PdfPTable table = new PdfPTable(4);
    PdfPCell cell;

    cell = new PdfPCell(img1);
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setColspan(2);
    cell.setBorderColor(BaseColor.WHITE);
    table.addCell(cell);
    table.addCell(cell);
    table.completeRow();

    cell = new PdfPCell(img2);
    cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
    cell.setColspan(1);
    cell.setBorderColor(BaseColor.WHITE);
    table.addCell(cell);

    cell = new PdfPCell(img3);
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
    cell.setPaddingTop(4);
    cell.setColspan(1);
    cell.setBorderColor(BaseColor.WHITE);
    table.addCell(cell);

    cell = new PdfPCell(img2);
    cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
    cell.setColspan(1);
    cell.setBorderColor(BaseColor.WHITE);
    table.addCell(cell);

    cell = new PdfPCell(img3);
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
    cell.setPaddingTop(4);
    cell.setColspan(1);
    cell.setBorderColor(BaseColor.WHITE);
    table.addCell(cell);

    table.setComplete(true);

    PdfPTable tableOuter = new PdfPTable(2);
    tableOuter.setWidthPercentage(54);
    cell = new PdfPCell(table);
    cell.setColspan(2);
    cell.setPadding(3);
    cell.setBorderColor(new BaseColor(130,130,130));
    cell.setBorderWidthBottom(1);
    tableOuter.addCell(cell);
    tableOuter.completeRow();

    Phrase phrase = new Phrase(userId, helvetica10);
    cell = new PdfPCell(phrase);
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
    cell.setPaddingTop(5);
    cell.setPaddingBottom(7);
    cell.setBorderColor(new BaseColor(130, 130, 130));
    cell.setBorderWidthTop(0);
    float borderWidth = cell.getBorderWidthRight();
    cell.setBorderWidthRight(0);
    tableOuter.addCell(cell);

    cell.setBorderWidthRight(borderWidth);
    cell.setBorderWidthLeft(0);
    tableOuter.addCell(cell);
    tableOuter.setComplete(true);
    document.add(tableOuter);

    //add instructions
    PdfPTable instructionTable = new PdfPTable(1);
    instructionTable.setSpacingBefore(30);

    cell = new PdfPCell(new Phrase("1. Print this page"));
    cell.setBorderWidth(0);
    instructionTable.addCell(cell);

    cell = new PdfPCell(new Phrase("2. Fold page in half the long way"));
    cell.setBorderWidth(0);
    instructionTable.addCell(cell);

    cell = new PdfPCell(new Phrase("3. Cut 3 edges along outer lines"));
    cell.setBorderWidth(0);
    instructionTable.addCell(cell);

    cell = new PdfPCell(new Phrase("4. Insert into 2-1/4\" X 3-3/4\" 10 mil laminating sleeve"));
    cell.setBorderWidth(0);
    instructionTable.addCell(cell);

    cell = new PdfPCell(new Phrase("5. Laminate and punch"));
    cell.setBorderWidth(0);
    instructionTable.addCell(cell);

    document.add(instructionTable);

    document.close();
  }


  public static Date getTruncatedDate(Date date) {
    //set calendar to date value
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);

    //clear time
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    calendar.set(Calendar.MILLISECOND, 0);

    return calendar.getTime();
  }

  public static String getWellAddress(int wellPosition) {
    if (wellPosition==1) return "A01";
    else if (wellPosition==2) return "B01";
    else if (wellPosition==3) return "C01";
    else if (wellPosition==4) return "D01";
    else if (wellPosition==5) return "E01";
    else if (wellPosition==6) return "F01";
    else if (wellPosition==7) return "G01";
    else if (wellPosition==8) return "H01";
    else if (wellPosition==9) return "A02";
    else if (wellPosition==10) return "B02";
    else if (wellPosition==11) return "C02";
    else if (wellPosition==12) return "D02";
    else if (wellPosition==13) return "E02";
    else if (wellPosition==14) return "F02";
    else if (wellPosition==15) return "G02";
    else if (wellPosition==16) return "H02";
    else if (wellPosition==17) return "A03";
    else if (wellPosition==18) return "B03";
    else if (wellPosition==19) return "C03";
    else if (wellPosition==20) return "D03";
    else if (wellPosition==21) return "E03";
    else if (wellPosition==22) return "F03";
    else if (wellPosition==23) return "G03";
    else if (wellPosition==24) return "H03";
    else if (wellPosition==25) return "A04";
    else if (wellPosition==26) return "B04";
    else if (wellPosition==27) return "C04";
    else if (wellPosition==28) return "D04";
    else if (wellPosition==29) return "E04";
    else if (wellPosition==30) return "F04";
    else if (wellPosition==31) return "G04";
    else if (wellPosition==32) return "H04";
    else if (wellPosition==33) return "A05";
    else if (wellPosition==34) return "B05";
    else if (wellPosition==35) return "C05";
    else if (wellPosition==36) return "D05";
    else if (wellPosition==37) return "E05";
    else if (wellPosition==38) return "F05";
    else if (wellPosition==39) return "G05";
    else if (wellPosition==40) return "H05";
    else if (wellPosition==41) return "A06";
    else if (wellPosition==42) return "B06";
    else if (wellPosition==43) return "C06";
    else if (wellPosition==44) return "D06";
    else if (wellPosition==45) return "E06";
    else if (wellPosition==46) return "F06";
    else if (wellPosition==47) return "G06";
    else if (wellPosition==48) return "H06";
    else if (wellPosition==49) return "A07";
    else if (wellPosition==50) return "B07";
    else if (wellPosition==51) return "C07";
    else if (wellPosition==52) return "D07";
    else if (wellPosition==53) return "E07";
    else if (wellPosition==54) return "F07";
    else if (wellPosition==55) return "G07";
    else if (wellPosition==56) return "H07";
    else if (wellPosition==57) return "A08";
    else if (wellPosition==58) return "B08";
    else if (wellPosition==59) return "C08";
    else if (wellPosition==60) return "D08";
    else if (wellPosition==61) return "E08";
    else if (wellPosition==62) return "F08";
    else if (wellPosition==63) return "G08";
    else if (wellPosition==64) return "H08";
    else if (wellPosition==65) return "A09";
    else if (wellPosition==66) return "B09";
    else if (wellPosition==67) return "C09";
    else if (wellPosition==68) return "D09";
    else if (wellPosition==69) return "E09";
    else if (wellPosition==70) return "F09";
    else if (wellPosition==71) return "G09";
    else if (wellPosition==72) return "H09";
    else if (wellPosition==73) return "A10";
    else if (wellPosition==74) return "B10";
    else if (wellPosition==75) return "C10";
    else if (wellPosition==76) return "D10";
    else if (wellPosition==77) return "E10";
    else if (wellPosition==78) return "F10";
    else if (wellPosition==79) return "G10";
    else if (wellPosition==80) return "H10";
    else if (wellPosition==81) return "A11";
    else if (wellPosition==82) return "B11";
    else if (wellPosition==83) return "C11";
    else if (wellPosition==84) return "D11";
    else if (wellPosition==85) return "E11";
    else if (wellPosition==86) return "F11";
    else if (wellPosition==87) return "G11";
    else if (wellPosition==88) return "H11";
    else if (wellPosition==89) return "A12";
    else if (wellPosition==90) return "B12";
    else if (wellPosition==91) return "C12";
    else if (wellPosition==92) return "D12";
    else if (wellPosition==93) return "E12";
    else if (wellPosition==94) return "F12";
    else if (wellPosition==95) return "G12";
    else if (wellPosition==96) return "H12";
    else {
      throw new AssertionError("The wellPosition must be between 1 and 96");
    }
  }

  public static BigDecimal evaluateExpression(String[] args, String expression) throws ScriptException {

    for(int i = 0 ; i < args.length ; i++){
      if(expression.indexOf("arg"+i) > -1) {
        expression = expression.replace("[arg" + i + "]", args[i]);
      }
    }
    ScriptEngineManager factory = new ScriptEngineManager();
    ScriptEngine engine = factory.getEngineByName("JavaScript");
    Double result = (Double) engine.eval(expression);

    return new BigDecimal(result);
  }

  public static final int getYear(int yearsFromNow) {
    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.YEAR, yearsFromNow);
    return cal.get(Calendar.YEAR) % 100;
  }

  public static Integer getBarcodeAdapter(Integer gridRow, Integer gridCol, Integer barcodeIndexPlate) {

    int wellPosition = gridRow + ((gridCol - 1) * 8);

    return ((barcodeIndexPlate-1)*96) + wellPosition;
  }

  public AtlasUserInfo saveBadgeInfo(String userId, String adminUserId, String wfConfigId, String userStatus, String badgeReason, String generateBadge) {

    AtlasUserInfo atlasUserInfo = new AtlasUserInfo();
    atlasUserInfo.setUserId(userId);
    atlasUserInfo.setUserName(userId);
    atlasUserInfo.setCreateUser(adminUserId);
    atlasUserInfo.setUserVersionStatus(userStatus);
    atlasUserInfo.setBadgeComment(badgeReason);
    atlasUserInfo.setWfConfigId(Long.valueOf(wfConfigId));
    atlasUserInfo.setWfConfigStatus(userStatus);

    //check if user exists
      // if yes, get all current user details
        // see if wf config id exists for the user with status as WfConfigStatus
        // generate the new version with status as UserVersionStatus, deactivate all previous version
      // if no, create new user config id and save current details

    Set<String> generatedUserIds = new HashSet<String>();

    List<AtlasUserInfo> atlasUserInfos = getUserInfo(userId);

    if(!atlasUserInfos.isEmpty()){
      for(AtlasUserInfo userInfo : atlasUserInfos){
        generatedUserIds.add(userInfo.getUserIdGenerated());
      }
      atlasUserInfo.setUserConfigId(atlasUserInfos.get(0).getUserConfigId());

      atlasUserDao.deActivateOldVersions(atlasUserInfo);

      if(generateBadge.equalsIgnoreCase("true")) {
        String nextUserIdGenerated = atlasUserInfo.getUserId() + "_" + (generatedUserIds.size()+1);
        atlasUserInfo.setUserIdGenerated(nextUserIdGenerated);

        atlasUserDao.addUserVersion(atlasUserInfo);
      }else{
        if(atlasUserInfo.getUserVersionStatus().equalsIgnoreCase("Y")){
          String userIdGenerated = atlasUserInfo.getUserId();
          if(generatedUserIds.size() > 1){
            userIdGenerated = atlasUserInfo.getUserId() + "_" + generatedUserIds.size();
          }
          atlasUserDao.setLastVersionStatus(atlasUserInfo,userIdGenerated);
        }
      }

      boolean isWfPresent = false;
      for(AtlasUserInfo atlasUser : atlasUserInfos){
        if(atlasUser.getWfConfigId() == Long.valueOf(wfConfigId)){
          isWfPresent = true;
        }
      }
      if(!isWfPresent){
        atlasUserDao.addUserPrivileges(atlasUserInfo);
      }else{
        atlasUserDao.setWfStatus(atlasUserInfo);
      }
    }else{
      atlasUserInfo.setUserIdGenerated(userId);
      atlasUserInfo = atlasUserDao.addUser(atlasUserInfo);
    }

    return atlasUserInfo;
  }

  public List<AtlasUserInfo> getUserInfo(String userId) {

    List<AtlasUserInfo> atlasUserInfos = atlasUserDao.getAtlasUserInfos(userId);
    return atlasUserInfos;
  }

  public boolean isAdminUser(String userId, String wfConfigId) {

    boolean isAdmin= false;
    String originalUserId = atlasUserDao.getOriginalUserId(userId);
    if(StringUtils.isNotEmpty(originalUserId)){
      WfConfig wfConfig = wfConfigDao.findWfConfigId(Long.valueOf(wfConfigId));
      isAdmin=wfConfig.getWfConfigAdmins().stream().anyMatch(originalUserId::equalsIgnoreCase);
    }
    return isAdmin;
  }

  public boolean isUserBlockedForWorkflow(String userId, String wfConfigDomain){

    List<AtlasUserInfo> userBlockedForWorkflow = atlasUserDao.isUserBlockedForWorkflow(userId, wfConfigDomain);
    if(userBlockedForWorkflow.size() == 0){
      //allow if there are no configurations present for the user as existing users might not have been configured yet
      return false;
    }else if(userBlockedForWorkflow.size() > 1){
      //more than 1 domain configurations should not be present for any user
      return true;
    }else if(userBlockedForWorkflow.get(0).getUserVersionStatus().equalsIgnoreCase("N") ||
        userBlockedForWorkflow.get(0).getWfConfigStatus().equalsIgnoreCase("N")){
      return true;
    }else{
      return false;
    }
  }
}