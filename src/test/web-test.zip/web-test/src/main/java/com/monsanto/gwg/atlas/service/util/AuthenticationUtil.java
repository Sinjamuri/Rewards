package com.monsanto.gwg.atlas.service.util;

import com.google.gson.Gson;
import com.monsanto.gwg.atlas.model.Authentication.AccessTokenResponse;
import com.monsanto.gwg.atlas.service.gbs.GbsService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Map;

/**
 * Created by syroth on 5/30/2017.
 */
@Service
public class AuthenticationUtil {

    private static final Logger LOG = LoggerFactory.getLogger(AuthenticationUtil.class);

    public static String getAccessToken(String baseUrl, String clientId, String secretKey, String grantType, String httpsProtocolsValue) {
        System.setProperty("https.protocols", httpsProtocolsValue);
        return getAzureAccessToken(baseUrl, clientId, secretKey, grantType);
    }

    public static String getPingAccessToken(String baseUrl, String clientId, String secretKey, String grantType, String httpsProtocolsValue) {
        System.setProperty("https.protocols", httpsProtocolsValue);

        String accessToken = null;
        try {

            String queryParamsEncoded = "client_id="+ URLEncoder.encode(clientId, "UTF-8")+
                    "&client_secret="+URLEncoder.encode(secretKey,"UTF-8")+
                    "&grant_type="+URLEncoder.encode(grantType,"UTF-8");

            //LOG.info("Encoded Url:"+queryParamsEncoded);

            URL url;
            URLConnection urlConn;
            DataOutputStream printout;
            DataInputStream input;

            // URL of CGI-Bin script.
            url = new URL (baseUrl);
            // URL connection channel.
            urlConn = url.openConnection();
            // Let the run-time system (RTS) know that we want input.
            urlConn.setDoInput (true);
            // Let the RTS know that we want to do output.
            urlConn.setDoOutput (true);
            // No caching, we want the real thing.
            urlConn.setUseCaches (false);
            // Specify the content type.
            urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            // Send POST output.
            printout = new DataOutputStream (urlConn.getOutputStream ());

            printout.writeBytes (queryParamsEncoded);
            printout.flush ();
            printout.close ();
            // Get response data.
            input = new DataInputStream (urlConn.getInputStream ());
            String str;
            StringBuilder textArea=new StringBuilder();
            while (null != ((str = input.readLine())))
            {
                textArea.append(str + "\n");
            }
            input.close ();

            //LOG.info(textArea);

            AccessTokenResponse accessTokenResponse =
                    new Gson().fromJson(textArea.toString(), AccessTokenResponse.class);
            accessToken = accessTokenResponse.getToken_type()+" "+accessTokenResponse.getAccess_token();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();

        }
        return accessToken;
    }


    private static ClientResponse getServiceResponse(WebResource webResource, String accessToken) throws Exception {
        ClientResponse response = webResource.accept("application/json")
            .type("application/json").header("Authorization", accessToken).get(ClientResponse.class);

        return response;
    }

    public static ClientResponse getResponse(String accessToken, String baseUrl) throws Exception {

        LOG.info("Accessing Service at:"+baseUrl+" with Token"+accessToken);
        WebResource webResource = getWebResource(baseUrl);
        ClientResponse serviceResponse = getServiceResponse(webResource, accessToken);
        LOG.info("Accessing Response:"+serviceResponse+" with Token:"+accessToken+" for URL:"+baseUrl);
        return serviceResponse;
    }

    private static WebResource getWebResource(String baseUrl) {
        Client client = Client.create();
        return client.resource(baseUrl);
    }


    public static ClientResponse postAwsAuthRequest(AWSV4Auth awsAuth, String host, String path, String contentType, String jsonRequest) {

        LOG.info("Accessing Service at:"+host+path);
        WebResource webResource = getWebResource("https://"+host+path);
        WebResource.Builder type = webResource.type(contentType);

        type.header("host", host).header("Content-Length", String.valueOf(jsonRequest.length()));

        //* Get header calculated for request *//
        Map<String, String> header = awsAuth.getHeaders();
        for (Map.Entry<String, String> entrySet : header.entrySet()) {
            String key = entrySet.getKey();
            String value = entrySet.getValue();

            //* Attach header in your request *//
            //* Simple get request *//
            type.header(key, value);
        }
        LOG.info("Post : "+jsonRequest);
        ClientResponse response = type.post(ClientResponse.class, jsonRequest);
        LOG.info("Accessing Response:"+response);
        return response;
    }

    public static String getAzureAccessToken(String baseUrl, String clientId, String secretKey, String grantType,String httpsProtocolsValue) {
        System.setProperty("https.protocols", httpsProtocolsValue);
        String accessToken = null;
        try {

            String queryParamsEncoded = "client_id="+ URLEncoder.encode(clientId, "UTF-8")+
                    "&client_secret="+URLEncoder.encode(secretKey,"UTF-8")+
                    "&scope="+URLEncoder.encode(clientId+"/.default","UTF-8")+
                    "&grant_type="+URLEncoder.encode(grantType,"UTF-8");

            //LOG.info("Encoded Url:"+queryParamsEncoded);

            URL url;
            URLConnection urlConn;
            DataOutputStream printout;
            DataInputStream input;

            // URL of CGI-Bin script.
            url = new URL (baseUrl);
            // URL connection channel.
            urlConn = url.openConnection();
            // Let the run-time system (RTS) know that we want input.
            urlConn.setDoInput (true);
            // Let the RTS know that we want to do output.
            urlConn.setDoOutput (true);
            // No caching, we want the real thing.
            urlConn.setUseCaches (false);
            // Specify the content type.
            urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            // Send POST output.
            printout = new DataOutputStream (urlConn.getOutputStream ());

            printout.writeBytes (queryParamsEncoded);
            printout.flush ();
            printout.close ();
            // Get response data.
            input = new DataInputStream (urlConn.getInputStream ());
            String str;
            StringBuilder textArea=new StringBuilder();
            while (null != ((str = input.readLine())))
            {
                textArea.append(str + "\n");
            }
            input.close ();

            //LOG.info(textArea);

            AccessTokenResponse accessTokenResponse =
                    new Gson().fromJson(textArea.toString(), AccessTokenResponse.class);
            accessToken = accessTokenResponse.getToken_type()+" "+accessTokenResponse.getAccess_token();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();

        }
        return accessToken;
    }

    public static String getAzureAccessToken(String baseUrl, String clientId, String secretKey, String grantType) {
        String accessToken = null;
        try {

            String queryParamsEncoded = "client_id="+ URLEncoder.encode(clientId, "UTF-8")+
                    "&client_secret="+URLEncoder.encode(secretKey,"UTF-8")+
                    "&scope="+URLEncoder.encode(clientId+"/.default","UTF-8")+
                    "&grant_type="+URLEncoder.encode(grantType,"UTF-8");

            //LOG.info("Encoded Url:"+queryParamsEncoded);

            URL url;
            URLConnection urlConn;
            DataOutputStream printout;
            DataInputStream input;

            // URL of CGI-Bin script.
            url = new URL (baseUrl);
            // URL connection channel.
            urlConn = url.openConnection();
            // Let the run-time system (RTS) know that we want input.
            urlConn.setDoInput (true);
            // Let the RTS know that we want to do output.
            urlConn.setDoOutput (true);
            // No caching, we want the real thing.
            urlConn.setUseCaches (false);
            // Specify the content type.
            urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            // Send POST output.
            printout = new DataOutputStream (urlConn.getOutputStream ());

            printout.writeBytes (queryParamsEncoded);
            printout.flush ();
            printout.close ();
            // Get response data.
            input = new DataInputStream (urlConn.getInputStream ());
            String str;
            StringBuilder textArea=new StringBuilder();
            while (null != ((str = input.readLine())))
            {
                textArea.append(str + "\n");
            }
            input.close ();

            //LOG.info(textArea);

            AccessTokenResponse accessTokenResponse =
                    new Gson().fromJson(textArea.toString(), AccessTokenResponse.class);
            accessToken = accessTokenResponse.getToken_type()+" "+accessTokenResponse.getAccess_token();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();

        }
        return accessToken;
    }

}
