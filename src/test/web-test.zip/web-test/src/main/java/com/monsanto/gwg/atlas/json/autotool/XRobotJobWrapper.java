package com.monsanto.gwg.atlas.json.autotool;





import com.monsanto.gwg.atlas.model.core.XRobotJob;

import java.util.List;

/**
 * Created by syroth on 6/14/2017.
 */
public class XRobotJobWrapper {

    private List<XRobotJob> xRobotJobList;

    public List<XRobotJob> getxRobotJobList(){return this.xRobotJobList;}
    public void setxRobotJobList(List<XRobotJob> xRobotJobList){this.xRobotJobList = xRobotJobList;}

    @Override
    public String toString(){
        return String.format("Num Jobs: %d", xRobotJobList.size());
    }
}
