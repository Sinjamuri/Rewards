package com.monsanto.gwg.atlas.service.pcrExt;

import com.monsanto.gwg.atlas.dao.BaseDao;
import com.monsanto.gwg.atlas.dao.core.*;
import com.monsanto.gwg.atlas.dao.dpcr.DPcrPlateDao;
import com.monsanto.gwg.atlas.model.core.Wf;
import com.monsanto.gwg.atlas.model.core.WfConfigProperty;
import com.monsanto.gwg.atlas.model.core.WfData;
import com.monsanto.gwg.atlas.model.core.WfGridAssoc;
import com.monsanto.gwg.atlas.model.dpcr.DPcrPlate;
import com.monsanto.gwg.atlas.service.core.WfService;
import com.monsanto.gwg.atlas.service.dpcr.DPcrConstants;
import com.monsanto.gwg.atlas.service.util.UtilityMethodsImpl;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

@Service
public class QPCRExcelReader implements DPcrConstants {

    @Autowired
    private WfConfigPropertyDao wfConfigPropertyDao;

    String createUser = "";
    int numberOfColumns = 0;

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public int getNumberOfColumns() {
        return numberOfColumns;
    }

    public void setNumberOfColumns(int numberOfColumns) {
        this.numberOfColumns = numberOfColumns;
    }


    /**
     * reads row by row starting with second row and populates the Object
     * returns the grid list.
     *
     * @param rowsList List of rows frm the excel
     */
    public List<String> processRows(String fileName, List<Row> rowsList) throws Exception {

        List<Object[]> rowArrayList = new ArrayList<Object[]>();
        List<String> errorLogs = new ArrayList<String>();
        //Get the CropName from the file name;
        String cropName = null;
        StringTokenizer tokenizer = new StringTokenizer(fileName,"_");
        while (tokenizer.hasMoreElements()) {
           cropName = (String) tokenizer.nextElement();
            break;
        }

        String instrumentName = null;
        String calibrationVICPerformed = null;
        int dataRowIndex = 0;
        int yInterceptColumnIndex = 0;
        int slopeColumnIndex = 0;
        double yInterceptValue = 0;
        double slopeValue = 0;

        //Iterate through each rows from first sheet
        for (int j = 1; j < rowsList.size(); j++) {
            Row row = rowsList.get(j);
            if (null != row && 0 < row.getPhysicalNumberOfCells()) {
                Object[] rowDataArray = new Object[8];

                double xCTMean = 0;
                double bYIntercept = 0;
                double mSlope = 0;

                for (int i = 0; i < numberOfColumns; i++) {
                    Cell cell = row.getCell(i, Row.RETURN_BLANK_AS_NULL);
                    //Read through all rows and check for cell data of "Instrument Name", "Calibration VIC performed on"
                    //For these two, once row found, immediately get the values from dajacent column.
                    if (null != cell) {

                        if (null == instrumentName && "Instrument Name".equals(cell.getStringCellValue().trim())) {
                            cell = row.getCell(i + 1, Row.RETURN_BLANK_AS_NULL);
                            instrumentName = cell.getStringCellValue();
                            break;
                        } else if (null == calibrationVICPerformed && "Calibration VIC performed on".equals(cell.getStringCellValue().trim())) {
                            cell = row.getCell(i + 1, Row.RETURN_BLANK_AS_NULL);
                            calibrationVICPerformed = cell.getStringCellValue();
                            break;
                        } //Contiue iterating to get the column index : Once the row is found for "Well"
                        //Based on rowIndex +1, get the column Index values--"Y-Intercept", "Slope"
                        else if (dataRowIndex == 0 && "Well".equals(cell.getStringCellValue().trim())) {
                            //capture the row index here and break the loop
                            dataRowIndex = j + 1;
                        } else if (yInterceptColumnIndex == 0 && "Y-Intercept".equals(cell.getStringCellValue().trim())) {
                            yInterceptColumnIndex = cell.getColumnIndex();
                        } else if (slopeColumnIndex == 00 && "Slope".equals(cell.getStringCellValue().trim())) {
                            slopeColumnIndex = cell.getColumnIndex();
                        } else if (dataRowIndex == j) {
                            cell = row.getCell(yInterceptColumnIndex, Row.RETURN_BLANK_AS_NULL);
                            yInterceptValue = cell.getNumericCellValue();
                            cell = row.getCell(slopeColumnIndex, Row.RETURN_BLANK_AS_NULL);
                            slopeValue = cell.getNumericCellValue();

                            if(slopeValue >= -3.1 && slopeValue <= -3.6 ) {
                                errorLogs.add("File not uploaded. Slope not in range -3.1 and -3.6");
                            }
                            break;
                        }
                    }
                }
            }
        }

        if (errorLogs.isEmpty()) {
            saveData(instrumentName, calibrationVICPerformed, slopeValue, yInterceptValue, cropName);
        }

        return errorLogs;
    }

    private void saveData(final String instrumentName, final String calibrationVICPerformed, final double slopeValue, final double yInterceptValue, final String cropName) {
        try {
            //check if the values already exist
            //If yes, then update the key with version number and then insert the new details.

            String key = "PCR_EXT_" + cropName + "_" + instrumentName + "_CALIBRATION_DT";
            WfConfigProperty config = checkIfConfigPropertyExists(key);
            String dateValue = calibrationVICPerformed.substring(0,19).trim();
            config.setValueTimestamp(Timestamp.valueOf(dateValue));
            wfConfigPropertyDao.insert(config);

            //Create wfConfigProperty entries for the captured values
            key = "PCR_EXT_" + cropName + "_" + instrumentName + "_SLOPE";
            config = checkIfConfigPropertyExists(key);
            config.setValueNumber(BigDecimal.valueOf(slopeValue));
            wfConfigPropertyDao.insert(config);

            key = "PCR_EXT_" + cropName + "_" + instrumentName + "_YINTERCEPT";
            config = checkIfConfigPropertyExists(key);
            config.setValueNumber(BigDecimal.valueOf(yInterceptValue));
            wfConfigPropertyDao.insert(config);

        } catch(Exception e) {
            System.out.println(e.getCause());
        }

    }


    private WfConfigProperty checkIfConfigPropertyExists(String key){
        WfConfigProperty config = wfConfigPropertyDao.findByWfConfigIdAndKey(1L, key);
        if (null != config) {
            //update the key
            // config.setKey(key + "_V1");
            // wfConfigPropertyDao.update(config);
            wfConfigPropertyDao.delete(config.getPropertyId());
        }
        config = new WfConfigProperty();
        config.setKey(key);
        config.setWfConfigId(1L);
        return config;
    }

}