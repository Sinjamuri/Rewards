package com.monsanto.gwg.atlas.model.core;

import java.sql.Timestamp;

/**
 * Created by pgros1 on 6/4/14.
 */
public class WfStepAssocVw {
    private long wfStepAssocId;
    private long wfConfigId;
    private long startId;
    private String startWfType;
    private String startName;
    private long nextId;
    private String nextWfType;

    private String status;
    private Timestamp lastUseScanTs;

    public long getWfStepAssocId() {
        return wfStepAssocId;
    }

    public void setWfStepAssocId(long wfStepAssocId) {
        this.wfStepAssocId = wfStepAssocId;
    }

    public long getWfConfigId() {
        return wfConfigId;
    }

    public void setWfConfigId(long wfConfigId) {
        this.wfConfigId = wfConfigId;
    }

    public long getStartId() {
        return startId;
    }

    public void setStartId(long startId) {
        this.startId = startId;
    }

    public String getStartWfType() {
        return startWfType;
    }

    public void setStartWfType(String startWfType) {
        this.startWfType = startWfType;
    }

    public String getStartName() {
        return startName;
    }

    public void setStartName(String startName) {
        this.startName = startName;
    }

    public long getNextId() {
        return nextId;
    }

    public void setNextId(long nextId) {
        this.nextId = nextId;
    }

    public String getNextWfType() {
        return nextWfType;
    }

    public void setNextWfType(String nextWfType) {
        this.nextWfType = nextWfType;
    }

    public Timestamp getLastUseScanTs() {
        return lastUseScanTs;
    }

    public void setLastUseScanTs(Timestamp lastUseScanTs) {
        this.lastUseScanTs = lastUseScanTs;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
