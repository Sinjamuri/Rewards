package com.monsanto.gwg.atlas.model.gbs;

import com.monsanto.gwg.atlas.model.core.WfEntityDisplay;

import java.io.Serializable;

public class WfRelationships implements Serializable,Cloneable {

  private WfEntityDisplay fBlock;
  private WfEntityDisplay eBlock;
  private WfEntityDisplay dilBlock;
  private WfEntityDisplay cleanTube;
  private WfEntityDisplay sequencingContainer;
  private WfEntityDisplay analyzedE;
  private String runName;
  private String runDisplay;

  @Override
  public Object clone() throws CloneNotSupportedException {
    return super.clone();
  }

  public String getRunName() {
    return runName;
  }

  public void setRunName(String runName) {
    this.runName = runName;
  }

  public WfEntityDisplay getfBlock() {
    return fBlock;
  }

  public void setfBlock(WfEntityDisplay fBlock) {
    this.fBlock = fBlock;
  }

  public WfEntityDisplay geteBlock() {
    return eBlock;
  }

  public void seteBlock(WfEntityDisplay eBlock) {
    this.eBlock = eBlock;
  }

  public WfEntityDisplay getDilBlock() {
    return dilBlock;
  }

  public void setDilBlock(WfEntityDisplay dilBlock) {
    this.dilBlock = dilBlock;
  }

  public WfEntityDisplay getCleanTube() {
    return cleanTube;
  }

  public void setCleanTube(WfEntityDisplay cleanTube) {
    this.cleanTube = cleanTube;
  }

  public WfEntityDisplay getSequencingContainer() {
    return sequencingContainer;
  }

  public void setSequencingContainer(WfEntityDisplay sequencingContainer) {
    this.sequencingContainer = sequencingContainer;
  }

  public WfEntityDisplay getAnalyzedE() {
    return analyzedE;
  }

  public void setAnalyzedE(WfEntityDisplay analyzedE) {
    this.analyzedE = analyzedE;
  }

  public String getRunDisplay() {
    return runDisplay;
  }

  public void setRunDisplay(String runDisplay) {
    this.runDisplay = runDisplay;
  }
}
