package com.monsanto.gwg.atlas.model.dpcr;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by pgros1 on 1/15/2015.
 */
public class RatioThreshold {
    private String marker;
    private String tissueType;

    private Float hemiMin;
    private Float hemiMax;

    public RatioThreshold() {}

    public RatioThreshold( Map serializedRatioThreshold ) {
        this.marker = (String) serializedRatioThreshold.get( "marker" );
        this.tissueType = (String) serializedRatioThreshold.get( "tissueType" );
        this.hemiMin = new Float( (String) serializedRatioThreshold.get( "hemiMin") );
        this.hemiMax = new Float( (String) serializedRatioThreshold.get( "hemiMax") );
    }

    public String getMarker() {
        return marker;
    }

    public void setMarker(String marker) {
        this.marker = marker;
    }

    public String getTissueType() {
        return tissueType;
    }

    public void setTissueType(String tissueType) {
        this.tissueType = tissueType;
    }

    public Float getHemiMin() {
        return hemiMin;
    }

    public void setHemiMin(Float hemiMin) {
        this.hemiMin = hemiMin;
    }

    public Float getHemiMax() {
        return hemiMax;
    }

    public void setHemiMax(Float hemiMax) {
        this.hemiMax = hemiMax;
    }
}
