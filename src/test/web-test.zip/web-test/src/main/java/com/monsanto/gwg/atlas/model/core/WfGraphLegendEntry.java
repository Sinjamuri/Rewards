package com.monsanto.gwg.atlas.model.core;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author atpinz
 * @version $Revision$
 */
public class WfGraphLegendEntry {

  public static final String GRAPH_LEGEND_SHAPE_POLYGON="Polygon";
  public static final String GRAPH_LEGEND_SHAPE_CIRCLE="Circle";
  public static final String GRAPH_LEGEND_SHAPE_SQUARE="Square";
  public static final String GRAPH_LEGEND_SHAPE_RECTANGLE="Rectangle";

  private String name;
  private String shape;
  private String color;

  public WfGraphLegendEntry(String name, String color, String shape) {
    this.name = name;
    this.shape = shape;
    this.color = color;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getColor() {
    return color;
  }

  public void setColor(String color) {
    this.color = color;
  }

  public String getShape() {
    return shape;
  }

  public void setShape(String shape) {
    this.shape = shape;
  }




}