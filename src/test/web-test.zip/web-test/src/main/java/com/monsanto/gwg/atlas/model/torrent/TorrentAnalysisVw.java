package com.monsanto.gwg.atlas.model.torrent;

public class
TorrentAnalysisVw {
  private Long torrentAnalysisId;
  private String torrentRunName;
  private String createUser;
  private String createTs;
  private String markerReference;
  private String qcThreshold;
  private String barcodeIndexPlate;
  private String torrentRunHost;
  private String analysisStart;
  private String analysisStatus;
  private String analysisComplete;
  private boolean analysisUploaded;

  public Long getTorrentAnalysisId() {
    return torrentAnalysisId;
  }

  public void setTorrentAnalysisId(Long torrentAnalysisId) {
    this.torrentAnalysisId = torrentAnalysisId;
  }

  public String getTorrentRunName() {
    return torrentRunName;
  }

  public void setTorrentRunName(String torrentRunName) {
    this.torrentRunName = torrentRunName;
  }

  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public String getCreateTs() {
    return createTs;
  }

  public void setCreateTs(String createTs) {
    this.createTs = createTs;
  }

  public String getMarkerReference() {
    return markerReference;
  }

  public void setMarkerReference(String markerReference) {
    this.markerReference = markerReference;
  }

  public String getQcThreshold() {
    return qcThreshold;
  }

  public void setQcThreshold(String qcThreshold) {
    this.qcThreshold = qcThreshold;
  }

  public String getBarcodeIndexPlate() {
    return barcodeIndexPlate;
  }

  public void setBarcodeIndexPlate(String barcodeIndexPlate) {
    this.barcodeIndexPlate = barcodeIndexPlate;
  }

  public String getTorrentRunHost() {
    return torrentRunHost;
  }

  public void setTorrentRunHost(String torrentRunHost) {
    this.torrentRunHost = torrentRunHost;
  }

  public String getAnalysisStart() {
    return analysisStart;
  }

  public void setAnalysisStart(String analysisStart) {
    this.analysisStart = analysisStart;
  }

  public String getAnalysisStatus() {
    return analysisStatus;
  }

  public void setAnalysisStatus(String analysisStatus) {
    this.analysisStatus = analysisStatus;
  }

  public String getAnalysisComplete() {
    return analysisComplete;
  }

  public void setAnalysisComplete(String analysisComplete) {
    this.analysisComplete = analysisComplete;
  }

  public boolean isAnalysisUploaded() {
    if (this.analysisComplete != null && this.analysisUploaded) {
      return true;
    }
    return false;

  }

  public void setAnalysisUploaded(boolean analysisUploaded) {
    this.analysisUploaded = analysisUploaded;
  }
}
