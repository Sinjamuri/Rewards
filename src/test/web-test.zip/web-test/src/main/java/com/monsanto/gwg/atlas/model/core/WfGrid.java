package com.monsanto.gwg.atlas.model.core;

import com.monsanto.gwg.atlas.model.annotations.DbColumn;

import java.sql.Timestamp;
import java.util.Map;

public class WfGrid {
    @DbColumn(field="wf_grid_id")
  private Long wfGridId;
    @DbColumn(field="project_id")
  private String projectId;
    @DbColumn(field="sample_id")
  private Long sampleId;
    @DbColumn(field="source_wf_id")
  private Long sourceWfId;
    @DbColumn(field="wf_config_id")
  private Long wfConfigId;

  public Long getWfGridId() {
    return wfGridId;
  }

  public void setWfGridId(Long wfGridId) {
    this.wfGridId = wfGridId;
  }

  public String getProjectId() {
    return projectId;
  }

  public void setProjectId(String projectId) {
    this.projectId = projectId;
  }

  public Long getSampleId() {
    return sampleId;
  }

  public void setSampleId(Long sampleId) {
    this.sampleId = sampleId;
  }

  public Long getSourceWfId() {
    return sourceWfId;
  }

  public void setSourceWfId(Long sourceWfId) {
    this.sourceWfId = sourceWfId;
  }

  public Long getWfConfigId() {
    return wfConfigId;
  }

  public void setWfConfigId(Long wfConfigId) {
    this.wfConfigId = wfConfigId;
  }
}
