package com.monsanto.gwg.atlas.model.dpcr;

import javax.sound.sampled.Control;
import java.util.ArrayList;

/**
 * Created by pgros1 on 6/10/14.
 */
public class FilterData {
  private String filterPairId;
  private boolean isReferenceFilter;
  private int intensityThreshold;
  private String referenceFilter;
  private String name;
  private ArrayList<Float> intenList;
  private Float filterThreshold;
  private Float roxNorm;
  private ArrayList<Float> intenNorm;
  private ArrayList<Float> intensityNorm;
  private int filterCount;

  public ArrayList<Float> getIntenNorm() {
    return intenNorm;
  }

  public void setIntenNorm(ArrayList<Float> intenNorm) {
    this.intenNorm = intenNorm;
  }

  public int getFilterCount() {
    return filterCount;
  }

  public void setFilterCount(int filterCount) {
    this.filterCount = filterCount;
  }

  public String getFilterPairId() {
        return filterPairId;
    }

  public void setFilterPairId(String filterPairId) {
      this.filterPairId = filterPairId;
  }

  public boolean getIsReferenceFilter() {
      return isReferenceFilter;
  }

  public void setIsReferenceFilter(boolean isReferenceFilter) {
      this.isReferenceFilter = isReferenceFilter;
  }

  public int getIntensityThreshold() {
      return intensityThreshold;
  }

  public void setIntensityThreshold(int intensityThreshold) {
      this.intensityThreshold = intensityThreshold;
  }

  public String getReferenceFilter() {
      return referenceFilter;
  }

  public void setReferenceFilter(String referenceFilter) {
      this.referenceFilter = referenceFilter;
  }

  public boolean isReferenceFilter() {
    return isReferenceFilter;
  }

  public void setReferenceFilter(boolean isReferenceFilter) {
    this.isReferenceFilter = isReferenceFilter;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ArrayList<Float> getIntenList() {
    return intenList;
  }

  public void setIntenList(ArrayList<Float> intenList) {
    this.intenList = intenList;
  }

  public Float getFilterThreshold() {
    return filterThreshold;
  }

  public void setFilterThreshold(Float filterThreshold) {
    this.filterThreshold = filterThreshold;
  }

  public Float getRoxNorm() {
    return roxNorm;
  }

  public void setRoxNorm(Float roxNorm) {
    this.roxNorm = roxNorm;
  }

  public ArrayList<Float> getIntensityNorm() {
    return intensityNorm;
  }

  public void setIntensityNorm(ArrayList<Float> intensityNorm) {
    this.intensityNorm = intensityNorm;
  }

  public void resetFilterCount() {
    filterCount=0;
  }
}
