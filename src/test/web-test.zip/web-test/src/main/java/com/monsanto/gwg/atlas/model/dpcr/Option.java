package com.monsanto.gwg.atlas.model.dpcr;

/**
 * Created by pgros1 on 7/30/14.
 */
public class Option {
    private String text;
    private String value;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
