package com.monsanto.aws.util;

import com.monsanto.aws.S3NotificationAgent;
import com.monsanto.labos.config.atlas.DbConfig;
import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.sql.Connection;


/**
 * Created by ASHAR7 on 10/4/2016.
 */
public class DbConnectionUtil {

    private static final Logger LOG = LoggerFactory.getLogger(DbConnectionUtil.class);

    private static Boolean dbInitialized = false;
    private static Connection con = null;

    public static Connection getGBSConnection() throws Exception {
        BasicDataSource dataSource = S3NotificationAgent.dataSource;
        synchronized (dbInitialized) {
            if (!dbInitialized) {
                DbConfig dbConfig = new DbConfig();
                final String dbUrl = dbConfig.getUrl();

                LOG.info("\n***********************************************************************************************\n" +
                        "Initializing data-source and connecting, using:\n" + dbUrl +
                        "\n***********************************************************************************************");

                dataSource.setDriverClassName(dbConfig.getDriverClassName());
                dataSource.setUrl(dbUrl);
                dataSource.setUsername(dbConfig.getUsername());
                dataSource.setPassword(dbConfig.getPassword());
                dataSource.addConnectionProperty("ssl", "true");
                dataSource.addConnectionProperty("sslfactory", "org.postgresql.ssl.NonValidatingFactory");
                dataSource.setInitialSize(10);
                dataSource.setMinIdle(10);
                dataSource.setMaxIdle(10);
                dataSource.setMaxActive(60);
                dataSource.setMaxWait(-1); //wait indefinitely
                dataSource.setValidationQuery("select version()");
                dataSource.setTestOnBorrow(true);
                dataSource.setTimeBetweenEvictionRunsMillis(120000); //evict idle connections every 10 minutes
                dataSource.setNumTestsPerEvictionRun(10);
                //prevent data source leaks and log offenders
                dataSource.setRemoveAbandoned(true);
                dataSource.setRemoveAbandonedTimeout(180);
                dataSource.setLogAbandoned(true);
                dataSource.setLogWriter(new PrintWriter(System.out));
                dataSource.setAccessToUnderlyingConnectionAllowed(false); //do not allow direct access to connection
                dbInitialized = true;
            }
        }
        LOG.info("Connecting to : " + dataSource.getUrl() + " and " + dataSource.getUsername());
        //Connection con=dataSource.getConnection();
        con = dataSource.getConnection();
        return con;
    }
}
