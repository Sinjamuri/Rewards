package com.monsanto.aws;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.s3.model.S3Object;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.monsanto.aws.json.JsonModel;
import com.monsanto.aws.pojo.AnkBeeRearrayResponse;
import com.monsanto.aws.pojo.CloudWatchMessage;
import com.monsanto.aws.util.*;
import com.monsanto.gwg.atlas.agent.common.model.*;
import com.monsanto.gwg.atlas.agent.common.utils.WfGridUtils;
import com.monsanto.gwg.atlas.agent.common.utils.WfUtilCommon;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.stream.Collectors;

public class BeehiveAgent extends WfUtil {


    // Initialize the Log4j logger.
    static Logger LOG = LoggerFactory.getLogger(BeehiveAgent.class);

    public JsonModel processMessage(LambdaLogger logger, CloudWatchMessage message) {

        //logger.log ("Start processing Message.key:" + message.getKey () + ", id:" + message.getId ());
        logger.log("Start processing Message.key:" + message.getKey());
        JsonModel jsonModel = new JsonModel();
        List<String[]> parsedMessage = message.getParsedMessage();

        try {
            List<PlateDetail> platesListfromFile = null;
            if (message.getKey().toUpperCase().contains(INVENTORY_FILENAME.toUpperCase())) {
                platesListfromFile = loadInventoryPlateList(parsedMessage);
            }
            if (message.getKey().toUpperCase().contains(DROPSENSE_PIPETTE_FILENAME.toUpperCase())) {
                platesListfromFile = loadDropSensePlateList(parsedMessage);
            }
            if (message.getKey().toUpperCase().contains(DROPSENSE_OUTPUT_FILENAME.toUpperCase())) {
                platesListfromFile = loadDropSenseOutputFile(parsedMessage);
            }
            if (message.getKey().toUpperCase().contains(NORMALIZATION_OUTPUT_FILENAME.toUpperCase())) {
                platesListfromFile = loadNormalizationPlateList(parsedMessage);
            }
            if (message.getKey().toUpperCase().contains(GL_PLATE_OUTPUT_FILENAME.toUpperCase())) {
                platesListfromFile = loadGlPlateCreationPlateList(parsedMessage);
            }
            if(message.getKey().toUpperCase().contains(GL_PLATE_OUTPUT_FILENAME_ANK.toUpperCase())) {
                String data = message.getMessage();
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                String inputJson = data.replaceAll("\\\\\"","\"");
                AnkBeeRearrayResponse ankBee =  gson.fromJson(inputJson, AnkBeeRearrayResponse.class);
                platesListfromFile = loadGlPlateCreationPlateListFromAnkBee(ankBee);
            }
           /* if(message.getKey().toUpperCase().contains(GL_PLATE_OUTPUT_FILENAME.toUpperCase())){
                platesListfromFile = loadGlPlateCreationFileFromAnk (parsedMessage);
            }*/
            if (message.getKey().toUpperCase().contains(Drop_Blocks.toUpperCase())) {
                platesListfromFile = loadDropBlockPlateList(parsedMessage);
            }
            jsonModel.setPlatesFromFile(platesListfromFile);

            logger.log("Successfully completed parsing. Fetched:" + platesListfromFile.size());

            for (PlateDetail plateDetail : platesListfromFile) {
                logger.log(plateDetail.getPlateName());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            processData(jsonModel, message.getKey());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return jsonModel;

    }

    /**
     * Getting List of active E Plates from ExtractionComplete queue
     * Comparing 2 lists(Inventory text file & ExtractionComplete queue) and getting common list of E plates
     * Generating DropSenseCSV File for common list of E plates
     *
     * @param jsonModel
     */
    public void processData(JsonModel jsonModel, String inputFileName) {

        jsonModel.setLogFileName(inputFileName);
        Connection gbsConnection = null;
        List<PlateDetail> ePlatesListFromQ = null;

        try {

            System.out.println("Processing Data for " + inputFileName);

            gbsConnection = DbConnectionUtil.getGBSConnection();

            if (inputFileName.toUpperCase().contains(INVENTORY_FILENAME.toUpperCase())) {
                processDataHelper(gbsConnection, jsonModel, null, "1 Inventory Loaded", "DROP_SENSE_INPUT");
                processDataHelperForChip(gbsConnection, jsonModel, null, "1 Inventory Loaded", "DROP_SENSE_INPUT");
            }
            if (inputFileName.toUpperCase().contains(DROPSENSE_PIPETTE_FILENAME.toUpperCase())) {
                processDataHelper(gbsConnection, jsonModel, "2 Quantification Job Pending", "2 Quantification Job Complete", "NORMALIZATION_INPUT");
            }
            if (inputFileName.toUpperCase().contains(DROPSENSE_OUTPUT_FILENAME.toUpperCase())) {
                processDataHelper(gbsConnection, jsonModel, null, null, "NORMALIZATION_INPUT_TEMP");
            }
            if (inputFileName.toUpperCase().contains(NORMALIZATION_OUTPUT_FILENAME.toUpperCase())) {
                processDataHelper(gbsConnection, jsonModel, "3 Normalization Pending", "3 Normalization Complete", "GL_PLATE_INPUT");
            }
            if (inputFileName.toUpperCase().contains(GL_PLATE_OUTPUT_FILENAME.toUpperCase()) || inputFileName.toUpperCase().contains(GL_PLATE_OUTPUT_FILENAME_ANK.toUpperCase())) {
                processDataHelper(gbsConnection, jsonModel, "4 Library Plate Creation Pending", "5 PCR EXT COMPLETE", "_INPUT");
                processDataHelperForChip(gbsConnection, jsonModel, "4 Library Plate Creation Pending", "5 PCR EXT COMPLETE", "_INPUT");
            }
            if (inputFileName.toUpperCase().contains(Drop_Blocks.toUpperCase())) {
                List<PlateDetail> platesFromFile = jsonModel.getPlatesFromFile();
                for (PlateDetail plate : platesFromFile) {
                    Long wfIdAtStep = WfUtil.getWfIdAtStep(gbsConnection, plate.getPlateName(), ENTITY_F_BLOCK, STEP_READY_FOR_CLEANUP, "M");
                    if (null != wfIdAtStep) {
                        WfUtil.updateWfStatus(gbsConnection, wfIdAtStep, "T");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Util.freeResource(gbsConnection);
        }

    }

    public void processDataHelper(Connection gbsConnection, JsonModel jsonModel, String fromStatus, String toStatus, String outputType) throws Exception {

        System.out.println("Change from " + fromStatus + " to " + toStatus + " for type " + outputType);

        String defaultTransferVolume = WfUtil.getWfConfigProperyString(gbsConnection, WF_CONFIG_ID, "DROPSENSE_TRANSFER_VOLUME");
        String defaultDestWell = WfUtil.getWfConfigProperyString(gbsConnection, WF_CONFIG_ID, "DROPSENSE_DEST_WELL");
        String defaultGLTransferVolume = WfUtil.getWfConfigProperyString(gbsConnection, WF_CONFIG_ID, "GL_TRANSFER_VOLUME");
        String BUCKETNAME = WfUtil.getWfConfigProperyString(gbsConnection, WF_CONFIG_ID, "S3_BUCKET_NAME_CF");
        String GENERATE_FOLDER_NAME = WfUtil.getWfConfigProperyString(gbsConnection, WF_CONFIG_ID, "S3_BEEHIVE_GENERATE_FOLDER");

        List<PlateDetail> ePlatesListFromQ = new ArrayList<>();
        List<PlateDetail> commonPlates = new ArrayList<>();
        Map<String, Long> commonPlatesWithWfID = new HashMap<>();
        if (null != fromStatus && null != toStatus) {
            ePlatesListFromQ = getEPlatesFromQueue(gbsConnection, WF_CONFIG_ID, STEP_SCHEDULING, fromStatus, defaultTransferVolume, defaultDestWell);
            if (outputType.equals("_INPUT")) {
                List<PlateDetail> ePlatesFromQueue = getEPlatesFromQueue(gbsConnection, WF_CONFIG_ID, STEP_SCHEDULING, fromStatus + "_Partial", defaultTransferVolume, defaultDestWell);
                ePlatesListFromQ.addAll(ePlatesFromQueue);
            }
            System.out.println("Queue size:" + ePlatesListFromQ.size());
            commonPlates = compareAndGetCommonPlates(jsonModel, ePlatesListFromQ, commonPlatesWithWfID);
            System.out.println("Updating priority");
            updatePriority(commonPlates);
        } else {
            commonPlates = jsonModel.getPlatesFromFile();
        }

        System.out.println("Common plates size:" + commonPlates.size());

        if (null != commonPlates && !commonPlates.isEmpty()) {

            if (outputType.equals("DROP_SENSE_INPUT")) {

                //01/25 - CHANGE : Move to atlas-agent
                //createDropSenseCSV(gbsConnection, commonPlates, DROPSENSE_INPUT_FILENAME);
                dropBlocks(gbsConnection, jsonModel.getPlatesFromFile());

                System.out.println("Updating plate status to database");
                for (PlateDetail detail : commonPlates) {
                    Long wfIdAtStepScheduling = WfUtil.getWfIdAtStep(gbsConnection, detail.getPlateName(), ENTITY_E_PLATE, STEP_SCHEDULING, "I");
                    if (null != wfIdAtStepScheduling) {
                        WfUtil.createWfDataVarchar2(gbsConnection, wfIdAtStepScheduling, WF_DATA_CONFIG_ID_PCR_EXT_STATUS, toStatus);

                    }
                }
            }

            if (outputType.equals("NORMALIZATION_INPUT")) {
                List<PlateDetail> removePlates = new ArrayList<>();
                for (PlateDetail plateDetail : commonPlates) {
                    WfUtil.createWfDataVarchar2(gbsConnection, plateDetail.getWfId(), WF_DATA_CONFIG_ID_DROPSENSE_PLATE, plateDetail.getDestPlate());
                    Long wfId = null;
                    try {
                        wfId = WfUtil.getWfIdAtStep(gbsConnection, plateDetail.getDestPlate(), ENTITY_DROPSENSE_PLATE, STEP_DROP_SENSE_FAKE_STEP, "M");
                    } catch (Exception e) {

                    }
                    if (null == wfId) {
                        System.out.println("WF Id Not Found for DropSense Plate:" + plateDetail.getDestPlate());
                        AWSAuthUtil awsAuthUtil = new AWSAuthUtil();
                        List<String[]> destString = awsAuthUtil.getObject(BUCKETNAME, GENERATE_FOLDER_NAME, plateDetail.getDestPlate());

                        if (null != destString && !destString.isEmpty()) {
                            List<PlateDetail> plateDetails = loadDropSenseOutputFile(destString);
                            extractDataForDropSenseConc(gbsConnection, plateDetails);
                        } else {
                            removePlates.add(plateDetail);
                        }
                    }
                    try {
                        wfId = WfUtil.getWfIdAtStep(gbsConnection, plateDetail.getDestPlate(), ENTITY_DROPSENSE_PLATE, STEP_DROP_SENSE_FAKE_STEP, "M");
                    } catch (Exception e) {

                    }

                    System.out.println("WF Id for DropSense Plate:" + wfId);
                    String pcrStatus = null;
                    if (null != wfId) {
                        pcrStatus = PcrExtUtils.calculateAndSaveWaterAmounts(gbsConnection, plateDetail.getWfId(), wfId, plateDetail.getPlateName());
                        if (pcrStatus.equals(PcrExtUtils.CONFIG_KEY_PCR_EXT_STATUS_FAILED_PCR)) {
                            WfUtil.updateDataConfigVarchar2(gbsConnection, plateDetail.getWfId(), "1 Inventory Loaded", WF_DATA_CONFIG_ID_PCR_EXT_STATUS);
                        } else {
                            WfUtil.updateDataConfigVarchar2(gbsConnection, plateDetail.getWfId(), toStatus, WF_DATA_CONFIG_ID_PCR_EXT_STATUS);
                        }
                    }
                }
            }

            if (outputType.equals("NORMALIZATION_INPUT_TEMP")) {
                extractDataForDropSenseConc(gbsConnection, commonPlates);

                //01/25 - CHANGE : Move to atlas-agent
                //List<String[]> rows = new ArrayList<String[]> ();

                for (PlateDetail plateDetail : commonPlates) {

                    Long wfIdAtStep = WfUtil.getWfDataWfID(gbsConnection, plateDetail.getPlateName(), WF_DATA_CONFIG_ID_DROPSENSE_PLATE);
                    try {
                        String ePlateName = WfUtil.getWfEntityLabel(gbsConnection, wfIdAtStep);

                        String pcrStatus = PcrExtUtils.calculateAndSaveWaterAmounts(gbsConnection, wfIdAtStep, plateDetail.getWfId(), ePlateName);

                        //01/25 - CHANGE : Move to atlas-agent
                        /*List<String[]> normCsvRows = getNormCsvRows(gbsConnection, plateDetail.getWfId(),
                                ePlateName,
                                WfUtil.getWfDataStringForWfID(gbsConnection, wfIdAtStep, 60L),
                                WfUtil.getWfDataStringForWfID(gbsConnection, wfIdAtStep, 10100L));
                        rows.addAll(normCsvRows);*/

                        if (pcrStatus.equals(PcrExtUtils.CONFIG_KEY_PCR_EXT_STATUS_FAILED_PCR)) {
                            WfUtil.updateDataConfigVarchar2(gbsConnection, wfIdAtStep, "1 Inventory Loaded", WF_DATA_CONFIG_ID_PCR_EXT_STATUS);
                        } else {
                            WfUtil.updateDataConfigVarchar2(gbsConnection, wfIdAtStep, "2 Quantification Job Complete", WF_DATA_CONFIG_ID_PCR_EXT_STATUS);
                        }
                    } catch (Exception e) {
                        System.out.println("Eplate not found. " + e.getMessage());
                        //e.printStackTrace();
                    } catch (AssertionError ae) {
                        System.out.println("Eplate not found. " + ae.getMessage());
                        //ae.printStackTrace();
                    }
                }

                //01/25 - CHANGE : Move to atlas-agent
                //writeToCSVAndUploadToS3(gbsConnection, NORMALIZATION_HEADER, rows, NORMALIZATION_INPUT_FILENAME);
            }

            if (outputType.equals("GL_PLATE_INPUT")) {
                //01/25 - CHANGE : Move to atlas-agent
               /* //add partial plates currently in "GL Plate Creation Pending" status with priority 1
                List<PlateDetail> ePlatesFromQueue = getEPlatesFromQueue(gbsConnection, WF_CONFIG_ID, STEP_SCHEDULING, toStatus +"_Partial", defaultTransferVolume, defaultDestWell);
                commonPlates.addAll(ePlatesFromQueue);

                List<PlateDetail> plateDetailList = createGlPlateCreationCSV(gbsConnection, commonPlates, GL_PLATE_INPUT_FILENAME, defaultGLTransferVolume);
*/
                System.out.println("Updating plate status to database");
                for (PlateDetail detail : commonPlates) {
                    WfUtil.updateDataConfigVarchar2(gbsConnection, detail.getWfId(), toStatus, WF_DATA_CONFIG_ID_PCR_EXT_STATUS);
                }
            }

            if (outputType.equals("_INPUT")) {
                createLibrary(gbsConnection, jsonModel, toStatus, commonPlates, commonPlatesWithWfID, fromStatus + "_Partial");
            }
        }
    }

    public void processDataHelperForChip(Connection gbsConnection, JsonModel jsonModel, String fromStatus, String toStatus, String outputType) throws Exception {

        System.out.println("Change from " + fromStatus + " to " + toStatus + " for type " + outputType);

        String defaultTransferVolume = WfUtil.getWfConfigProperyString(gbsConnection, WF_CONFIG_ID, "DROPSENSE_TRANSFER_VOLUME");
        String defaultDestWell = WfUtil.getWfConfigProperyString(gbsConnection, WF_CONFIG_ID, "DROPSENSE_DEST_WELL");
        List<PlateDetail> dPlatesListFromQ = new ArrayList<>();
        List<PlateDetail> commonPlates = new ArrayList<>();
        Map<String, Long> commonPlatesWithWfID = new HashMap<>();
        if (null != fromStatus && null != toStatus) {
            dPlatesListFromQ = getEPlatesFromQueue(gbsConnection, WF_CONFIG_ID, STEP_CHIP_LC_PLATE_CREATION, fromStatus, defaultTransferVolume, defaultDestWell);
            if (outputType.equals("_INPUT")) {
                List<PlateDetail> ePlatesFromQueue = getEPlatesFromQueue(gbsConnection, WF_CONFIG_ID, STEP_CHIP_LC_PLATE_CREATION, fromStatus + "_Partial", defaultTransferVolume, defaultDestWell);
                dPlatesListFromQ.addAll(ePlatesFromQueue);
            }
            System.out.println("Queue size:" + dPlatesListFromQ.size());
            commonPlates = compareAndGetCommonPlates(jsonModel, dPlatesListFromQ, commonPlatesWithWfID);
            System.out.println("Updating priority");
            updatePriority(commonPlates);
        } else {
            commonPlates = jsonModel.getPlatesFromFile();
        }

        System.out.println("Common plates size:" + commonPlates.size());

        if (null != commonPlates && !commonPlates.isEmpty()) {

            if (outputType.equals("DROP_SENSE_INPUT")) {

                System.out.println("Updating plate status to database");
                for (PlateDetail detail : commonPlates) {
                    Long wfIdAtStepScheduling = WfUtil.getWfIdAtStep(gbsConnection, detail.getPlateName(), ENTITY_D_PLATE, STEP_CHIP_LC_PLATE_CREATION, "I");
                    if (null != wfIdAtStepScheduling) {
                        WfUtil.createWfDataVarchar2(gbsConnection, wfIdAtStepScheduling, WF_DATA_CONFIG_ID_PCR_EXT_STATUS, toStatus);
                    }
                }
            }

            if (outputType.equals("_INPUT")) {
                List<PlateDetail> platesFromFile = jsonModel.getPlatesFromFile();
                Map<String,List<PlateDetail>> dPlateMap = platesFromFile.stream().collect(Collectors.groupingBy(PlateDetail::getPlateName));
                if (dPlateMap.size() == commonPlates.size()) {
                    createLibrary(gbsConnection, jsonModel, toStatus, commonPlates, commonPlatesWithWfID, fromStatus + "_Partial");
                } else {
                    //TODO: trigger email with something failed
                }
            }
        }
    }



    private void createLibrary(Connection gbsConnection, JsonModel jsonModel, String toStatus, List<PlateDetail> commonPlates, Map<String, Long> commonPlatesWithWfID, String status) throws Exception {

        gbsConnection.setAutoCommit(false);
        try {
            String sampleTypeRv = null;
            List<WfWellMap> wfPlateMapList = WfUtil.getWfPlateMap(gbsConnection, 1L, "BIOCELL_96_TO_384");
            Map<String, List<WfWellMap>> biocellWellMapGroupByDstWell = wfPlateMapList.stream().collect(Collectors.groupingBy(WfWellMap::getDestWellName));
            Map<Pair<Integer, String>, List<WfWellMap>> biocellWellMapGroupByQuadRowCol = wfPlateMapList.stream().collect(Collectors.groupingBy
                    (w -> Pair.of(w.getSourceQuadrant(), w.getSourceRowCol())));

            Set<String> commonPlateNames = commonPlates.stream().map(plateDetail -> plateDetail.getPlateName()).collect(Collectors.toSet());

            Map<String, List<PlateDetail>> eToglMapByDest = jsonModel.getPlatesFromFile().stream().
                    filter(plateDetail -> commonPlateNames.contains(plateDetail.getPlateName())).
                    collect(Collectors.groupingBy(PlateDetail::getDestPlate));

            //Save Wf Data for D Quad entitylabel
            for (Long ePlateWfId : commonPlatesWithWfID.values()) {
                String sampleType = WfUtil.getWfDataVarchar2(gbsConnection, ePlateWfId, 61L);
                if (sampleType != null) {
                    sampleTypeRv = "Bulk".equals(sampleType) || "Legacy".equals(sampleType) ? "Bulk" :
                            ("Chip".equals(sampleType) || "Hap-Chip".equals(sampleType)) ? "CHIP" : sampleTypeRv;
                    break;
                }
            }
            Map<String, List<String>> baseLibraryPlateMap = new HashMap<>();
            for (String libraryPlateReceived : eToglMapByDest.keySet()) {
                //Check if libraryPlateReceived Exists
                Boolean libraryPlateExists = WfUtilCommon.wfExists(gbsConnection, libraryPlateReceived, 5L);
                if(!libraryPlateExists){
                    List<PlateDetail> plateDetailsPerGL = eToglMapByDest.get(libraryPlateReceived);
                    Map<Integer, Map<Long, List<WfGridAssoc>>> gridAssocWithWfIdPerQuad = null;
                    Map<Integer, Map<Long, Map<String, String>>> srcDestPerQuadWithWfIDFromFile = new HashMap<>();
                    boolean isDlPlate = false;

                    if (libraryPlateReceived.startsWith("DL")) {
                        isDlPlate = true;
                        gridAssocWithWfIdPerQuad = LibraryPlateUtil.mapGridAssocWithWfIdPerQuadForDL(gbsConnection, plateDetailsPerGL, commonPlatesWithWfID);

                    } else {
                        Map<Pair<String, String>, List<PlateDetail>> plateDetailPerGlGroupBySrcDstWell = plateDetailsPerGL.stream().collect(Collectors.groupingBy(
                                (p -> Pair.of(p.getSrcWellName(), p.getDstWellName()))));

                        gridAssocWithWfIdPerQuad = LibraryPlateUtil.mapGridAssocWithWfIdPerQuad(gbsConnection, biocellWellMapGroupByDstWell, plateDetailPerGlGroupBySrcDstWell,
                                commonPlatesWithWfID, srcDestPerQuadWithWfIDFromFile);
                    }

                    //Create reference so we can use in the following methods.
                    List<String> oligaPoolWithTimeStamp = new ArrayList<>();
                    //Creating DQuads for Eplates in Library Plate creation
                    Map<Integer, Map<Long, List<WfGridAssoc>>> quadWithDWfIdGridAssocMap = LibraryPlateUtil.createDquadWithAssocs(gbsConnection, libraryPlateReceived, gridAssocWithWfIdPerQuad,
                            srcDestPerQuadWithWfIDFromFile, oligaPoolWithTimeStamp, biocellWellMapGroupByDstWell, biocellWellMapGroupByQuadRowCol, isDlPlate, sampleTypeRv, "BEEHIVE",jsonModel.getLogFileName());
                    //Creating DL/AL for Eplates in Library Creation Recieved
                    LibraryPlateUtil.createGlPlateFromDQuad(gbsConnection, quadWithDWfIdGridAssocMap, biocellWellMapGroupByQuadRowCol, libraryPlateReceived, oligaPoolWithTimeStamp, "BEEHIVE",jsonModel.getLogFileName());

                    LOG.info("Successfully created Library Plate :" + libraryPlateReceived);
                    LOG.info("Updating plate status to database");
                    for (PlateDetail detail : commonPlates) {
                        //Change the status on D plate to "M" only if all samples have an active DL/AL Quadrant
                        List<WfGridAssoc> wfGridAssocList = WfGridUtils.fetchWfGridAssocByWfId(gbsConnection, detail.getWfId());
                        List<HashMap<String, Object>> pivotGridData = WfGridUtils.callStoredProcForPivotGridData(gbsConnection, detail.getWfId(), "17,10170");
                        List<Sample> barcodeGemslist = WfGridUtils.mapPivotGridDataToGemsSample(pivotGridData, "17,10170");
                        long usedBarcodeGemsSize = barcodeGemslist.stream().filter(sample -> sample.getDPlateQuadrant() != null).count();
                        if (usedBarcodeGemsSize == wfGridAssocList.size()) {
                            WfUtil.updateWfStatus(gbsConnection, detail.getWfId(), "M");
                            WfUtil.createWfDataVarchar2(gbsConnection, detail.getWfId(), WF_DATA_CONFIG_ID_PCR_EXT_STATUS, toStatus);
                        }
                    }
                    if(baseLibraryPlateMap.containsKey(libraryPlateReceived.split("-")[0])){
                        List<String> basePlateList = baseLibraryPlateMap.get(libraryPlateReceived.split("-")[0]);
                        basePlateList.add(libraryPlateReceived);
                        baseLibraryPlateMap.put(libraryPlateReceived.split("-")[0],basePlateList);
                    }else{
                        ArrayList<String> basePlateList = new ArrayList<>();
                        basePlateList.add(libraryPlateReceived);
                        baseLibraryPlateMap.put(libraryPlateReceived.split("-")[0],basePlateList);
                    }
                }
            }
            //Create Fake Library Plate -02
            for(String libraryPlate: baseLibraryPlateMap.keySet()){
                List<String> basePlateList = baseLibraryPlateMap.get(libraryPlate);
                if(basePlateList.size()==1){
                    createFakePlateWithQuadrants(basePlateList.get(0), gbsConnection, sampleTypeRv, jsonModel.getLogFileName());
                }
            }
            gbsConnection.commit();
        } catch (Exception e) {
            e.printStackTrace();
            gbsConnection.rollback();
        }
    }


    private void createFakePlateWithQuadrants(String libraryPlateName, Connection gbsConnection, String sampleTypeRv, String logFileName) throws Exception {

        String fakePlate = null;
        int count = 1;

        if (libraryPlateName.contains("-01")) {
            fakePlate = libraryPlateName.replace("-01", "-02");
        }else{
            fakePlate = libraryPlateName.replace("-02", "-01");
        }
        // Check if fakePlate already exists
        Boolean fakePlateWfId= WfUtilCommon.wfExists(gbsConnection, fakePlate, 5L);
        if (!fakePlateWfId) {
            long libraryWfID = WfUtil.getNextSeq(gbsConnection, "ATLAS.WF_ID_SEQ");
            String glOligoPool = WfUtil.getWfDataVarchar2(gbsConnection, WfUtil.getWfId(gbsConnection, libraryPlateName, 5L), WF_DATA_CONFIG_ID_OLIGO_POOL);
            if(logFileName.toUpperCase().contains(GL_PLATE_OUTPUT_FILENAME_ANK.toUpperCase())) {
                //it means its from Ank Chip library plate; and needs to go to the new holding queue. wf_step_config_id =15
                WfUtil.createWf(gbsConnection, libraryWfID, WF_CONFIG_ID, "I", 15L, "BEEHIVE", 5L, fakePlate);
            } else {
                WfUtil.createWf(gbsConnection, libraryWfID, WF_CONFIG_ID, "I", 11L, "BEEHIVE", 5L, fakePlate);
            }
            //SVANT : mark the quadrant as FAKE... 1240L
            WfUtil.createWfDataVarchar2(gbsConnection, libraryWfID, WF_DATA_FAKE_PLATE, "Y");  //47
            WfUtil.createWfDataVarchar2(gbsConnection, libraryWfID, WF_DATA_CONFIG_ID_OLIGO_POOL, glOligoPool);
            WfUtil.createWfDataVarchar2(gbsConnection, libraryWfID, WF_DATA_CONFIG_ID_FINAL_GL_PLATE_IN_SET, fakePlate); //45

            List<Long> dQuadWfIDs = new ArrayList<>();
            while (count <= 4) {
                long newWfID = WfUtil.getNextSeq(gbsConnection, "ATLAS.WF_ID_SEQ");
                int barcodeIndex = getBarcodeIndex(fakePlate, count);
                String dQuadEntityLabel = fakePlate.substring(0, fakePlate.indexOf("-") + 1) + barcodeIndex;
                WfUtil.createWf(gbsConnection, newWfID, WF_CONFIG_ID, "M", 10L, "BEEHIVE", 10199L, dQuadEntityLabel);
                WfUtil.createWfAssoc(gbsConnection, newWfID, libraryWfID, barcodeIndex, dQuadEntityLabel);
                //SVANT : mark the quadrant as FAKE... 1240L
                WfUtil.createWfDataVarchar2(gbsConnection, newWfID, WF_DATA_FAKE_PLATE, "Y");
                WfUtil.createWfDataNumber(gbsConnection, newWfID, WF_DATA_E_BLOCK_INDEX_WITHIN_GL_SET, Integer.valueOf(dQuadEntityLabel.substring(fakePlate.lastIndexOf("-") + 1)));  //47
                WfUtil.createWfDataVarchar2(gbsConnection, newWfID, WF_DATA_CONFIG_ID_DQuad_PLATE_FOR_E, dQuadEntityLabel); //10564
                WfUtil.createWfDataNumber(gbsConnection, newWfID, WF_DATA_CONFIG_ID_GL_PLATE_SET_INDEX, 2); //105
                WfUtil.createWfDataNumber(gbsConnection, newWfID, WF_DATA_CONFIG_ID_GL_PLATE_QUADRANT, count); //106
                WfUtil.createWfDataVarchar2(gbsConnection, newWfID, WF_DATA_CONFIG_ID_GL_PLATE_FOR_E, fakePlate); //107
                WfUtil.createWfDataVarchar2(gbsConnection, newWfID, WF_DATA_CONFIG_ID_OLIGO_POOL, glOligoPool);//7
                WfUtil.createWfDataVarchar2(gbsConnection, newWfID, WF_DATA_CONFIG_ID_TRANSFER_TYPE, fakePlate.substring(0, 2) + "-" + fakePlate.substring(0, 2));
                WfUtil.createWfDataNumber(gbsConnection, newWfID, WF_DATA_CONFIG_ID_SAMPLES_COUNT, 0);//SamplesSize
                WfUtil.createWfDataVarchar2(gbsConnection, newWfID, WF_DATA_SAMPLE_TYPE_ID, sampleTypeRv);//61

                count = count + 1;
            }
        }
    }

    private void dropBlocks(Connection gbsConnection, List<PlateDetail> plateDetailList) throws Exception {

        List<String> wfInStep = WfUtil.wfInStep(gbsConnection, 1L, STEP_RECEIVE_F_BLOCK);
        for (PlateDetail plateDetail : plateDetailList) {
            if (wfInStep.contains(plateDetail.getPlateName())) {
                Long receiveFBlockWfId = WfUtil.getWfIdAtStep(gbsConnection, plateDetail.getPlateName(), ENTITY_F_BLOCK, STEP_RECEIVE_F_BLOCK);
                if (null != receiveFBlockWfId) {
                    WfUtil.updateWfStepAndStatus(gbsConnection, receiveFBlockWfId, STEP_RECEIVE_F_BLOCK, "M");
                    WfUtil.createWfDataVarchar2(gbsConnection, receiveFBlockWfId, 420L, "HIVE");
                }
                Long cleanUpFBlockWfId = WfUtil.getWfIdAtStep(gbsConnection, plateDetail.getPlateName(), ENTITY_F_BLOCK, STEP_READY_FOR_CLEANUP);

                if (null != cleanUpFBlockWfId) {
                    WfUtil.updateWfStepAndStatus(gbsConnection, cleanUpFBlockWfId, STEP_READY_FOR_CLEANUP, "C");
                }
            }
        }
    }

    public void extractDataForDropSenseConc(Connection gbsConnection, List<PlateDetail> commonPlates) throws Exception {

        System.out.println("Extracting Data from Drop Sense");

        List<WfGridBase> wfGridBaseList = new ArrayList();

        for (PlateDetail plateDetail : commonPlates) {
            String plateName = plateDetail.getPlateName();
            List<WfWellMap> wellDetail = plateDetail.getWellDetail();
            long i = 0;
            Long wfId = null;
            try {
                wfId = WfUtil.getWfIdAtStep(gbsConnection, plateName, ENTITY_DROPSENSE_PLATE, STEP_DROP_SENSE_FAKE_STEP, "M");
            } catch (Exception e) {

            }
            if (null == wfId) {
                wfId = WfUtil.getNextSeq(gbsConnection, "ATLAS.wf_id_seq");
                System.out.println("Inserting WF for WF ID:" + wfId + " with sample size :" + wellDetail.size());

                WfUtil.createWf(gbsConnection, wfId, WF_CONFIG_ID, "M", STEP_DROP_SENSE_FAKE_STEP,
                        "ATLAS", ENTITY_DROPSENSE_PLATE, plateName);
                //WfUtil.createWfStep(gbsConnection, wfId, 80L, "I");

                for (WfWellMap wfGridData : wellDetail) {
                    try {
                        i++;
                        String sourceWellName = wfGridData.getSourceWellName();

                        String r[] = splitStringToPositionArray(sourceWellName);
                        int row = getNumberForLetter(r[0]);
                        int col = Integer.valueOf(r[1]);
                        WfGridBase wfGridBase = new WfGridBase(gbsConnection, plateName, i, WF_CONFIG_ID, wfId);
                        WfGridAssoc wfGridAssoc = new WfGridAssoc(wfGridBase.getWfGridId(), wfId, row, col, sourceWellName, WF_CONFIG_ID, "A");
                        List<WfGridData> gridDataList = new ArrayList();
                        gridDataList.add(new WfGridData(wfGridBase.getWfGridId(), WF_GRID_CONFIG_ID_DROPSENSE_SAMPLE_CONC, wfId, new BigDecimal(wfGridData.getConc())));

                        wfGridBase.setWfGridAssoc(wfGridAssoc);
                        wfGridBase.setWfGridDataList(gridDataList);
                        wfGridBaseList.add(wfGridBase);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            plateDetail.setWfId(wfId);
        }

        System.out.println("Inserting Grid Data. Sample Size :" + wfGridBaseList.size());
        if (null != wfGridBaseList && !wfGridBaseList.isEmpty()) {
            WfGridUtils.insertGridAll(gbsConnection, wfGridBaseList);
        }

    }

    /**
     * update rank, crop and priority for each plate
     * 1-      sort the blocks ascending based on the ranks being submitted by Partner Success Team, highest priority has rank 1, (Katie?s team)
     * 2-      if multiple blocks have similar ranks (including NAs) sort based on Days_In_Lab (descending)
     * 3-      if multiple blocks have similar ranks and Days_in_Lab, sort based on the Days_In_Queue (descending, older blocks first)
     * 4-      (This might not be applicable for Bumblebee) but If multiple blocks get into one (as in GL, PCR, Pooled_Tube) the aggregated block has the priority of the highest priority eblock.
     * <p>
     * Q1) When do you decide the priority-when it is created as F or in Extraction Complete?
     *
     * @param commonPlates
     */
    public void updatePriority(List<PlateDetail> commonPlates) {

        //Collections.sort(commonPlates);
        commonPlates.sort(Comparator.comparing(PlateDetail::getCropType).
                thenComparing(PlateDetail::getPriority).
                thenComparing(PlateDetail::getDaysInLab).
                thenComparing(PlateDetail::getDaysInQueue).reversed());
    }

    /**
     * To get list of Eplates from ExtractionComplete Queue with given status
     *
     * @param gbsConnection
     * @param wfConfigId
     * @param wfStepConfigId
     * @param wfStatus
     * @param defaultTransferVolume
     * @param defaultDestWell
     * @return
     * @throws Exception
     */
    public List<PlateDetail> getEPlatesFromQueue(Connection gbsConnection, Long wfConfigId, Long wfStepConfigId, String wfStatus,
                                                 String defaultTransferVolume, String defaultDestWell) throws
            Exception {

        //TODO - update SchedulingAgent query to get crop name and Sampel Verification time as well
        final String SQL = "select wf.WF_ID,wf.WF_ENTITY_LABEL E_PLATE, \n" +
                "        wd.WF_DATA_VARCHAR2 TEAM_NAME, wd3.wf_data_number PRIORITY," +
                "        coalesce(wd1.WF_DATA_VARCHAR2,'Soy') CROP_TYPE,\n" +
                "        --wf2.CREATE_TS F_PLATE_CREATION, date_trunc('DAY', wf2.CREATE_TS) F_PLATE_ARRIVED_TIME, \n" +
                "        case \n" +
                "                when wd.WF_DATA_VARCHAR2='GWS' then coalesce(DATE_PART('day',(now()- wf2.CREATE_TS)),0) \n" +
                "                else coalesce(DATE_PART('day',(now()- wd4.WF_DATA_TIMESTAMP)),0) \n" +
                "        end DAYS_IN_LAB,\n" +
                "        --wf.CREATE_TS E_PLATE_CREATION, date_trunc('DAY', wf.CREATE_TS) E_PLATE_ARRIVED_TIME, \n" +
                "        DATE_PART('day',(now()- wf.CREATE_TS)) DAYS_IN_QUEUE\n" +
                "from ATLAS.WF wf \n" +
                "LEFT OUTER JOIN ATLAS.WF_DATA WD ON wf.WF_ID=wd.WF_ID and wd.WF_DATA_CONFIG_ID=62 \n" +
                "LEFT OUTER JOIN ATLAS.WF_DATA wd1 ON wf.WF_ID=wd1.WF_ID and wd1.WF_DATA_CONFIG_ID=60 \n" +
                "LEFT OUTER JOIN ATLAS.WF_DATA wd2 ON wf.WF_ID=wd2.WF_ID and wd2.WF_DATA_CONFIG_ID=158 \n" +
                "LEFT OUTER JOIN ATLAS.WF_DATA wd3 ON wf.WF_ID=wd3.WF_ID and wd3.WF_DATA_CONFIG_ID=10100 \n" +
                "LEFT OUTER JOIN ATLAS.WF_DATA wd4 ON wf.WF_ID=wd4.WF_ID and wd4.WF_DATA_CONFIG_ID=10101 \n" +
                "LEFT OUTER JOIN ATLAS.WF_ASSOC wa ON wa.TO_WF_ID=wd.WF_ID \n" +
                "LEFT OUTER JOIN ATLAS.WF wf1 ON wf1.WF_ID=wa.FROM_WF_ID \n" +
                "LEFT OUTER JOIN ATLAS.WF wf2 ON wf2.WF_ENTITY_LABEL=wf1.WF_ENTITY_LABEL AND wf2.WF_STATUS IN ('I','M') and wf2.WF_STEP_CONFIG_ID=34\n" +
                "where wf.WF_CONFIG_ID=? and wf.WF_STATUS IN ('I') and wf.WF_STEP_CONFIG_ID=? AND wd2.wf_data_varchar2=? ";

        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<PlateDetail> plateDetailList = new ArrayList<PlateDetail>();
        try {
            pstmt = gbsConnection.prepareStatement(SQL);
            pstmt.setLong(1, wfConfigId);
            pstmt.setLong(2, wfStepConfigId);
            pstmt.setString(3, wfStatus);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                PlateDetail detail = new PlateDetail();
                detail.setPlateName(rs.getString("E_PLATE"));
                detail.setWfId(rs.getLong("WF_ID"));
                detail.setCropType(rs.getString("CROP_TYPE"));
                detail.setDaysInLab(rs.getLong("DAYS_IN_LAB"));
                detail.setDaysInQueue(rs.getLong("DAYS_IN_QUEUE"));
                detail.setPriority(String.valueOf(rs.getInt("PRIORITY")));
                detail.setTransferVolume(defaultTransferVolume);
                detail.setDstWellName(defaultDestWell);
                plateDetailList.add(detail);
            }
        } finally {
            Util.freeResource(rs);
            Util.freeResource(pstmt);
        }
        return plateDetailList;
    }


    /**
     * Getting List of Common E plates from Inventory text file & ExtractionComplete queue
     *
     * @param jsonModel
     * @param platesListFromQ
     * @param ePlateWfIdMap
     * @return
     */
    public List<PlateDetail> compareAndGetCommonPlates(JsonModel jsonModel, List<PlateDetail> platesListFromQ, Map<String, Long> ePlateWfIdMap) {
        List<PlateDetail> commonPlates = new ArrayList<>();
        List<PlateDetail> platesFromFile = jsonModel.getPlatesFromFile();

        for (PlateDetail detail : platesListFromQ) {
            Optional<PlateDetail> optionalPlateDetail = platesFromFile.stream().filter(o -> o.getPlateName().equals(detail.getPlateName())).findFirst();
            if (optionalPlateDetail.isPresent()) {
                PlateDetail plateDetail = optionalPlateDetail.get();
                detail.setDestPlate(plateDetail.getDestPlate());
                detail.setGlPlateSetIndex(plateDetail.getGlPlateSetIndex());
                detail.setQuadrant(plateDetail.getQuadrant());
                commonPlates.add(detail);
                ePlateWfIdMap.put(detail.getPlateName(), detail.getWfId());
            }
        }
        return commonPlates;
    }

    /**
     * Load plates list from "Inventory.txt" from below file
     * Inventory List:
     * E17GSY_MG0200001
     * E17G2B_MG0120004E17GSY_MG0200001
     * E17G34_MG0190001
     * E17G2B_MG0120001
     * E17GSY_MG0210004
     * E17G2B_MG0120005
     * E17G90_MG0540006
     * F17G34_MG0190006
     *
     * @param parsedMessage
     * @return
     */
    public List<PlateDetail> loadInventoryPlateList(List<String[]> parsedMessage) {
        List<PlateDetail> ePlatesListfromFile = new ArrayList<>();
        for (String[] line : parsedMessage) {
            PlateDetail plateDetail = new PlateDetail();
            //System.out.println (line[0]);
            if (!line[0].trim().equalsIgnoreCase("Barcode") && !line[0].isEmpty()) {
                plateDetail.setPlateName(line[0]);
                ePlatesListfromFile.add(plateDetail);
            }
        }
        return ePlatesListfromFile;
    }

    public List<PlateDetail> loadDropBlockPlateList(List<String[]> parsedMessage) {
        List<PlateDetail> fPlatesListfromFile = new ArrayList<>();
        for (String[] line : parsedMessage) {
            PlateDetail plateDetail = new PlateDetail();
            //System.out.println (line[0]);
            if (!line[0].trim().equalsIgnoreCase("Barcode") && !line[0].isEmpty()) {
                plateDetail.setPlateName(line[0]);
                fPlatesListfromFile.add(plateDetail);
            }
        }
        return fPlatesListfromFile;
    }

    /**
     * Load plates list from "DropSense Output.csv" from below file
     * VWorks produces tab-separated text files.  line 1 are the column headers.
     * line 2 is an example of what one would see during the stamping to DropSense plates.
     * <p>
     * ---- IGNORE EVERYTHING ABOVE THIS LINE ----
     * Timestamp	Class	Session ID	Volume	Aspirate Location	Aspirate Selection	Dispense Location	Dispense Selection	Description	FileName
     * 8/1/2017 9:02:00 AM	Transfer	1	2	ABC123	Entire plate	DS-001	Entire plate		Protocol File
     *
     * @param parsedMessage
     * @return
     */
    public List<PlateDetail> loadDropSensePlateList(List<String[]> parsedMessage) {
        List<PlateDetail> ePlatesListfromFile = new ArrayList<>();
        for (String[] row : parsedMessage) {
            PlateDetail plateDetail = new PlateDetail();
            Boolean isDetailRow = isDetailRow(row);
            if (isDetailRow) {
                plateDetail.setPlateName(row[4].split("[\\(\\)]")[1]);
                plateDetail.setDestPlate(row[6].split("[\\(\\)]")[1]);
                ePlatesListfromFile.add(plateDetail);
            }
        }
        return ePlatesListfromFile;
    }

    /**
     * DropPlate ID,DropPlate Position,Pump,Sample name,A260 Concentration (ng/ul),A260 (10mm),A280 (10mm),A260/A280
     * 104758E2O10362,A1,2,blank,-,-,-,-
     * 104758E2O10362,B1,2,sample1,-,-,-,-
     * 104758E2O10362,C1,2,sample2,-,-,-,-
     * 104758E2O10362,D1,2,sample3,-,-,-,-
     * 104758E2O10362,E1,2,sample4,-,-,-,-
     * 104758E2O10362,F1,2,sample5,-,-,-,-
     *
     * @param parsedMessage
     * @return
     */
    public List<PlateDetail> loadDropSenseOutputFile(List<String[]> parsedMessage) {

        List<PlateDetail> ePlatesListfromFile = new ArrayList<>();
        PlateDetail plateDetail = new PlateDetail();
        List<WfWellMap> wellMap = new ArrayList<>();
        for (String[] row : parsedMessage) {
            WfWellMap plateWellDetail = new WfWellMap();
            Boolean isDetailRow = isDetailRow(row);
            if (isDetailRow) {
                try {
                    plateWellDetail.setPlateId(row[0]);
                    plateWellDetail.setSourceWellName(row[1]);
                    plateWellDetail.setConc(row[4]);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                wellMap.add(plateWellDetail);
            }
        }
        plateDetail.setWellDetail(wellMap);
        plateDetail.setPlateName(wellMap.get(0).getPlateId());
        ePlatesListfromFile.add(plateDetail);
        return ePlatesListfromFile;
    }

    /**
     * Load plates list from "Normalization Output.csv" from below file
     * VWorks produces tab-separated text files.  line 1 is the column headers.
     * line 2 is an example of what one would see during the normalization process when diluent is added to wells to normalize the plate.
     * <p>
     * ---- IGNORE EVERYTHING ABOVE THIS LINE ----
     * Timestamp	Class	Session ID	Volume	Aspirate Location	Aspirate Selection	Dispense Location	Dispense Selection	Description	FileName
     * 8/1/2017 9:03:00 AM	Transfer	1	10	Diluent	A1	ABC123	A4		Protocol File
     *
     * @param parsedMessage
     * @return
     */
    public List<PlateDetail> loadNormalizationPlateList(List<String[]> parsedMessage) {
        List<PlateDetail> ePlatesListfromFile = new ArrayList<>();
        for (String[] row : parsedMessage) {
            PlateDetail plateDetail = new PlateDetail();
            Boolean isDetailRow = isDetailRow(row);
            if (isDetailRow) {
                plateDetail.setPlateName(row[6].split("[\\(\\)]")[1]);
                plateDetail.setDstWellName(row[7]);
                plateDetail.setTransferVolume(row[3]);
                ePlatesListfromFile.add(plateDetail);
            }
        }
        return ePlatesListfromFile;
    }

    /**
     * Load plates list from "GL_Plate_Creation_Output.csv" from below file
     * VWorks produces tab-separated text files.  line 1 is the column headers.
     * line 2 is an example of what one would see during daughter stamping
     * <p>
     * ---- IGNORE EVERYTHING ABOVE THIS LINE ----
     * Timestamp	Class	Session ID	Volume	Aspirate Location	Aspirate Selection	Dispense Location	Dispense Selection	Description	FileName
     * 8/1/2017 9:02:00 AM	Transfer	1	2	ABC123	Entire plate	Daughter0	A1 Quadrant		Protocol File
     *
     * @param parsedMessage
     * @return
     */
    //TODO: Build the jsonModel.setPlatesFromFile(platesListfromFile);  from our json...build the list for Ank Bee...

    public List<PlateDetail> loadGlPlateCreationPlateList(List<String[]> parsedMessage) {
        List<PlateDetail> ePlatesListfromFile = new ArrayList<>();
        for (String[] row : parsedMessage) {
            PlateDetail plateDetail = new PlateDetail();
            if (isDetailRow(row)) {
                plateDetail.setPlateName(row[4].split("[\\(\\)]")[1]);
                plateDetail.setSrcWellName(row[5]);
                plateDetail.setDstWellName(row[7]);
                plateDetail.setTransferVolume(row[3]);
                plateDetail.setDestPlate(row[6].split("[\\(\\)]")[1]);
                plateDetail.setGlPlateSetIndex(row[6].split("[\\(\\)]")[0].split(" ")[1]);
                plateDetail.setQuadrant(row[4].split("[\\(\\)]")[0].split(" ")[1]);
                //ProjectType
                // plateDetail.setProjectType(row[8]);
                ePlatesListfromFile.add(plateDetail);
            }
        }
        return ePlatesListfromFile;
    }


    public List<PlateDetail> loadGlPlateCreationPlateListFromAnkBee(AnkBeeRearrayResponse ankBee) {
        List<PlateDetail> ePlatesListfromFile = new ArrayList<>();
        PlateDetail plateDetail = new PlateDetail();
        for(AnkBeeRearrayResponse.DestinationContainers container : ankBee.getDestinationContainers()) {

            for(AnkBeeRearrayResponse.DestinationContainers.DestinationPartitions partition : container.getDestinationPartitions()) {

                plateDetail = new PlateDetail();
                plateDetail.setPlateName(partition.getSourceContainerName());
                plateDetail.setDestPlate(container.getDestinationContainerName());
                plateDetail.setSrcWellName(partition.getSourceRow()+String.format("%02d",Integer.valueOf(partition.getSourceColumn())));
                plateDetail.setDstWellName(partition.getRow()+String.format("%02d",Integer.valueOf(partition.getColumn())));
                //TODO: Need to figure out the GLPlateSetIndex and quadrant based on the info..
                //plateDetail.setTransferVolume(row[3]);
                //plateDetail.setGlPlateSetIndex(row[6].split("[\\(\\)]")[0].split(" ")[1]);
                //plateDetail.setQuadrant(row[4].split("[\\(\\)]")[0].split(" ")[1]);
                ePlatesListfromFile.add(plateDetail);
            }
        }
        return ePlatesListfromFile;

    }



    /**
     * Load plates list from "GL_Plate_Creation_Output.csv" from below file
     * VWorks produces tab-separated text files.  line 1 is the column headers.
     * line 2 is an example of what one would see during daughter stamping
     * <p>
     * ---- IGNORE EVERYTHING ABOVE THIS LINE ----
     * Timestamp	Class	Session ID	Volume	Aspirate Location	Aspirate Selection	Dispense Location	Dispense Selection	Description	FileName
     * 8/1/2017 9:02:00 AM	Transfer	1	2	ABC123	Entire plate	Daughter0	A1 Quadrant		Protocol File
     *
     * @param parsedMessage
     * @return
     */
    public List<PlateDetail> loadGlPlateCreationFileFromAnk(List<String[]> parsedMessage) {
        List<PlateDetail> ePlatesListfromFile = new ArrayList<>();
        for (String[] row : parsedMessage) {
            PlateDetail plateDetail = new PlateDetail();
            if (isDetailRow(row)) {
                plateDetail.setPlateName(row[0]);
                plateDetail.setSrcWellName(row[1]);
                plateDetail.setDestPlate(row[2]);
                plateDetail.setDstWellName(row[3]);
                plateDetail.setTransferVolume(row[4]);
                plateDetail.setGlPlateSetIndex(row[2].split("-")[1]);
                //plateDetail.setQuadrant(row[4].split("[\\(\\)]")[0].split(" ")[1]);
                //ProjectType
                // plateDetail.setProjectType(row[8]);
                ePlatesListfromFile.add(plateDetail);
            }
        }
        return ePlatesListfromFile;
    }

    public boolean isDetailRow(String[] row) {
        return !row[0].startsWith("VWorks produces tab-separated text files.  line 1 is the column headers.") &&
                !row[0].startsWith("VWorks produces tab-separated text files.  line 1 are the column headers.") &&
                !row[0].startsWith("line 2 is an example of what one would see during the stamping to DropSense plates.") &&
                !row[0].startsWith("line 2 is an example of what one would see during the normalization process when diluent is added to wells to normalize the plate.") &&
                !row[0].startsWith("line 2 is an example of what one would see during daughter stamping") &&
                !row[0].trim().startsWith("---- IGNORE EVERYTHING ABOVE THIS LINE ----") &&
                !row[0].startsWith("Timestamp") &&
                !row[0].startsWith("DropPlate ID") &&
                !row[0].isEmpty();
    }

}
