package com.monsanto.aws.json;

import com.monsanto.aws.pojo.*;
import com.monsanto.gwg.atlas.agent.common.model.PlateDetail;

import java.util.List;
import java.util.Map;

/**
 * Created by ASHAR7 on 4/22/2016.
 */
public class JsonModel {

  private String agentName;
  private String parsedAgentName;
  private Map<String, VWorksRun> vWorkdsEtoGL;
  private List<List<VWorksRunLogAssoc>> vWorksFtoE;
  private Map<String, VWorksRun> vWorksEtoPcr;
  private Map<Integer, Double> qpcr;
  private Map<String, Double> qpcrLC;
  private Map<Integer, ClicDetail> clic;
  private List<RogueDetail> rogue;
  private Map<Integer, ShawDetail> shawDetails;
  private PicoDetail picoDetail;
  private String logFileName;
  //CLicAgent
  private String instrumentId;
  private boolean nineTenRun;
  private String glBarcodeBase;
  private String runName;

  //RogueAgent
  private String systemName;
  private String userId;

  //qpcrAgent
  private String experimentName;
  private String instrumentName;
  private Map<String, Double> rawQuantsMap;

  //BeeHiveAgent
  private List<PlateDetail> platesFromFile;


  public String getAgentName() {
    return agentName;
  }

  public void setAgentName(String agentName) {
    this.agentName = agentName;
  }

  public String getParsedAgentName() {
    return parsedAgentName;
  }

  public void setParsedAgentName(String parsedAgentName) {
    this.parsedAgentName = parsedAgentName;
  }

  public Map<String, VWorksRun> getvWorkdsEtoGL() {
    return vWorkdsEtoGL;
  }

  public void setvWorkdsEtoGL(Map<String, VWorksRun> vWorkdsEtoGL) {
    this.vWorkdsEtoGL = vWorkdsEtoGL;
  }

  public Map<String, VWorksRun> getvWorksEtoPcr() {
    return vWorksEtoPcr;
  }

  public void setvWorksEtoPcr(Map<String, VWorksRun> vWorksEtoPcr) {
    this.vWorksEtoPcr = vWorksEtoPcr;
  }

  public List<List<VWorksRunLogAssoc>> getvWorksFtoE() {
    return vWorksFtoE;
  }

  public void setvWorksFtoE(List<List<VWorksRunLogAssoc>> vWorksFtoE) {
    this.vWorksFtoE = vWorksFtoE;
  }

  public Map<Integer, Double> getQpcr() {
    return qpcr;
  }

  public void setQpcr(Map<Integer, Double> qpcr) {
    this.qpcr = qpcr;
  }

  public Map<String, Double> getQpcrLC() {
    return qpcrLC;
  }

  public void setQpcrLC(Map<String, Double> qpcrLC) {
    this.qpcrLC = qpcrLC;
  }

  public Map<Integer, ClicDetail> getClic() {
    return clic;
  }

  public void setClic(Map<Integer, ClicDetail> clic) {
    this.clic = clic;
  }

  public Map<Integer, ShawDetail> getShawDetails() {
    return shawDetails;
  }

  public void setShawDetails(Map<Integer, ShawDetail> shawDetails) {
    this.shawDetails = shawDetails;
  }

  public PicoDetail getPicoDetail() {
    return picoDetail;
  }

  public void setPicoDetail(PicoDetail picoDetail) {
    this.picoDetail = picoDetail;
  }

  public String getInstrumentId() {
    return instrumentId;
  }

  public void setInstrumentId(String instrumentId) {
    this.instrumentId = instrumentId;
  }

  public boolean isNineTenRun() {
    return nineTenRun;
  }

  public void setNineTenRun(boolean nineTenRun) {
    this.nineTenRun = nineTenRun;
  }

  public String getGlBarcodeBase() {
    return glBarcodeBase;
  }

  public void setGlBarcodeBase(String glBarcodeBase) {
    this.glBarcodeBase = glBarcodeBase;
  }

  public String getRunName() {
    return runName;
  }

  public void setRunName(String runName) {
    this.runName = runName;
  }

  public String getExperimentName() {
    return experimentName;
  }

  public void setExperimentName(String experimentName) {
    this.experimentName = experimentName;
  }

  public String getInstrumentName() {
    return instrumentName;
  }

  public void setInstrumentName(String instrumentName) {
    this.instrumentName = instrumentName;
  }

  public Map<String, Double> getRawQuantsMap() {
    return rawQuantsMap;
  }

  public void setRawQuantsMap(Map<String, Double> rawQuantsMap) {
    this.rawQuantsMap = rawQuantsMap;
  }

  public boolean isEmptyOrNull(){

    boolean isEmptyOrNull = false;
    if((null == vWorkdsEtoGL || vWorkdsEtoGL.isEmpty())
            && (null == vWorksFtoE || vWorksFtoE.isEmpty())
            && (null == qpcr || qpcr.isEmpty())
            && (null == clic || clic.isEmpty())){

      isEmptyOrNull = true;
    }
    return isEmptyOrNull;
  }

  public List<RogueDetail> getRogue() {
    return rogue;
  }

  public void setRogue(List<RogueDetail> rogue) {
    this.rogue = rogue;
  }

  public String getSystemName() {
    return systemName;
  }

  public void setSystemName(String systemName) {
    this.systemName = systemName;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public List<PlateDetail> getPlatesFromFile() {
    return platesFromFile;
  }

  public void setPlatesFromFile(List<PlateDetail> platesFromFile) {
    this.platesFromFile = platesFromFile;
  }

  public String getLogFileName() {
    return logFileName;
  }

  public void setLogFileName(String logFileName) {
    this.logFileName = logFileName;
  }
}
