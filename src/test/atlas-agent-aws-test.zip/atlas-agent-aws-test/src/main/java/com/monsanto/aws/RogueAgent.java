package com.monsanto.aws;

import com.monsanto.aws.util.VWorksUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.monsanto.aws.json.JsonModel;
import com.monsanto.aws.pojo.RogueDetail;
import com.monsanto.aws.pojo.CloudWatchMessage;
import com.monsanto.aws.util.DbConnectionUtil;
import com.monsanto.aws.util.Util;
import java.util.*;



/**
 * Created by SINJA on 1/15/2018.
 */
public class RogueAgent extends VWorksUtils {
    //private static final Logger LOG = Logger.getLogger(RogueAgent.class);
    private static final Logger LOG = LoggerFactory.getLogger(RogueAgent.class);
    private static final String SYSTEM_NAME = "System Name";
    private static final String RUN_ID = "RunID";
    private static final String USER_ID = "UserID";

    public static String findAdjacent(List<String[]> csvContents, String key, int keyColumn, int valColumn, int occurrence) {
        int occurrenceFound = 0;
        for (String[] row: csvContents) {
            if (row.length>=keyColumn) {
                if (key.equals(row[keyColumn-1])) {
                    if (++occurrenceFound==occurrence) {
                        if (row.length>=valColumn) {
                            return row[valColumn-1];
                        }
                    }
                }
            }
        }
        return null;
    }

    public JsonModel processMessage(LambdaLogger logger, CloudWatchMessage message) {
        logger.log("Start processing Message.key:" + message.getKey());

        JsonModel jsonModel = new JsonModel();
        List<String[]> rogueCsv = message.getParsedMessage();
        try {
            jsonModel = getRogueDetailMap(rogueCsv);
            jsonModel.setLogFileName(message.getKey());
            logger.log("Successfully completed parsing. Fetched:"+jsonModel.getRogue().size());
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            processData(jsonModel);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonModel;
    }

    public JsonModel getRogueDetailMap(List<String[]> rogueCsv) throws Exception {
        List< RogueDetail> rogueDetailList = new ArrayList<RogueDetail>();
        JsonModel jsonModel = new JsonModel();

        for (int i = 3; i < rogueCsv.size(); i++) { // GLs start from 3rd row
            String[] row = rogueCsv.get(i);
            for (int j = i + 1; j < rogueCsv.size(); j++) {
                // check is it complete?
                String[] completeRow = rogueCsv.get(j);
                if (completeRow[0].equals("COMPLETE")) {
                    // It is complete
                    RogueDetail rogueDetail = new RogueDetail();
                    rogueDetail.setGlPlateNumber(row[0]);
                    rogueDetail.setCleanTubeId(row[1]);
                    rogueDetail.setBarcodePlate(row[2]);
                    //DSA-15897-- Validate/ Modify Clean tube ID's missing leading zeros
                    checkAndUpdateCLeanTubeId(rogueDetail);
                    rogueDetailList.add(rogueDetail);
                }
            }
        }

        jsonModel.setSystemName(getSystemName(rogueCsv));
        jsonModel.setUserId(getUserId(rogueCsv));
        jsonModel.setRunName(getRunId(rogueCsv));
        jsonModel.setNineTenRun(false);
        jsonModel.setRogue(rogueDetailList);
        return jsonModel;


    }

    public void processData(JsonModel jsonModel) throws Exception {

        Connection gbsConnection = DbConnectionUtil.getGBSConnection();
        gbsConnection.setAutoCommit(false);
        int countProcessed = 0;
        //pull the list of GL plates in process
        Map<String, Long> glPlateWfMap = getGlPlateWfMap(gbsConnection);

        try {
            for (String glPlateBarcodeBase : glPlateWfMap.keySet()) {
                try {
                    Map<Integer, RogueDetail> rogueDetailMap = new LinkedHashMap<Integer, RogueDetail>();
                    int glPlateCount = 0;
                    boolean foundGlPlateBarcodeBase = false;

                    for (RogueDetail rogueDetail:jsonModel.getRogue()) {
                        if(rogueDetail.getGlPlateNumber().contains(glPlateBarcodeBase)){
                            foundGlPlateBarcodeBase = true;
                            rogueDetailMap.put(++glPlateCount, rogueDetail);
                        }

                    }

                    if (foundGlPlateBarcodeBase && (rogueDetailMap.size() == 8)) {
                        processRogueDetailMap(gbsConnection, jsonModel.getSystemName(), jsonModel.getUserId(), jsonModel.getRunName(), glPlateBarcodeBase, rogueDetailMap, jsonModel.getLogFileName());
                        countProcessed++;
                        //move forward qPCR blocks
                        //SVANT:
                        //passReceived(gbsConnection);
                        // gbsConnection.commit();
                    } else if (foundGlPlateBarcodeBase && (rogueDetailMap.size() == 0)) {
                        LOG.error("Incomplete Run on GL Set :" + glPlateBarcodeBase);
                    } else if (foundGlPlateBarcodeBase && (rogueDetailMap.size() != 8)) {
                        LOG.error("Failed Run on GL Set :" + glPlateBarcodeBase + " . Please check the log file.");
                    }

                } catch (Exception ex) {
                    gbsConnection.rollback();
                    LOG.error("Failed while processing..");
                    throw ex;
                }

            }
            try{
                gbsConnection.commit();
            } catch (Exception ex) {
                gbsConnection.rollback();
                LOG.error("Failed while updating data ..");
                throw ex;
            }
        }
        finally {
            Util.freeResource(gbsConnection);
        }

    }

    public static void checkAndUpdateCLeanTubeId(RogueDetail rogueDetail) {

            if(rogueDetail.getBarcodePlate().substring(0, 10) .equals("GL-BCAP-01") ){
                rogueDetail.setCleanTubeId(rogueDetail.getCleanTubeId().startsWith("0") ? rogueDetail.getCleanTubeId() :  "0"+rogueDetail.getCleanTubeId());
            }

            if(rogueDetail.getBarcodePlate().substring(0, 10) .equals("GL-BCAP-02") ){
                rogueDetail.setCleanTubeId(rogueDetail.getCleanTubeId().startsWith("0") ? rogueDetail.getCleanTubeId() :  "0"+rogueDetail.getCleanTubeId());
            }

            if(rogueDetail.getBarcodePlate().substring(0, 10) .equals("GL-BCAP-03") ){
                rogueDetail.setCleanTubeId(!rogueDetail.getCleanTubeId().startsWith("9") ? rogueDetail.getCleanTubeId() :  "0"+rogueDetail.getCleanTubeId());
            }

    }

    private boolean isValidBarCodeFormat(RogueDetail rogueDetail,List<String[]> rogueCsv) {
        boolean isValidBarCodeFormat = true;
        if((rogueDetail.getGlPlateNumber().substring((rogueDetail.getGlPlateNumber().length())-3)).equals("-01") ){
            if(!rogueDetail.getBarcodePlate().substring(0, 10) .equals("GL-BCAP-01") ){
                isValidBarCodeFormat = false;
                //log error
                LOG.error("Failed while processing:" + getRunId(rogueCsv) + ".csv log file. The Barcode Plate  should have the format: GL-BCAP-01-xxxx. Found " + rogueDetail.getBarcodePlate() + " for GL Plate: "+ rogueDetail.getGlPlateNumber()+" .");
            }

        }

        if((rogueDetail.getGlPlateNumber().substring((rogueDetail.getGlPlateNumber().length())-3)).equals("-02") ){
            if(!rogueDetail.getBarcodePlate().substring(0, 10) .equals("GL-BCAP-02") ){
                isValidBarCodeFormat = false;
                //log error
                LOG.error("Failed while processing:" + getRunId(rogueCsv) + ".csv log file. The Barcode Plate  should have the format: GL-BCAP-02-xxxx. Found " + rogueDetail.getBarcodePlate() + " for GL Plate: "+ rogueDetail.getGlPlateNumber()+" .");
            }

        }

        return isValidBarCodeFormat;
    }


    private String getSystemName(List<String[]> rogueCsv) {
        return findAdjacent(rogueCsv, SYSTEM_NAME, 1, 2, 1);
    }

    private String getUserId(List<String[]> barcodeCsv) {

        return findAdjacent(barcodeCsv, USER_ID, 1, 2, 1);
    }


    private String getRunId(List<String[]> rogueCsv) {

        return findAdjacent(rogueCsv, RUN_ID, 1, 2, 1);
    }

}

