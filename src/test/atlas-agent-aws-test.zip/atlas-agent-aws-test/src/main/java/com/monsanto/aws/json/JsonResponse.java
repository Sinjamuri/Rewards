package com.monsanto.aws.json;

/**
 * Created by ASHAR7 on 4/22/2016.
 */
public class JsonResponse {
  // example json:  {"errorCode":"","jobID":"0012002-150330180657059-oozie-oozi-W"}

  private String errorCode;
  private String jobID;
  private String status;

  public String getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public String getJobID() {
    return jobID;
  }

  public void setJobID(String jobID) {
    this.jobID = jobID;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }
}
